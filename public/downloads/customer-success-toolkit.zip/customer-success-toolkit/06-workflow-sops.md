# 06 — Workflow SOPs

*5 complete systems for your most time-intensive CSM tasks — powered by AI*

---

> **How to use this file:** Each SOP is a repeatable, step-by-step process. Follow the steps in order, use the referenced prompt files at each stage, and replace the example inputs with your own context. The goal isn't just to use AI — it's to have a *system* that produces consistent, professional output every time.

---

## SOP A: Run a High-Impact QBR in Under 2 Hours of Prep

**What this produces:** A complete QBR deck narrative, talking points, and follow-up email  
**When to run it:** 3-5 days before every Quarterly Business Review  
**Time commitment:** 90 minutes (vs. 4-6 hours without AI)  
**Prompt files:** `03-retention-health-prompts.md`, `05-stakeholder-reporting-prompts.md`

---

### The QBR Prep System

**Before you start (20 minutes): Pull your data**

Gather from your CS platform (Gainsight, Totango, ChurnZero, etc.):
- [ ] Health score trend (last 90 days)
- [ ] Feature adoption data (which modules active vs. inactive)
- [ ] Support ticket volume and themes
- [ ] NPS or CSAT score (if available)
- [ ] Renewal date and commercial terms
- [ ] Any open escalations or commitments

---

**Step 1 — Champion prep document (15 minutes)**

Use **QBR Prep Summary for Customer Champion** from `05-stakeholder-reporting-prompts.md`.

Fill in:
- QBR attendees and their roles
- Key metrics you're planning to present
- The 2 questions you'll need their input on
- The expansion topic you want to preview (if applicable)

Send 3-4 days before the QBR. This ensures your champion walks in aligned, not surprised.

---

**Step 2 — Build the QBR narrative (30 minutes)**

Use **Executive Business Review (EBR) Deck Narrative** from `05-stakeholder-reporting-prompts.md`.

Key inputs to have ready:
- Goals set at last QBR vs. what actually happened
- Your 3 strongest metrics from the period
- The 1 area where you fell short (be honest — execs respect it)
- The roadmap item most relevant to their stated priorities
- Your proposed goals for next quarter

**Pro tip:** Fill in the "goals not achieved" section honestly. Executives who feel they're getting the full picture trust you more — and that trust is your best retention tool.

---

**Step 3 — Prepare for expansion moment (15 minutes)**

Use **QBR Expansion Moment Script** from `04-expansion-upsell-prompts.md`.

Decide:
- What's the expansion opportunity? (Have one ready even if you're not sure you'll use it)
- What's the data-backed bridge from their current results to the next opportunity?
- What question will you ask to open the dialogue (not close a deal)?

In a healthy QBR, the expansion conversation should feel like a natural extension of the results discussion — not a gear shift into sales mode.

---

**Step 4 — Post-QBR follow-up (10 minutes)**

Within 24 hours of the QBR, send a follow-up that:
1. Recaps the goals agreed on (with owners and dates)
2. Confirms any commitments you made
3. Introduces the next step (whether that's an expansion call, a product intro, or just a check-in)

Use: **QBR Follow-Up Email** from `03-retention-health-prompts.md`

---

**QBR Prep Checklist:**
- [ ] Champion prep doc sent (3-4 days before)
- [ ] Health score data pulled and understood
- [ ] Metrics story built (not just numbers — what do they mean?)
- [ ] Honest assessment of what didn't work
- [ ] Roadmap items identified and tied to customer priorities
- [ ] Expansion moment prepared (even if you don't use it)
- [ ] Follow-up template ready to send same day

---

## SOP B: The Renewal Campaign — 90-Day Playbook

**What this produces:** A systematic renewal sequence from at-risk identification to contract signed  
**When to run it:** 90 days before any renewal > [YOUR ARR THRESHOLD]  
**Time commitment:** 3-5 hours over 90 days  
**Prompt files:** `03-retention-health-prompts.md`, `04-expansion-upsell-prompts.md`, `05-stakeholder-reporting-prompts.md`

---

### The 90-Day Renewal System

**Day 90: Assessment and Categorization**

Run a renewal health assessment using **At-Risk Account Escalation Brief** from `05-stakeholder-reporting-prompts.md` (even for healthy accounts — use it as a checklist).

Categorize each renewal:
- **Green (>90% likely):** Run standard renewal process, look for expansion
- **Yellow (60-90%):** Activate proactive health plays immediately
- **Red (<60%):** Escalate to leadership today — don't wait

---

**Days 90-60: Value Reinforcement**

For all accounts:
- Send ROI summary email using **ROI Review Email Pre-Renewal** from `04-expansion-upsell-prompts.md`
- Schedule a value review call if you haven't had one in 60 days
- Build the "before and after" story using **Value Story — Before and After** from `04-expansion-upsell-prompts.md`

For yellow/red accounts:
- Use **Risk Re-engagement Email** from `03-retention-health-prompts.md`
- Get executive sponsor engaged immediately

---

**Days 60-30: Decision Maker Engagement**

Book a renewal-focused call with the economic buyer (not just your champion).

Use **QBR Expansion Moment Script** or a renewal-specific version to structure the conversation.

Key agenda:
1. Review the value delivered (5 min)
2. Align on next year's goals (10 min)
3. Present renewal terms (5 min)
4. Handle objections (open-ended, not scripted)

---

**Day 30: Contract Velocity**

- Send renewal documentation and make it frictionless to sign
- Address any final objections using **Expansion Objection Handler** from `04-expansion-upsell-prompts.md` (the same objections apply to renewals)
- If appropriate, introduce upgrade at renewal using **Upsell Email — Annual Upgrade Offer** from `04-expansion-upsell-prompts.md`

---

**Day 0-7 after signing: Close the Loop**

Send a "thank you for renewing" note that:
- Celebrates the continued partnership
- Confirms the goals for the year ahead
- Sets the expectation for how you'll work together going forward

---

**Renewal Campaign Tracking:**

| Day | Action | Prompt Used | Status |
|-----|--------|-------------|--------|
| 90 | Health assessment | At-Risk Brief | ☐ |
| 75 | ROI email sent | ROI Review Email | ☐ |
| 60 | Value review call | EBR Narrative | ☐ |
| 45 | Exec sponsor engaged | Risk Re-engagement | ☐ |
| 30 | Decision maker call | QBR Script | ☐ |
| 14 | Contract sent | — | ☐ |
| 7 | Objection handling | Objection Handler | ☐ |
| 0 | Renewal signed | — | ☐ |

---

## SOP C: The Expansion Playbook — From Signal to Closed

**What this produces:** A systematic process for identifying, pursuing, and closing expansion revenue  
**When to run it:** Monthly account reviews, or when an expansion trigger fires  
**Time commitment:** 2-3 hours per active expansion opportunity  
**Prompt files:** `04-expansion-upsell-prompts.md`

---

### The Expansion System

**Step 1 — Identify the signal (10 minutes)**

Expansion signals to watch for:
- Seat utilization at 80%+ for 30+ days
- Customer asking about features in a higher tier
- Champion mentions team growth or new use case
- High NPS score (8+)
- Reaching a major product milestone
- Support tickets that are actually growth pains

Map each signal to an expansion type:
- Seats/users → Seat expansion email
- Feature request → Feature value bridge email
- New department → Cross-sell pitch
- Monthly customer → Annual upgrade offer
- Post-milestone → Success milestone trigger email

---

**Step 2 — Research the opportunity (15 minutes)**

Use **Account Expansion Opportunity Assessment** from `04-expansion-upsell-prompts.md` to produce:
- The business case in their language
- The right stakeholder to approach
- The red flags that might block expansion

Don't skip this step. Pitching expansion to the wrong person or at the wrong time is worse than waiting.

---

**Step 3 — First touch (20 minutes)**

Choose the right email from `04-expansion-upsell-prompts.md` based on the signal:
- Usage gap → **Upsell Email — Feature Value Bridge**
- Seat utilization → **Upsell Email — Seat Expansion**
- NPS promoter → **NPS Promoter Expansion Prompt**
- Milestone hit → **Success Milestone → Expansion Trigger Email**

Personalize aggressively. Reference their specific data, their specific goal. Generic expansion emails get ignored.

---

**Step 4 — Discovery call (30 minutes)**

Use **Expansion Discovery Call Prep** from `04-expansion-upsell-prompts.md` to prepare:
- 5 discovery questions (not pitching — learning)
- The bridge statement from their goals to your product
- Objection responses for the most likely resistance

**Golden rule:** In the discovery call, spend 70% of your time asking and listening, 30% presenting. The more they talk, the more you can tailor the pitch.

---

**Step 5 — Formal proposal (20 minutes)**

Use **Expansion Proposal One-Pager** from `04-expansion-upsell-prompts.md`.

Send within 24 hours of the discovery call. While they still remember the conversation and the energy is high.

---

**Step 6 — Close and handoff**

If the deal exceeds your authority or requires legal/contracts, use **CS-to-Sales Handoff Report** from `05-stakeholder-reporting-prompts.md` to ensure the transition is seamless.

---

## SOP D: New Customer Onboarding — First 30 Days

**What this produces:** A structured onboarding sequence that maximizes time-to-value and sets up long-term health  
**When to run it:** For every new customer sign  
**Time commitment:** 3-4 hours of active work over 30 days  
**Prompt files:** `02-onboarding-prompts.md`

---

### The 30-Day Onboarding System

**Day 1: Welcome and kickoff prep**
- Send welcome email using **New Customer Welcome Email** from `02-onboarding-prompts.md`
- Build the 90-day success plan using **Onboarding Success Plan Document** from `02-onboarding-prompts.md`
- Schedule kickoff call for Day 3-5

**Days 3-5: Kickoff call**
- Use kickoff agenda from `02-onboarding-prompts.md`
- Goal: Align on success criteria, introduce key contacts, confirm timeline
- End with: shared doc link to the success plan, next milestone date

**Days 7-14: First value milestone**
- Use training content and setup prompts from `02-onboarding-prompts.md`
- Check: Have they completed the "Day 1" setup? If not, what's blocking them?
- Send proactive check-in at Day 10

**Days 14-30: Adoption and first results**
- Monitor usage daily (or weekly for lower-touch accounts)
- Send progress update at Day 21: celebrate what's working, address what's not
- At Day 30: Run a mini-review using **30-Day Check-In** from `03-retention-health-prompts.md`

---

**Onboarding Health Signals to Watch:**
- ✅ Logged in within 48 hours of welcome email
- ✅ Completed setup steps within 7 days
- ✅ First meaningful action taken within 14 days
- ✅ Primary KPI baseline established
- ⚠️ No login after 5 days → immediate outreach
- ⚠️ Setup incomplete at 14 days → escalate internally

---

## SOP E: The At-Risk Account Save Playbook

**What this produces:** A structured approach to identifying, diagnosing, and saving at-risk accounts  
**When to run it:** When a customer's health drops to Yellow or Red, or when a renewal risk is identified  
**Time commitment:** 4-8 hours over 30-60 days per account  
**Prompt files:** `03-retention-health-prompts.md`, `05-stakeholder-reporting-prompts.md`

---

### The Account Save System

**Step 1 — Diagnosis (30 minutes)**

Before doing anything else, understand what you're dealing with. Use **At-Risk Account Escalation Brief** from `05-stakeholder-reporting-prompts.md` as a framework:

Ask yourself:
- Is this a relationship problem, a product problem, or a value problem?
- Who are the real decision-makers, and are any of them detractors?
- What has changed recently? (Sponsor left? New competitor? Budget cut?)
- What does "saved" actually look like? (Renewal at full value? Downgrade to retain? Pause?)

**Don't assume you know the root cause before asking the customer directly.**

---

**Step 2 — Executive escalation (if needed)**

If the ARR is above [YOUR ARR THRESHOLD] or the customer has executive-level dissatisfaction, escalate immediately.

Use **At-Risk Account Escalation Brief** to get leadership context and aligned on the save strategy before you approach the customer.

---

**Step 3 — Direct conversation**

Request a call framed as a "success review" — not a check-in, not a business review. Something that signals you're taking their situation seriously.

Open by listening. Use questions from `03-retention-health-prompts.md` health check prompts:
- "What's changed in how you're using [PRODUCT] since we last spoke?"
- "If you could change one thing about working with us, what would it be?"
- "What does success look like for your team in the next 6 months?"

---

**Step 4 — Recovery plan**

Based on what you heard, build a recovery plan:
- If the issue is product: Create a roadmap for resolution with product team input
- If the issue is adoption: Restart onboarding for the stuck use case
- If the issue is relationship: Executive sponsor engagement, account review with CS leadership
- If the issue is commercial: Loop in sales or CS leadership for a commercial solution

Document and share the recovery plan using **Executive Business Review (EBR) Deck Narrative** format (abbreviated for smaller accounts).

---

**Step 5 — 30-day check-in on recovery**

Track progress against the recovery plan. Report internally using **Monthly Customer Pulse Email** from `05-stakeholder-reporting-prompts.md`.

If the account doesn't recover in 30-45 days despite a genuine save attempt, begin transition planning to reduce the renewal loss (downgrade, shorter term, etc.) while maintaining the relationship for future re-engagement.

---

**Save Playbook Success Metrics:**
- 70%+ of Yellow accounts should return to Green within 60 days
- 40%+ of Red accounts with a proper save play should renew
- Every loss should produce a churn post-mortem within 2 weeks

---

*5 complete CSM workflow SOPs*
