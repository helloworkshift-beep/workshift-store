# 07 — The CSM's AI Cheat Sheet

*The 15 most powerful prompts in this toolkit — ready to copy, paste, and use right now*

---

> **How to use this file:** This is your quick-access layer. Every prompt here is copied in full from the main prompt files. No need to dig through folders. When you're prepping for a call, writing a renewal email, or building a QBR deck — start here.
>
> Fill in every `[BRACKET]` with your real context before pasting. The quality of your output is directly proportional to the specificity of your inputs.

---

## THE 15 MOST POWERFUL PROMPTS

---

### 🏆 Prompt 1: The QBR Deck Narrative
*Source: 05-stakeholder-reporting-prompts.md*
*Why it's here: This single prompt turns 4 hours of slide-building into 30 minutes of editing.*

```
You are a senior CSM preparing an Executive Business Review. Write the narrative and talking points for each section of the EBR deck.

Customer: [COMPANY_NAME]
Attendees: [ATTENDEE_LIST_WITH_ROLES]
Review period: [REVIEW_PERIOD]
Customer's strategic priorities: [CUSTOMER_PRIORITIES]
Key metrics: [METRICS]
Goals set at last QBR: [PRIOR_GOALS]
Goals achieved: [GOALS_ACHIEVED]
Goals not achieved: [GOALS_MISSED] — reason: [MISS_REASON]
Product roadmap items relevant to them: [ROADMAP_ITEMS]

Write slide narratives for:
1. Partnership recap (joint achievement framing)
2. Metrics and outcomes (story, not table)
3. Where we fell short and what's changing
4. What's coming (roadmap tied to their priorities)
5. Next 6-month co-created goals
6. Closing
```

---

### 🏆 Prompt 2: The At-Risk Re-engagement Email
*Source: 03-retention-health-prompts.md*
*Why it's here: When a customer goes quiet, this email gets them back in the room.*

```
Write a re-engagement email for a customer who has gone quiet and is showing churn risk signals.

Customer: [CONTACT_NAME] at [COMPANY_NAME]
Last meaningful touchpoint: [DATE]
Risk signals: [RISK_INDICATORS]
Their original goal when they bought: [ORIGINAL_GOAL]
Value they've gotten so far (if any): [VALUE_DELIVERED]
What I want from this email: [DESIRED_OUTCOME — a call, a reply, a meeting]

Write an email that:
1. Opens with a genuine observation, not a check-in cliché
2. Acknowledges that we may not be delivering what they need
3. Creates psychological safety for them to tell me the truth
4. Ends with a single, low-commitment ask
```

---

### 🏆 Prompt 3: New Customer Welcome Email
*Source: 02-onboarding-prompts.md*
*Why it's here: First impressions set the tone for the entire relationship.*

```
Write a new customer welcome email.

Customer name / company: [CONTACT_NAME], [COMPANY_NAME]
Product: [PRODUCT_NAME AND BRIEF DESCRIPTION]
What they purchased: [PLAN / PACKAGE / TIER]
Primary use case: [WHAT THEY BOUGHT IT TO DO]
Key stakeholders at the customer: [NAMES AND ROLES]
My name and role: [YOUR_NAME], [TITLE]
Onboarding timeline: [WHAT HAPPENS IN THE FIRST 30-60-90 DAYS]

Write a welcome email that:
1. Opens with genuine excitement about the partnership
2. Names their primary goal and confirms alignment
3. Outlines the next 3 concrete steps with dates
4. Introduces myself and my role
5. Sets an expectation for communication cadence
6. Ends with a single, clear action for them to take

Tone: Warm and professional. Length: 3-4 short paragraphs.
```

---

### 🏆 Prompt 4: The Upsell Email — Feature Value Bridge
*Source: 04-expansion-upsell-prompts.md*
*Why it's here: This is the highest-converting expansion email in the toolkit.*

```
Write a personalized upsell email that bridges from a customer's current situation to a specific feature.

Customer: [CONTACT_NAME], [CONTACT_ROLE] at [COMPANY_NAME]
Current plan: [CURRENT_PLAN]
How they use the product today: [CURRENT_USAGE]
Business goal they've expressed: [STATED_GOAL]
Feature on upgrade plan that serves this goal: [UPSELL_FEATURE]
Upgrade plan: [UPGRADE_PLAN], [UPGRADE_PRICE]
Expected outcome: [EXPECTED_OUTCOME]

Write an email that:
1. Acknowledges what they're achieving today (1 sentence)
2. Bridges to a gap based on their stated goal (1-2 sentences)
3. Introduces the specific feature — not the plan (2-3 sentences)
4. States the expected outcome in their language
5. Ends with a soft CTA (demo, not "buy now")

Under 200 words. Tone: Helpful advisor, not salesperson.
```

---

### 🏆 Prompt 5: ROI Review Email Pre-Renewal
*Source: 04-expansion-upsell-prompts.md*
*Why it's here: The pre-renewal ROI email is the single best retention tool you have.*

```
Write a pre-renewal ROI summary email that makes the business case for both renewal and expansion.

Customer: [CONTACT_NAME], [CONTACT_ROLE] at [COMPANY_NAME]
Contract value: [CURRENT_ARR]
Renewal date: [RENEWAL_DATE]
Key metrics achieved: [METRICS]
Original goals at signing: [ORIGINAL_GOALS]
Goals achieved: [GOALS_ACHIEVED]
Expansion opportunity: [EXPANSION_OPPORTUNITY]
Expected additional value from expansion: [EXPANSION_VALUE]

Write an email that:
1. Opens with their original goal and what they've achieved
2. Quantifies the ROI in their language
3. Identifies the next-level opportunity without hard-selling
4. Makes renewal feel obvious, and expansion feel smart
```

---

### 🏆 Prompt 6: Churn Post-Mortem
*Source: 05-stakeholder-reporting-prompts.md*
*Why it's here: The teams that learn from churn are the ones that stop it.*

```
Write an internal churn post-mortem report.

Lost account: [COMPANY_NAME]
ARR lost: [CHURNED_ARR]
Tenure: [MONTHS_AS_CUSTOMER] months
Primary churn reason (stated): [CUSTOMER_STATED_REASON]
Primary churn reason (actual): [ACTUAL_REASON]
Was churn preventable? [YES/NO/PARTIALLY] — explain: [PREVENTION_ANALYSIS]
Warning signs we missed: [WARNING_SIGNS]
Actions taken in save attempt: [SAVE_ACTIONS]
What we'd do differently: [LESSONS_LEARNED]
Systemic issue (if any): [SYSTEMIC_ISSUE]

Format with: account summary, timeline of key events, root cause analysis, lessons, and recommended process change.
```

---

### 🏆 Prompt 7: Account Expansion Opportunity Assessment
*Source: 04-expansion-upsell-prompts.md*
*Why it's here: Know your expansion opportunities before your AE does.*

```
Analyze the following account details and produce an expansion opportunity assessment.

Company: [COMPANY_NAME]
Current plan: [CURRENT_PLAN]
Contract value: [CURRENT_ARR]
Products in use: [ACTIVE_PRODUCTS]
Products NOT in use: [UNUSED_PRODUCTS]
Seat utilization: [CURRENT_SEATS_USED] / [TOTAL_SEATS_PURCHASED]
Usage trend (last 90 days): [INCREASING/DECREASING/FLAT]
Primary use case: [MAIN_USE_CASE]
Known business challenges: [CUSTOMER_PAIN_POINTS]
Renewal date: [RENEWAL_DATE]

Produce:
1. Top 3 expansion opportunities ranked by likelihood and revenue potential
2. For each: business case in customer's language, timing, right stakeholder
3. Red flags that need addressing before expansion is realistic
4. Recommended next action within 30 days
```

---

### 🏆 Prompt 8: At-Risk Escalation Brief
*Source: 05-stakeholder-reporting-prompts.md*
*Why it's here: Get leadership help before the customer is gone.*

```
Write an internal escalation brief for an at-risk customer.

Account: [COMPANY_NAME]
ARR at risk: [ARR_AT_RISK]
Renewal date: [RENEWAL_DATE]
Health status: Red / [HEALTH_SCORE]
Risk indicators: [RISK_INDICATORS]
Root cause assessment: [ROOT_CAUSE]
Steps taken so far: [ACTIONS_TAKEN]
What hasn't worked: [WHAT_FAILED]
What I'm asking for: [ESCALATION_ASK]
Proposed save plan: [SAVE_STRATEGY]
Timeline: renewal in [X] days

Write a 1-page brief: situation, risk, what's been tried, and the ask.
```

---

### 🏆 Prompt 9: Customer Health Check-In Email
*Source: 03-retention-health-prompts.md*
*Why it's here: Regular touches prevent most at-risk situations from developing.*

```
Write a proactive health check-in email for a customer who is due for a touch.

Customer: [CONTACT_NAME] at [COMPANY_NAME]
Last touch: [DATE]
Current health status: [STATUS]
Recent product usage: [USAGE_SUMMARY]
Milestone or event to reference: [RECENT_EVENT_OR_MILESTONE — if applicable]
Goal of this email: [GOAL — a quick call, usage feedback, or just staying present]

Write a short, genuine email (under 150 words) that:
1. References something specific about them or their account
2. Adds value (insight, tip, or relevant update)
3. Has a natural, low-pressure ask
4. Doesn't feel like a template
```

---

### 🏆 Prompt 10: QBR Expansion Moment Script
*Source: 04-expansion-upsell-prompts.md*
*Why it's here: The transition from "results review" to "here's what's next" is the hardest moment in any QBR.*

```
Write the expansion portion of a QBR — the segment that transitions from results to opportunity.

Customer: [COMPANY_NAME]
QBR participants: [ATTENDEES_AND_ROLES]
Metrics achieved: [KEY_METRICS]
Goals met: [GOALS_STATUS]
Expansion opportunity: [EXPANSION_OPPORTUNITY]
Business case: [BUSINESS_CASE]
Expected ROI: [EXPECTED_OUTCOME]
Cost: [UPGRADE_COST]

Write:
1. A 3-sentence transition from review to expansion conversation
2. The expansion pitch in 5-7 sentences (anchor to their goals)
3. The discovery question to open dialogue (not a close)
4. How to handle "we need to think about it"
```

---

### 🏆 Prompt 11: Onboarding Success Plan
*Source: 02-onboarding-prompts.md*
*Why it's here: A shared success plan is the #1 predictor of healthy onboarding.*

```
Write a 90-day customer onboarding success plan.

Customer: [COMPANY_NAME]
Primary contact: [CONTACT_NAME], [CONTACT_ROLE]
Product: [PRODUCT_NAME]
Use case: [USE_CASE]
Business goal: [BUSINESS_GOAL]
Success metric (how they'll know it's working): [SUCCESS_METRIC]
Key stakeholders involved: [STAKEHOLDERS]
Known risks to onboarding: [KNOWN_RISKS]
Milestones by month: [MONTH_1_GOALS], [MONTH_2_GOALS], [MONTH_3_GOALS]

Write a plan document with: overview, 30/60/90-day goals, milestones, owner assignments, and success criteria. Format for sharing with the customer.
```

---

### 🏆 Prompt 12: Voice of Customer Summary for Product
*Source: 05-stakeholder-reporting-prompts.md*
*Why it's here: CSMs hold the best product intelligence in the company. This prompt puts it in a format product teams can actually use.*

```
Write a structured Voice of Customer (VoC) summary for the product team.

Feedback period: [TIME_PERIOD]
Sources: [SOURCES]
Top 5 feature requests (ranked by frequency/ARR):
1. [REQUEST_1] — [X] customers, [ARR_WEIGHT]
2. [REQUEST_2] — ...
3-5. [CONTINUE]

Top 3 pain points:
1. [PAIN_1] — impact: [IMPACT]
2. [PAIN_2] — ...
3. [PAIN_3] — ...

Positive themes: [POSITIVE_THEMES]
Churn-correlated feedback: [CHURN_LINKED_FEEDBACK]
Notable customer quotes: [QUOTES]

Format as a VoC brief for sprint planning: prioritized asks, evidence base, and "if we don't fix this" risk.
```

---

### 🏆 Prompt 13: Renewal Forecast Report
*Source: 05-stakeholder-reporting-prompts.md*
*Why it's here: Leadership needs your renewal forecast in a format they can act on.*

```
Write a renewal forecast report for [MONTH/QUARTER].

Renewals due: [RENEWAL_COUNT] accounts, [TOTAL_ARR] in ARR

High confidence (>90%): [HIGH_CONFIDENCE_ACCOUNTS] — [HIGH_ARR]
Medium confidence (60-90%): [MEDIUM_CONFIDENCE_ACCOUNTS] — [MEDIUM_ARR]
At-risk (<60%): [AT_RISK_ACCOUNTS] — [AT_RISK_ARR]

Largest renewal: [ACCOUNT] — [ARR] — status: [STATUS]
Highest risk: [ACCOUNT] — [ARR] — save plan: [PLAN]
Expansion likely at renewal: [ACCOUNT] — [OPPORTUNITY]

Format: summary metrics, account-by-account breakdown, top 3 actions needed from leadership or cross-functional partners.
```

---

### 🏆 Prompt 14: Customer Success Story / Case Study
*Source: 05-stakeholder-reporting-prompts.md*
*Why it's here: CSMs have the best stories. This prompt helps you tell them in a way marketing can actually use.*

```
Write a customer success case study draft.

Customer: [COMPANY_NAME], [INDUSTRY]
Use case: [USE_CASE]
Before state: [CHALLENGE] — previous solution: [PRIOR_SOLUTION] — cost/time: [PRIOR_COST]
After state: [KEY_METRICS] — qualitative impact: [QUALITATIVE_IMPACT]
Customer quote: "[CUSTOMER_QUOTE]" — [CONTACT_NAME], [CONTACT_ROLE]

Write a 400-500 word case study: challenge → solution → results → future. Professional but human. The customer should want to share it.
```

---

### 🏆 Prompt 15: CS-to-Sales Account Handoff Brief
*Source: 05-stakeholder-reporting-prompts.md*
*Why it's here: A clean handoff prevents deals from dying in transition.*

```
Write a CS-to-Sales account handoff brief.

Account: [COMPANY_NAME], [CURRENT_ARR], renewal [RENEWAL_DATE]
Handoff reason: [REASON]
Champion: [CHAMPION_NAME], [ROLE] — relationship quality: [QUALITY]
Exec sponsor: [EXEC_SPONSOR] — engaged: [YES/NO]
Decision maker for expansion: [DECISION_MAKER]

Health summary: [HEALTH_SUMMARY]
Key wins delivered: [KEY_WINS]
Open risks: [OPEN_RISKS]
Expansion opportunity: [EXPANSION_DETAILS]
What they care about most: [CUSTOMER_PRIORITIES]
What NOT to bring up: [SENSITIVE_TOPICS]
Recommended approach: [STRATEGY]

Format as a 1-page brief the AE can read in 5 minutes.
```

---

## 10 GOLDEN RULES FOR CSM AI PROMPTING

1. **Specific context produces specific output** — "B2B SaaS enterprise customer at risk of churning due to executive sponsor turnover" beats "at-risk customer" every time.

2. **Name the goal, not just the task** — Tell the AI what you're trying to achieve, not just what to write. "This email needs to get a reply from a silent customer" sets the success bar.

3. **Personalize after generating** — AI can't replicate your actual relationship with a customer. Every output is a draft. Add 1-2 specific personal touches before sending.

4. **Use the system prompt** — Always start a new conversation with the CSM system prompt from `01-quick-start-guide.md`. It calibrates every response.

5. **Regenerate for tone** — If the output is too formal or too casual, say "Regenerate this at a [tone] level for a [relationship type]." Takes 10 seconds.

6. **Stack prompts** — Great workflows use multiple prompts in sequence. Run the health check prompt → feed into escalation brief → feed into leadership email.

7. **Include their actual words** — If a customer said something memorable in a call or email, paste it into your prompt. The AI will mirror their language back, which feels more personal.

8. **Test the objection handler** — Before an important expansion call, run the expansion objection handler. Knowing your responses cold makes you infinitely more confident.

9. **Don't send first output raw** — Read it. Edit it. Make it yours. AI writes competent prose; great CSMs write memorable ones.

10. **Use AI for the internal stuff too** — QBR prep docs, escalation briefs, renewal forecasts, post-mortems — AI speeds up the internal work just as much as the customer-facing work. Don't leave that leverage on the table.

---

## QUICK VARIABLE REFERENCE

| Variable | What to Put Here |
|----------|-----------------|
| `[COMPANY_NAME]` | Customer's company name |
| `[CONTACT_NAME]` | Primary contact's first and last name |
| `[CONTACT_ROLE]` | Their job title |
| `[CURRENT_PLAN]` | Their subscription tier/package |
| `[CURRENT_ARR]` | Annual recurring revenue of this account |
| `[RENEWAL_DATE]` | Contract renewal date |
| `[HEALTH_SCORE]` | Numerical or tiered health score |
| `[PRODUCT_NAME]` | Your product's full name |
| `[USE_CASE]` | Primary way they use your product |
| `[STATED_GOAL]` | What they've told you they want to achieve |
| `[KEY_METRICS]` | Usage or outcome data points (be specific) |
| `[EXPANSION_OPPORTUNITY]` | What upgrade/add-on you're pursuing |
| `[MY_NAME]` | Your name |
| `[MY_ROLE]` / `[MY_TITLE]` | Your job title |

---

*Built for CSMs who retain, expand, and scale.*
