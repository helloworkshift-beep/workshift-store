# 05 — Stakeholder Reporting Prompts

*20 prompts for executive reporting, internal CS metrics, renewal documentation, and business reviews*

---

## EXECUTIVE REPORTING PROMPTS

---

### Executive Business Review (EBR) Deck Narrative
*Use when building the narrative for a formal executive business review with a customer's C-suite.*

```
You are a senior CSM preparing an Executive Business Review for a strategic customer. Write the narrative and talking points for each section of the EBR deck.

EBR context:
- Customer: [COMPANY_NAME]
- Attendees: [ATTENDEE_LIST_WITH_ROLES]
- Review period: [REVIEW_PERIOD — e.g., "H1 2025"]
- Customer's strategic priorities for this period: [CUSTOMER_PRIORITIES]
- Metrics we're presenting: [KEY_METRICS — e.g., "adoption rate: 87%, support ticket volume: down 40%, time-to-value: 14 days avg"]
- Goals set at last EBR: [PRIOR_GOALS]
- Goals achieved: [GOALS_ACHIEVED]
- Goals not achieved: [GOALS_MISSED] — reason: [MISS_REASON]
- Product roadmap items relevant to their needs: [ROADMAP_ITEMS]
- Expansion being introduced: [EXPANSION_OPPORTUNITY — if applicable]

Write slide narratives for:
1. Partnership recap (what we've done together — framed as a joint achievement)
2. Metrics and outcomes (data-driven, tells a story not just a table)
3. Where we fell short and what's changing (honest, not defensive)
4. What's coming (roadmap tied to their priorities)
5. Next 6-month goals (co-created, specific, measurable)
6. Closing — the "why we're a great fit for your future" moment

Tone: Executive-ready. Confident. No fluff. They have 60 minutes and need to leave with clarity.
```

---

### QBR Prep Summary for Customer Champion
*Use when sending a pre-QBR prep document to your champion so they walk in prepared.*

```
Write a pre-QBR preparation email and attached summary document for my champion to review before our quarterly business review.

Customer: [COMPANY_NAME]
Champion: [CHAMPION_NAME], [CHAMPION_ROLE]
QBR date/time: [QBR_DATE]
QBR attendees: [ATTENDEE_LIST]
Key metrics to highlight: [METRICS]
Potential tough questions to prepare for: [ANTICIPATED_QUESTIONS]
What I need from the champion: [CHAMPION_INPUT_NEEDED — e.g., "goals for next quarter", "updated headcount using product"]
Expansion topic to preview: [EXPANSION_IF_APPLICABLE]

Write:
1. A short email (under 150 words) asking them to review the attached prep doc
2. A 1-page prep doc with: meeting agenda, key data points, 3 things we want to accomplish, and 2 questions I'll be asking that they should be ready to answer
```

---

### CS Team Health Report — Account Portfolio Summary
*Use when preparing your monthly portfolio health summary for your CS manager or team.*

```
Write a monthly CS portfolio health report based on the following data. This will be shared with my CS manager and possibly leadership.

Reporting period: [MONTH/QUARTER]
My name: [MY_NAME]
Portfolio overview:
- Total accounts: [TOTAL_ACCOUNTS]
- Total ARR managed: [TOTAL_ARR]
- Accounts by health tier: Green [GREEN_COUNT], Yellow [YELLOW_COUNT], Red [RED_COUNT]

Key events this period:
- Renewals closed: [RENEWALS_CLOSED — amount, GRR]
- Expansions closed: [EXPANSIONS — amount]
- Churn: [CHURN — accounts lost, ARR lost, reason]
- New accounts onboarded: [NEW_ACCOUNTS]
- Accounts moved from yellow to green: [SAVES]
- Accounts that deteriorated: [AT_RISK_MOVEMENTS]

Focus accounts (top 3): [ACCOUNT_1], [ACCOUNT_2], [ACCOUNT_3] — with status summary

Risks requiring leadership attention: [ESCALATION_ITEMS]

Format as an executive-ready health summary with: portfolio snapshot, key wins, key risks, and what I need from the team or leadership.
```

---

### At-Risk Account Escalation Brief
*Use when escalating an at-risk customer to CS leadership, sales, or executive sponsors.*

```
Write an internal escalation brief for an at-risk customer account that needs leadership attention.

Account: [COMPANY_NAME]
ARR at risk: [ARR_AT_RISK]
Renewal date: [RENEWAL_DATE]
Health status: Red / [HEALTH_SCORE]
Risk indicators:
- [RISK_INDICATOR_1 — e.g., "NPS dropped from 8 to 4 in last survey"]
- [RISK_INDICATOR_2 — e.g., "executive sponsor left the company"]
- [RISK_INDICATOR_3 — e.g., "support tickets have doubled in 60 days"]
Root cause assessment: [ROOT_CAUSE]
Steps taken so far: [ACTIONS_TAKEN]
What hasn't worked: [WHAT_FAILED]
What I'm asking for: [ESCALATION_ASK — e.g., executive sponsor call, engineering escalation, commercial flexibility]
Proposed save plan: [SAVE_STRATEGY]
Timeline: [URGENCY — renewal in X days]

Write a 1-page escalation brief that gives leadership everything they need to act in under 3 minutes: the situation, the risk, what's been tried, and the ask.
```

---

### Renewal Forecast Report for Leadership
*Use when preparing your renewal forecast summary for monthly or quarterly business reviews.*

```
Write a renewal forecast report for [MONTH/QUARTER] to be presented at a leadership or revenue team meeting.

My book of business for this period:
- Renewals due: [RENEWAL_COUNT] accounts worth [TOTAL_ARR] in ARR

Renewal breakdown by confidence tier:
- High confidence (>90% likely to renew): [HIGH_CONFIDENCE_ACCOUNTS] — ARR: [HIGH_ARR]
- Medium confidence (60-90%): [MEDIUM_CONFIDENCE_ACCOUNTS] — ARR: [MEDIUM_ARR]
- At-risk (<60%): [AT_RISK_ACCOUNTS] — ARR: [AT_RISK_ARR]

Key renewal highlights:
- Largest renewal: [LARGEST_ACCOUNT] — [LARGEST_ARR] — status: [STATUS]
- Highest risk renewal: [AT_RISK_ACCOUNT] — [AT_RISK_ARR] — save plan: [SAVE_PLAN]
- Most likely expansion at renewal: [EXPANSION_ACCOUNT] — [EXPANSION_OPPORTUNITY]

Format as a clean renewal forecast with: summary metrics, account-by-account breakdown, and top 3 actions needed from leadership or cross-functional partners.
```

---

### Churn Post-Mortem Report
*Use when documenting the loss of a customer account for internal learning.*

```
Write an internal churn post-mortem report for a lost customer account.

Lost account: [COMPANY_NAME]
ARR lost: [CHURNED_ARR]
Contract end date: [END_DATE]
Tenure as customer: [MONTHS_AS_CUSTOMER]
Primary churn reason (stated): [CUSTOMER_STATED_REASON]
Primary churn reason (actual, if different): [ACTUAL_REASON]
Was churn preventable? [YES/NO/PARTIALLY] — explain: [PREVENTION_ANALYSIS]
Warning signs we missed or ignored: [WARNING_SIGNS]
Actions taken in save attempt: [SAVE_ACTIONS]
What we'd do differently: [LESSONS_LEARNED]
Systemic issue (if any): [SYSTEMIC_ISSUE — e.g., product gap, onboarding failure, pricing]

Format as a post-mortem with:
1. Account summary
2. Timeline of key events (sign, first red flag, escalation, loss)
3. Root cause analysis
4. What we'd do differently at each stage
5. Recommended process or product change to prevent recurrence
6. Any recoverable opportunity (future re-engagement possibility)
```

---

## INTERNAL STAKEHOLDER REPORTING PROMPTS

---

### CS Monthly Business Review — Internal Presentation
*Use when presenting CS team performance at a monthly or quarterly business review.*

```
Write an internal monthly CS team performance presentation narrative for [MONTH].

Team metrics:
- GRR (Gross Revenue Retention): [GRR]%
- NRR (Net Revenue Retention): [NRR]%
- Churn: [CHURN_AMOUNT] ARR ([CHURN_COUNT] accounts)
- Expansion closed: [EXPANSION_AMOUNT]
- Average health score across portfolio: [AVG_HEALTH_SCORE]
- NPS from customers (if available): [NPS]
- Time to first value (new customers): [TTFV]

Key wins: [KEY_WINS]
Key losses: [KEY_LOSSES_WITH_LESSONS]
Top initiatives in flight: [CURRENT_INITIATIVES]
What we need from product: [PRODUCT_ASKS]
What we need from sales: [SALES_ASKS]
Outlook for next month: [NEXT_MONTH_OUTLOOK]

Write slide narratives for a 15-minute presentation. Lead with the metrics story, then the qualitative insights, then the cross-functional asks. Keep it crisp — leadership wants the "so what", not the raw numbers.
```

---

### CS Operations Report — Capacity and Coverage Analysis
*Use when reporting on team capacity, account coverage gaps, or the need for additional headcount.*

```
Write a CS capacity and coverage analysis report for [TIME_PERIOD] to share with CS leadership and/or finance.

Team capacity data:
- CS team size: [TEAM_SIZE] CSMs
- Total accounts managed: [TOTAL_ACCOUNTS]
- Average accounts per CSM: [ACCOUNTS_PER_CSM]
- Recommended ratio for our segment: [RECOMMENDED_RATIO — e.g., "1:40 for enterprise, 1:100 for mid-market"]
- Average ARR per CSM: [ARR_PER_CSM]

Coverage gaps:
- Accounts with no touch in 90+ days: [NEGLECTED_ACCOUNTS]
- High-value accounts without dedicated CSM: [UNCOVERED_HV_ACCOUNTS]
- Onboarding backlog: [ONBOARDING_BACKLOG]

Growth projection:
- Expected new accounts next quarter: [NEW_ACCOUNTS_Q]
- Headcount needed to maintain current ratios: [HEADCOUNT_NEEDED]

Write a report that makes the business case for [RECOMMENDATION — e.g., hiring 2 CSMs, shifting coverage model, implementing digital CS tier]. Include cost of inaction in terms of churn risk and GRR impact.
```

---

### Voice of Customer Summary for Product Team
*Use when summarizing customer feedback and feature requests for your product team.*

```
Write a structured Voice of Customer (VoC) summary to share with the product team based on the following customer feedback.

Feedback period: [TIME_PERIOD]
Sources: [SOURCES — e.g., NPS surveys, QBR conversations, support tickets, Slack community]
Total feedback items analyzed: [COUNT]

Top 5 feature requests (ranked by frequency/ARR of requesters):
1. [FEATURE_REQUEST_1] — requested by [X] customers, [ARR_WEIGHT] in ARR
2. [FEATURE_REQUEST_2] — requested by [X] customers, [ARR_WEIGHT] in ARR
3. [FEATURE_REQUEST_3] — ...
4. [FEATURE_REQUEST_4] — ...
5. [FEATURE_REQUEST_5] — ...

Top 3 pain points (friction in current product):
1. [PAIN_POINT_1] — impact: [IMPACT_DESCRIPTION]
2. [PAIN_POINT_2] — ...
3. [PAIN_POINT_3] — ...

Positive themes (what customers love): [POSITIVE_THEMES]
Churn-correlated feedback: [CHURN_LINKED_FEEDBACK]
Customer quotes: [NOTABLE_QUOTES]

Format as a VoC brief that product can use in sprint planning: prioritized asks, evidence base, and the "if we don't fix this" risk for each.
```

---

### CS-to-Sales Handoff Report
*Use when summarizing an account's status for a sales rep taking over an expansion or renewal opportunity.*

```
Write a CS-to-Sales account handoff brief for an account that needs a sales-led expansion or renewal conversation.

Account: [COMPANY_NAME]
Account ARR: [CURRENT_ARR]
Renewal date: [RENEWAL_DATE]
Handoff reason: [REASON — e.g., "expansion opportunity exceeds CSM authority", "complex multi-year renewal", "exec sponsor engagement needed"]

Key contacts:
- Champion: [CHAMPION_NAME], [CHAMPION_ROLE] — relationship quality: [RELATIONSHIP_QUALITY]
- Executive sponsor: [EXEC_SPONSOR], [EXEC_ROLE] — engaged: [YES/NO]
- Decision maker for expansion: [DECISION_MAKER]

Account health summary: [HEALTH_SUMMARY]
Key wins we've delivered: [KEY_WINS]
Open risks or concerns: [OPEN_RISKS]
Expansion opportunity: [EXPANSION_DETAILS]
What they care about most: [CUSTOMER_PRIORITIES]
What NOT to bring up: [SENSITIVE_TOPICS]
Recommended approach: [RECOMMENDED_STRATEGY]

Format as a 1-page brief the AE can read in 5 minutes and walk into the call ready.
```

---

### New CSM Account Transition Summary
*Use when handing off an account from one CSM to another.*

```
Write an account transition brief for handing off [COMPANY_NAME] from [OUTGOING_CSM] to [INCOMING_CSM].

Account overview:
- Company: [COMPANY_NAME], [INDUSTRY], [EMPLOYEE_COUNT] employees
- ARR: [ACCOUNT_ARR]
- Renewal date: [RENEWAL_DATE]
- Health: [HEALTH_STATUS]
- Tenure: [MONTHS_AS_CUSTOMER] months

Key contacts:
- Primary: [PRIMARY_CONTACT], [ROLE], [EMAIL] — communication preference: [PREFERENCE]
- Secondary: [SECONDARY_CONTACT], [ROLE]
- Executive sponsor: [EXEC_SPONSOR], [ROLE] — engagement level: [LEVEL]

Relationship notes: [RELATIONSHIP_NUANCES — what they like, what's sensitive, what makes them tick]
Open items / active projects: [OPEN_ITEMS]
Upcoming milestones: [UPCOMING_MILESTONES]
Known risks: [KNOWN_RISKS]
Expansion opportunity: [EXPANSION_IF_APPLICABLE]
Do NOT drop the ball on: [CRITICAL_COMMITMENTS]

Format as a transition brief with a "Day 1 action list" for the incoming CSM and a recommended intro email template they can use to introduce themselves.
```

---

### CS Roadmap Input for Annual Planning
*Use when contributing to company-wide annual planning with CS team perspective and data.*

```
Write a CS annual planning submission representing the customer success team's perspective, priorities, and resource requests for [FISCAL_YEAR].

CS team context:
- Current GRR: [GRR]% / NRR: [NRR]%
- Annual churn rate: [CHURN_RATE]%
- Team size: [TEAM_SIZE]
- ARR under management: [TOTAL_ARR]

Performance vs. last year targets: [PERFORMANCE_VS_TARGETS]

Top 3 CS priorities for next year:
1. [PRIORITY_1] — why: [RATIONALE], resource need: [RESOURCE]
2. [PRIORITY_2] — ...
3. [PRIORITY_3] — ...

Top product investments requested (ranked by churn/expansion impact):
1. [PRODUCT_ASK_1] — expected impact: [IMPACT]
2. [PRODUCT_ASK_2] — ...
3. [PRODUCT_ASK_3] — ...

Headcount plan: [CURRENT_HEADCOUNT] → [REQUESTED_HEADCOUNT] — business case: [HEADCOUNT_RATIONALE]
Technology/tooling needs: [TOOLS_NEEDED]

Write as a professional annual planning document that makes the CS team's case for investment clearly, with ROI framing wherever possible.
```

---

### Customer Health Score Explanation for Sales
*Use when explaining your health scoring methodology to a new AE or sales leader.*

```
Write a clear explanation of our customer health scoring methodology for the sales team, designed to help AEs understand what makes a customer healthy or at-risk.

Health score methodology:
- Score range: [SCORE_RANGE — e.g., 0-100]
- Health tiers: Green ([GREEN_RANGE]), Yellow ([YELLOW_RANGE]), Red ([RED_RANGE])
- Scoring components:
  - [COMPONENT_1] — weight: [WEIGHT]% — what it measures: [DESCRIPTION]
  - [COMPONENT_2] — weight: [WEIGHT]% — ...
  - [COMPONENT_3] — weight: [WEIGHT]% — ...
  - [COMPONENT_4] — weight: [WEIGHT]% — ...

Common patterns:
- A customer who looks healthy but is actually at risk: [EXAMPLE_SCENARIO]
- A customer who looks at-risk but is actually fine: [EXAMPLE_SCENARIO_2]
- The #1 leading indicator we track: [TOP_INDICATOR]

What AEs should do with this information: [AE_ACTIONS — e.g., "flag low scores before bringing expansion opportunities"]

Write as a 1-page internal guide that an AE can read once and understand well enough to have an informed conversation with CS.
```

---

### Monthly Customer Pulse Email — Internal Summary
*Use when sending a monthly pulse check summary to internal stakeholders (leadership, product, sales).*

```
Write a monthly customer pulse email summarizing customer sentiment across the book of business.

Reporting period: [MONTH]
Author: [MY_NAME], [MY_ROLE]

Customer sentiment summary:
- NPS this month: [NPS_SCORE] (trend: [UP/DOWN/FLAT] from [PRIOR_NPS])
- Top promoter themes (what happy customers are saying): [PROMOTER_THEMES]
- Top detractor themes (what unhappy customers are saying): [DETRACTOR_THEMES]
- Notable individual customer moments: [NOTABLE_CUSTOMER_STORIES — wins or concerns]

Product feedback highlights:
- Most requested feature: [TOP_REQUEST]
- Most-cited pain point: [TOP_PAIN]
- Competitive mentions: [COMPETITIVE_INTEL]

Red flags to watch: [RED_FLAGS]
Green shoots (positive signals): [GREEN_SHOOTS]
Ask from other teams: [CROSS_FUNCTIONAL_ASKS]

Write a 400-500 word internal email that reads like a human wrote it — not a data dump, but a curated view of what's happening in our customer base and what it means.
```

---

### Renewal Risk Register Update
*Use when updating a risk register before presenting at a revenue review.*

```
Write a renewal risk register update for the current quarter's at-risk accounts.

Quarter: [CURRENT_QUARTER]
Total at-risk ARR: [AT_RISK_ARR]
Number of at-risk accounts: [AT_RISK_COUNT]

For each at-risk account, provide:
Account: [ACCOUNT_NAME]
ARR at risk: [ARR]
Renewal date: [DATE]
Risk level: High / Medium
Primary risk factor: [RISK_FACTOR]
Health trend: [IMPROVING/DECLINING/STABLE]
Save actions in flight: [ACTIONS]
Confidence to save: [CONFIDENCE_%]
Executive escalation needed: [YES/NO]

Accounts to cover:
[LIST 4-6 AT-RISK ACCOUNTS WITH ABOVE DETAILS]

End with: a summary of total at-risk ARR, expected retention rate, and top 2 cross-functional asks needed to improve the numbers.

Format as a clean, scannable table followed by narrative commentary for the top 3 most at-risk accounts.
```

---

### Customer Success Impact Report — Board / Investor Summary
*Use when preparing a board-level summary of customer success metrics and retention health.*

```
Write a board/investor-level customer success impact report for [PERIOD].

Company context: [COMPANY_NAME], [BUSINESS_MODEL], [STAGE]
CS metrics for this period:
- Gross Revenue Retention: [GRR]%
- Net Revenue Retention: [NRR]%
- Logo churn: [LOGO_CHURN]%
- Average customer health score: [AVG_HEALTH]
- Time to first value (new customers): [TTFV]
- Customer satisfaction score / NPS: [CSAT_NPS]
- Expansion ARR: [EXPANSION_ARR]

Year-over-year comparison: [YOY_COMPARISON]
Key driver of improvements: [IMPROVEMENT_DRIVERS]
Key risks or headwinds: [RISKS]
Investments made in CS this period: [CS_INVESTMENTS]
ROI on CS investment: [ROI_FRAMING]

Write a 2-page board report section with:
1. Headline metrics (table + 2-sentence narrative per metric)
2. Story of the period (what happened, why, what we did about it)
3. Forward outlook (what we expect next period and why)
4. Ask from the board (if any — capital, partnership, introductions)

Tone: Investor-grade. Precise, honest, forward-looking.
```

---

### Success Story Case Study for Marketing
*Use when drafting a customer success story to share with marketing for case study or social proof.*

```
Write a customer success case study draft based on the following information. This will be reviewed by the customer and potentially published on our website.

Customer: [COMPANY_NAME] (use "[COMPANY_NAME]" as placeholder if not yet approved to name publicly)
Industry: [INDUSTRY]
Company size: [EMPLOYEE_COUNT]
Product used: [PRODUCT_NAME]
Use case: [USE_CASE]

Before state:
- Challenge: [CHALLENGE]
- How they were solving it before: [PRIOR_SOLUTION]
- Time/cost of the old approach: [PRIOR_COST_OR_TIME]

After state (results):
- Key metric 1: [METRIC_1 — e.g., "reduced onboarding time by 60%"]
- Key metric 2: [METRIC_2]
- Key metric 3: [METRIC_3]
- Qualitative impact: [QUALITATIVE_IMPACT]
- Customer quote (if available): "[CUSTOMER_QUOTE]" — [CONTACT_NAME], [CONTACT_ROLE]

Write a 400-500 word case study in a narrative format: challenge → solution → results → future. Professional but human. The customer should want to share it with their own network.
```

---

*Total prompts in this file: 20*
