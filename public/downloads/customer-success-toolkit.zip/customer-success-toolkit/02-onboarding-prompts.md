# 02 — Onboarding Prompts

*25 prompts for new customer onboarding, kickoff meetings, training sequences, and time-to-value*

---

**Prompt 1: New Customer Welcome Email**

*When to use: First email to a new customer after they sign*

```
Write a new customer welcome email.

Customer name / company: [CONTACT NAME], [COMPANY NAME]
Product: [PRODUCT NAME AND BRIEF DESCRIPTION]
What they purchased: [PLAN / PACKAGE / TIER]
Primary use case: [WHAT THEY BOUGHT IT TO DO]
Key stakeholders at the customer: [NAMES AND ROLES — main contact, exec sponsor, end users]
My name and role: [YOUR NAME], [TITLE]
Onboarding timeline: [WHAT HAPPENS IN THE FIRST 30-60-90 DAYS]

Write a welcome email that:
1. Opens with genuine excitement about the partnership — not "congratulations on your purchase"
2. Names their primary goal and confirms we're aligned on it
3. Outlines the next 3 concrete steps with dates
4. Introduces myself and what my role is in their success
5. Sets an expectation for communication cadence
6. Ends with a single, clear action for them to take

Tone: Warm and professional. Length: 3-4 short paragraphs.
```

---

**Prompt 2: Onboarding Success Plan Document**

*When to use: Creating a shared success plan for the first 90 days*

```
Write a 90-day customer onboarding success plan document.

Customer: [COMPANY NAME]
Product: [PRODUCT]
Primary contact: [NAME, TITLE]
Exec sponsor: [NAME, TITLE — if applicable]
Their goals: [LIST 2-3 SPECIFIC BUSINESS OUTCOMES — not product features]
Key use case: [PRIMARY WORKFLOW OR USE CASE THEY NEED RUNNING]
Success metric: [HOW WE'LL KNOW ONBOARDING WAS SUCCESSFUL]
Users to onboard: [NUMBER AND TYPES OF USERS]
Technical requirements: [INTEGRATIONS, DATA MIGRATION, SETUP WORK NEEDED]

Create a 90-day success plan including:

**Phase 1 — Foundation (Days 1-30)**
- Account setup milestones
- Admin training
- Initial workflow activation
- Success criteria for Phase 1

**Phase 2 — Adoption (Days 31-60)**
- User onboarding
- Advanced feature enablement
- Adoption metrics to hit
- Success criteria for Phase 2

**Phase 3 — Value (Days 61-90)**
- First value realization milestone
- Expansion or optimization opportunities
- Health score baseline
- 90-day review agenda

Format as a shared document suitable to send to the customer.
```

---

**Prompt 3: Kickoff Meeting Agenda and Prep**

*When to use: Preparing for the first customer kickoff meeting*

```
Write a kickoff meeting agenda and talking points for a new customer.

Customer: [COMPANY NAME]
Attendees (customer side): [NAMES AND ROLES]
Attendees (our side): [YOUR TEAM MEMBERS]
Meeting duration: [30 / 45 / 60 MINUTES]
Meeting format: [VIDEO / IN-PERSON]
Product: [PRODUCT]
Their goals: [WHAT THEY TOLD SALES THEY WANTED TO ACHIEVE]
Key risks or complexity: [ANYTHING UNUSUAL — complex integration, large user base, tight timeline]

Create:
1. Meeting agenda with time allocations
2. Talking points for each agenda item
3. Discovery questions to ask (what haven't we learned yet that we need?)
4. Success criteria to agree on together
5. An action items template to fill out at the end of the meeting
6. The "one thing" to get them excited about by the end of the meeting

The best kickoffs make the customer feel like they made the right decision. End on energy and clarity.
```

---

**Prompt 4: User Training Email Sequence**

*When to use: Preparing a series of emails to guide end users through product adoption*

```
Write a 4-email user training sequence for new end users.

Product: [PRODUCT NAME]
User type: [WHO THESE USERS ARE — e.g., sales reps, support agents, project managers]
Primary use case: [WHAT THEY USE THE PRODUCT FOR]
Key features to introduce: [LIST 4-6 CORE FEATURES, ONE PER EMAIL]
Tone: [FRIENDLY / PROFESSIONAL / TECHNICAL]
Company name: [YOUR COMPANY]

Write 4 emails sent over 2 weeks:

**Email 1 (Day 1): Welcome + First Win**
- Welcome to the platform
- The single most important thing to do first
- How to get help

**Email 2 (Day 4): Core Workflow**
- The primary use case step-by-step
- Tips for the most common setup question
- Quick win to complete today

**Email 3 (Day 9): Power Feature**
- One feature that saves significant time
- Why most users overlook it
- A specific prompt to try it

**Email 4 (Day 14): Success Check-In**
- Celebrate early progress
- Common sticking points and solutions
- Invitation to a training call

Each email: under 200 words, specific and actionable, one clear CTA.
```

---

**Prompt 5: Integration or Technical Setup Follow-Up**

*When to use: Following up on technical setup, integration, or data migration progress*

```
Write a technical setup follow-up email.

Customer: [COMPANY NAME]
Contact: [NAME, TITLE]
Setup task in progress: [DESCRIBE — e.g., Salesforce integration, data migration, SSO setup]
Current status: [WHERE THINGS STAND — in progress, blocked, near completion]
Any blockers: [WHAT'S NEEDED FROM THEM — IT access, data files, API credentials]
Timeline: [WHEN THIS NEEDS TO BE DONE]
Who owns the next step: [THEM / US / BOTH]

Write an email that:
1. Updates them on status clearly
2. Specifies any action needed from their side (by when)
3. Offers to jump on a call if it would move things faster
4. Keeps the momentum without being pushy
5. Is brief — technical status updates should be scannable

Format key actions as bullet points. Under 200 words.
```

---

**Prompt 6: Admin Training Guide Email**

*When to use: Sending self-serve training resources to customer admins*

```
Write an admin setup and training guide email.

Customer: [COMPANY NAME]
Admin contact: [NAME, TITLE]
Product: [PRODUCT]
Key admin tasks to configure: [LIST — user provisioning, settings, permissions, integrations]
Resources available: [HELP CENTER LINKS / VIDEO GUIDES / LIVE TRAINING SESSION]
Timeline for admin setup: [DEADLINE OR MILESTONE]

Write an email that:
1. Clearly lists what the admin needs to configure and in what order
2. Links to the right resources for each task (use [LINK PLACEHOLDER])
3. Estimates how long each task takes
4. Offers a live training session if preferred
5. Gives a clear timeline expectation
6. Provides a single contact for questions

This email should make the admin feel supported, not overwhelmed. Format as a numbered checklist.
```

---

**Prompt 7: Week 2 Check-In Email**

*When to use: Checking in during the first two weeks of onboarding*

```
Write a Week 2 onboarding check-in email.

Customer: [COMPANY NAME]
Primary contact: [NAME]
What should have happened by now: [PHASE 1 MILESTONES — setup tasks, training, first login]
What you know has happened: [STATUS FROM YOUR INTERNAL SYSTEM / LAST CONVERSATION]
What you're monitoring: [USAGE DATA / SETUP COMPLETION / OTHER]
Any concerns: [ANYTHING THAT SEEMS OFF — slow start, no logins, technical issue]

Write an email that:
1. Acknowledges where they are in onboarding positively
2. Confirms specific milestones are complete (or asks about ones that aren't)
3. Offers a specific help if anything seems stuck
4. Previews what's coming next in the onboarding
5. Is brief and easy to respond to — one specific question at the end

Under 200 words.
```

---

**Prompt 8: 30-Day Onboarding Check-In and Assessment**

*When to use: Formal mid-onboarding check-in to assess health and progress*

```
Write a 30-day onboarding health check email requesting a brief check-in call.

Customer: [COMPANY NAME]
Contact: [NAME]
30-day status (based on your data): [WHAT'S GOING WELL / ANY CONCERNS]
Milestones completed: [LIST]
Milestones pending: [LIST]
Next 30-day focus: [WHAT HAPPENS IN DAYS 31-60]

Write an email + meeting invite that:
1. Celebrates the 30-day mark as a real milestone
2. Shares a summary of what's been accomplished
3. Notes any open items neutrally
4. Explains the purpose of the 30-day review call
5. Proposes a 20-minute agenda
6. Makes it easy to schedule (include link placeholder or offer times)

Tone: Proactive and organized. Make the customer feel like they're on a defined path to success.
```

---

**Prompt 9: Onboarding Delay Communication**

*When to use: When onboarding is behind schedule due to customer or vendor delays*

```
Write an email addressing an onboarding delay.

Customer: [COMPANY NAME]
Contact: [NAME]
Delay cause: [OUR SIDE / THEIR SIDE / EXTERNAL — be specific]
Impact of delay: [WHAT IS NOW DELAYED — go-live date, specific milestone]
New timeline: [REVISED DATES]
What we're doing: [STEPS BEING TAKEN TO RECOVER]
Any action needed from them: [SPECIFIC — or none]

Write an email that:
1. States the delay directly — don't hide it or over-soften it
2. Owns responsibility if we caused the delay
3. Explains the revised timeline clearly
4. States what we're doing to recover
5. Is brief — delays are stressful; long emails make it worse

Apologize once, clearly. Then move forward.
```

---

**Prompt 10: Executive Sponsor Introduction Email**

*When to use: Connecting your executive sponsor with the customer's executive sponsor*

```
Write an introduction email between executive sponsors.

Customer executive sponsor: [NAME, TITLE, COMPANY]
Our executive sponsor: [NAME, TITLE, COMPANY]
Customer relationship context: [HOW LONG / WHAT THEY USE US FOR]
Why this introduction matters: [STRATEGIC RELATIONSHIP / SPECIFIC INITIATIVE / EXECUTIVE ALIGNMENT]
What you want them to do: [SCHEDULE A BRIEF CALL / EXCHANGE CONTACT INFO / SPECIFIC ASK]

Write an introduction email that:
1. Establishes context for both parties
2. Explains why this relationship matters strategically
3. Makes a clear but low-pressure ask for a brief connection
4. Is short — executives don't read long emails
5. Reflects the importance of the customer relationship

Under 200 words. cc both people.
```

---

**Prompt 11: Power User Identification and Engagement**

*When to use: Engaging with highly active or influential users within an account*

```
Write an email to a power user within a customer account.

Company: [COMPANY NAME]
Power user: [NAME, TITLE]
Why they're a power user: [HIGH USAGE / CHAMPION BEHAVIOR / INNOVATIVE USE CASE]
What I want to accomplish: [BUILD THE RELATIONSHIP / GATHER FEEDBACK / CASE STUDY / REFERENCE / FEATURE BETA]
Product context: [WHAT THEY USE AND HOW]

Write an email that:
1. Acknowledges their advanced usage specifically (not generic flattery)
2. States specifically why I'm reaching out
3. Offers something in return (early access, direct input to the product team, special session)
4. Makes a clear ask
5. Is brief and direct

Power users get lots of generic outreach. This one should feel like we actually pay attention to how they use the product.
```

---

**Prompt 12: Training Session Follow-Up**

*When to use: Following up after a group or 1:1 training session*

```
Write a post-training follow-up email.

Customer: [COMPANY NAME]
Training attendees: [NAMES OR "the team"]
Training date: [DATE]
Topics covered: [LIST KEY TOPICS]
Resources shared: [RECORDINGS / HELP DOCS / SLIDES — with link placeholders]
Key actions for attendees: [LIST 2-3 THINGS THEY SHOULD DO NOW]
Next session (if applicable): [DATE / TOPIC]
How to get help: [SUPPORT CONTACT / KNOWLEDGE BASE / MY EMAIL]

Write an email that:
1. Thanks them for attending with specific appreciation
2. Summarizes key takeaways (3-4 bullets — not everything)
3. Lists their action items clearly
4. Provides all follow-up resources in one place
5. Sets up the next session
6. Invites questions

Formatted for easy scanning — this gets bookmarked and referenced later.
```

---

**Prompt 13: Milestone Celebration Email**

*When to use: Celebrating a customer completing a key onboarding milestone*

```
Write an email celebrating a key customer milestone.

Customer: [COMPANY NAME]
Contact: [NAME]
Milestone: [WHAT THEY ACCOMPLISHED — e.g., "100 users trained", "first automated workflow live", "completed data migration"]
Why this matters: [THE BUSINESS IMPACT OF THIS MILESTONE]
Time to milestone: [HOW LONG IT TOOK]
What comes next: [NEXT MILESTONE OR PHASE]

Write a brief, genuine celebration email (under 150 words) that:
1. Names the milestone specifically
2. Connects it to why it matters for their business
3. Expresses genuine enthusiasm (not just "congrats!")
4. Points forward to what comes next

Milestones are moments of momentum. Make the customer feel the progress.
```

---

**Prompt 14: Champion Enablement Email**

*When to use: Equipping a customer champion to advocate for your product internally*

```
Write an email enabling a customer champion to advocate for your product internally.

Customer champion: [NAME, TITLE at COMPANY]
Product: [PRODUCT]
Their internal audience: [WHO THEY NEED TO CONVINCE OR INFORM — leadership, other teams, budget decision-maker]
Key value points for their context: [WHAT MATTERS TO THEIR LEADERSHIP]
Resources I'm providing: [ROI DATA / CASE STUDIES / INTERNAL DECK / SPEAKING POINTS]
What I need from them: [INTERNAL PRESENTATION / RENEWAL SUPPORT / REFERENCE CALL / OTHER]

Write an email that:
1. Acknowledges their role as a champion explicitly
2. Gives them specific tools to use internally
3. Coaches them on how to present the value in their organization's language
4. Makes a specific ask that's clear and easy to fulfill
5. Offers support (happy to join a call, provide more data, etc.)

Champions win renewals. This email should make them feel empowered, not tasked.
```

---

**Prompt 15: Onboarding Survey / Feedback Request**

*When to use: Gathering feedback at the end of onboarding*

```
Write an onboarding feedback survey email.

Customer: [COMPANY NAME]
Contact: [NAME]
Onboarding completion date / milestone: [DATE OR EVENT]
Survey platform: [TYPEFORM / GOOGLE FORM / IN-EMAIL / OTHER — with link placeholder]
Survey length: [3-5 QUESTIONS / ~3 MINUTES]
What feedback you want: [SPECIFIC AREAS — support quality, time to value, training effectiveness]

Write an email that:
1. Frames the feedback as important to improving their experience and future customers
2. Notes the time commitment (3 minutes — don't say "quick survey" without a specific time)
3. Makes the request feel personal, not automated
4. Includes the link prominently
5. Thanks them in advance

Also draft 5 specific survey questions you'd include for an onboarding feedback survey.
```

---

**Prompt 16: User Adoption Nudge Email**

*When to use: A specific feature or workflow is not being used by the customer*

```
Write an email nudging a customer to adopt a feature they're not using.

Customer: [COMPANY NAME]
Contact: [NAME or "the team"]
Underused feature: [FEATURE NAME AND BRIEF DESCRIPTION]
Why they bought it / why it's relevant to them: [THEIR USE CASE]
What they're missing out on: [THE BUSINESS IMPACT OF NOT USING IT]
How to get started: [SIMPLE FIRST STEP]
Resources: [HELP ARTICLE / VIDEO / OFFER TO SHOW THEM]

Write an email that:
1. Opens with their business outcome (not "I noticed you haven't used X")
2. Connects the feature directly to what they're trying to accomplish
3. Makes the first step feel easy (not a project)
4. Offers a short 15-minute walkthrough if they want
5. Is brief — under 200 words

Don't lead with the feature. Lead with what they're trying to accomplish and how this makes it easier.
```

---

**Prompt 17: Onboarding Stakeholder Update (Internal)**

*When to use: Updating your internal team on a key onboarding customer's status*

```
Write an internal stakeholder update for a strategic onboarding customer.

Customer: [COMPANY NAME]
ACV: [$AMOUNT]
Onboarding phase: [PHASE 1 / 2 / 3 — DAY X OF Y]
Health status: [GREEN / YELLOW / RED]
Key milestones this period: [WHAT'S BEEN ACCOMPLISHED]
Open risks: [WHAT COULD GO WRONG — and mitigation]
Next 30-day priorities: [WHAT WE'RE FOCUSED ON]
Support needed from internal team: [PRODUCT BUG / EXECUTIVE CALL / TECHNICAL RESOURCES]

Write a clear, scannable internal update that:
1. Leads with the health status (green/yellow/red) and why
2. Summarizes progress in bullet form
3. Calls out risks specifically with mitigation plans
4. Identifies any internal support needed
5. States next priorities clearly

No fluff. Internal updates are read quickly.
```

---

**Prompt 18: Onboarding Retrospective Invitation**

*When to use: Inviting a customer to a 90-day onboarding retrospective*

```
Write an invitation email for a 90-day onboarding retrospective.

Customer: [COMPANY NAME]
Contact: [NAME]
Days since go-live: [APPROXIMATELY 90]
What we want to discuss: [WHAT'S WORKING, WHAT COULD BE BETTER, WHAT'S NEXT]
Meeting format: [VIDEO / PHONE]
Duration: [30-45 MINUTES]
What they'll get from it: [ADJUSTED SUCCESS PLAN / CLEAR ROADMAP / MY COMMITMENT TO THEIR GOALS]

Write an invitation that:
1. Frames the retrospective as a celebration of 90 days and a forward-looking planning session
2. Notes specifically what you'll discuss (they need a reason to show up)
3. Keeps the ask low-friction (30-45 minutes — not a big deal)
4. Shows that their feedback genuinely shapes how you support them

Under 200 words.
```

---

**Prompt 19: Reference Request During Onboarding**

*When to use: Asking a happy early customer for a reference or testimonial*

```
Write a reference or testimonial request during onboarding.

Customer: [COMPANY NAME]
Contact: [NAME]
What they're excited about (specific): [WHAT THEY'VE SAID OR SHOWN ENTHUSIASM FOR]
What type of reference I want: [CASE STUDY / WRITTEN TESTIMONIAL / REFERENCE CALL / G2 REVIEW / LOGO USE]
What they'd need to do: [TIME COMMITMENT / PROCESS]
What they get in return: [RECOGNITION / EARLY ACCESS / NOTHING TO OFFER — BE HONEST]

Write a brief, genuine request that:
1. References their specific enthusiasm (shows I'm paying attention)
2. States exactly what I'm asking for and how long it takes
3. Is clearly optional — no pressure
4. Expresses genuine appreciation

Under 150 words. Referencing their enthusiasm specifically is the difference between "feels transactional" and "feels like they value our relationship."
```

---

**Prompt 20: Onboarding Completion Certificate / Recognition**

*When to use: Formally marking the end of the onboarding phase and transition to growth*

```
Write an onboarding completion communication.

Customer: [COMPANY NAME]
Contact: [NAME]
Onboarding accomplishments: [LIST WHAT THEY ACHIEVED — users trained, workflows live, metrics hit]
Time to full adoption: [NUMBER OF DAYS/WEEKS]
Transition to: [ONGOING CSM RELATIONSHIP / NEW CSM / SHARED SUCCESS MODEL]
What changes: [CADENCE / POINT OF CONTACT / FOCUS]
Next phase focus: [OPTIMIZATION / EXPANSION / SPECIFIC GOALS]

Write a communication that:
1. Formally celebrates the end of onboarding with genuine recognition
2. Summarizes what they've accomplished specifically
3. Clearly explains what changes now (cadence, relationship model)
4. Sets the focus for the next phase
5. Expresses commitment to their long-term success

This is a milestone moment. Make it feel like one.
```

---

**Prompt 21: Disengaged Contact Re-Engagement**

*When to use: A customer's main contact has gone dark during onboarding*

```
Write a re-engagement email for a contact who has gone quiet during onboarding.

Customer: [COMPANY NAME]
Contact who has gone quiet: [NAME]
Last interaction: [DATE AND WHAT WAS DISCUSSED]
Where they are in onboarding: [WHAT'S PAUSED]
Impact of delay: [WHAT'S BEING HELD UP]
Possible reasons for silence: [BUSY / INTERNAL CHANGE / LOST ENTHUSIASM / UNKNOWN]

Write an email that:
1. Is brief and warm — no accusation or passive aggression
2. Gives a specific reason to respond (something they're missing, not just a check-in)
3. Removes friction (offers alternative contacts, flexibility, or a quick call)
4. Acknowledges that things get busy
5. Gives them an easy out (if priorities have changed, let's discuss)

Under 150 words. Simple ask, easy to respond to.
```

---

**Prompt 22: Multi-Site or Multi-Team Rollout Plan Email**

*When to use: Planning an onboarding rollout across multiple teams or locations*

```
Write a multi-team onboarding rollout plan communication.

Customer: [COMPANY NAME]
Total teams/sites: [NUMBER]
Rollout strategy: [PHASED BY TEAM / ALL AT ONCE / PILOT TEAM FIRST]
Pilot team: [FIRST TEAM — name, size, location]
Phase timeline: [DATES FOR EACH PHASE]
Training model: [TRAIN-THE-TRAINER / CSM TRAINS ALL / HYBRID]
Key risks of this rollout: [WHAT COULD GO WRONG]
Change management support needed: [HOW WE CAN HELP THEM MANAGE INTERNAL CHANGE]

Write a rollout plan email that:
1. Confirms the agreed rollout strategy
2. Shows the phase timeline clearly
3. Identifies who owns what at each phase
4. Notes the key risks and how we'll manage them
5. Commits to specific support at each phase
6. Sets up a coordination rhythm (weekly check-in, Slack channel, etc.)
```

---

**Prompt 23: New User Welcome Email (Automated / Scalable)**

*When to use: Writing an automated welcome email for individual new users within an account*

```
Write an automated welcome email for individual end users who are newly added to an account.

Product: [PRODUCT NAME]
User type: [ROLE — e.g., sales rep, project manager, support agent]
What they should do first: [THE SINGLE MOST IMPORTANT FIRST ACTION]
Resources to help: [HELP CENTER / QUICK START VIDEO — link placeholders]
Support option: [HOW TO GET HELP]
Company or team name: [THEIR TEAM OR OUR COMPANY — or both]

Write an email that:
1. Welcomes them warmly but briefly
2. Tells them exactly what to do first (one action — not a list)
3. Gives them 1 resource to reference
4. Tells them how to get help
5. Is under 150 words

This email will be seen by hundreds of users. It must be simple, warm, and immediately actionable.
```

---

**Prompt 24: Onboarding Risk Flag to Internal Team**

*When to use: Escalating an at-risk onboarding internally*

```
Write an internal escalation note for an onboarding account that is at risk.

Customer: [COMPANY NAME]
ACV: [$AMOUNT]
Risk description: [WHAT IS GOING WRONG — specifically]
Root cause (if known): [WHY IS IT HAPPENING]
Customer sentiment: [HOW ARE THEY FEELING — frustrated, patient, unresponsive]
Impact if not resolved: [WHAT HAPPENS — delayed go-live, churn risk, executive escalation]
What I've tried: [WHAT YOU'VE DONE ALREADY]
What I need from the team: [SPECIFIC ASK — engineering support, exec call, product team input]
Timeline urgency: [HOW SOON DOES THIS NEED RESOLUTION]

Write a brief escalation note (for Slack, email, or a risk log) that:
1. States the issue and impact clearly
2. Names what's been tried
3. Makes a specific request of the team
4. Includes a timeline

Internal escalations need to be specific and actionable — not just "this is going badly."
```

---

**Prompt 25: Onboarding Success Story (Internal)**

*When to use: Documenting a successful onboarding for internal learning or case study seed material*

```
Write an internal onboarding success story.

Customer: [COMPANY NAME]
Industry: [INDUSTRY]
Use case: [PRIMARY USE CASE]
Onboarding timeline: [DAYS TO FULL ADOPTION]
Key accomplishments: [LIST — metrics, milestones, outcomes]
What went well: [SPECIFIC PRACTICES THAT WORKED]
What was challenging: [WHAT WAS HARD AND HOW WE NAVIGATED IT]
Quote from customer (if any): [DIRECT QUOTE — or "obtain quote"]
CSM on the account: [YOUR NAME]

Write an internal success story (1 page) that:
1. Describes the customer context briefly
2. Tells the onboarding story with specific milestones
3. Highlights what made this onboarding successful
4. Notes key learnings to apply to future accounts
5. Seeds any external case study potential

Internal stories build institutional knowledge. Write it while the details are fresh.
```

---

*Next: `03-retention-health-prompts.md` → 23 prompts for QBRs, health scores, and proactive retention*
