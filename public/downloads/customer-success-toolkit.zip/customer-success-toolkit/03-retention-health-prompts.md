# 03 — Retention & Health Prompts

*23 prompts for QBRs, health monitoring, proactive check-ins, and relationship management*

---

**Prompt 1: QBR Agenda and Deck Outline**

*When to use: Preparing a Quarterly Business Review*

```
Create a Quarterly Business Review agenda and talking points.

Customer: [COMPANY NAME]
Quarter: [Q + YEAR]
Attendees (customer): [NAMES AND ROLES]
Attendees (our side): [YOUR TEAM]
Duration: [45-60 MINUTES]
Customer's goals (what they said at last QBR or during onboarding): [LIST THEIR GOALS]
Progress made this quarter: [METRICS / OUTCOMES / MILESTONES]
Product usage summary: [KEY USAGE STATS — active users, adoption %, key features used]
Open support issues or concerns: [ANY CURRENT FRICTION]
Expansion opportunity: [ANY OPPORTUNITY TO DISCUSS]

Create a QBR outline:
1. **Business Review** (15 min) — How are we doing vs. their stated goals?
2. **Product & Usage Review** (10 min) — What's working, what's not?
3. **Value Realized** (10 min) — Specific business impact and ROI
4. **Roadmap Preview** (5 min) — What's coming they should know about
5. **Success Plan for Next Quarter** (10 min) — What we'll focus on together
6. **Open Discussion** (10 min) — Their questions, concerns, requests

For each section: 3-4 specific talking points and 2 questions to ask the customer.

The goal of a QBR is to show you're a business partner, not just a vendor checking in.
```

---

**Prompt 2: Business Value / ROI Review Email**

*When to use: Sending a value summary ahead of a renewal or QBR*

```
Write a business value review email.

Customer: [COMPANY NAME]
Contact: [NAME]
Time period: [LAST QUARTER / YEAR]
Metrics to highlight:
- Users: [ACTIVE USERS / TOTAL LICENSED]
- Key feature adoption: [SPECIFIC FEATURES AND USAGE RATES]
- Business outcomes: [WHAT THEIR BUSINESS ACHIEVED — time saved, revenue impacted, costs reduced]
- Support: [TICKETS RESOLVED / UPTIME / CSAT]
Their primary goal when they bought: [WHAT THEY SAID THEY WANTED]
Progress toward that goal: [SPECIFIC, HONEST ASSESSMENT]

Write an email that:
1. Opens with their business outcome — not product metrics
2. Shows the data in plain language ("your team processed 2,400 requests this quarter vs. 400 before the platform")
3. Connects usage to business value (not "you used the API 50,000 times" — "your team automated 80% of manual ticket routing")
4. Acknowledges any gaps honestly
5. Sets up a conversation about the next quarter
6. Is under 300 words — this is an appetizer before the QBR, not the meal
```

---

**Prompt 3: Health Score Decline Outreach**

*When to use: A customer's health score has dropped — proactive outreach before they call you*

```
Write a proactive outreach email for a customer whose health score has dropped.

Customer: [COMPANY NAME]
Contact: [NAME]
Health score change: [FROM X TO Y]
What drove the decline: [LOW USAGE / SUPPORT TICKETS / MISSED MILESTONES / SURVEY RESPONSE / OTHER]
What I know about their situation: [ANY CONTEXT — internal change, busy period, specific issue]
What I want to accomplish: [UNDERSTAND THE SITUATION / OFFER SUPPORT / BOOK A CALL]

Write an email that:
1. Doesn't mention the "health score" — that's internal language
2. Leads with a genuine check-in based on what you observe
3. Names the specific signal you're seeing (e.g., "I noticed activity dropped in the past few weeks")
4. Asks an open question — don't assume you know why
5. Offers a specific type of help
6. Is brief and feels human, not like a system-triggered automation

Under 200 words.
```

---

**Prompt 4: Executive Business Review Prep**

*When to use: Preparing for a C-suite or VP-level business review*

```
Write preparation materials for an executive business review.

Customer: [COMPANY NAME]
Executive attendee: [NAME, TITLE]
Our executive: [NAME, TITLE]
Meeting duration: [30-45 MINUTES]
Customer's top business priorities: [THEIR COMPANY'S STRATEGIC FOCUS — not just product use]
Value we've delivered in business terms: [OUTCOMES IN BUSINESS LANGUAGE — not feature adoption]
Risk or concern to address: [ANYTHING THAT NEEDS EXEC ATTENTION]
Our ask: [RENEWAL / EXPANSION / STRATEGIC PARTNERSHIP / REFERENCE]

Create:
1. A 5-point meeting agenda (executive appropriate — no feature demos)
2. Talking points for each agenda item (crisp, business-outcome language)
3. The 3 key messages we want them to leave with
4. How to handle likely executive questions or pushback
5. A clear ask and how to make it

Executive meetings are measured in ROI and strategic value. Lead with both.
```

---

**Prompt 5: Proactive Monthly Check-In Email**

*When to use: Regular scheduled check-in with a healthy customer*

```
Write a proactive monthly check-in email.

Customer: [COMPANY NAME]
Contact: [NAME]
Current health status: [HEALTHY — this is a routine proactive outreach]
Key usage update: [1-2 DATA POINTS — positive indicators]
Something specific to mention: [PRODUCT UPDATE / UPCOMING WEBINAR / RELEVANT RESOURCE / THEIR INDUSTRY NEWS]
Open items: [ANY OUTSTANDING ACTIONS OR FOLLOW-UPS]
Ask: [SCHEDULE A CALL / CONFIRM STATUS / NO SPECIFIC ASK]

Write a check-in that:
1. Does NOT start with "just checking in" — give a specific reason
2. Leads with something relevant to them (a usage insight, a news item, a product update)
3. Shows a specific usage metric or positive signal
4. Asks one focused question or proposes one next step
5. Is under 150 words

The best check-in emails feel like they came from someone who pays attention. Make it obvious you do.
```

---

**Prompt 6: NPS Detractor Follow-Up**

*When to use: A customer gives you a 0-6 NPS score*

```
Write a follow-up email for an NPS detractor.

Customer: [COMPANY NAME]
NPS respondent: [NAME, TITLE]
Their score: [0-6]
Their verbatim feedback (if any): [WHAT THEY WROTE]
What I know about their account: [RECENT HISTORY — issues, usage, support tickets]
My goal: [UNDERSTAND THE ROOT CAUSE / FIX THE RELATIONSHIP / PREVENT CHURN]

Write an email that:
1. Thanks them for their honest feedback (specifically — don't be generic)
2. Acknowledges the low score without defensiveness
3. Asks ONE open question to understand the root cause
4. Offers a call to discuss (makes it feel like they matter, not like you're fixing a metric)
5. Does NOT explain or defend yourself in the first email — listen first

Under 150 words. The first response is about listening, not fixing.
```

---

**Prompt 7: Proactive Risk Communication to Internal Team**

*When to use: Flagging a customer risk to your manager or team*

```
Write an internal risk flag for a customer account.

Customer: [COMPANY NAME]
ACV: [$AMOUNT]
Contract end date: [DATE]
Risk level: [LOW / MEDIUM / HIGH / CRITICAL]
Risk indicators: [SPECIFIC SIGNALS — low login, bad NPS, open tickets, champion departure, budget cuts]
Root cause hypothesis: [WHY THIS IS HAPPENING]
What I've done: [OUTREACH, CALLS, ACTIONS TAKEN]
What I need: [INTERNAL SUPPORT — exec call, product roadmap info, pricing flexibility, escalation]
My confidence in renewal: [X%]

Write a concise internal risk note (for Slack, risk review, or email) that:
1. Names the risk and evidence clearly
2. States root cause hypothesis
3. Lists actions already taken
4. Makes a specific internal ask
5. Notes the timeline urgency

No fluff — internal risk flags need to generate action, not discussion.
```

---

**Prompt 8: Annual Success Report**

*When to use: Sending customers an annual summary of value delivered*

```
Write an annual customer success report.

Customer: [COMPANY NAME]
Year: [YEAR]
Their goals at the start of the year: [WHAT THEY WANTED TO ACHIEVE]
Value delivered:
- Users trained / active: [NUMBERS]
- Key workflows automated or improved: [SPECIFIC]
- Support metrics: [CSAT / RESPONSE TIME / RESOLUTION RATE]
- Business outcomes achieved: [SPECIFIC — time saved, revenue impacted, cost reduction]
Milestones hit this year: [LIST]
What we're proud of: [THE MOST IMPACTFUL THING WE DID FOR THEM]
Challenges we navigated: [HONEST MENTION OF HARD MOMENTS AND HOW WE RESOLVED THEM]
Focus for next year: [2-3 PRIORITIES]

Write a 1-page annual report that:
1. Leads with their business outcomes — not our product metrics
2. Shows progress toward their original goals
3. Acknowledges challenges honestly
4. Frames the relationship as a partnership
5. Sets up the next year's conversation

This should make the buyer feel the ROI was real.
```

---

**Prompt 9: Champion Departure Risk Management Email**

*When to use: Your customer champion leaves the company or changes roles*

```
Write an email addressing a champion departure at a customer account.

Departing champion: [NAME, TITLE]
New context: [THEY LEFT THE COMPANY / CHANGED ROLES / ON LEAVE]
Relationship history: [HOW LONG / WHAT WE'VE BUILT TOGETHER]
Current renewal timeline: [MONTHS UNTIL RENEWAL]
Who I know at the account: [OTHER CONTACTS — any relationship?]
What I need: [TRANSITION TO NEW CHAMPION / EXECUTIVE INTRODUCTION / MAINTAIN CONTINUITY]

Write an email to the departing champion (if appropriate) or to the account leadership:

Option A (to departing champion):
- Thank them for the partnership
- Wish them well genuinely
- Ask for a warm introduction to who's taking over
- Keep it under 150 words

Option B (to account leadership when champion has already left):
- Acknowledge the transition
- Reintroduce my role and commitment
- Request a brief call to ensure continuity
- Express specific interest in the account's success

Write both options.
```

---

**Prompt 10: Competitive Displacement Defense**

*When to use: A customer mentions they're evaluating a competitor*

```
Write a response email for a customer who mentions they're evaluating a competitor.

Customer: [COMPANY NAME]
Contact: [NAME]
Competitor mentioned: [NAME — or "an alternative solution"]
What they said: [EXACT OR PARAPHRASED — their concern or reason for looking]
The real issue (if you know it): [WHAT'S ACTUALLY DRIVING THE EVALUATION — price, missing feature, internal politics]
Our strengths vs. competitor: [KEY DIFFERENTIATORS]
What I want to do: [SCHEDULE A CALL / BRING IN SALES / ESCALATE INTERNALLY / UNDERSTAND BETTER FIRST]

Write an email that:
1. Does NOT panic or immediately start selling
2. Acknowledges their concern genuinely
3. Asks a clarifying question to understand what's driving the evaluation
4. Expresses confidence without being defensive
5. Proposes a call to ensure we understand their needs fully
6. Does NOT badmouth the competitor

Under 200 words. Keep the relationship first.
```

---

**Prompt 11: Success Plan Update After Business Change**

*When to use: A customer's business has changed significantly — merger, reorg, strategy shift*

```
Write an email updating the success plan after a significant business change at a customer.

Customer: [COMPANY NAME]
Change: [MERGER / ACQUISITION / REORG / BUDGET CUT / STRATEGY SHIFT / TEAM CHANGE — describe]
Impact on their use of our product: [HOW DOES THIS CHANGE THEIR NEEDS]
Impact on our relationship: [NEW STAKEHOLDERS / REDUCED SCOPE / EXPANDED OPPORTUNITY]
What I propose: [UPDATED SUCCESS PLAN / REVISED ENGAGEMENT MODEL / CONVERSATION TO ALIGN]

Write an email that:
1. Acknowledges the change and its significance to their business
2. Notes the potential impact on our partnership
3. Proposes a conversation to realign on goals and success metrics
4. Shows flexibility — we adapt to their needs, not vice versa
5. Expresses continued commitment

Business changes create uncertainty. Show up with clarity and commitment.
```

---

**Prompt 12: Usage Report and Insights Email**

*When to use: Sending a regular usage report to a customer*

```
Write a usage insights email for a customer.

Customer: [COMPANY NAME]
Contact: [NAME]
Time period: [MONTH / QUARTER]
Usage highlights:
- Active users: [X of Y licensed]
- Most used features: [LIST]
- Underused features: [LIST — with context on why they should care]
- Trends: [INCREASING / DECREASING / STABLE — specific]
Business connection: [HOW DOES THIS USAGE DATA CONNECT TO THEIR STATED GOALS?]
One action recommendation: [WHAT SHOULD THEY DO BASED ON THIS DATA]

Write an email that:
1. Leads with the insight, not the raw data ("Your team automated X requests this month")
2. Connects usage trends to business outcomes
3. Specifically calls out one underused feature with a business reason to use it
4. Makes one clear recommendation
5. Is scannable — use numbers, bold, and short sentences

Usage reports that feel like billing statements don't get read. Usage reports that feel like advice do.
```

---

**Prompt 13: Case Study Request Email**

*When to use: Asking a healthy customer to participate in a case study*

```
Write a case study request email.

Customer: [COMPANY NAME]
Contact: [NAME]
Results they've achieved: [SPECIFIC OUTCOMES — metrics, milestones, business impact]
Case study format: [WRITTEN / VIDEO / WEBINAR FEATURE / SPEAKING OPPORTUNITY]
What's involved: [30-45 MIN INTERVIEW / REVIEW AND APPROVAL / SPECIFIC TIME ASK]
What they get: [RECOGNITION / CO-MARKETING / EARLY PRODUCT ACCESS / NOTHING — BE HONEST]
Timeline: [WHEN YOU NEED THIS]

Write an email that:
1. Opens with a genuine compliment about their specific results (use their data)
2. Frames it as sharing their story, not promoting our product
3. States exactly what's involved and how long it takes
4. Shares what they'll get in return
5. Makes it easy to say yes (or easy to decline)

Under 200 words. The best case study requests feel like a recognition, not a request.
```

---

**Prompt 14: "Why We Partner With You" Relationship Email**

*When to use: Reinforcing the value of the relationship at a key moment — before renewal, after a challenge*

```
Write a relationship-reinforcing email.

Customer: [COMPANY NAME]
Contact: [NAME]
Timing: [BEFORE RENEWAL / AFTER RESOLVING A HARD ISSUE / ANNIVERSARY / RELATIONSHIP LOW POINT]
What the partnership has accomplished: [SPECIFIC VALUE — their outcomes, not our metrics]
What I appreciate about working with them: [SOMETHING GENUINE AND SPECIFIC]
Where we're going together: [FORWARD-LOOKING STATEMENT]

Write an email that:
1. Is genuine — not a form email
2. References something specific about this customer (shows you know them)
3. Summarizes the partnership value honestly
4. Looks forward with specific intent
5. Is brief — under 200 words

Relationship emails work when they feel like they came from a human who cares. Don't let this one feel like a template.
```

---

**Prompt 15: Low Usage / Dormant Account Intervention**

*When to use: An account has very low or declining usage — potential churn risk*

```
Write an intervention email for a low-usage or dormant account.

Customer: [COMPANY NAME]
Contact: [NAME]
Usage status: [NO LOGINS IN X DAYS / USAGE DOWN X% / ONLY X% OF USERS ACTIVE]
Contract value: [$AMOUNT]
Renewal date: [DATE]
Last meaningful interaction: [DATE AND TOPIC]
Possible causes: [BUSY SEASON / INTERNAL CHANGE / LOST INTEREST / UNKNOWN]
What I'm offering: [RE-ONBOARDING / NEW TRAINING / EXECUTIVE CALL / QUICK WIN SESSION]

Write an email that:
1. Opens with a genuine check-in — not an accusation about low usage
2. Mentions the usage observation naturally (not as a gotcha)
3. Offers a specific, low-friction path to getting value again
4. Doesn't panic or over-offer — one clear option
5. Gives them an easy out if their needs have changed

Dormant accounts often just need one clear reason to reengage. Provide it.
```

---

**Prompt 16: Post-Escalation Relationship Recovery Email**

*When to use: After resolving a difficult issue, working to rebuild trust*

```
Write a post-escalation relationship recovery email.

Customer: [COMPANY NAME]
Contact: [NAME]
What happened: [THE ISSUE — briefly and factually]
How it was resolved: [SPECIFIC RESOLUTION]
Root cause: [WHY IT HAPPENED]
What we've changed: [SPECIFIC PROCESS, PRODUCT, OR SUPPORT IMPROVEMENT]
Timeline of resolution: [FROM ISSUE RAISED TO RESOLVED]
Current relationship status: [STABLE / STILL FRAGILE / UNCLEAR]

Write an email that:
1. Acknowledges the experience from their perspective
2. Summarizes the resolution clearly
3. Explains what changed specifically to prevent recurrence
4. Thanks them for their patience honestly
5. Expresses commitment to the relationship going forward
6. Does NOT over-apologize or be sycophantic — be direct and sincere

Under 300 words. Recovery emails that wallow in the problem make things worse. This one moves forward.
```

---

**Prompt 17: Customer Advisory Board Invitation**

*When to use: Inviting select customers to a customer advisory board or council*

```
Write a Customer Advisory Board invitation.

Customer: [COMPANY NAME]
Contact: [NAME]
Why they're selected: [WHAT MAKES THEM VALUABLE FOR THE CAB — tenure, use case, influence, results]
CAB overview: [WHAT THE CAB IS / HOW OFTEN IT MEETS / FORMAT]
What we're asking of them: [TIME COMMITMENT / NUMBER OF SESSIONS / PREP REQUIRED]
What they get: [PRODUCT ROADMAP INPUT / PEER NETWORK / EXECUTIVE ACCESS / RECOGNITION]
First session: [DATE AND FORMAT]

Write an invitation that:
1. Makes them feel genuinely selected — not mass-invited
2. Clearly explains what the CAB does and what membership means
3. States the time commitment honestly
4. Shows what they'll get in return (access, influence, community)
5. Makes it easy to accept or ask questions

Under 250 words. Being on a CAB should feel like an honor. Write it that way.
```

---

**Prompt 18: Stakeholder Change — New Contact Outreach**

*When to use: A new stakeholder joins the customer account and needs to be onboarded to the relationship*

```
Write an introduction email to a new stakeholder at an existing customer account.

Customer: [COMPANY NAME]
New contact: [NAME, TITLE]
How long they've been with the account: [JUST JOINED / PROMOTED / TRANSFERRED FROM OTHER TEAM]
What I know about them: [ANY CONTEXT — referred by champion, LinkedIn research, etc.]
Our account history: [BRIEF — what we've accomplished with this customer]
What I want from this first email: [INTRODUCE MYSELF / SCHEDULE A BRIEF CALL / OFFER VALUE]

Write an email that:
1. Introduces myself and my role in their success
2. Briefly mentions what we've built with their team
3. Offers something specific — an overview session, relevant resources, an intro call
4. Is brief — new stakeholders have a lot of new vendor relationships to manage
5. Doesn't assume they care yet — earn it

Under 200 words.
```

---

**Prompt 19: Mutual Success Plan Review**

*When to use: Reviewing and updating the customer's success plan mid-year*

```
Write a mutual success plan update email and document.

Customer: [COMPANY NAME]
Contact: [NAME]
Original success goals: [WHAT YOU AGREED ON AT START OF YEAR / CONTRACT]
Progress: [WHAT'S BEEN ACCOMPLISHED — against each goal]
Goals that need updating: [WHAT HAS CHANGED — new priorities, completed goals, pivot]
New or revised goals for second half: [UPDATED PRIORITIES]
Support needed from us: [WHAT WE NEED TO DO]
Support needed from them: [WHAT THEY NEED TO DO]

Write an email + updated success plan document that:
1. Celebrates progress honestly
2. Acknowledges any goals that aren't on track
3. Proposes updated goals that reflect current reality
4. Assigns clear ownership (us vs. them) for each goal
5. Frames this as an ongoing partnership tool, not a compliance document

A success plan that nobody looks at after onboarding isn't a plan. Update it regularly.
```

---

**Prompt 20: Internal Account Review for CSM Team**

*When to use: Preparing an account review for your team's weekly or monthly internal review meeting*

```
Write an internal account review for [COMPANY NAME].

CSM: [YOUR NAME]
Customer: [COMPANY NAME]
ACV: [$AMOUNT]
Renewal date: [DATE]
Renewal likelihood: [HIGH / MEDIUM / LOW — X% confidence]
Health score: [GREEN / YELLOW / RED]
Key accomplishments this quarter: [LIST]
Current risks: [LIST — specific]
Open actions: [WHAT YOU'RE DOING NEXT]
Support needed from team: [IF ANY]
Expansion opportunity: [YES / NO / MAYBE — describe]

Format as a 1-page account review ready for a 5-minute team discussion. Scannable format — use bullets.

Key question for team input: [WHAT SPECIFIC GUIDANCE DO YOU NEED?]
```

---

**Prompt 21: Customer Health Newsletter / Segment Update**

*When to use: Sending a value-add newsletter to a segment of your book of business*

```
Write a customer segment newsletter or update email.

Segment: [ENTERPRISE / MID-MARKET / SPECIFIC INDUSTRY / SPECIFIC USE CASE]
Topic: [PRODUCT UPDATE / INDUSTRY INSIGHT / BEST PRACTICE / UPCOMING WEBINAR]
Key content: [DESCRIBE THE MAIN CONTENT]
Value for this segment specifically: [WHY DOES THIS MATTER TO THEM?]
Call to action: [REGISTER / READ / RESPOND / SCHEDULE A CALL]
Sender: [CSM NAME or TEAM]

Write a brief newsletter email (under 300 words) that:
1. Leads with something relevant to this specific segment (not generic)
2. Delivers genuine value in 2-3 bullets or a short paragraph
3. Has one clear CTA
4. Feels personal — like it was written for their type of business

The best segment newsletters make recipients think "this was written for me." Achieve that.
```

---

**Prompt 22: Feedback on Product Feature Request**

*When to use: Following up with a customer who submitted a feature request*

```
Write an email following up on a customer's product feature request.

Customer: [COMPANY NAME]
Contact: [NAME]
Feature requested: [DESCRIBE THEIR REQUEST]
Status: [ON ROADMAP — Q[X] / UNDER CONSIDERATION / NOT ON ROADMAP CURRENTLY / ALREADY EXISTS]
Why this matters to them: [THEIR USE CASE AND BUSINESS IMPACT]
Alternative solution (if applicable): [WORKAROUND OR EXISTING FEATURE THAT HELPS]
My role: [CSM PASSING FEEDBACK TO PRODUCT / PRODUCT DECISION ALREADY MADE]

Write an email that:
1. Thanks them for the specific request
2. Gives them the honest status (don't oversell "under consideration" as "on the roadmap")
3. If not on roadmap: acknowledges the gap honestly and offers the workaround
4. If on roadmap: gives what detail you can without creating false expectations
5. Commits to following up when there's a status change
6. Shows the feedback loop is real

Feature request follow-ups build trust when they're honest. They destroy trust when they overpromise.
```

---

**Prompt 23: Retention Risk Assessment Summary**

*When to use: Creating a risk summary for a potentially churning customer*

```
Write a retention risk assessment for a customer account.

Customer: [COMPANY NAME]
Contract value: [$AMOUNT]
Renewal date: [DATE]

Risk signals:
- Usage trend: [DESCRIBE]
- Engagement (calls, emails, QBR attendance): [DESCRIBE]
- Support issues: [ANY OPEN OR RECENT ESCALATIONS]
- Champion status: [STABLE / AT RISK / DEPARTED]
- Budget / economic health: [ANY KNOWN CHANGES]
- Competitor activity: [ANY KNOWN EVALUATION]
- NPS / survey feedback: [SCORE AND VERBATIM]

Write a risk assessment (for internal use) that:
1. Assigns an overall risk level (Low / Medium / High / Critical)
2. Names the primary risk driver
3. Estimates renewal probability
4. Outlines the retention play (what you'll do to save this)
5. States what you need from the team
6. Sets a timeline for the save attempt

Use this as the basis for your next internal account review. Be honest — sugar-coating risk assessments is how churn surprises everyone.
```

---

*Next: `04-expansion-upsell-prompts.md` → 22 prompts for expansion plays, upsell emails, and ROI reviews*
