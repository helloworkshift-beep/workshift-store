# PRODUCT INFO — The Customer Success Manager's AI Prompt Toolkit

| Field | Value |
|-------|-------|
| **Product Name** | Customer Success Manager's AI Prompt Toolkit |
| **Price** | $57 |
| **Format** | 7 Markdown files |
| **Total Prompts** | 95+ |

## Sales Description

CSMs spend too much time writing the same emails, building the same QBR decks, and crafting the same "just checking in" messages that never quite land. The work that actually drives retention — proactive outreach, risk identification, expansion conversations, and meaningful QBRs — keeps getting squeezed.

**The Customer Success Manager's AI Prompt Toolkit** gives you 95+ prompts built for real CSM workflows: onboarding sequences, quarterly business reviews, health score outreach, renewal campaigns, escalation scripts, and expansion plays — all ready to customize and send.

**Stop writing. Start retaining.**

## Target Audience

CSMs and Account Managers at B2B SaaS companies managing 20-100+ accounts. Responsible for onboarding, retention, expansion, and renewal metrics.

## Files

| File | Prompts |
|------|---------|
| `01-quick-start-guide.md` | Setup |
| `02-onboarding-prompts.md` | 25 |
| `03-retention-health-prompts.md` | 23 |
| `04-expansion-upsell-prompts.md` | 22 |
| `05-escalation-renewal-prompts.md` | 20 |
| `06-workflow-sops.md` | 5 SOPs |
| `07-cheat-sheet.md` | 15 + rules |

*Last updated: March 2026*
