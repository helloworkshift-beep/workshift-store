# 01 — Quick Start Guide

*How to get maximum value from this toolkit in the first 10 minutes*

---

## The 3-Minute Setup

### Step 1: Pick Your AI Tool
- **ChatGPT (GPT-4o)** — Best for email drafts and quick outreach
- **Claude (Sonnet or Opus)** — Best for QBRs, business reviews, and strategic communication
- **Gemini Advanced** — Good for data analysis and structured reports

### Step 2: Set a System Prompt

```
You are an experienced Customer Success Manager at a B2B SaaS company. You write with empathy, professionalism, and a bias toward customer outcomes over product features. You understand that customers measure success by business results, not product usage metrics. Your communications build trust, drive adoption, and protect and grow revenue. When I give you a prompt, produce clean, professional output I can use immediately — no filler or generic "hope you're doing well" openers.
```

**Customize:**
```
You are a CSM at [COMPANY NAME], a [PRODUCT DESCRIPTION] for [CUSTOMER TYPE]. My book of business covers [SEGMENT — enterprise / mid-market / SMB]. My key metrics are [NRR / GRR / NPS / QBR completion rate]. My communication style is [DIRECT / WARM / CONSULTATIVE].
```

### Step 3: Fill In the Brackets

**Bad:** `[CUSTOMER] = our customer`

**Good:** `[CUSTOMER] = Apex Logistics, a 200-person freight brokerage using our TMS platform since January 2025. Their main contact is Diana Reyes, VP of Operations. They have 45 active users. Their primary use case is carrier dispatch automation. They've had one escalation related to integration delay.`

---

## Power Techniques

### Technique 1: QBR in 4 Prompts
1. Use Retention Prompt #1 to build the QBR agenda
2. Use Retention Prompt #2 to write the business review narrative
3. Use Retention Prompt #3 to generate the ROI summary
4. Use Expansion Prompt #3 to build the expansion recommendation section

### Technique 2: At-Risk Response Protocol
When you get a bad NPS score or a red health flag:
1. Escalation Prompt #1 — identify the root cause
2. Escalation Prompt #3 — draft the recovery plan
3. Escalation Prompt #5 — write the executive check-in

### Technique 3: Personalize at Scale
For bulk outreach across your book:
```
Here are 5 customers and their situations: [LIST]. For each, write a personalized 3-paragraph check-in email using the same structure but reflecting their specific situation and usage.
```

---

## Common Mistakes to Avoid

❌ **Sending generic "just checking in" emails** — They don't generate responses. Every outreach needs a specific reason.

❌ **Using product metrics as the proof of value** — Customers care about their business outcomes, not your DAU numbers. Connect usage to their results.

❌ **Waiting for renewal conversations** — The best renewal conversations happen at month 3, not month 11.

❌ **Burying the ask** — If you need something (a meeting, a reference, a response), state it early and clearly.

---

## Quick Reference

| Situation | File | Prompt # |
|-----------|------|---------|
| New customer onboarding email | Onboarding | #1 |
| Kickoff meeting prep | Onboarding | #3 |
| Quarterly business review | Retention | #1 |
| At-risk customer outreach | Escalation | #1 |
| Expansion opportunity email | Expansion | #1 |
| Renewal conversation | Escalation | #10 |
| Executive sponsor outreach | Retention | #12 |
| Champion left the company | Escalation | #8 |

---

*Start with the cheat sheet. Come back to the full files for your specific situation.*
