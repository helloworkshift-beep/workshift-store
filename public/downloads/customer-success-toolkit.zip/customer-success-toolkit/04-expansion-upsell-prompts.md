# 04 — Expansion & Upsell Prompts

*22 prompts for identifying expansion opportunities, driving upsell conversations, and growing account revenue*

---

## EXPANSION IDENTIFICATION PROMPTS

---

### Account Expansion Opportunity Assessment
*Use when preparing for a QBR or account review to identify upsell potential.*

```
You are a strategic customer success manager skilled at identifying revenue expansion opportunities through customer value delivery. Analyze the following account details and produce an expansion opportunity assessment.

Account details:
- Company: [COMPANY_NAME]
- Current plan/tier: [CURRENT_PLAN]
- Contract value: [CURRENT_ARR]
- Products/modules in use: [ACTIVE_PRODUCTS]
- Products/modules NOT in use: [UNUSED_PRODUCTS]
- Team size using product: [CURRENT_SEATS_USED] out of [TOTAL_SEATS_PURCHASED]
- Usage trend (last 90 days): [INCREASING/DECREASING/FLAT]
- Primary use case: [MAIN_USE_CASE]
- Known business challenges: [CUSTOMER_PAIN_POINTS]
- Key stakeholders: [CHAMPION_NAME] ([CHAMPION_ROLE]), [EXEC_SPONSOR] ([EXEC_ROLE])
- Renewal date: [RENEWAL_DATE]

Produce:
1. Top 3 expansion opportunities ranked by likelihood to close and revenue potential
2. For each opportunity: the business case in the customer's language, the recommended timing, and the right person to have the conversation with
3. Red flags or account health concerns that need to be addressed before expansion is realistic
4. Recommended next action within the next 30 days
```

---

### Usage Gap Analysis — Upsell Trigger
*Use when a customer is underutilizing features that could drive a natural upsell conversation.*

```
You are a CSM who specializes in turning product usage data into upsell conversations that feel helpful, not pushy. Write a usage gap analysis and recommended conversation approach.

Customer: [COMPANY_NAME], [CONTACT_NAME] ([CONTACT_ROLE])
Current plan: [CURRENT_PLAN]
Features actively used: [LIST_ACTIVE_FEATURES]
Features purchased but not adopted: [LIST_UNUSED_FEATURES]
Features not yet purchased that could address their needs: [LIST_UPSELL_FEATURES]
Customer's stated goals: [CUSTOMER_GOALS]
Industry: [INDUSTRY]

Produce:
1. A 3-paragraph usage gap summary framed around their goals (not our features)
2. A recommended conversation opener for the unused features
3. A natural bridge from "you're not using X" to "here's why adding Y makes sense now"
4. The metric or outcome they should expect to see if they adopt the recommendation

Write in a tone that positions me as a trusted advisor, not a sales rep.
```

---

### Multi-Thread Expansion Strategy
*Use when you have a single champion but want to expand the account's footprint to other teams.*

```
You are a strategic account manager skilled at expanding within large organizations by building new stakeholder relationships. Create a multi-thread expansion strategy.

Current state:
- Company: [COMPANY_NAME] ([EMPLOYEE_COUNT] employees)
- Current champion: [CHAMPION_NAME], [CHAMPION_ROLE], [CHAMPION_DEPARTMENT]
- Current use case: [CURRENT_USE_CASE]
- Departments NOT yet using our product: [TARGET_DEPARTMENTS]
- Our product's value for each: [RELEVANT_VALUE_PROP_PER_DEPARTMENT]
- Known relationships at this company (beyond champion): [OTHER_KNOWN_CONTACTS]

Produce:
1. A prioritized list of the 2-3 best expansion targets (department + specific role to connect with)
2. A warm intro email my champion could forward to each target
3. A cold outreach message for departments where I have no existing relationship
4. The business case language tailored to each target department's priorities
```

---

### Expansion Opportunity from Support Ticket Pattern
*Use when you notice patterns in support tickets that signal a customer needs more capability.*

```
You are a CSM who reads between the lines of support data to identify customers who are outgrowing their current plan or configuration. Analyze this pattern and write an expansion pitch.

Customer: [COMPANY_NAME]
Recent support ticket themes (last 60 days): [TICKET_THEMES — e.g., "asking how to do X which requires Plan Y", "workarounds for feature Z"]
Number of support tickets in last 60 days: [TICKET_COUNT]
Current plan: [CURRENT_PLAN]
Plan(s) that would resolve these pain points: [UPGRADE_PLAN]
Key features in upgrade that address their pain: [UPGRADE_FEATURES]

Write:
1. A 2-paragraph internal assessment of what this pattern signals about their needs
2. A 3-4 sentence conversation opener I can use in our next call that references their support experience without making it feel like a sales pitch
3. The specific upgrade recommendation with a ROI framing in 2 sentences
```

---

## UPSELL EMAIL PROMPTS

---

### Upsell Email — Feature Value Bridge
*Use when emailing a customer about upgrading based on a specific feature they'd benefit from.*

```
Write a personalized upsell email that bridges from a customer's current situation to a specific feature in our higher tier.

Customer info:
- Name: [CONTACT_NAME], [CONTACT_ROLE] at [COMPANY_NAME]
- Current plan: [CURRENT_PLAN]
- How they're using the product today: [CURRENT_USAGE]
- Business goal they've expressed: [STATED_GOAL]
- Feature on upgrade plan that serves this goal: [UPSELL_FEATURE]
- Upgrade plan name and price: [UPGRADE_PLAN], [UPGRADE_PRICE]
- Specific outcome the feature enables: [EXPECTED_OUTCOME]
- My name and title: [MY_NAME], [MY_TITLE]

Write an email that:
1. Opens with acknowledgment of what they're achieving today (1 sentence)
2. Bridges to a gap or opportunity based on their stated goal (1-2 sentences)
3. Introduces the specific feature — not the plan — as the solution (2-3 sentences)
4. States the expected outcome in their language
5. Ends with a soft CTA (a call to see it in action, not "buy now")

Length: Under 200 words. Tone: Helpful advisor, not salesperson.
```

---

### Upsell Email — Seat Expansion
*Use when a customer's team is growing and they need additional seats.*

```
Write a seat expansion email that feels timely and value-focused, not transactional.

Customer info:
- Contact: [CONTACT_NAME] at [COMPANY_NAME]
- Current seats: [CURRENT_SEATS]
- Usage data: [USAGE_DETAIL — e.g., "your team has been at 95%+ seat utilization for 60 days"]
- Known company growth context: [GROWTH_CONTEXT — e.g., "you mentioned hiring 5 engineers this quarter"]
- Seat price or package: [SEAT_PRICING]
- Benefit of expanding now vs. waiting: [EXPANSION_BENEFIT]

Write an email that:
1. References the usage data or growth context as the trigger (personalized, not generic)
2. Frames expansion as enabling their growth, not upselling them
3. Makes the next step frictionless (a specific offer or a quick call)
4. Avoids pressure language entirely

Keep it under 150 words. Conversational tone.
```

---

### Upsell Email — Annual Upgrade Offer
*Use when a monthly customer is a strong expansion candidate for an annual commitment.*

```
Write an email offering a monthly-to-annual upgrade to a healthy, engaged customer.

Customer: [CONTACT_NAME] at [COMPANY_NAME]
Current plan: [CURRENT_MONTHLY_PLAN] at [MONTHLY_PRICE]/month
Annual plan offer: [ANNUAL_PRICE] (saves them [SAVINGS_AMOUNT] vs. monthly)
Tenure: [MONTHS_AS_CUSTOMER] months as a customer
Usage health: [HEALTH_SUMMARY — e.g., "daily active users, strong engagement"]
Additional benefits of annual: [ANNUAL_EXTRAS — e.g., priority support, onboarding for new hires]
My name: [MY_NAME]

Write an email that:
1. Leads with their track record as a customer (make them feel seen)
2. Frames annual as a financial win, not a commitment burden
3. Mentions any additional perks beyond the discount
4. Ends with a simple "want me to set this up?" CTA

Tone: Like a call from a financial advisor who noticed something in your favor.
```

---

### Upsell Follow-Up After Demo
*Use when a customer has seen a demo of an upgraded feature but hasn't committed.*

```
Write a follow-up email after a customer watched a demo of an upgrade feature but didn't commit on the call.

Context:
- Customer: [CONTACT_NAME] at [COMPANY_NAME]
- Demo feature/plan: [DEMO_FEATURE_OR_PLAN]
- Their reaction during demo: [REACTION — e.g., "positive but said they needed to check budget", "asked about [SPECIFIC_CONCERN]"]
- Objection or concern raised: [OBJECTION]
- How we address that objection: [OBJECTION_RESPONSE]
- Next step I want: [DESIRED_NEXT_STEP]
- Timeline pressure (if any): [DEADLINE — e.g., "pricing changes Q2", "budget cycle ends X"]

Write a follow-up that:
1. Acknowledges their reaction without pressure
2. Directly addresses their concern or objection
3. Reframes the value in terms of their specific goal
4. Suggests a low-friction next step
5. Mentions any timeline factor naturally (not as a scare tactic)
```

---

## UPSELL CONVERSATION PROMPTS

---

### QBR Expansion Moment Script
*Use when planning the expansion section of a Quarterly Business Review.*

```
You are a CSM preparing the expansion portion of a quarterly business review. Write a QBR segment that transitions from "here's how you've done" to "here's how you could do more" without feeling like a sales meeting.

QBR context:
- Customer: [COMPANY_NAME]
- QBR participants: [ATTENDEES_AND_ROLES]
- Metrics achieved this quarter: [KEY_METRICS]
- Goals they originally set: [ORIGINAL_GOALS]
- Goals met vs. not met: [GOALS_STATUS]
- Expansion opportunity: [EXPANSION_OPPORTUNITY]
- Business case for expansion: [BUSINESS_CASE]
- Expected ROI or outcome: [EXPECTED_OUTCOME]
- Price/investment required: [UPGRADE_COST]

Write:
1. A 3-sentence transition from the review section to the expansion conversation
2. The expansion pitch in 5-7 sentences using their own goals as the anchor
3. The question I should ask to open the dialogue (not a close — a discovery question)
4. How to handle "we need to think about it" gracefully
```

---

### Expansion Discovery Call Prep
*Use when scheduling a dedicated call to explore expanding an account.*

```
Prepare me for an expansion discovery call with the goal of understanding whether [COMPANY_NAME] is ready to expand their use of [PRODUCT_NAME].

Account background:
- Contact: [CONTACT_NAME], [CONTACT_ROLE]
- Current product usage: [USAGE_SUMMARY]
- Known business priorities for next 6 months: [PRIORITIES]
- Expansion product/feature: [EXPANSION_TARGET]
- Their likely objections: [ANTICIPATED_OBJECTIONS]

Produce:
1. 5 discovery questions to open the call (no pitching — just learning about their goals and challenges)
2. The bridge statement I'll use to introduce the expansion product once I've heard their priorities
3. 3 objection responses for the most common resistance I'll face
4. How to close the call if the timing isn't right (keep the relationship, plant the seed)
```

---

### Cross-Sell into New Department
*Use when presenting a use case to a new internal stakeholder who hasn't used your product before.*

```
Write a pitch for introducing [PRODUCT_NAME] to a new department at an existing customer company.

Context:
- Company: [COMPANY_NAME]
- New department target: [TARGET_DEPARTMENT]
- Contact in new department: [NEW_CONTACT_NAME], [NEW_CONTACT_ROLE]
- How our current customer uses the product: [CURRENT_USE_CASE]
- Use case for the new department: [NEW_DEPARTMENT_USE_CASE]
- Value prop specific to this department: [DEPARTMENT_VALUE_PROP]
- Proof point from current usage: [INTERNAL_PROOF_POINT — e.g., "your [TEAM] cut X by Y%"]

Write:
1. An intro paragraph that establishes my credibility via the existing relationship
2. The use case framed in their department's language and priorities
3. The internal proof point as social proof (not a case study — an internal win)
4. A call to a 20-minute exploratory conversation — not a full demo
```

---

## ROI AND VALUE REINFORCEMENT PROMPTS

---

### ROI Review Email Pre-Renewal
*Use when building a pre-renewal ROI summary to create urgency and justify expansion.*

```
Write a pre-renewal ROI summary email that makes the business case for both renewal and expansion.

Customer: [CONTACT_NAME], [CONTACT_ROLE] at [COMPANY_NAME]
Contract value: [CURRENT_ARR]
Renewal date: [RENEWAL_DATE]
Key metrics achieved during contract period: [METRICS — e.g., "reduced X by Y%, saved Z hours/month"]
Original goals at signing: [ORIGINAL_GOALS]
Goals achieved: [GOALS_ACHIEVED]
Expansion opportunity: [EXPANSION_OPPORTUNITY]
Expected additional value from expansion: [EXPANSION_VALUE]

Write an email that:
1. Opens with their original goal and what they've achieved (1 paragraph)
2. Quantifies the ROI in their language (not product language)
3. Identifies the next-level opportunity without hard-selling
4. Makes the renewal feel like the obvious choice, and expansion feel like the smart move
```

---

### Value Story — Before and After
*Use when creating a compelling narrative for an internal champion to use with their exec.*

```
Write a "before and after" value story my champion can use to justify continued investment and expansion to their leadership.

Champion: [CHAMPION_NAME], [CHAMPION_ROLE] at [COMPANY_NAME]
Exec they need to convince: [EXEC_NAME], [EXEC_ROLE]
Before state (when they started using [PRODUCT_NAME]): [BEFORE_STATE — pain, inefficiency, cost]
After state (current results): [AFTER_STATE — outcomes, time saved, revenue impact]
Metrics that prove it: [KEY_METRICS]
Proposed expansion: [EXPANSION_PROPOSAL]
Expected additional benefit: [EXPANSION_BENEFIT]

Write a 1-page internal pitch document they can share or present. Include:
1. The original business problem (2-3 sentences)
2. What changed after implementing [PRODUCT_NAME] (bullet points with data)
3. The ROI calculation or equivalent (keep it simple)
4. The case for the next investment step
5. A recommended decision timeline
```

---

### Competitive Displacement — Consolidation Pitch
*Use when a customer is using a competitor alongside your product and you want to consolidate.*

```
Write an expansion pitch aimed at consolidating a customer off a competing tool and onto [PRODUCT_NAME] for a unified workflow.

Customer: [COMPANY_NAME]
Contact: [CONTACT_NAME], [CONTACT_ROLE]
Current tools in their stack for this use case: [CURRENT_TOOLS_USED]
Our product's features that replace those tools: [REPLACEMENT_FEATURES]
Cost of their current stack: [COMPETITOR_COST — if known]
Our consolidated pricing: [OUR_PRICE]
Operational benefit of consolidation: [CONSOLIDATION_BENEFIT — fewer tools, single source of truth, etc.]
Integration: [INTEGRATION_DETAILS — if applicable]

Write:
1. A consolidation case framed around simplicity and cost (not "your other tool is bad")
2. A side-by-side capability comparison (their current stack vs. us) in plain language
3. A migration path that reduces their fear of switching
4. The 3-sentence business case they can forward to IT or finance
```

---

### Expansion Proposal One-Pager
*Use when sending a formal expansion proposal document after an exploratory conversation.*

```
Write a one-page expansion proposal to send after a discovery conversation where the customer showed interest.

Customer: [COMPANY_NAME]
Contact: [CONTACT_NAME], [CONTACT_ROLE]
Current plan: [CURRENT_PLAN] at [CURRENT_ARR]
Proposed expansion: [EXPANSION_PLAN_OR_FEATURE]
Proposed expansion investment: [EXPANSION_PRICE]
Business case discussed on call: [BUSINESS_CASE_SUMMARY]
Key outcome they care about: [PRIMARY_OUTCOME]
Timeline they mentioned: [CUSTOMER_TIMELINE]
Next step agreed on call: [AGREED_NEXT_STEP]

Format the one-pager with:
1. Why we're recommending this (their goal in their words)
2. What we're proposing (clear, simple)
3. What they'll gain (outcome-focused, specific)
4. Investment and timeline
5. Next steps (2-3 simple action items)

No jargon. No fluff. Executive-readable in 90 seconds.
```

---

### Expansion Objection Handler
*Use when a customer expresses resistance to an expansion conversation.*

```
Write objection responses for the most common expansion pushback scenarios.

My product: [PRODUCT_NAME]
Expansion being proposed: [EXPANSION_PROPOSAL]
Price: [EXPANSION_PRICE]

Write responses for each of these objections:

1. "We don't have budget for this right now."
2. "We're still not fully using what we have."
3. "We need to get more value out of the current tier first."
4. "Let's revisit this at renewal."
5. "I need to get approval from [EXECUTIVE_NAME]."

For each response:
- Acknowledge the concern (1 sentence, don't dismiss it)
- Reframe or address it directly (2-3 sentences)
- Suggest a next step that keeps the conversation alive without pressure

Keep all responses under 5 sentences. Professional, not pushy.
```

---

### Success Milestone → Expansion Trigger Email
*Use when a customer hits a key milestone — the best moment to introduce expansion.*

```
Write an email that celebrates a customer's milestone and uses it as a natural bridge to introduce an expansion opportunity.

Customer: [CONTACT_NAME] at [COMPANY_NAME]
Milestone achieved: [MILESTONE — e.g., "1,000th project completed", "6 months of on-time delivery", "team adopted the platform company-wide"]
When they hit it: [DATE_OR_TIMEFRAME]
What this milestone means for their business: [BUSINESS_SIGNIFICANCE]
Expansion opportunity to introduce: [EXPANSION_OPPORTUNITY]
Why this milestone makes the timing right for expansion: [TIMING_RATIONALE]

Write an email that:
1. Opens by genuinely celebrating their achievement (not transactionally)
2. Connects the milestone to what's now possible
3. Introduces the expansion as a natural next chapter — not a pivot to sales
4. Ends with a question or soft CTA

Tone: Excited and celebratory. This is a win for them, and you're part of that.
```

---

### Account Growth Presentation to Internal Team
*Use when preparing an internal expansion strategy presentation for your CS or sales team.*

```
Write a brief internal expansion strategy presentation for account [COMPANY_NAME] to be shared in a CS team meeting or account planning session.

Account details:
- Company: [COMPANY_NAME], [INDUSTRY], [EMPLOYEE_COUNT] employees
- Current ARR: [CURRENT_ARR]
- Contract: [CONTRACT_TERM], renewal date [RENEWAL_DATE]
- Health score: [HEALTH_SCORE]
- Current champion: [CHAMPION_NAME], [CHAMPION_ROLE]
- Executive sponsor: [EXEC_SPONSOR] (engaged / not engaged)
- Expansion opportunity identified: [EXPANSION_TARGET] — estimated [EXPANSION_VALUE] in new ARR
- Blockers: [KNOWN_BLOCKERS]
- Strategy to unlock: [PROPOSED_APPROACH]

Format as a 5-slide summary:
1. Account snapshot (who they are, current state)
2. Opportunity (what we're going after and why now)
3. Strategy (how we get there — key moves and stakeholders)
4. Blockers and mitigation
5. Timeline and ask from the team
```

---

### NPS Promoter Expansion Prompt
*Use when a customer gives a high NPS score — the ideal time to have an expansion conversation.*

```
A customer just gave us an NPS score of [NPS_SCORE] with the comment: "[NPS_COMMENT]"

Customer: [CONTACT_NAME], [CONTACT_ROLE] at [COMPANY_NAME]
Current plan: [CURRENT_PLAN]
Best expansion fit based on their profile: [EXPANSION_FIT]

Write:
1. A personal response to their NPS that acknowledges their feedback specifically (not a template thank-you)
2. A segue that asks if they'd be open to a quick conversation about doing more together
3. A brief framing of the expansion opportunity that fits their expressed satisfaction

The response should feel like a real person wrote it, not a CS playbook. Under 150 words total.
```

---

### Customer Reference and Expansion Dual Ask
*Use when asking a customer to be a reference while also introducing an expansion conversation.*

```
Write an email that accomplishes two goals: asking a happy customer to be a reference, and opening an expansion conversation.

Customer: [CONTACT_NAME], [CONTACT_ROLE] at [COMPANY_NAME]
Reference use case: [WHAT_YOU'RE_ASKING_THEM_TO_DO — e.g., "15-minute call with a prospect", "case study", "G2 review"]
Why they're a good fit for this: [REASON — e.g., "your use case in [INDUSTRY] is exactly what this prospect is doing"]
Expansion opportunity: [EXPANSION_OPPORTUNITY]
How to introduce it without being pushy: [NATURAL_TIE_IN]

Write an email that:
1. Opens with genuine appreciation and a specific reason you thought of them
2. Makes the reference ask clearly and easily (no commitment required upfront)
3. Mentions the expansion opportunity as a "by the way" — not the main event
4. Keeps both asks light and low-pressure

Under 200 words. Warm and direct.
```

---

### Proactive Expansion Outreach Sequence (3 Emails)
*Use when building a multi-touch expansion outreach sequence for a specific account segment.*

```
Write a 3-email expansion outreach sequence for customers on [CURRENT_PLAN] who have been customers for [CUSTOMER_TENURE] and are strong candidates for [EXPANSION_TARGET].

Segment profile:
- Current plan: [CURRENT_PLAN]
- Tenure: [CUSTOMER_TENURE]
- Usage indicator triggering this sequence: [USAGE_TRIGGER — e.g., "at 90% seat capacity for 30+ days"]
- Expansion offer: [EXPANSION_OFFER]
- Key benefit: [KEY_BENEFIT]
- Price: [EXPANSION_PRICE]

Email 1 (Day 1): Value check-in — open with their recent usage win, introduce the idea of "what's next" casually
Email 2 (Day 5): Feature spotlight — highlight one specific feature from the expansion that addresses their current usage pattern
Email 3 (Day 12): Light close — ask for a 20-minute conversation; offer a personalized usage review as the hook

Each email: under 150 words. Tone: Helpful teammate, not sales rep.
```

---

### Expansion Pricing Conversation Script
*Use when preparing to discuss pricing changes or upgrade costs in a way that emphasizes value over cost.*

```
Write a script for navigating a pricing conversation when presenting an expansion opportunity to a value-conscious customer.

Context:
- Customer: [COMPANY_NAME], [CONTACT_NAME]
- Expansion: [EXPANSION_PROPOSAL]
- Cost increase: from [CURRENT_PRICE] to [NEW_PRICE] (increase of [DELTA])
- What they're getting for the increase: [NEW_VALUE]
- Their value sensitivity level: [HIGH/MEDIUM — why: describe their budget context]
- Best ROI framing available: [ROI_EXAMPLE — e.g., "saves [X] hours/month worth [DOLLAR_VALUE]"]

Write:
1. How to present the new price without apologizing for it
2. The ROI bridge that makes the cost feel like an investment
3. A payment flexibility option to offer if they push back (if applicable: [PAYMENT_OPTIONS])
4. How to close the conversation even if they need time to decide

Keep the tone confident and consultative. You're helping them invest wisely, not justifying a charge.
```

---

*Total prompts in this file: 22*
