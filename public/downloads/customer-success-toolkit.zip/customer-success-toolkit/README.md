# 🤝 The Customer Success Manager's AI Prompt Toolkit

**95+ battle-tested AI prompts for CSMs, account managers, and customer success teams**

---

## What's Inside

Every prompt is:
- **Role-specific** — Built for real CSM work, not generic business writing
- **Structured** — Uses `[BRACKET VARIABLES]` so you can customize in seconds
- **Outcome-focused** — Designed to drive retention, expansion, and customer health

---

## File Guide

| File | Contents | Prompts |
|------|----------|---------|
| [01-quick-start-guide.md](01-quick-start-guide.md) | Setup, system prompts, best practices | — |
| [02-onboarding-prompts.md](02-onboarding-prompts.md) | Onboarding sequences, kickoff emails, training plans | 25 |
| [03-retention-health-prompts.md](03-retention-health-prompts.md) | QBRs, health scores, risk escalation, check-ins | 23 |
| [04-expansion-upsell-prompts.md](04-expansion-upsell-prompts.md) | Expansion plays, upsell emails, ROI reviews | 22 |
| [05-escalation-renewal-prompts.md](05-escalation-renewal-prompts.md) | Escalation scripts, renewal campaigns, churn saves | 20 |
| [06-workflow-sops.md](06-workflow-sops.md) | 5 complete CSM workflow playbooks | — |
| [07-cheat-sheet.md](07-cheat-sheet.md) | Top 15 power prompts + 10 Golden Rules | 15 |

**Total: 95+ prompts**

---

## Who This Is For

- **Customer Success Managers** at B2B SaaS companies
- **Account Managers** responsible for retention and expansion
- **Customer Success Team Leads** standardizing team communication
- **CS Ops** building playbooks and templates
- **Founders / Sales doing CSM work** at early-stage startups

---

*Built for CSMs who want to retain, expand, and scale.*
