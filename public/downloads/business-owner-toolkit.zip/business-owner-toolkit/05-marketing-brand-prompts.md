# 05 — Marketing & Brand Prompts

*17 prompts for brand copy, social media, email marketing, ads, and growing your business*

---

### Brand Positioning Statement
*Use when defining or refining how you describe your business to the market.*

```
Write a brand positioning statement for my business.

Business: [BUSINESS_NAME]
What we do: [WHAT_WE_DO]
Who we serve: [TARGET_CUSTOMER — be specific]
The primary problem we solve: [PRIMARY_PROBLEM]
How we solve it differently than competitors: [KEY_DIFFERENTIATOR]
The feeling we want customers to have: [BRAND_FEELING — e.g., "confident", "taken care of", "like a partner, not a vendor"]
What we are NOT: [ANTI_POSITIONING — what you want to be the opposite of]

Write:
1. A 1-sentence positioning statement ("For [WHO] who [PROBLEM], [BUSINESS_NAME] is the [CATEGORY] that [SOLUTION] because [PROOF]")
2. A 2-3 sentence "About Us" for the website
3. A 1-sentence elevator pitch (for networking events)
4. A tagline (3-6 words)

Test each against: Is it specific? Is it memorable? Does it make a clear promise?
```

---

### Website Homepage Copy
*Use when writing or rewriting the homepage of your business website.*

```
Write website homepage copy for my small business.

Business: [BUSINESS_NAME]
Tagline: [TAGLINE]
What we do: [SERVICE_OR_PRODUCT]
Who our ideal customer is: [IDEAL_CUSTOMER]
Their biggest pain point: [CUSTOMER_PAIN]
How we solve it: [OUR_SOLUTION]
Top 3 reasons to choose us: [DIFFERENTIATORS]
Social proof available: [PROOF — reviews, years in business, clients served, etc.]
Primary call to action: [CTA — e.g., "Get a free estimate", "Book a call", "Shop now"]

Write homepage copy for these sections:
1. Hero headline + subheading (clear, compelling, specific)
2. "What we do" section (3 benefit-led paragraphs or a short overview + 3 features)
3. Why choose us (3-4 value points with brief descriptions)
4. Social proof intro (how to frame testimonials or trust badges)
5. CTA section (closing section before footer)

Tone: [DESIRED_TONE — e.g., professional and trustworthy, bold and confident, warm and approachable]. No marketing buzzwords.
```

---

### Social Media Post — Business Story / Origin
*Use when sharing your business origin story for brand building on social media.*

```
Write a social media post sharing my business story or origin.

Business: [BUSINESS_NAME]
Platform: [INSTAGRAM/FACEBOOK/LINKEDIN/X]
When I started: [YEAR]
Why I started: [ORIGIN_STORY — what drove me to start this business]
What it's become: [WHERE_WE_ARE_NOW]
What I've learned: [KEY_LESSON]
CTA or closing message: [HOW_YOU_WANT_PEOPLE_TO_RESPOND — follow, comment, share, etc.]

Write a post that:
1. Opens with a hook that stops the scroll (not "My name is...")
2. Tells the origin story briefly and personally
3. Builds to a message that connects to the reader's experience
4. Ends with a CTA

[PLATFORM] tone. [SHORT — under 150 words / MEDIUM — 200-300 words / LONG — 400+ words for LinkedIn].
```

---

### Facebook / Instagram Ad Copy
*Use when writing a paid social media ad for your business.*

```
Write social media ad copy for [PLATFORM — Facebook, Instagram, etc.].

Business: [BUSINESS_NAME]
Service or product being advertised: [PRODUCT_OR_SERVICE]
Target audience: [AUDIENCE — age, interests, location, or pain point]
Problem the ad addresses: [CUSTOMER_PROBLEM]
Offer being presented: [OFFER — e.g., "free estimate", "20% off first service", "new customer discount"]
Call to action: [CTA — "Book Now", "Get a Free Quote", "Learn More"]
Ad format: [STATIC_IMAGE / CAROUSEL / VIDEO_SCRIPT]
Budget level: [HIGH / MEDIUM / LOW — this affects how long/polished the copy should be]

Write:
1. Primary headline (under 40 characters)
2. Body copy (under 125 characters for mobile-first)
3. Long body copy version (for desktop, under 250 characters)
4. CTA button text
5. A/B test variation (different hook or offer angle)

Make the hook specific to the pain point, not the product.
```

---

### Email Newsletter — Monthly
*Use when writing a monthly email newsletter to your customer or prospect list.*

```
Write a monthly email newsletter for my business.

Business: [BUSINESS_NAME]
Month: [MONTH]
Audience: [SUBSCRIBER_TYPE — current customers, prospects, local community]
Main topic or theme: [NEWSLETTER_THEME]
Content to include:
- Business update or news: [BUSINESS_NEWS]
- Useful tip or insight: [TIP_OR_INSIGHT]
- Promotion or offer (if any): [OFFER]
- Customer spotlight or story (if any): [CUSTOMER_STORY]
- CTA: [DESIRED_ACTION]
My name: [MY_NAME]

Write a newsletter that:
1. Has a subject line that gets opened (specific and personal, not generic)
2. Opens with something worth reading (not a business announcement)
3. Feels like a personal note, not a press release
4. Provides at least one piece of genuine value (tip, insight, story)
5. Has one clear CTA at the end

Under 400 words. Readable in 90 seconds.
```

---

### Google Business Profile Description
*Use when writing or optimizing your Google Business Profile for local search.*

```
Write an optimized Google Business Profile description for my business.

Business: [BUSINESS_NAME]
Location: [CITY, STATE]
Service area: [SERVICE_AREA — if different from location]
Business type: [TYPE — e.g., auto repair shop, landscaping company, accounting firm]
Services offered: [TOP_5_SERVICES]
Years in business: [YEARS]
What makes us different: [DIFFERENTIATOR]
Customer type: [IDEAL_CUSTOMER]
Awards or certifications (if any): [CREDENTIALS]
Target keywords: [LOCAL_KEYWORDS — e.g., "oil change [CITY]", "[TRADE] contractor near me"]

Write a Google Business Profile description that:
1. Includes the business name and location naturally in the first sentence
2. Mentions top services with natural keyword placement
3. Highlights what makes us different
4. Includes a call to action
5. Stays under 750 characters (the Google limit)

Write 2 versions: one for brand-new customers, one that's more trust/reputation focused.
```

---

### Before and After / Results Post
*Use when sharing a completed project or transformation on social media.*

```
Write a before-and-after social media post showcasing a completed project or client result.

Platform: [PLATFORM]
Project: [PROJECT_DESCRIPTION]
Client type: [CLIENT_TYPE — without naming the client if confidential]
Before state: [WHAT_IT_WAS_BEFORE]
After state: [WHAT_IT_LOOKS_LIKE_NOW]
Result or outcome: [MEASURABLE_RESULT — if applicable]
Time it took: [TIMEFRAME]
What I'm proud of: [PERSONAL_NOTE — what made this job special]
Hashtags (if applicable): [HASHTAGS]

Write a post that:
1. Opens with the visual outcome (before/after hook)
2. Gives enough context that someone who doesn't follow you understands it
3. Adds a human moment (something that made this job memorable)
4. Ends with a CTA (get a quote, DM us, etc.)

Authentic and specific — not a catalog description.
```

---

### Referral Program Announcement
*Use when launching or promoting a referral program to your existing customer base.*

```
Write a referral program announcement for my existing customers.

Business: [BUSINESS_NAME]
Referral offer: [REFERRAL_INCENTIVE — e.g., "$50 off your next service for every referral who becomes a customer"]
What the referred friend gets: [NEW_CUSTOMER_INCENTIVE — e.g., "$25 off their first service"]
How to refer: [HOW_TO_REFER — text your name and theirs, use a link, etc.]
Expiration: [EXPIRATION_DATE — or "no expiration"]
My name: [MY_NAME]

Write:
1. An email to existing customers announcing the program
2. A social media post about the referral program
3. A one-line version for invoices or receipts

Each should:
- Lead with the customer benefit (not "we're launching a referral program")
- Make referring easy and clear
- Create a sense of community ("tell your friends, help them out")
```

---

### Customer Review Response — Positive
*Use when replying to a 4-5 star review online.*

```
Write a response to a positive customer review.

Business: [BUSINESS_NAME]
Review platform: [GOOGLE / YELP / FACEBOOK / OTHER]
Customer name (if shown): [REVIEWER_NAME]
What they wrote: "[REVIEW_TEXT]"
Specific thing to acknowledge: [SPECIFIC_DETAIL_FROM_REVIEW]
Your name: [YOUR_NAME]

Write a response that:
1. Thanks them by name (or "thank you" if anonymous)
2. Specifically acknowledges what they mentioned (not generic "glad you had a good experience")
3. Adds a personal note or reinforces what makes your business special
4. Invites them back or encourages them to recommend

Under 75 words. Warm and genuine — not a corporate template.
```

---

### Customer Review Response — Negative
*Use when responding to a 1-3 star review to protect your reputation.*

```
Write a professional response to a negative customer review.

Business: [BUSINESS_NAME]
Review platform: [GOOGLE / YELP / FACEBOOK]
Customer name (if shown): [REVIEWER_NAME]
What they wrote: "[NEGATIVE_REVIEW_TEXT]"
What actually happened (your side): [YOUR_ACCOUNT]
Was the complaint valid? [YES / PARTIALLY / NO — explain briefly]
Resolution offered (if any): [WHAT_YOU_DID_OR_OFFERED]
My name: [MY_NAME]

Write a response that:
1. Opens with genuine acknowledgment (not a denial)
2. Is factual — no emotional language, no defensiveness
3. Takes responsibility where appropriate
4. States what was done or offered to resolve it
5. Invites them to contact you directly
6. Demonstrates professionalism to other readers (this response is marketing)

Under 150 words. Professional and measured.
```

---

### Email Marketing Sequence — New Lead Follow-Up
*Use when setting up an automated email sequence for new leads or inquiries.*

```
Write a 3-email follow-up sequence for new leads who inquire about my services but haven't booked.

Business: [BUSINESS_NAME]
Service: [SERVICE]
Lead source: [WHERE_THEY_CAME_FROM — website form, referral, social]
Typical objection before booking: [COMMON_OBJECTION]
What I want them to do: [CTA — book a call, get a quote, visit, etc.]
Tone: [FORMAL / FRIENDLY / URGENT]

Email 1 (same day as inquiry):
- Acknowledge their inquiry
- Set expectations (when/how I'll follow up)
- Add one piece of value or a quick answer to a common question

Email 2 (Day 3):
- Remind them you're available
- Address the most common objection
- Make it easy to take the next step

Email 3 (Day 7):
- Last follow-up
- Add urgency or scarcity (availability, seasonal demand, etc.)
- Give them an easy out if now isn't the time

Each email: under 150 words. Personalized, not spammy.
```

---

### Service Menu / Offerings Page Copy
*Use when writing or revising the services or offerings page on your website.*

```
Write a services page for my business website.

Business: [BUSINESS_NAME]
Target customer: [IDEAL_CUSTOMER]
Services offered (list each with brief description):
1. [SERVICE_1]: [DESCRIPTION]
2. [SERVICE_2]: [DESCRIPTION]
3. [SERVICE_3]: [DESCRIPTION]
4. [SERVICE_4]: [DESCRIPTION — if applicable]
Price range: [PRICE_RANGE or STARTING AT prices]
How to book or inquire: [BOOKING_METHOD]
Trust signals: [CREDENTIALS, YEARS IN BUSINESS, GUARANTEE — if applicable]

Write a services page that:
1. Opens with a 2-3 sentence intro that speaks to the customer's situation
2. Describes each service with: what it is, who it's for, and what they'll get
3. Doesn't list every detail — just enough to make them want to contact you
4. Ends with a CTA

Write for someone who lands on this page having never heard of you. Make it easy to say "yes, this is exactly what I need."
```

---

### Seasonal Promotion Email
*Use when running a seasonal sale, holiday promotion, or limited-time offer.*

```
Write a seasonal promotion email for my business.

Business: [BUSINESS_NAME]
Season/occasion: [SEASON_OR_HOLIDAY]
Offer: [PROMOTION — e.g., "20% off all services through [DATE]", "free add-on with any [SERVICE]"]
Deadline: [OFFER_EXPIRATION]
Who's receiving this: [EMAIL_LIST — customers, past customers, prospects]
My name: [MY_NAME]

Write an email that:
1. Opens with the season/occasion as context (not "WE'RE HAVING A SALE")
2. Presents the offer clearly and specifically
3. Creates legitimate urgency (deadline, limited slots, etc.)
4. Makes it frictionless to claim the offer (one-click, reply, call, etc.)
5. Closes warmly

Subject line options: provide 3 options.
Under 200 words.
```

---

### LinkedIn Post — Business Insight or Lesson
*Use when sharing a business lesson or thought leadership post on LinkedIn.*

```
Write a LinkedIn post sharing a business lesson or insight.

My business/role: [BUSINESS_NAME] / [MY_ROLE]
Lesson or insight: [WHAT_I_WANT_TO_SHARE]
Story behind it: [BRIEF_STORY — what experience led to this insight]
Who this is for: [AUDIENCE — other business owners, potential clients, peers in my industry]
CTA (if any): [WHAT_I_WANT_THEM_TO_DO — comment, follow, DM, etc.]

Write a LinkedIn post that:
1. Opens with a bold or surprising statement (not "Today I want to share...")
2. Tells the story in 3-5 short paragraphs (1-2 sentences each)
3. Gets to the insight without burying it
4. Ends with a question or CTA that invites engagement

200-400 words. First-person. Specific over generic.
```

---

### "About" Page Bio
*Use when writing an About page or professional bio for your website or LinkedIn.*

```
Write a professional bio / About page for my business website.

My name: [MY_NAME]
Business: [BUSINESS_NAME]
What I do: [WHAT_I_DO]
How long I've been doing it: [YEARS]
My background before this business: [BACKGROUND]
Why I started this business: [MOTIVATION]
What makes my approach different: [DIFFERENTIATOR]
Credentials or awards (if any): [CREDENTIALS]
Personal note (optional): [PERSONAL_DETAIL — family, location, hobby — if comfortable sharing]

Write 2 versions:
1. Third-person formal bio (for speaking, media, or professional directories) — 200 words
2. First-person "About Me" page (for website) — 300-400 words, conversational and warm

Both should:
- Establish credibility without sounding arrogant
- Make the reader trust you
- End with how to contact or work with you
```

---

### Seasonal Content Calendar — One Month
*Use when planning a month of social media content in advance.*

```
Create a one-month social media content calendar for my business.

Business: [BUSINESS_NAME]
Platform(s): [PLATFORM_1], [PLATFORM_2]
Month: [MONTH]
Posting frequency: [POSTS_PER_WEEK]
Content goals: [GOALS — awareness, lead gen, trust-building, promotions]
Key dates this month: [EVENTS_PROMOTIONS_HOLIDAYS]
Content pillars (what I post about): [PILLAR_1 — e.g., tips], [PILLAR_2 — e.g., behind the scenes], [PILLAR_3 — e.g., customer results], [PILLAR_4 — e.g., promotions]
My tone: [TONE]

Create a calendar with:
- Date
- Platform
- Content type (photo, video, carousel, text post)
- Post topic / hook
- Brief content brief (what to include)

Also write 3 fully drafted posts from the calendar to get me started.
```

---

*Total prompts in this file: 17*
