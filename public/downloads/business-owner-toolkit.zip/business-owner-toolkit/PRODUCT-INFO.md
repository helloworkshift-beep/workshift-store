# PRODUCT INFO — The Small Business Owner's AI Prompt Toolkit

---

## Product Details

| Field | Value |
|-------|-------|
| **Product Name** | The Small Business Owner's AI Prompt Toolkit |
| **Version** | 1.0 |
| **Format** | 7 Markdown files (digital download) |
| **Total Prompts** | 90+ ready-to-use AI prompts |
| **Support** | helloworkshift@gmail.com |

---

## Who It's For

Small business owners, entrepreneurs, and founders who need to produce better client proposals, manage their teams more effectively, communicate with investors, and market their brand — without hiring a full team to do it.

---

## What's Included

| File | Description | Prompt Count |
|------|-------------|--------------|
| `01-quick-start-guide.md` | Setup, system prompt, best practices | — |
| `02-client-proposals-prompts.md` | Proposals, pricing, contracts, follow-ups | 23 |
| `03-team-operations-prompts.md` | Hiring, SOPs, team communication, performance | 22 |
| `04-financial-investor-prompts.md` | Financial summaries, investor decks, funding pitches | 18 |
| `05-marketing-brand-prompts.md` | Brand copy, social, email marketing, ads | 17 |
| `06-workflow-sops.md` | 5 complete playbooks for recurring business workflows | — |
| `07-cheat-sheet.md` | Top 15 prompts + variable quick reference | 15 |

---

*For support: helloworkshift@gmail.com*
*Last updated: 2026*
