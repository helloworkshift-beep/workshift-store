# 02 — Client Proposals Prompts

*23 prompts for writing winning proposals, contracts, pricing conversations, and client acquisition*

---

### Client Proposal Generator — Full Proposal
*Use when writing a formal proposal for a new or prospective client.*

```
You are an experienced small business owner who has won hundreds of client engagements with clear, professional proposals. Write a complete client proposal for the following project.

Business: [BUSINESS_NAME] — [BUSINESS_DESCRIPTION]
Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Project or service: [PROJECT_DESCRIPTION]
Scope of work: [SCOPE — what you will and won't do]
Timeline: [TIMELINE — start date, milestones, completion date]
Deliverables: [LIST_OF_DELIVERABLES]
Investment (pricing): [TOTAL_PRICE] — payment terms: [PAYMENT_TERMS]
Why we're the right fit: [YOUR_KEY_DIFFERENTIATOR]

Write a professional proposal with:
1. Executive summary (2-3 sentences — what we'll do and why it matters)
2. Understanding of the client's need (show you listened)
3. Scope of work (detailed, numbered list)
4. What's NOT included (explicit exclusions)
5. Timeline with key milestones
6. Investment and payment terms
7. Why [BUSINESS_NAME] (2-3 compelling differentiators)
8. Next steps (clear, simple, low-friction)

Tone: Professional and confident. Length: 1-2 pages.
```

---

### Service Proposal — One-Page Version
*Use when a client prefers a concise summary instead of a full multi-page proposal.*

```
Write a tight, one-page service proposal for a client who wants simplicity over detail.

Business: [BUSINESS_NAME]
Client: [CLIENT_NAME] / [CLIENT_COMPANY]
Service being proposed: [SERVICE_DESCRIPTION]
Key deliverables: [DELIVERABLES]
Timeline: [TIMELINE]
Price: [PRICE]
Payment structure: [PAYMENT_STRUCTURE]
Your #1 selling point: [TOP_DIFFERENTIATOR]

Format as a clean one-pager:
1. What we'll do (3-4 bullet points)
2. Timeline
3. Investment
4. Why work with us (2 sentences max)
5. How to say yes (single CTA — sign and return, reply to this email, etc.)

No fluff. Executive-readable in 60 seconds.
```

---

### Project Discovery Questions — Pre-Proposal
*Use before writing a proposal to gather the information you need from a prospect.*

```
You are helping me prepare for a discovery conversation with a potential client. Write a list of discovery questions I should ask before submitting a proposal.

My business: [BUSINESS_NAME] — [WHAT_I_DO]
Type of project they've mentioned: [PROJECT_TYPE]
What I need to know to price this accurately: [PRICING_FACTORS]
Common scope creep situations in my business: [SCOPE_CREEP_RISKS]

Write 12-15 discovery questions that will:
1. Help me understand their exact needs and expectations
2. Surface any red flags (unrealistic timelines, unclear decision-making, budget misalignment)
3. Let me price accurately without guessing
4. Position me as professional and thorough

Include a mix of: scope questions, timeline questions, budget questions, decision-making questions, and success criteria questions.
```

---

### Pricing Justification Letter
*Use when a client pushes back on your price and you need to defend your value.*

```
Write a pricing justification email or document for a client who said our proposal is too expensive.

Business: [BUSINESS_NAME]
Client: [CLIENT_NAME]
Service: [SERVICE_DESCRIPTION]
Our price: [OUR_PRICE]
Their objection: [WHAT_THEY_SAID — e.g., "we found someone cheaper", "this is over our budget"]
What our price includes: [WHAT'S_INCLUDED]
What a cheaper alternative typically misses: [RISK_OF_CHEAPER_OPTION]
Our track record or proof: [RELEVANT_PROOF — years in business, similar projects, testimonials]

Write a response that:
1. Acknowledges their concern without being defensive
2. Breaks down what's included in the price (value, not just tasks)
3. Addresses the risk of choosing a cheaper option (without badmouthing competitors)
4. Offers one optional compromise (if appropriate): [OPTIONAL_COMPROMISE]
5. Invites a conversation rather than forcing a binary yes/no decision

Tone: Confident, not apologetic. We believe in our pricing.
```

---

### Project Scope of Work Document
*Use when creating a detailed scope of work for a signed client before work begins.*

```
Write a formal scope of work document for a signed client project.

Business: [BUSINESS_NAME]
Client: [CLIENT_NAME] / [CLIENT_COMPANY]
Project name: [PROJECT_NAME]
Project start date: [START_DATE]
Estimated completion: [END_DATE]

In-scope work (detailed):
[SCOPE_ITEM_1]
[SCOPE_ITEM_2]
[SCOPE_ITEM_3]
[SCOPE_ITEM_4]

Out-of-scope (explicit):
[EXCLUSION_1]
[EXCLUSION_2]

Deliverables:
[DELIVERABLE_1] — due [DATE]
[DELIVERABLE_2] — due [DATE]
[DELIVERABLE_3] — due [DATE]

Client responsibilities:
[WHAT_CLIENT_MUST_PROVIDE]

Change order policy: [CHANGE_ORDER_PROCESS]
Payment schedule: [PAYMENT_SCHEDULE]

Format as a professional SOW document with section headers, numbered lists, and clear language. Both parties should be able to refer to this document to resolve any scope dispute.
```

---

### Service Retainer Agreement Proposal
*Use when proposing an ongoing retainer arrangement to a client.*

```
Write a retainer proposal for a client who currently uses me on a project basis and would benefit from an ongoing arrangement.

Business: [BUSINESS_NAME]
Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Services in the retainer: [RETAINER_SERVICES]
Hours per month or deliverables included: [RETAINER_SCOPE]
Monthly retainer price: [RETAINER_PRICE]
Compared to what they currently pay per project: [CURRENT_SPEND — if known]
Key benefits of a retainer for them: [CLIENT_BENEFITS]
Key benefits for me: [MY_BENEFITS — e.g., predictable revenue, priority scheduling]

Write a retainer proposal email that:
1. Opens with the value they've already gotten (reference a specific project or result)
2. Presents the retainer as a smarter arrangement for their ongoing needs
3. Clearly outlines what's included
4. Shows the value comparison (retainer vs. ad-hoc pricing)
5. Ends with a simple next step

Tone: Like a trusted advisor recommending a better way to work together.
```

---

### Proposal Follow-Up Email — No Response
*Use when you've sent a proposal and haven't heard back after several days.*

```
Write a follow-up email for a prospect who hasn't responded to a proposal.

Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Proposal sent: [DATE_PROPOSAL_SENT]
Service proposed: [SERVICE_BRIEF]
Amount: [PROPOSAL_AMOUNT]
Days since no response: [DAYS_SINCE_SEND]
My name: [MY_NAME]

Write a follow-up that:
1. Is short (under 100 words)
2. Doesn't pressure or guilt-trip
3. Opens the door for them to share any questions or concerns
4. Re-states the key value in one sentence
5. Ends with a simple, single-choice ask (a call, a reply, a yes/no)

Tone: Warm and confident. Not desperate.
```

---

### Proposal Follow-Up — After a Call Where They Were Interested
*Use after a great discovery call when you want to send a same-day follow-up that reinforces their interest.*

```
Write a same-day follow-up email after a discovery call where the client was clearly interested.

Client: [CLIENT_NAME] at [CLIENT_COMPANY]
What we discussed: [CALL_SUMMARY]
Their main priority: [CLIENT_PRIORITY]
What I recommended: [MY_RECOMMENDATION]
Next step agreed on call: [AGREED_NEXT_STEP]
Proposal to be sent: [PROPOSAL_TIMING — e.g., "I'll send by Thursday"]

Write an email that:
1. Acknowledges the conversation and what you understood their goal to be
2. Confirms the next step you agreed on
3. Adds one additional value point or insight (to keep the momentum)
4. Sets clear expectations for timeline

Under 150 words. Keep the energy from the call alive.
```

---

### Objection Handling — Common Sales Objections
*Use when preparing for a pricing or closing conversation where you anticipate resistance.*

```
Write responses for the top objections I face when closing new clients.

My business: [BUSINESS_NAME] — [WHAT_I_DO]
My typical price range: [PRICE_RANGE]
My ideal client: [IDEAL_CLIENT_DESCRIPTION]

Write professional, confident responses for each of these objections:

1. "Your price is higher than someone else I talked to."
2. "We need to think about it / I need to talk to my partner."
3. "Can you do it for less if we cut some things?"
4. "We've had bad experiences with [TYPE_OF_VENDOR] before."
5. "Our budget isn't approved yet — can we start next month?"
6. "Can you do a trial period before we commit?"

For each response:
- Acknowledge without caving
- Reframe the objection as a value or risk question
- Move toward a decision (don't leave it open-ended)

Tone: Confident and consultative. Not pushy.
```

---

### New Client Welcome Email
*Use when a client signs and pays to kick off the relationship on the right foot.*

```
Write a new client welcome email for a client who just signed and made their first payment.

Business: [BUSINESS_NAME]
Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Service they purchased: [SERVICE_DESCRIPTION]
Start date: [START_DATE]
What happens next: [NEXT_STEPS — e.g., "I'll send you an intake form", "we'll schedule a kickoff call"]
What to expect in the first week: [FIRST_WEEK_PREVIEW]
My name: [MY_NAME]
Best way to reach me: [CONTACT_METHOD]

Write a welcome email that:
1. Opens with genuine enthusiasm (not "thank you for your business")
2. Confirms what they've purchased and what happens next
3. Sets clear expectations for timeline and communication
4. Makes them feel confident they made the right decision
5. Ends with one specific action they need to take

Warm, professional, and specific. Length: 3-4 paragraphs.
```

---

### Case Study Request Email
*Use when asking a happy client to participate in a case study for your marketing.*

```
Write an email asking a satisfied client to participate in a short case study.

Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Project or service delivered: [PROJECT_SUMMARY]
Result or outcome they experienced: [RESULT]
What I'm asking for: [CASE_STUDY_FORMAT — e.g., "a few quotes I can use on my website", "a 15-minute phone interview", "a written testimonial"]
What they'll get in return: [OFFER — e.g., "I'll feature your business on my website and social", "a discount on your next project"]

Write an email that:
1. Opens by referencing something specific from our work together
2. Makes the ask clearly and explains what's involved (time commitment)
3. Shows why this helps them too (exposure, LinkedIn feature, etc.)
4. Ends with a simple yes/no reply option

Under 200 words. Personal and direct.
```

---

### Price Increase Announcement
*Use when raising your rates and communicating it to existing clients.*

```
Write a price increase announcement for existing clients.

Business: [BUSINESS_NAME]
Existing clients receiving this: [CLIENT_TYPE — e.g., "all monthly retainer clients", "project clients in [INDUSTRY]"]
Current price: [CURRENT_PRICE]
New price: [NEW_PRICE]
Effective date: [EFFECTIVE_DATE]
Notice period: [NOTICE_GIVEN — e.g., "60 days' notice"]
Reason for increase (brief, honest): [REASON — e.g., "rising material costs", "business growth and service quality investment"]
Grandfathering option (if applicable): [GRANDFATHER_TERMS]

Write a price increase email that:
1. Leads with appreciation, not apology
2. Clearly states the new price and effective date
3. Gives a brief, honest reason (without over-explaining)
4. Mentions any grandfathering or loyalty acknowledgment
5. Ends with a warm invitation to ask questions

Tone: Confident and respectful. Don't apologize for charging what you're worth.
```

---

### Referral Request Email — After Project Completion
*Use when following up with a happy client to ask for referrals.*

```
Write a referral request email to send to a satisfied client after delivering a completed project.

Business: [BUSINESS_NAME]
Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Project completed: [PROJECT_DESCRIPTION]
Result or outcome: [RESULT_OR_OUTCOME]
Who I'm looking for: [IDEAL_REFERRAL_DESCRIPTION — e.g., "small business owners in [INDUSTRY] who need [SERVICE]"]
Incentive for referral (if any): [INCENTIVE]
My name: [MY_NAME]

Write a referral request that:
1. Opens by acknowledging the project and outcome specifically
2. Makes the ask naturally — not as a transactional demand
3. Describes clearly who would benefit from my service
4. Makes it easy to refer (what they'd say, or who to CC)
5. Ends with appreciation, not pressure

Under 150 words. Feels like a note from a friend, not a sales email.
```

---

### Contract Non-Payment Follow-Up
*Use when a client has missed a payment and you need to follow up professionally.*

```
Write a payment follow-up email for a client who has a past-due invoice.

Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Invoice number: [INVOICE_NUMBER]
Invoice amount: [AMOUNT]
Invoice due date: [DUE_DATE]
Days past due: [DAYS_OVERDUE]
Current project status: [STATUS — is work ongoing, complete, or paused?]
Previous follow-up attempts: [PREVIOUS_CONTACTS — none, or describe]
Late fee policy (if applicable): [LATE_FEE_POLICY]

Write a follow-up sequence of 2 emails:

Email 1 (friendly reminder, 1-7 days overdue):
- Professional, assumes it's an oversight
- States the amount and due date clearly
- Provides payment link or instructions
- Warm closing

Email 2 (firmer, 14+ days overdue):
- More direct, states the situation plainly
- References previous email
- States consequence if not resolved (e.g., work pause, late fee)
- Leaves door open for communication if there's an issue

Both emails under 150 words each.
```

---

### Proposal for a Government or Institutional Client
*Use when bidding on contracts with government agencies, schools, or larger institutions.*

```
Write a formal proposal for a government or institutional contract.

Business: [BUSINESS_NAME] — [BUSINESS_DESCRIPTION]
Client organization: [ORGANIZATION_NAME]
RFP or project number (if applicable): [RFP_REFERENCE]
Service proposed: [SERVICE_DESCRIPTION]
Scope of work: [SCOPE]
Timeline: [TIMELINE]
Pricing: [TOTAL_PRICE] — breakdown: [PRICE_BREAKDOWN]
Qualifications and relevant experience: [QUALIFICATIONS_AND_EXPERIENCE]
References available: [REFERENCES — yes/no, or list]
Business credentials: [LICENSES, INSURANCE, CERTIFICATIONS]

Write a formal proposal that:
1. Follows standard RFP response structure (executive summary, qualifications, scope, timeline, pricing)
2. Uses formal institutional language (less conversational than typical proposals)
3. Highlights compliance with any stated requirements
4. Clearly lists all credentials and qualifications
5. Includes a signature block and certification statement

Tone: Formal and precise. This will be evaluated by a committee.
```

---

### Discovery Call Agenda Prep
*Use when preparing the agenda and talking points for a sales discovery call.*

```
Write a discovery call agenda and talking points for a 30-minute call with a prospective client.

My business: [BUSINESS_NAME] — [WHAT_I_DO]
Prospect: [PROSPECT_NAME] at [PROSPECT_COMPANY]
What they reached out about: [INQUIRY_SUMMARY]
My goal for this call: [CALL_GOAL — e.g., "understand their needs, qualify them, and agree on next steps"]
Questions I want to ask: [MY_KEY_QUESTIONS]
Value points I want to communicate: [MY_KEY_VALUE_POINTS]

Write:
1. A 30-minute agenda with timestamps (e.g., 0-5 min: introductions)
2. Opening line to start the call on the right note
3. The 5 most important questions to ask (discovery-focused, not a pitch)
4. How to pivot from discovery to presenting my services naturally
5. Closing — how to end the call with a clear next step

Keep it practical. I'll be using this as a loose script, not reading it verbatim.
```

---

### Lost Proposal Response
*Use when a prospect chose a competitor and you want to learn why and leave the door open.*

```
Write an email to a prospect who chose a competitor after reviewing my proposal.

Client: [CLIENT_NAME] at [CLIENT_COMPANY]
What they told me: [THEIR_REASON — e.g., "went with a lower price", "chose another vendor", "decided to do it in-house"]
How long I worked on the proposal: [EFFORT_INVESTED]
My relationship with them: [RELATIONSHIP — first time prospect / prior client / referral]
Whether I want future business from them: [YES/NO]

Write a response that:
1. Graciously acknowledges their decision without bitterness
2. Thanks them for considering us and their time
3. Asks 1 honest question about why they went another direction (to learn from it)
4. Leaves the door open for future work without being pushy
5. Ends warmly

Under 100 words. Professional and human.
```

---

### Joint Venture / Partnership Proposal
*Use when proposing a collaboration, referral arrangement, or joint project with another business.*

```
Write a partnership or joint venture proposal for another business.

My business: [MY_BUSINESS_NAME] — [MY_BUSINESS_DESCRIPTION]
Potential partner: [PARTNER_BUSINESS_NAME] — [PARTNER_DESCRIPTION]
Proposed arrangement: [PARTNERSHIP_STRUCTURE — e.g., referral fee, co-marketing, joint project]
What I bring to the partnership: [MY_VALUE]
What they bring: [THEIR_VALUE]
How customers benefit: [CUSTOMER_BENEFIT]
Proposed terms: [TERMS — e.g., "15% referral fee on closed deals", "50/50 revenue split on joint projects"]

Write a partnership proposal email that:
1. Opens by establishing why these two businesses are a natural fit
2. Describes the partnership clearly and concisely
3. Makes the mutual benefit explicit
4. Outlines the proposed terms without making it feel like a legal document
5. Suggests a 30-minute call to discuss

Tone: Collaborative and professional. Peer-to-peer.
```

---

### Client Testimonial Request — Written
*Use when asking a happy client to write a testimonial for your website or marketing materials.*

```
Write a testimonial request email for a completed client project.

Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Project completed: [PROJECT_DESCRIPTION]
Outcome they experienced: [OUTCOME]
Where the testimonial will be used: [USE — e.g., "website", "Google Business profile", "LinkedIn"]
Format request: [FORMAT — e.g., "2-3 sentences", "LinkedIn recommendation", "video recording"]
My name: [MY_NAME]

Write an email that:
1. Thanks them for the project and references a specific positive moment
2. Asks for the testimonial in a natural, low-pressure way
3. Gives them guidance on what to write (what to include — so they don't face a blank page)
4. Makes it easy (link to where they can post, or reply to this email)

Under 150 words. Personal, not transactional.
```

---

### End-of-Year Client Review Email
*Use when reaching out to all clients at year-end to review the relationship and look ahead.*

```
Write an end-of-year client review email to send to my active client base.

Business: [BUSINESS_NAME]
Year: [YEAR]
What we accomplished together this year: [YEAR_IN_REVIEW_HIGHLIGHTS]
Any changes for next year (pricing, services, availability): [UPCOMING_CHANGES]
What I want from clients for next year: [GOAL — renewals, referrals, expanded projects]
My name: [MY_NAME]

Write a warm year-end email that:
1. Reflects on the year with genuine gratitude (not generic "thank you for your business")
2. Previews anything changing in the new year
3. Plants the seed for continued or expanded work
4. Ends with a warm, personal closing

Tone: Like a note from someone who genuinely cares about their clients' success.
Length: 2-3 paragraphs.
```

---

### Unsolicited Prospect Outreach — Cold Email
*Use when reaching out to a potential client who hasn't inquired.*

```
Write a cold outreach email to a business I believe would benefit from my services.

My business: [BUSINESS_NAME] — [WHAT_I_DO]
Prospect: [PROSPECT_NAME] at [PROSPECT_COMPANY], [INDUSTRY]
Why I'm reaching out to them specifically: [PERSONALIZED_REASON — something specific you noticed about their business]
The problem I can solve for them: [PROBLEM_I_SOLVE]
Relevant proof or credibility: [PROOF — e.g., "we've helped 3 [INDUSTRY] businesses achieve [RESULT]"]
My ask: [CTA — a call, a reply, a coffee]

Write a cold email that:
1. Opens with something specific about their business (shows I did my homework)
2. Names the problem I can solve in their language (not my service jargon)
3. Adds credibility without bragging (a result, not a list of features)
4. Ends with one simple, low-commitment ask
5. Does NOT start with "I hope this email finds you well"

Under 150 words. Human, direct, and specific.
```

---

### Proposal for Repeat Client — Expanded Scope
*Use when creating a proposal for a client who already knows you and is expanding their engagement.*

```
Write a proposal for a returning client who is expanding their work with us.

Business: [BUSINESS_NAME]
Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Previous work together: [PRIOR_PROJECT_SUMMARY]
Result we delivered: [PRIOR_RESULT]
New project or expanded scope: [NEW_PROJECT_DESCRIPTION]
Timeline: [TIMELINE]
Price: [PRICE]
How this builds on previous work: [CONNECTION_TO_PRIOR_WORK]

Write a proposal that:
1. Opens by referencing our prior work and outcome (not a generic introduction)
2. Frames the new project as a natural next step
3. Keeps the scope section concise (they already know how we work)
4. Includes pricing and timeline clearly
5. Ends with a warm, direct close (they trust us — make it easy to say yes)

Shorter than a first-time proposal. Tone: Like a trusted partner presenting the next phase.
```

---

### Terms and Conditions Summary Email
*Use when sending a new client your terms of service and want to highlight the key points.*

```
Write an email summarizing the key terms of our client agreement for a new client.

Business: [BUSINESS_NAME]
Client: [CLIENT_NAME]
Contract/terms highlights to explain:
- Payment terms: [PAYMENT_TERMS]
- Cancellation policy: [CANCELLATION_POLICY]
- Revision/change order policy: [REVISION_POLICY]
- Confidentiality (if applicable): [CONFIDENTIALITY_TERMS]
- Project start / timeline: [START_AND_TIMELINE]

Write an email that:
1. Presents the key terms in plain language (not legal-speak)
2. Highlights the 3 most important items they should be aware of
3. Invites questions before signing
4. Ends with a clear instruction on how to sign and return

Tone: Professional but friendly. The goal is clarity, not intimidation.
```

---

*Total prompts in this file: 23*
