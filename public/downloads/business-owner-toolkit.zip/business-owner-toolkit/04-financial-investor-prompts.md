# 04 — Financial & Investor Prompts

*18 prompts for financial summaries, investor pitches, funding requests, and financial communication*

---

### Monthly Financial Summary — Owner Review
*Use when writing a plain-language summary of your monthly financials for yourself or a business partner.*

```
Write a plain-language monthly financial summary based on the following data.

Business: [BUSINESS_NAME]
Month: [MONTH] [YEAR]
Revenue: [TOTAL_REVENUE]
Revenue vs. prior month: [CHANGE — up/down by %]
Revenue vs. same month last year: [YOY_CHANGE — if applicable]
Cost of goods sold (COGS): [COGS]
Gross profit: [GROSS_PROFIT] / [GROSS_MARGIN_%]
Operating expenses: [OPEX]
Net profit: [NET_PROFIT] / [NET_MARGIN_%]
Cash balance: [CASH_ON_HAND]
Accounts receivable outstanding: [AR_BALANCE]
Biggest revenue drivers: [TOP_REVENUE_SOURCES]
Biggest expense changes: [NOTABLE_EXPENSE_CHANGES]

Write a 300-400 word summary that:
1. Leads with the headline number (net profit) and its trend
2. Explains what drove revenue and expenses
3. Flags any concerning trends
4. Highlights positive momentum
5. Ends with 1-2 priorities for next month based on the numbers

No jargon. Write like you're explaining this to a smart non-accountant.
```

---

### Annual Financial Summary for Accountant
*Use when preparing a year-end narrative to accompany your financials for your accountant or tax preparer.*

```
Write a year-end business financial summary to share with my accountant.

Business: [BUSINESS_NAME]
Year: [YEAR]
Total revenue: [ANNUAL_REVENUE]
Major revenue streams: [REVENUE_STREAMS]
Total expenses: [TOTAL_EXPENSES]
Major expense categories: [EXPENSE_CATEGORIES_WITH_AMOUNTS]
Net profit: [NET_PROFIT]
Any unusual items (one-time revenue or expenses): [UNUSUAL_ITEMS]
Equipment purchased: [EQUIPMENT_PURCHASED]
Business loans or lines of credit changes: [DEBT_CHANGES]
Home office or vehicle use: [HOME_OFFICE_VEHICLE — if applicable]
Contractor payments over $600: [CONTRACTOR_PAYMENTS — names and amounts]

Write a year-end summary memo that helps my accountant understand the context behind the numbers:
1. Brief business overview and any major changes during the year
2. Revenue narrative
3. Expense narrative
4. Unusual or one-time items with explanation
5. Questions I have for my accountant
```

---

### Cash Flow Projection Narrative
*Use when presenting a cash flow projection to a lender, investor, or business partner.*

```
Write a cash flow projection narrative for the next [PROJECTION_PERIOD — e.g., 6 months, 12 months].

Business: [BUSINESS_NAME]
Current cash balance: [CURRENT_CASH]
Expected monthly revenue: [MONTHLY_REVENUE — or range if variable]
Expected monthly expenses: [MONTHLY_EXPENSES]
Seasonal variations: [SEASONAL_PATTERN — e.g., "Q4 is 40% of annual revenue"]
Planned major expenses: [PLANNED_MAJOR_EXPENSES — equipment, hires, marketing]
Planned revenue growth drivers: [GROWTH_INITIATIVES]
Cash flow risk factors: [RISKS — e.g., "key client contract renewal", "seasonal slow period in Feb-March"]

Write a cash flow narrative that:
1. Presents the projection clearly (month-by-month summary table)
2. Explains the assumptions behind the numbers
3. Identifies the best-case and worst-case months
4. Addresses risk factors and mitigations
5. States the minimum cash reserve goal and whether it's achievable

This will be presented to [AUDIENCE — lender/investor/partner]. Write accordingly.
```

---

### Loan Application Business Summary
*Use when applying for a business loan and need to write the business narrative section.*

```
Write a business summary for a small business loan application.

Business: [BUSINESS_NAME]
Owner(s): [OWNER_NAMES]
Business type: [BUSINESS_TYPE]
Years in operation: [YEARS_IN_BUSINESS]
Location: [LOCATION]
Number of employees: [EMPLOYEE_COUNT]
Annual revenue (last year): [ANNUAL_REVENUE]
Annual revenue (year before): [PRIOR_YEAR_REVENUE]
Net profit margin: [PROFIT_MARGIN]
Loan amount requested: [LOAN_AMOUNT]
Purpose of loan: [LOAN_PURPOSE]
How loan will be repaid: [REPAYMENT_PLAN]
Collateral offered (if any): [COLLATERAL]
Business strengths: [TOP_3_STRENGTHS]

Write a loan application narrative that:
1. Describes the business clearly (what we do, who we serve, how long we've been doing it)
2. Demonstrates financial stability and track record
3. States clearly what the funds will be used for and why
4. Shows how the loan will be repaid
5. Presents risk factors honestly and explains how they're managed

2-3 pages. Professional and factual.
```

---

### Investor Pitch — Elevator Pitch (60 seconds)
*Use when preparing a verbal or written elevator pitch for potential investors.*

```
Write a 60-second elevator pitch for attracting a small business investor.

Business: [BUSINESS_NAME]
What we do: [ONE_SENTENCE_DESCRIPTION]
The problem we solve: [PROBLEM]
Our solution: [SOLUTION]
Market size or opportunity: [MARKET_OPPORTUNITY]
Revenue model: [HOW_WE_MAKE_MONEY]
Current revenue: [CURRENT_REVENUE]
Growth rate: [GROWTH_RATE]
What we're asking for: [FUNDING_ASK]
What we'll do with it: [USE_OF_FUNDS]
Why now / why us: [WHY_NOW_WHY_US]

Write a 150-200 word elevator pitch that:
1. Opens with the problem — not a business introduction
2. Presents the solution simply
3. States the traction (proof this works)
4. Makes the ask clear
5. Ends with the vision (where is this going?)

Punchy, memorable, and specific. Designed to make the listener say "tell me more."
```

---

### Investor Pitch Deck — Narrative for Key Slides
*Use when building a pitch deck and need compelling narrative for each slide.*

```
Write slide narratives for a small business investor pitch deck.

Business: [BUSINESS_NAME]
Stage: [STAGE — early-stage startup, established business seeking growth capital, etc.]
Funding ask: [FUNDING_ASK]
Use of funds: [USE_OF_FUNDS]
Business metrics: [KEY_METRICS — revenue, customers, growth rate, margins]
Market opportunity: [MARKET_SIZE_AND_OPPORTUNITY]
Competitive differentiation: [HOW_WE_WIN]
Team: [KEY_TEAM_MEMBERS_AND_CREDENTIALS]
Traction: [PROOF_POINTS — customers, contracts, partnerships]
Financial projections (3 years): [YEAR_1], [YEAR_2], [YEAR_3]

Write compelling narrative for each of these slides:
1. Problem (the pain point in the market)
2. Solution (what we built)
3. Market opportunity (size and timing)
4. Business model (how we make money)
5. Traction (what we've proven)
6. Team (why we can execute)
7. Financial projections (what the numbers look like)
8. The ask (what we need and what you'll get)

Each slide narrative: 3-5 sentences of compelling copy + 2-3 bullet points.
```

---

### Budget Planning Memo
*Use when setting an annual budget and want to document your assumptions and priorities.*

```
Write a budget planning memo for my business for [FISCAL_YEAR].

Business: [BUSINESS_NAME]
Revenue target: [REVENUE_TARGET]
Revenue growth assumption: [GROWTH_ASSUMPTION — based on what?]
Budget priorities: [TOP_3_BUDGET_PRIORITIES]
Planned investments: [PLANNED_INVESTMENTS — hires, equipment, marketing, etc.]
Cost reduction targets: [COST_REDUCTION_GOALS — if any]
Key financial risk factors: [RISK_FACTORS]
Cash reserve target: [CASH_RESERVE_GOAL]
Owner distributions or salary: [OWNER_COMP_PLAN]

Write a budget planning memo that:
1. Sets context for the year ahead
2. States the revenue target and growth assumption
3. Explains the key budget decisions and why
4. Identifies the top financial risks
5. Sets a clear framework for quarterly check-ins

1-2 pages. Plain language. For internal use or sharing with an accountant or business partner.
```

---

### Pricing Strategy Analysis
*Use when evaluating your pricing model and preparing to change or defend it.*

```
Help me analyze and improve my pricing strategy.

Business: [BUSINESS_NAME]
Current pricing: [CURRENT_PRICING_STRUCTURE]
Cost to deliver: [COST_TO_DELIVER_PER_UNIT_OR_PROJECT]
Current gross margin: [GROSS_MARGIN]
Competitor pricing (if known): [COMPETITOR_PRICING]
Customer willingness to pay signals: [CUSTOMER_SIGNALS — complaints about price, what tier they're on, etc.]
Business revenue goal: [REVENUE_GOAL]
Growth constraint: [WHAT'S_LIMITING_GROWTH — not enough customers? margins too low? can't scale at current price?]

Analyze my pricing and write:
1. Assessment of current pricing vs. costs and market (am I over or under-pricing?)
2. Three alternative pricing structures to consider (with pros/cons for each)
3. Recommended pricing strategy with rationale
4. How to implement a price change without losing existing customers
5. The long-term impact of each option on revenue and margin

Be direct. I need actionable insight, not a textbook overview.
```

---

### Grant Application Narrative
*Use when applying for a small business grant and need to write the business description or narrative.*

```
Write a grant application narrative for a small business grant.

Business: [BUSINESS_NAME]
Owner: [OWNER_NAME]
Grant: [GRANT_NAME] offered by [GRANT_ORGANIZATION]
Grant amount: [GRANT_AMOUNT]
Grant purpose/focus: [WHAT_GRANT_FUNDS — e.g., minority-owned business, local job creation, sustainability initiative]
Business description: [WHAT_WE_DO]
How we meet the grant criteria: [ALIGNMENT_WITH_GRANT_GOALS]
How we'll use the funds: [FUND_USE]
Community impact: [COMMUNITY_OR_ECONOMIC_IMPACT]
Business challenges we're solving: [CHALLENGES]
Evidence of viability: [BUSINESS_PROOF — revenue, customers, years operating]

Write a grant narrative that:
1. Opens with a compelling 1-paragraph story of the business and owner
2. Aligns our business clearly with the grant's stated goals
3. Describes the use of funds specifically
4. Demonstrates measurable community impact
5. Closes with a vision statement

2-3 pages. Compelling and specific. Grant readers see hundreds of applications — make ours memorable.
```

---

### Financial Health Check — Self-Assessment
*Use when doing a quarterly financial health review of your business.*

```
You are a small business financial advisor. Based on the metrics I provide, give me an honest financial health assessment.

Business: [BUSINESS_NAME]
Revenue trend (last 3 months): [MONTHLY_REVENUES]
Gross margin: [GROSS_MARGIN_%]
Net margin: [NET_MARGIN_%]
Monthly expenses (total): [MONTHLY_EXPENSES]
Cash on hand: [CASH_BALANCE]
Months of runway (cash / monthly expenses): [RUNWAY]
AR (accounts receivable) over 30 days: [OVERDUE_AR]
Business debt: [TOTAL_DEBT] — monthly payment: [DEBT_PAYMENT]
Owner pay: [OWNER_SALARY_OR_DRAW]
Revenue concentration risk: [LARGEST_CLIENT_%_OF_REVENUE]

Provide:
1. An honest 1-paragraph assessment of current financial health
2. The top 3 financial risks I should address in the next 90 days
3. 1 quick win I can make this week
4. A 6-month priority list (in order of impact)

Don't sugarcoat it. I need the real picture.
```

---

### Invoice Late Fee Policy Communication
*Use when establishing or communicating a late payment policy to clients.*

```
Write a late fee policy statement and client communication for late invoice payments.

Business: [BUSINESS_NAME]
Late fee structure: [LATE_FEE — e.g., "1.5% per month on balances over 30 days", "flat $50 fee after 15 days"]
Grace period: [GRACE_PERIOD — e.g., 7 days, 15 days]
When policy takes effect: [EFFECTIVE_DATE]
Existing clients who need notification: [CLIENT_GROUP]

Write:
1. A 1-paragraph late fee policy statement (for contracts and invoices)
2. An email announcing the policy to existing clients
3. A standard line to add to all future invoices

Tone for the client email: Professional and matter-of-fact. Not apologetic, but not aggressive.
```

---

### Business Partnership Financial Split Agreement Summary
*Use when documenting a revenue or profit split between business partners.*

```
Write a partnership financial agreement summary for two business co-owners.

Partner 1: [PARTNER_1_NAME] — ownership %: [OWNERSHIP_1]
Partner 2: [PARTNER_2_NAME] — ownership %: [OWNERSHIP_2]
Business: [BUSINESS_NAME]
Revenue/profit split: [SPLIT_ARRANGEMENT — e.g., "60/40 after expenses", "equal draw from profits quarterly"]
How expenses are handled: [EXPENSE_HANDLING]
Owner compensation: [EACH_PARTNER_SALARY_OR_DRAW]
Decision-making for major purchases: [DECISION_THRESHOLD — e.g., "any expense over $5,000 requires agreement"]
Exit provisions: [EXIT_TERMS — what happens if one partner wants out]

Write a summary document of the financial arrangement that:
1. Clearly states each partner's ownership and financial rights
2. Documents the revenue/profit distribution method
3. Notes how expenses and major decisions are handled
4. Describes the exit process simply

Note: This summary is not a legal substitute for a proper partnership agreement. Use alongside legal counsel.
```

---

### Funding Pitch to Friends and Family
*Use when asking people you know personally to invest in your business.*

```
Write a funding request to present to friends and family investors.

Business: [BUSINESS_NAME]
What we do: [BRIEF_DESCRIPTION]
Amount raising: [FUNDING_AMOUNT]
What it will be used for: [USE_OF_FUNDS]
Projected return or terms: [INVESTOR_TERMS — loan at X% interest, equity share, etc.]
Repayment timeline: [TIMELINE]
Risk disclosure: [HONEST_RISK_STATEMENT — this should be real and honest]
Current business status: [CURRENT_REVENUE_AND_STAGE]

Write a pitch letter that:
1. Treats this as a professional investment, not a favor
2. Clearly explains the business opportunity
3. States what they're being offered (terms)
4. Is 100% honest about risk
5. Includes how and when they'll be paid back
6. Ends with next steps to participate

Tone: Personal but professional. Warm but serious. This is a business deal, not a family favor.
```

---

### Business Valuation Summary — For Sale or Partnership
*Use when preparing a summary of your business's value for a potential buyer or partner.*

```
Write a business valuation summary for presenting to a potential buyer or investor.

Business: [BUSINESS_NAME]
Years in operation: [YEARS]
Annual revenue: [ANNUAL_REVENUE]
Annual profit (SDE — seller's discretionary earnings): [SDE]
Industry multiple range: [MULTIPLE_RANGE — e.g., "2-3x SDE for this industry"]
Estimated valuation range: [VALUATION_RANGE]
Key value drivers: [WHAT_MAKES_THIS_BUSINESS_VALUABLE — e.g., recurring revenue, brand, customer list, systems]
Growth opportunity: [UNTAPPED_GROWTH]
Owner involvement required: [OWNER_DEPENDENCE]
Asking price: [ASKING_PRICE — if applicable]

Write a 1-2 page business valuation summary that:
1. Presents the financial performance clearly
2. Explains the valuation methodology
3. Highlights the value drivers (what makes this a good investment)
4. Addresses owner dependence and transition risk
5. States the opportunity for the buyer/investor

Professional and factual. For presentation to qualified buyers or investors only.
```

---

### Year-End Tax Planning Memo
*Use when preparing notes for year-end tax planning conversations with your accountant.*

```
Write a year-end tax planning memo for my business.

Business: [BUSINESS_NAME]
Current year revenue: [CURRENT_YEAR_REVENUE]
Current year estimated profit: [ESTIMATED_PROFIT]
Estimated tax liability: [ESTIMATED_TAX]
Business structure: [LLC/S-CORP/SOLE_PROP/PARTNERSHIP]
Planned major purchases before year-end: [PLANNED_PURCHASES]
Retirement contributions: [RETIREMENT_PLAN_CONTRIBUTIONS]
Pending invoices to defer (if cash basis): [DEFERRABLE_INCOME]
Expenses to accelerate: [EXPENSES_TO_PREPAY]
Questions for my accountant: [QUESTIONS]

Write a year-end tax planning memo that:
1. Summarizes the financial position for the year
2. Lists opportunities to reduce taxable income before year-end
3. Notes questions to address with the accountant
4. Sets a 30-60-90 day action plan

Clear, organized, and actionable. This is prep material for a tax planning meeting.
```

---

### Break-Even Analysis
*Use when evaluating a new service, product, or business decision.*

```
Help me calculate and present a break-even analysis for [DECISION_OR_NEW_SERVICE].

Decision: [WHAT_I'M_EVALUATING — e.g., "adding a new service", "hiring a full-time employee", "opening a second location"]
Fixed costs for this decision: [FIXED_COSTS — monthly/annual]
Variable costs per unit/sale: [VARIABLE_COST_PER_UNIT]
Revenue per unit/sale: [REVENUE_PER_UNIT]
Current monthly revenue (baseline): [BASELINE_REVENUE]
Expected monthly revenue from this decision: [PROJECTED_NEW_REVENUE]

Calculate:
1. Break-even point (units sold / months until profitable)
2. Break-even timeline (how long before ROI is positive)
3. Best-case and worst-case scenarios
4. My recommendation (is this a good decision at these numbers?)

Present as a clear analysis with a simple table and a plain-language summary I can use to make the decision.
```

---

### Investor Update Email — Monthly or Quarterly
*Use when sending a regular update to investors or financial partners.*

```
Write a monthly/quarterly investor update email.

Business: [BUSINESS_NAME]
Period: [MONTH/QUARTER]
Key metric highlights:
- Revenue: [REVENUE] (vs. target: [TARGET])
- Customers/clients: [CUSTOMER_COUNT]
- Key growth metrics: [GROWTH_METRICS]
Wins this period: [WINS]
Challenges this period: [CHALLENGES]
What we're working on next: [UPCOMING_PRIORITIES]
Cash position: [CASH_STATUS]
Any asks from investors: [INVESTOR_ASK — introductions, advice, etc.]

Write an investor update that:
1. Opens with the headline metric first
2. Gives context behind the numbers (story, not just data)
3. Is honest about challenges (investors respect transparency)
4. Ends with a clear forward-looking statement
5. Includes any specific asks

Under 400 words. Direct, honest, and professional.
```

---

*Total prompts in this file: 18*
