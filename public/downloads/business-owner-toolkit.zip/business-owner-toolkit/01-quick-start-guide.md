# 01 — Quick Start Guide

*How to get maximum value from this toolkit in the first 10 minutes*

---

## The 3-Minute Setup

### Step 1: Pick Your AI Tool
These prompts work with any modern LLM:
- **ChatGPT (GPT-4o)** — Best for iterative back-and-forth
- **Claude (Sonnet or Opus)** — Best for long-form documents and professional writing
- **Gemini Advanced** — Good for research-heavy prompts

### Step 2: Set a System Prompt (Optional but Powerful)
Paste this at the start of any new conversation to establish context:

```
You are a seasoned business advisor and entrepreneur with 15+ years running and growing small businesses. You understand cash flow, team dynamics, client relationships, and the reality of wearing multiple hats. You write with clarity, confidence, and practicality — no corporate jargon. When I give you a prompt, produce clean, professional output I can use immediately. Assume I'm running a business with 1-25 employees and my time is extremely valuable.
```

### Step 3: Fill In the Brackets
Every prompt uses `[BRACKET_VARIABLES]` in ALL_CAPS. Before you paste, replace every bracket with your real context.

---

## How to Fill In Variables Like a Pro

**Bad:**
```
[BUSINESS_NAME] = my company
[SERVICE] = what we do
```

**Good:**
```
[BUSINESS_NAME] = Apex Landscaping — a commercial and residential landscaping company in Austin, TX
[SERVICE] = weekly lawn maintenance, seasonal cleanups, and landscape installation for properties with $500K+ value
```

The more specific you are, the more professional the output.

---

## Power Techniques

### Stack Prompts for Complex Tasks
Use multiple prompts together:
1. Use **Client Proposal Generator** (Prompt 1) to draft the proposal
2. Feed it into **Proposal Follow-Up Email** (Prompt 8) when there's no response
3. Use **Objection Handler** (Prompt 9) before a price negotiation call

### Regenerate with Constraints
- *"Regenerate this, but make it 30% shorter and more direct"*
- *"Rewrite this for a more skeptical client who's comparing multiple vendors"*
- *"Make the tone less formal — I have a casual relationship with this client"*

### Ask for Alternatives
- *"Give me 3 different versions of this proposal introduction"*
- *"What are 5 ways to frame this price increase to minimize resistance?"*

---

## Common Mistakes to Avoid

❌ **Using generic context** — Fill in your real business name, service, client type, and specific situation.

❌ **Sending AI output unedited** — Always read, edit, and make it sound like you.

❌ **Using AI for decisions** — These prompts help you communicate. The decision about what to charge, who to hire, or what to offer is still yours.

❌ **Skipping the system prompt** — It makes every response more tailored.

---

## Recommended Use by Situation

| Situation | Go-To Prompts |
|-----------|--------------|
| Writing a new client proposal | Client Proposals #1, #2 |
| Following up on an ignored proposal | Client Proposals #7, #8 |
| Writing a job description | Team Operations #1 |
| Dealing with a difficult employee | Team Operations #12, #13 |
| Preparing for a bank meeting | Financial/Investor #1, #3 |
| Writing a pitch to investors | Financial/Investor #7, #8 |
| Creating social media content | Marketing #1, #2, #3 |
| Asking for referrals | Marketing #13 |
| Writing an email newsletter | Marketing #10 |

---

## File Navigation

- **Client Proposals** → [02-client-proposals-prompts.md](02-client-proposals-prompts.md)
- **Team Operations** → [03-team-operations-prompts.md](03-team-operations-prompts.md)
- **Financial & Investor** → [04-financial-investor-prompts.md](04-financial-investor-prompts.md)
- **Marketing & Brand** → [05-marketing-brand-prompts.md](05-marketing-brand-prompts.md)
- **Full Workflow Playbooks** → [06-workflow-sops.md](06-workflow-sops.md)
- **Quick Reference** → [07-cheat-sheet.md](07-cheat-sheet.md)

---

*Ready? Jump to the cheat sheet for the 15 highest-impact prompts, or go straight to the section you need most right now.*
