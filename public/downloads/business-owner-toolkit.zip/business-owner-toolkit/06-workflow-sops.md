# 06 — Workflow SOPs

*5 complete systems for your most time-intensive business tasks — powered by AI*

---

> **How to use this file:** Each SOP is a repeatable, step-by-step process. Follow the steps in order, use the referenced prompt files, and replace example inputs with your own context. The goal is a *system* — something you run every time, not just once.

---

## SOP A: The New Client Proposal System — From Lead to Signed in 48 Hours

**What this produces:** A professional proposal and signed client agreement  
**When to run it:** Every time you have a qualified lead ready for a proposal  
**Time commitment:** 60-90 minutes (vs. 3-4 hours without AI)  
**Prompt file:** `02-client-proposals-prompts.md`

---

**Step 1 — Qualify before you write (20 minutes)**

Before writing a single word, run **Discovery Call Agenda Prep** from `02-client-proposals-prompts.md` and use the **Discovery Questions** prompt to run a proper discovery conversation.

Gather:
- [ ] Exact scope of what they need
- [ ] Timeline and decision deadline
- [ ] Budget range (or signals)
- [ ] Who makes the final decision
- [ ] What "success" looks like to them

Don't skip this. A proposal written without proper discovery wastes your time and loses you work.

---

**Step 2 — Choose the right proposal format (5 minutes)**

- **Full proposal** (for projects over $5,000, new clients, or government/institutional): Use **Client Proposal Generator — Full Proposal**
- **One-page proposal** (for returning clients, smaller jobs, or clients who prefer brevity): Use **Service Proposal — One-Page Version**
- **Retainer arrangement**: Use **Service Retainer Agreement Proposal**

---

**Step 3 — Write the proposal (20-30 minutes)**

Use the appropriate prompt. Fill in every bracket with real, specific details.

Review checklist before sending:
- [ ] Is the scope crystal clear? Would YOU know exactly what to do from this document?
- [ ] Is everything NOT included explicitly listed?
- [ ] Is the price and payment schedule clear?
- [ ] Is there one obvious CTA?

---

**Step 4 — Send with a personal note (5 minutes)**

Never send a proposal as a cold attachment. Write a 3-4 sentence email that:
1. References something specific from your discovery conversation
2. Tells them what's attached and what to look for
3. Gives them a deadline to review (creates momentum)
4. Makes it easy to reply with questions

---

**Step 5 — Follow up systematically**

If no response within 5 business days: Use **Proposal Follow-Up Email — No Response**
If they were interested but went quiet: Use **Proposal Follow-Up — After a Call**
If they push back on price: Use **Pricing Justification Letter**
If they chose someone else: Use **Lost Proposal Response**

---

## SOP B: The Annual Financial Review — 2-Hour Year-End Ritual

**What this produces:** A clear picture of your business's financial health, year-end tax prep, and priorities for next year  
**When to run it:** December or January each year  
**Time commitment:** 2 hours  
**Prompt file:** `04-financial-investor-prompts.md`

---

**Step 1 — Pull the numbers (30 minutes)**

Before opening any AI tool, gather from your accounting software (QuickBooks, Wave, FreshBooks, spreadsheet):
- [ ] Total revenue by month (12 months)
- [ ] Top 5 expense categories with totals
- [ ] Net profit
- [ ] AR outstanding
- [ ] Cash balance at year-end
- [ ] Any loans or credit line balances

---

**Step 2 — Write the financial summary (20 minutes)**

Use **Annual Financial Summary for Accountant** from `04-financial-investor-prompts.md`.

This accomplishes two things:
1. Gives you a clear English-language summary of your year
2. Gives your accountant the context they need to do their job better

---

**Step 3 — Run the financial health check (15 minutes)**

Use **Financial Health Check — Self-Assessment** from `04-financial-investor-prompts.md`.

Don't sugarcoat your inputs. You need an honest picture, not a flattering one.

---

**Step 4 — Plan the budget (20 minutes)**

Use **Budget Planning Memo** from `04-financial-investor-prompts.md`.

Key decisions to make:
- Revenue target: Based on last year, what's realistic with 15-20% growth?
- The 2 investments that will drive the most growth
- The 1 cost you can cut without hurting operations

---

**Step 5 — Year-end tax planning (30 minutes)**

Use **Year-End Tax Planning Memo** from `04-financial-investor-prompts.md`.

Send this to your accountant 2-3 weeks before your tax planning meeting. It puts the context in writing and makes the meeting dramatically more productive.

---

## SOP C: The Marketing Month — Batch Your Content in 2 Hours

**What this produces:** A full month of social media content, one newsletter, and any promotional materials  
**When to run it:** First Monday of every month  
**Time commitment:** 2 hours  
**Prompt file:** `05-marketing-brand-prompts.md`

---

**Step 1 — Review last month (15 minutes)**

Before creating new content, assess what worked:
- What posts got the most engagement?
- Did the newsletter get good response?
- What offers or promotions worked?
- What should you do more of?

---

**Step 2 — Plan the content calendar (20 minutes)**

Use **Seasonal Content Calendar — One Month** from `05-marketing-brand-prompts.md`.

Fill in:
- Any seasonal events, promotions, or holidays
- Any projects or results you can share
- Educational or value-based content ideas

---

**Step 3 — Draft 4-6 social posts (30 minutes)**

From your calendar, pick the highest-priority posts and draft them using:
- **Social Media Post — Business Story** (once a month, great for connection)
- **Before and After / Results Post** (whenever you have a great finished job)
- **LinkedIn Post — Business Insight** (thought leadership, trust-building)

---

**Step 4 — Write the monthly newsletter (30 minutes)**

Use **Email Newsletter — Monthly** from `05-marketing-brand-prompts.md`.

Newsletter rule: Lead with value, end with an offer. Not the other way around.

---

**Step 5 — Handle any review responses (15 minutes)**

Use **Customer Review Response — Positive** and **Customer Review Response — Negative** for any outstanding reviews from last month.

Never let a negative review sit unanswered for more than 72 hours.

---

## SOP D: The New Hire System — From Job Post to First Day

**What this produces:** A professional hiring process from job description to onboarding  
**When to run it:** Any time you're bringing on a new team member  
**Time commitment:** 3-4 hours over 2-3 weeks  
**Prompt file:** `03-team-operations-prompts.md`

---

**Week 1 — Write and post the job description**

Use **Job Description Writer** from `03-team-operations-prompts.md`.

Post to:
- [ ] Indeed / ZipRecruiter / LinkedIn (depending on role)
- [ ] Local Facebook group or community board (for local roles)
- [ ] Your own social media
- [ ] Personal network outreach

---

**Week 1-2 — Screen and interview**

Use **Interview Question Set** from `03-team-operations-prompts.md`.

Run a 15-minute phone screen first — eliminate bad fits before spending 60 minutes interviewing them.

Reference check every finalist before making an offer. Ask previous employers:
- "Would you hire this person again?"
- "What's their greatest strength? Their biggest challenge?"

---

**Week 2 — Make the offer**

Use **Team Announcement — New Hire** from `03-team-operations-prompts.md` to prepare the announcement.

If using a contractor: Use **Contractor Agreement Summary** to document the arrangement.

---

**First day — Onboarding**

Use **Employee Onboarding Checklist** from `03-team-operations-prompts.md`.

The first day sets the tone for the entire employment relationship. Make it organized, welcoming, and productive.

---

**First 30 days — Culture and SOPs**

Use **Employee Policy Document** for any critical policies.
Use **Standard Operating Procedure (SOP)** for their core recurring tasks.

The goal: By the end of week 4, they should be able to perform their core tasks without asking you for help.

---

## SOP E: The Investor / Lender Meeting Prep System

**What this produces:** A polished pitch or loan application that gets funded  
**When to run it:** 2-3 weeks before any funding conversation  
**Time commitment:** 4-6 hours  
**Prompt file:** `04-financial-investor-prompts.md`

---

**Step 1 — Know your numbers cold (1 hour)**

Before any investor or lender conversation, you need to be able to answer these without hesitation:
- Annual revenue (last 2 years)
- Net profit margin
- Monthly cash burn and runway
- Top 3 revenue sources
- Biggest cost category

Use **Financial Health Check — Self-Assessment** to get honest about your financial position.

---

**Step 2 — Write your pitch (1-2 hours)**

- For a bank/SBA loan: Use **Loan Application Business Summary**
- For angel investors or business partners: Use **Investor Pitch Deck — Narrative for Key Slides**
- For friends and family: Use **Funding Pitch to Friends and Family**
- For a quick verbal pitch: Use **Investor Pitch — Elevator Pitch (60 seconds)**

---

**Step 3 — Prepare your projections (1 hour)**

Use **Cash Flow Projection Narrative** to build and narrate your 12-month projection.

Investors/lenders don't expect perfection. They expect:
- That you understand your numbers
- That your assumptions are defensible
- That you have a plan if things go slower than expected

---

**Step 4 — Anticipate their questions (30 minutes)**

Every funder will ask:
1. "Why do you need this money and why now?"
2. "How will you pay it back / what's my return?"
3. "What could go wrong?"
4. "Why you — why is your business the right bet?"

Prepare a 2-3 sentence answer to each before you walk in the room.

---

**Step 5 — Follow up after the meeting**

Within 24 hours, send a follow-up email:
1. Thank them for their time
2. Address any open questions from the meeting
3. State clearly what the next step is and your timeline

Don't leave funding conversations without a defined next step.

---

*5 complete small business workflow SOPs*
