# 07 — The Business Owner's AI Cheat Sheet

*The 15 most powerful prompts in this toolkit — ready to copy, paste, and use right now*

---

> **How to use this file:** Every prompt here is copied in full from the main prompt files. Fill in every `[BRACKET]` with your real context before pasting. Output quality = input specificity.

---

## THE 15 MOST POWERFUL PROMPTS

---

### 🏆 Prompt 1: Client Proposal Generator
*Source: 02-client-proposals-prompts.md*
*Why it's here: Your proposal wins or loses the job. This one wins.*

```
Write a complete client proposal.

Business: [BUSINESS_NAME] — [BUSINESS_DESCRIPTION]
Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Project: [PROJECT_DESCRIPTION]
Scope of work: [SCOPE]
Timeline: [TIMELINE]
Deliverables: [DELIVERABLES]
Investment: [PRICE] — payment terms: [PAYMENT_TERMS]
Why us: [DIFFERENTIATOR]

Include: executive summary, understanding of need, detailed scope, exclusions, timeline with milestones, investment, why [BUSINESS_NAME], next steps.
Tone: Professional and confident.
```

---

### 🏆 Prompt 2: Pricing Justification
*Source: 02-client-proposals-prompts.md*
*Why it's here: Every business owner faces price objections. This stops the negotiation cold.*

```
Write a pricing justification email for a client who said our proposal is too expensive.

Business: [BUSINESS_NAME]
Client: [CLIENT_NAME]
Our price: [OUR_PRICE]
Their objection: [WHAT_THEY_SAID]
What our price includes: [WHAT'S_INCLUDED]
Risk of cheaper alternative: [CHEAPER_RISK]
Our proof: [CREDENTIALS_OR_TRACK_RECORD]
Optional compromise: [COMPROMISE — if applicable]

Write a response that: acknowledges their concern, shows value not just tasks, addresses the risk of going cheaper, offers one optional compromise, and invites a conversation.
Tone: Confident, not apologetic.
```

---

### 🏆 Prompt 3: Monthly Financial Summary
*Source: 04-financial-investor-prompts.md*
*Why it's here: If you can't explain your numbers in plain English, you can't manage them.*

```
Write a plain-language monthly financial summary.

Month: [MONTH] [YEAR]
Revenue: [REVENUE] (vs. last month: [CHANGE])
COGS: [COGS]
Gross profit: [GROSS_PROFIT] / [GROSS_MARGIN_%]
Operating expenses: [OPEX]
Net profit: [NET_PROFIT] / [NET_MARGIN_%]
Cash balance: [CASH]
Top revenue drivers: [TOP_SOURCES]
Notable expense changes: [EXPENSE_CHANGES]

Write a 300-word summary: headline number + trend, what drove results, concerning trends, positive momentum, next month priorities.
```

---

### 🏆 Prompt 4: Job Description Writer
*Source: 03-team-operations-prompts.md*
*Why it's here: The quality of your job description determines the quality of your applicant pool.*

```
Write a compelling job description.

Business: [BUSINESS_NAME] — [BUSINESS_DESCRIPTION]
Role: [JOB_TITLE]
Type: [FULL_TIME/PART_TIME/CONTRACT]
Location: [IN_PERSON/REMOTE/HYBRID]
Pay: [PAY_RANGE]
Core responsibilities: [RESPONSIBILITIES]
Requirements: [REQUIREMENTS]
Nice to have: [PREFERRED]
What makes this job great: [WHY_WORK_HERE]
How to apply: [INSTRUCTIONS]

Write a description that opens with why someone would want this job, describes impact not just tasks, and ends with an easy application CTA.
```

---

### 🏆 Prompt 5: Investor Elevator Pitch
*Source: 04-financial-investor-prompts.md*
*Why it's here: You have 60 seconds. Use them perfectly.*

```
Write a 60-second investor elevator pitch.

Business: [BUSINESS_NAME]
What we do: [ONE_SENTENCE]
The problem: [PROBLEM]
Our solution: [SOLUTION]
Market opportunity: [MARKET]
Revenue model: [HOW_WE_MAKE_MONEY]
Current revenue: [REVENUE]
Growth rate: [GROWTH]
Ask: [FUNDING_AMOUNT]
Use of funds: [USE_OF_FUNDS]
Why now / why us: [WHY_NOW_WHY_US]

Write 150-200 words: opens with the problem, presents traction, makes the ask clear, ends with vision.
```

---

### 🏆 Prompt 6: Difficult Employee Conversation Script
*Source: 03-team-operations-prompts.md*
*Why it's here: Most people avoid hard conversations. This makes them easier to have — and more effective.*

```
Prepare me for a difficult conversation with an employee.

Issue: [SPECIFIC_ISSUE — what happened, when, impact]
My goal: [GOAL — correct behavior, let them go, address complaint]
Their likely reaction: [ANTICIPATED_REACTION]
What I want to avoid: [AVOID]

Write: opening statement, how to present the issue factually, how to give space to respond, how to redirect if defensive, how to close with a clear next step, what to document.
```

---

### 🏆 Prompt 7: Facebook/Instagram Ad Copy
*Source: 05-marketing-brand-prompts.md*
*Why it's here: Paid social is how most small businesses grow. This produces ads that actually convert.*

```
Write Facebook/Instagram ad copy.

Service being advertised: [SERVICE]
Target audience: [AUDIENCE — age, interests, location, pain point]
Problem the ad addresses: [CUSTOMER_PROBLEM]
Offer: [OFFER]
CTA: [CTA]

Write:
1. Headline (under 40 characters)
2. Mobile body copy (under 125 characters)
3. Desktop body copy (under 250 characters)
4. CTA button text
5. A/B test variation
```

---

### 🏆 Prompt 8: Referral Request Email
*Source: 02-client-proposals-prompts.md*
*Why it's here: Referrals are your best leads. Most owners never ask.*

```
Write a referral request email for a satisfied client.

Client: [CLIENT_NAME] at [CLIENT_COMPANY]
Project completed: [PROJECT]
Result: [OUTCOME]
Who I'm looking for: [IDEAL_REFERRAL]
Incentive: [INCENTIVE — if any]

Write a referral request that: opens by acknowledging the project specifically, asks naturally (not transactionally), describes who'd benefit, makes it easy to refer, and ends with appreciation not pressure.
Under 150 words.
```

---

### 🏆 Prompt 9: Standard Operating Procedure
*Source: 03-team-operations-prompts.md*
*Why it's here: SOPs are how you stop being the bottleneck in your own business.*

```
Write an SOP for a recurring business process.

Process name: [PROCESS_NAME]
Who follows it: [ROLE]
Frequency: [HOW_OFTEN]
Steps involved: [DESCRIBE_THE_PROCESS]
Tools used: [TOOLS]
Common mistakes to avoid: [PITFALLS]
What "done right" looks like: [QUALITY_STANDARD]

Write with: purpose statement, scope, numbered step-by-step instructions, quality checkpoints, what to do if something goes wrong, owner and review date.
```

---

### 🏆 Prompt 10: Price Increase Announcement
*Source: 02-client-proposals-prompts.md*
*Why it's here: Most owners dread raising prices. This email makes it easy.*

```
Write a price increase announcement for existing clients.

Current price: [CURRENT_PRICE]
New price: [NEW_PRICE]
Effective date: [EFFECTIVE_DATE]
Notice given: [NOTICE_PERIOD]
Reason: [REASON — brief and honest]
Grandfathering option: [GRANDFATHER_TERMS — if any]

Write an email that: leads with appreciation, clearly states new price and date, gives a brief honest reason, mentions any grandfathering, invites questions.
Tone: Confident and respectful.
```

---

### 🏆 Prompt 11: Website Homepage Copy
*Source: 05-marketing-brand-prompts.md*
*Why it's here: Your homepage is your hardest-working salesperson. Most are terrible.*

```
Write website homepage copy.

Tagline: [TAGLINE]
What we do: [SERVICE]
Ideal customer: [IDEAL_CUSTOMER]
Their pain point: [CUSTOMER_PAIN]
Our solution: [SOLUTION]
Top 3 differentiators: [DIFFERENTIATORS]
Social proof: [PROOF]
CTA: [CTA]

Write copy for: hero headline + subhead, what we do (benefit-led), why choose us (3-4 value points), social proof framing, CTA section.
```

---

### 🏆 Prompt 12: Monthly Email Newsletter
*Source: 05-marketing-brand-prompts.md*
*Why it's here: Email is your most valuable marketing channel. Most business owners don't use it.*

```
Write a monthly email newsletter.

Month: [MONTH]
Audience: [SUBSCRIBER_TYPE]
Main topic: [THEME]
Business news: [UPDATE]
Useful tip: [TIP]
Offer (if any): [OFFER]
CTA: [ACTION]

Write with: a subject line that gets opened, an opener worth reading (not a business announcement), genuine value, one clear CTA.
Under 400 words. Readable in 90 seconds.
```

---

### 🏆 Prompt 13: Negative Review Response
*Source: 05-marketing-brand-prompts.md*
*Why it's here: Your response to a bad review is marketing to every future customer who reads it.*

```
Write a professional response to a negative review.

What they wrote: "[NEGATIVE_REVIEW]"
What actually happened: [YOUR_ACCOUNT]
Was the complaint valid? [YES/PARTIALLY/NO]
Resolution offered: [RESOLUTION]

Write a response that: opens with acknowledgment (not denial), is factual not emotional, takes responsibility where appropriate, states what was done to resolve it, invites direct contact, demonstrates professionalism to future readers.
Under 150 words.
```

---

### 🏆 Prompt 14: Loan Application Business Summary
*Source: 04-financial-investor-prompts.md*
*Why it's here: The narrative section of a loan application is where most businesses lose the deal.*

```
Write a business summary for a loan application.

Business: [BUSINESS_NAME]
Owner: [OWNER_NAME]
Years in operation: [YEARS]
Annual revenue: [REVENUE] (last year) / [PRIOR_YEAR] (year before)
Net profit margin: [MARGIN]
Loan amount: [LOAN_AMOUNT]
Purpose: [LOAN_PURPOSE]
Repayment plan: [REPAYMENT]
Collateral: [COLLATERAL — if any]
Top 3 strengths: [STRENGTHS]

Write a 2-3 page narrative: business description, financial stability, specific use of funds, repayment plan, risk factors and management.
```

---

### 🏆 Prompt 15: Performance Review
*Source: 03-team-operations-prompts.md*
*Why it's here: Most small business owners skip performance reviews entirely. These make them easy and effective.*

```
Write a performance review for an employee.

Employee: [EMPLOYEE_NAME], [ROLE]
Review period: [PERIOD]
What they do well: [STRENGTHS]
Areas for improvement: [IMPROVEMENT_AREAS]
Key accomplishments: [ACCOMPLISHMENTS]
Prior goals: [PRIOR_GOALS] — progress: [GOAL_PROGRESS]
New goals: [NEW_GOALS]
Compensation change: [COMP_CHANGE — if any]

Write a review that: leads with genuine recognition, addresses improvement with specific examples, sets clear measurable goals, ends with encouragement.
Tone: Direct and fair. Growth conversation, not punishment.
```

---

## QUICK VARIABLE REFERENCE

| Variable | What to Put Here |
|----------|-----------------|
| `[BUSINESS_NAME]` | Your full business name |
| `[CLIENT_NAME]` | Client's first and last name |
| `[CLIENT_COMPANY]` | Their company name |
| `[PROJECT_DESCRIPTION]` | Specific project being proposed |
| `[SCOPE]` | Detailed list of what you will do |
| `[PRICE]` | Total or starting price |
| `[TIMELINE]` | Start date, end date, milestones |
| `[DIFFERENTIATOR]` | What makes your business uniquely valuable |
| `[OUTCOME]` | Measurable result delivered |
| `[MY_NAME]` | Your name |
| `[ANNUAL_REVENUE]` | Your business's annual top-line revenue |
| `[NET_PROFIT]` | Revenue minus expenses |
| `[EMPLOYEE_NAME]` | Team member's name |
| `[JOB_TITLE]` | Role/position title |

---

*Built for business owners who do the work.*
