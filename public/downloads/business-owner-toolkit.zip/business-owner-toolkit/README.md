# 💼 The Small Business Owner's AI Prompt Toolkit

**90+ battle-tested AI prompts for entrepreneurs, founders, and small business owners**

---

## What's Inside

Running a small business means wearing every hat — salesperson, manager, marketer, and CFO — often in the same hour. This toolkit gives you instant access to high-quality, copy-paste-ready prompts for every part of owning and growing a business.

Every prompt is:
- **Practical** — Built for real small business challenges, not corporate theory
- **Structured** — Uses `[BRACKET VARIABLES]` so you can customize in seconds
- **Immediately usable** — Designed to produce output you can send, present, or post today

---

## File Guide

| File | Contents | Prompts |
|------|----------|---------|
| [01-quick-start-guide.md](01-quick-start-guide.md) | How to use this toolkit effectively | — |
| [02-client-proposals-prompts.md](02-client-proposals-prompts.md) | Proposals, contracts, pricing, and client acquisition | 23 |
| [03-team-operations-prompts.md](03-team-operations-prompts.md) | Hiring, managing, SOPs, and team communication | 22 |
| [04-financial-investor-prompts.md](04-financial-investor-prompts.md) | Financial summaries, investor pitches, funding asks | 18 |
| [05-marketing-brand-prompts.md](05-marketing-brand-prompts.md) | Brand copy, social media, ads, and email marketing | 17 |
| [06-workflow-sops.md](06-workflow-sops.md) | 5 complete business workflow playbooks | — |
| [07-cheat-sheet.md](07-cheat-sheet.md) | Top 15 power prompts + quick reference | 15 |

**Total: 90+ prompts**

---

## Who This Is For

- **Small business owners** managing a team of 2–50 people
- **Entrepreneurs** launching or growing a service or product business
- **Founders** who need to punch above their weight without a full team
- **Freelancers** scaling into an agency or studio model

---

## How to Use

1. Start with **[01-quick-start-guide.md](01-quick-start-guide.md)** — 3-minute setup
2. Bookmark **[07-cheat-sheet.md](07-cheat-sheet.md)** — your daily driver
3. Deep-dive into specific sections as you need them

---

*Built for business owners who do the work.*
