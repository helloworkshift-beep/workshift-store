# 03 — Team Operations Prompts

*22 prompts for hiring, managing, building SOPs, and communicating with your team*

---

### Job Description Writer
*Use when creating a job posting for a new or replacement hire.*

```
Write a compelling job description for an open position at my small business.

Business: [BUSINESS_NAME] — [BUSINESS_DESCRIPTION]
Role: [JOB_TITLE]
Type: [FULL_TIME/PART_TIME/CONTRACT/SEASONAL]
Location: [IN_PERSON/REMOTE/HYBRID] in [LOCATION — if applicable]
Pay range: [PAY_RANGE] — [HOURLY/SALARY/COMMISSION_STRUCTURE]
Core responsibilities: [RESPONSIBILITY_1], [RESPONSIBILITY_2], [RESPONSIBILITY_3], [RESPONSIBILITY_4]
Required skills/experience: [REQUIREMENTS]
Nice-to-have: [PREFERRED_QUALIFICATIONS]
What makes this job great: [BENEFITS_AND_CULTURE — what sets this job apart]
How to apply: [APPLICATION_INSTRUCTIONS]

Write a job description that:
1. Opens with 2-3 sentences about the business that make the reader want to work here
2. Describes the role's impact, not just the tasks
3. Lists responsibilities as outcomes ("You will be responsible for...")
4. Distinguishes between required and preferred qualifications clearly
5. Ends with a call to action that makes applying feel easy

Tone: Friendly and professional. Attract someone who wants to grow with the business.
```

---

### Interview Question Set
*Use when preparing for a job interview for a specific role.*

```
Write a set of interview questions for a [JOB_TITLE] position at my [BUSINESS_TYPE] business.

What this person will actually do day-to-day: [DAY_TO_DAY_RESPONSIBILITIES]
The most important quality for success in this role: [MOST_IMPORTANT_QUALITY]
Previous problem areas with this role (if any): [PAST_PAIN_POINTS — e.g., "previous hires weren't reliable", "needed more initiative"]
Skill areas I want to assess: [SKILL_AREAS]

Write 15 interview questions including:
- 4 experience-based questions (tell me about a time...)
- 4 situational questions (what would you do if...)
- 3 skill-specific questions for [SKILL_AREAS]
- 2 culture-fit questions
- 2 closing questions to assess interest and ask them

Include what a strong answer to each question looks like (brief note, not a full rubric).
```

---

### Employee Onboarding Checklist
*Use when creating a first-week onboarding plan for a new hire.*

```
Create a first-week onboarding plan and checklist for a new employee.

Business: [BUSINESS_NAME]
New hire: [EMPLOYEE_NAME], [JOB_TITLE]
Start date: [START_DATE]
Who they report to: [MANAGER_NAME]
Their core responsibilities: [RESPONSIBILITIES]
Tools/systems they'll use: [TOOLS_AND_SYSTEMS]
Key people they need to meet: [KEY_TEAM_MEMBERS]
Critical policies to cover: [POLICIES — e.g., schedule, communication expectations, dress code]

Create a day-by-day onboarding plan for the first 5 days:
- Day 1: Orientation, introductions, setup
- Day 2: Training on [TRAINING_TOPIC_1]
- Day 3: Training on [TRAINING_TOPIC_2]
- Day 4: First supervised tasks
- Day 5: Check-in, feedback, Q&A

Include: a onboarding checklist (tasks with owner and deadline), and a list of what the new hire should be able to do independently by end of week one.
```

---

### Standard Operating Procedure (SOP) — Template
*Use when documenting a recurring business process so anyone on your team can follow it.*

```
Write a Standard Operating Procedure (SOP) for the following business process.

Business: [BUSINESS_NAME]
Process name: [PROCESS_NAME — e.g., "New Client Intake", "Weekly Cash Close", "Opening Shift Procedure"]
Who follows this SOP: [ROLE_OR_TEAM]
Frequency: [HOW_OFTEN — daily, weekly, per-job, etc.]
Steps involved: [DESCRIBE_THE_PROCESS_IN_YOUR_OWN_WORDS]
Tools or systems used: [TOOLS_USED]
Common mistakes or shortcuts to avoid: [PITFALLS]
Quality standard (what does "done right" look like): [QUALITY_STANDARD]

Write a SOP with:
1. Purpose statement (why this process exists)
2. Scope (who this applies to, when)
3. Step-by-step instructions (numbered, action-oriented: "Do X, then Y")
4. Quality checkpoints (how to know if each step was done correctly)
5. What to do if something goes wrong
6. Owner and review date

Format for easy printing or sharing in a team chat.
```

---

### Performance Review — Annual or Quarterly
*Use when writing an employee performance review.*

```
Write a performance review for an employee based on the following information.

Employee: [EMPLOYEE_NAME], [JOB_TITLE]
Review period: [REVIEW_PERIOD]
Performance summary:
- What they do well: [STRENGTHS]
- Areas for improvement: [IMPROVEMENT_AREAS]
- Key accomplishments this period: [ACCOMPLISHMENTS]
- Goals from last review: [PRIOR_GOALS]
- Progress on those goals: [GOAL_PROGRESS]
- New goals for next period: [NEW_GOALS]
- Compensation change (if any): [COMPENSATION_CHANGE]

Write a review that:
1. Leads with genuine recognition of what they do well
2. Addresses improvement areas with specific examples (not vague feedback)
3. Sets clear, measurable goals for the next period
4. Is honest but not demoralizing
5. Ends with encouragement and a forward-looking statement

Tone: Direct and fair. This is a growth conversation, not a performance punishment.
```

---

### Employee Reprimand Letter
*Use when documenting a disciplinary action for a policy violation or performance issue.*

```
Write a formal reprimand letter for an employee issue that needs to be documented.

Employee: [EMPLOYEE_NAME], [JOB_TITLE]
Issue: [DESCRIBE_THE_ISSUE — what happened, when, any pattern of behavior]
Policy violated (if applicable): [POLICY_VIOLATED]
Previous verbal warning? [YES/NO — if yes, when]
Consequences if issue continues: [CONSEQUENCES]
Required corrective action: [WHAT_THEY_MUST_DO — specific, measurable]
Review date: [FOLLOW_UP_DATE — when this will be revisited]
Manager name: [MANAGER_NAME]

Write a reprimand letter that:
1. States the issue factually (no emotion, no character attacks)
2. References prior warnings if applicable
3. Clearly states the required corrective action
4. States the consequence of non-compliance
5. Ends with an opportunity for the employee to respond
6. Includes a signature line for both parties

Tone: Professional and firm. Not punitive — corrective.
```

---

### Team Meeting Agenda
*Use when planning a team meeting and want to maximize the time spent.*

```
Write a team meeting agenda for [MEETING_PURPOSE].

Business: [BUSINESS_NAME]
Meeting type: [WEEKLY_STANDUP / MONTHLY_REVIEW / PROBLEM_SOLVING / TRAINING / ALL_HANDS]
Attendees: [TEAM_MEMBERS_OR_ROLES]
Meeting length: [DURATION — e.g., 30 minutes, 1 hour]
Goals for this meeting: [WHAT_SHOULD_BE_DECIDED_OR_COMMUNICATED]
Topics to cover: [TOPIC_1], [TOPIC_2], [TOPIC_3]
Any decisions needed: [DECISIONS_REQUIRED]
Any announcements: [ANNOUNCEMENTS]

Create an agenda with:
1. Timestamps for each section
2. Owner of each agenda item
3. Clear description of whether each item is for information, discussion, or decision
4. Parking lot section (for topics that come up but aren't on the agenda)
5. Action items section at the end

Also write a 2-sentence email I can send to attendees in advance with the agenda attached.
```

---

### Employee Policy Document
*Use when writing or updating a workplace policy for your team.*

```
Write a clear employee policy document for [POLICY_TOPIC].

Business: [BUSINESS_NAME]
Policy topic: [POLICY_TOPIC — e.g., "Cell Phone Use During Work Hours", "Time-Off Request Process", "Social Media Policy"]
Why this policy exists: [REASON_FOR_POLICY]
What the policy requires: [POLICY_REQUIREMENTS]
What is prohibited: [PROHIBITIONS]
Consequence for violation: [CONSEQUENCE]
Effective date: [EFFECTIVE_DATE]

Write a policy document that:
1. States the purpose in 1-2 sentences
2. Defines the scope (who it applies to)
3. States the policy requirements clearly (simple language, no jargon)
4. Lists prohibited behaviors explicitly
5. States consequences for violations
6. Includes a signature/acknowledgment section

Tone: Clear and professional, not legalistic. This should be readable by any employee.
```

---

### Difficult Conversation Script — Employee Issue
*Use when preparing for a tough conversation with an employee about performance or behavior.*

```
Write a script to help me prepare for a difficult conversation with an employee.

Employee: [EMPLOYEE_NAME]
Issue to address: [ISSUE — be specific: what happened, when, what the impact was]
My goal for the conversation: [GOAL — e.g., "get them to understand the impact of their behavior and commit to changing it", "let them go professionally", "address a complaint another employee made"]
Their likely reaction: [ANTICIPATED_REACTION — defensive, emotional, cooperative]
What I want to avoid: [AVOID — e.g., "a shouting match", "an HR complaint", "them quitting on the spot"]

Write:
1. An opening statement (how to start the conversation without ambushing them)
2. How to present the issue factually (use specific examples)
3. How to give them space to respond
4. How to redirect if they become defensive or emotional
5. How to close the conversation with a clear next step
6. What to document after the meeting

Tone: Direct but respectful. This is a business conversation, not a personal attack.
```

---

### Employee Termination Letter
*Use when formally terminating an employee.*

```
Write a termination letter for an employee.

Employee: [EMPLOYEE_NAME], [JOB_TITLE]
Termination date: [TERMINATION_DATE]
Reason for termination: [REASON — performance, layoff, policy violation, end of contract]
Prior warnings documented? [YES/NO]
Severance (if any): [SEVERANCE_DETAILS]
Final pay details: [FINAL_PAY — when and how]
Benefits/continuation (if applicable): [BENEFITS_INFO]
Equipment/property return: [RETURN_REQUIREMENTS]
Reference policy: [REFERENCE_POLICY — what you'll say if contacted]

Write a termination letter that:
1. States clearly and directly that employment is ending and when
2. Gives the reason without over-explaining
3. Covers the practical details (final pay, benefits, property return)
4. Is professional and without cruelty
5. Maintains dignity for the employee

Note: Always have an employment attorney review termination letters for your jurisdiction before sending.
```

---

### Team Announcement — New Hire
*Use when announcing a new team member to your existing staff.*

```
Write a new hire announcement to share with the team.

Business: [BUSINESS_NAME]
New hire: [EMPLOYEE_NAME]
Role: [JOB_TITLE]
Start date: [START_DATE]
Background: [BRIEF_BACKGROUND — where they're from, relevant experience]
Fun fact or personal note: [PERSONAL_DETAIL — something they shared they're comfortable sharing]
What they'll be doing: [ROLE_SUMMARY]
How team members interact with them: [INTERACTION — who they'll work with, what to expect]
My name: [MY_NAME]

Write a welcome announcement (email or message) that:
1. Introduces the new hire warmly
2. Gives enough context for the team to understand their role
3. Includes a human detail (not just a job summary)
4. Invites the team to welcome them
5. Sets expectations for their first week

Tone: Warm and welcoming. This sets the culture tone.
```

---

### Contractor Agreement Summary
*Use when onboarding an independent contractor and want to document the arrangement clearly.*

```
Write a project agreement summary for an independent contractor.

My business: [BUSINESS_NAME]
Contractor: [CONTRACTOR_NAME / COMPANY]
Project or services: [PROJECT_DESCRIPTION]
Deliverables: [DELIVERABLES]
Timeline: [START_DATE] to [END_DATE]
Compensation: [RATE] — payment terms: [PAYMENT_TERMS]
Independent contractor status: [CONFIRM — not an employee, responsible for own taxes]
Intellectual property: [IP_TERMS — who owns the work product]
Confidentiality: [CONFIDENTIALITY_REQUIREMENTS]
Termination clause: [HOW_EITHER_PARTY_CAN_END_ARRANGEMENT]

Write a contractor agreement summary letter/email that:
1. Confirms the scope of work and deliverables
2. States compensation and payment terms clearly
3. Confirms their independent contractor status
4. Notes IP and confidentiality expectations
5. States termination terms
6. Ends with a clear instruction to sign/confirm

Note: This summary is not a substitute for a formal legal contract. Use for supplemental clarity only.
```

---

### Team Culture Values Statement
*Use when defining or articulating the values and culture you want to build in your business.*

```
Write a team culture and values statement for my business.

Business: [BUSINESS_NAME]
What we do: [BUSINESS_DESCRIPTION]
How we want to treat our team: [TEAM_CULTURE_GOALS]
How we want to treat our customers: [CUSTOMER_PHILOSOPHY]
What we won't compromise on: [NON_NEGOTIABLES]
What success looks like to us: [SUCCESS_DEFINITION]
Examples of our best days at work: [BEST_DAY_EXAMPLES — when has the team been at their best?]

Write:
1. A 3-5 sentence mission/culture statement (the "why we exist" paragraph)
2. 4-6 core values with a 1-sentence explanation of each
3. A short paragraph on how we treat each other
4. A short paragraph on how we treat customers
5. A "this is who we are" statement for the end of a job posting or onboarding doc

Tone: Authentic and specific to your business. Not generic corporate values.
```

---

### Compensation Review Request — Internal
*Use when presenting a salary or wage adjustment recommendation to leadership or a business partner.*

```
Write an internal memo recommending a compensation adjustment for an employee.

Employee: [EMPLOYEE_NAME], [JOB_TITLE]
Current compensation: [CURRENT_RATE]
Recommended new rate: [PROPOSED_RATE]
Reason for recommendation: [REASON — performance, tenure, market rate, role expansion]
Performance highlights supporting the recommendation: [PERFORMANCE_EVIDENCE]
Market rate context (if known): [MARKET_DATA]
When the increase would take effect: [EFFECTIVE_DATE]
Budget impact: [ANNUAL_IMPACT]

Write a memo that:
1. States the recommendation clearly upfront
2. Builds the business case with evidence
3. Notes the cost of NOT giving the increase (turnover risk, morale)
4. Recommends a path forward

Under 300 words. Designed to get a quick decision from a business partner or decision-maker.
```

---

### Vendor Comparison Summary
*Use when evaluating multiple vendors or suppliers and presenting your recommendation.*

```
Write a vendor comparison summary to help decide between multiple service providers or suppliers.

Category being evaluated: [VENDOR_CATEGORY — e.g., payroll service, cleaning company, materials supplier]
Vendors compared: [VENDOR_1], [VENDOR_2], [VENDOR_3]
Evaluation criteria:
- Price: [PRICE_COMPARISON]
- Quality/reliability: [QUALITY_NOTES]
- Customer service: [SERVICE_NOTES]
- Contract terms: [CONTRACT_COMPARISON]
- References/reviews: [REFERENCE_SUMMARY]

My recommendation: [VENDOR_I_RECOMMEND]
Reason: [REASON_FOR_RECOMMENDATION]

Write a vendor comparison summary document with:
1. A quick overview table (vendor, price, key pros, key cons)
2. A short narrative section explaining the decision
3. My recommendation with rationale
4. Next steps (who needs to sign off, when to start)

Format for sharing with a business partner or team lead who wasn't part of the evaluation.
```

---

### Staff Scheduling Communication
*Use when communicating schedule changes, requirements, or policies to your team.*

```
Write a staff scheduling communication for [SCHEDULE_CHANGE_OR_POLICY].

Business: [BUSINESS_NAME]
Change or policy: [DESCRIBE_THE_SCHEDULE_CHANGE_OR_RULE]
Effective date: [EFFECTIVE_DATE]
Who it affects: [AFFECTED_STAFF]
Why it's changing: [REASON — if appropriate to share]
What employees need to do: [REQUIRED_ACTION]
Who to contact with questions: [CONTACT]

Write a clear, direct message (email or team chat post) that:
1. States the change clearly in the first sentence
2. Explains why (briefly, if appropriate)
3. Tells staff exactly what they need to do and by when
4. Gives a place to ask questions

Under 150 words. No fluff.
```

---

### Employee Recognition Message
*Use when publicly recognizing a team member for exceptional work.*

```
Write an employee recognition message for a team member who went above and beyond.

Employee: [EMPLOYEE_NAME], [ROLE]
What they did: [SPECIFIC_ACTION — what exactly happened that deserves recognition]
When it happened: [TIMEFRAME]
Impact it had: [IMPACT — how it helped the business, a customer, or a teammate]
Where this will be shared: [CHANNEL — team meeting, group chat, posted in break room, etc.]
My name: [MY_NAME]

Write a recognition message that:
1. Names the specific action (not vague "great work")
2. Explains why it mattered
3. Connects it to a value or standard the team aspires to
4. Feels genuine, not scripted

Under 100 words. Warm and specific.
```

---

### Business Operations Review — Quarterly Internal Memo
*Use when documenting quarterly business performance for yourself or a business partner.*

```
Write a quarterly business operations review memo.

Business: [BUSINESS_NAME]
Quarter: [QUARTER] [YEAR]
Revenue this quarter: [REVENUE]
Revenue vs. goal: [VS_GOAL — over/under by how much]
Biggest wins: [TOP_3_WINS]
Biggest challenges: [TOP_3_CHALLENGES]
Key lessons learned: [LESSONS]
Team changes: [TEAM_CHANGES]
Operational improvements made: [IMPROVEMENTS]
Goals for next quarter: [Q_NEXT_GOALS]
What I need to decide or do differently: [DECISIONS_NEEDED]

Write a 1-page quarterly memo that:
1. Summarizes the quarter in one paragraph
2. Highlights wins and challenges with context
3. Extracts the key lessons
4. Sets clear priorities for next quarter
5. Ends with personal action items

Use this as a record for yourself or as a document to share with a business partner, investor, or board.
```

---

### Team Retreat or Offsite Planning Email
*Use when planning an in-person team event and need to communicate details to staff.*

```
Write a team event announcement and logistics email.

Business: [BUSINESS_NAME]
Event type: [EVENT_TYPE — team lunch, annual retreat, training day, holiday party]
Date: [DATE]
Time: [TIME]
Location: [LOCATION]
Who is invited: [ATTENDEES]
What to expect: [AGENDA_SUMMARY]
What employees need to do: [REQUIRED_ACTIONS — RSVP, bring something, etc.]
Dress code (if applicable): [DRESS_CODE]
Any coverage or schedule notes: [COVERAGE_PLAN — who covers if needed]
My name: [MY_NAME]

Write a clear, enthusiastic event announcement that:
1. Conveys excitement without overdoing it
2. Gives all practical details clearly
3. States what employees need to do (RSVP, etc.)
4. Ends warmly

Under 200 words. Easy to read in 30 seconds.
```

---

*Total prompts in this file: 22*
