# 01 — Quick Start Guide

*How to get maximum value from this toolkit in the first 10 minutes*

---

## The 3-Minute Setup

### Step 1: Pick Your AI Tool
These prompts work with any modern LLM:
- **ChatGPT (GPT-4o)** — Great for proposals and quick client emails
- **Claude (Sonnet or Opus)** — Best for detailed scope of work documents
- **Gemini Advanced** — Works well on Android and mobile

### Step 2: Set a System Prompt
Paste this at the start of any new conversation:

```
You are an experienced general contractor and construction business owner with 20+ years in residential and commercial construction. You understand how to write professional proposals, manage client expectations, document change orders, and build a reputation in a competitive market. You write clearly and professionally — never overcomplicated, never vague. When I give you a prompt, produce clean, professional output I can send to a client or post online today.
```

### Step 3: Fill In the Brackets
Every prompt uses `[BRACKET_VARIABLES]` in ALL_CAPS. Replace every bracket with your real project details before pasting.

---

## How to Fill In Variables Like a Pro

**Bad:**
```
[PROJECT] = the job
[CLIENT] = my client
```

**Good:**
```
[PROJECT] = Complete kitchen remodel including cabinet replacement, countertop installation, tile backsplash, and new lighting — estimated 3-week timeline, $28,000 budget
[CLIENT] = Sarah M., homeowner in Denver, CO — referred by a previous client
```

Specific inputs produce proposals that win jobs.

---

## Power Techniques

### Build a Proposal Library
Once you generate a strong proposal for a kitchen remodel, bathroom renovation, or deck build — save it. The next similar job takes 10 minutes instead of an hour.

### Use the Change Order Prompts Proactively
Don't wait for scope creep to become a conflict. Use the change order prompts the moment additional work is requested, even before you've confirmed the cost.

### Let AI Handle the Awkward Conversations
Client unhappy with a delay? Vendor missed a delivery? The client communication prompts handle the diplomatic language so you can stay focused on the work.

---

## Common Mistakes to Avoid

❌ **Vague scope descriptions** — "Remodel bathroom" produces a weak proposal. "Replace vanity, tile shower, install new toilet, replace exhaust fan — 5-day job" produces a professional one.

❌ **Sending AI output without your license/insurance details** — Always add your contractor license number, insurance info, and signature line.

❌ **Skipping the marketing prompts** — Reputation and referrals are your growth engine. The review request and referral prompts pay for themselves.

---

## Recommended Use by Situation

| Situation | Go-To Prompts |
|-----------|--------------|
| Writing a job proposal | Proposals #1, #2 |
| Explaining your pricing | Proposals #8, #9 |
| Client requesting changes mid-job | Client Comm #6, #7 |
| Difficult client situation | Client Comm #11, #12 |
| Managing a subcontractor | Project Management #8, #9 |
| Requesting a Google review | Marketing #1, #2 |
| Responding to a bad review | Marketing #6 |
| Creating a project timeline | Project Management #1 |
| Writing a payment reminder | Client Comm #10 |
| Posting completed work on social | Marketing #9, #10 |

---

## File Navigation

- **Proposals & Bidding** → [02-proposal-bidding-prompts.md](02-proposal-bidding-prompts.md)
- **Client Communication** → [03-client-communication-prompts.md](03-client-communication-prompts.md)
- **Project Management** → [04-project-management-prompts.md](04-project-management-prompts.md)
- **Marketing & Reputation** → [05-marketing-prompts.md](05-marketing-prompts.md)
- **Full Workflow Playbooks** → [06-workflow-sops.md](06-workflow-sops.md)
- **Quick Reference** → [07-cheat-sheet.md](07-cheat-sheet.md)

---

*Start with the cheat sheet to get oriented, or jump straight to proposals if you have a bid due today.*
