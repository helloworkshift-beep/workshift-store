# 02 — Proposal & Bidding Prompts

*23 prompts for writing winning bids, proposals, scope of work documents, and pricing conversations*

---

### Full Project Proposal
*Use when writing a formal proposal for a new residential or commercial project.*

```
Write a professional contractor project proposal.

Company: [COMPANY_NAME], [LICENSE_NUMBER]
Client: [CLIENT_NAME] at [CLIENT_ADDRESS]
Project: [PROJECT_DESCRIPTION]
Scope of work: [DETAILED_SCOPE]
Materials to be used: [MATERIALS_AND_BRANDS]
Timeline: Start [START_DATE], complete by [COMPLETION_DATE]
Total bid: $[TOTAL_BID]
Breakdown: Labor $[LABOR], Materials $[MATERIALS], Other $[OTHER]
Payment schedule: [PAYMENT_SCHEDULE — e.g., 30% deposit, 40% at framing, 30% at completion]
Warranty: [WARRANTY_TERMS]
Exclusions: [WHAT'S_NOT_INCLUDED]

Write a proposal with:
1. Project overview (brief summary of what we're doing and why)
2. Detailed scope of work (numbered, specific)
3. Materials specification (brand/grade where relevant)
4. Timeline with key milestones
5. Pricing and payment schedule
6. Warranty and workmanship guarantee
7. Explicit exclusions
8. Next steps (how to accept this proposal)
```

---

### Quick Estimate — Phone or Walk-Through
*Use when a client needs a ballpark estimate during or immediately after a walk-through.*

```
Write a quick estimate summary to send after a project walk-through.

Client: [CLIENT_NAME]
Project: [PROJECT_TYPE — e.g., bathroom remodel, deck build, roof repair]
Size/scope: [SCOPE_BRIEF]
Estimate range: $[LOW] – $[HIGH]
What's included in this range: [INCLUDED_ITEMS]
What could move it higher: [VARIABLES — e.g., "material upgrades, hidden structural issues, permit costs"]
Next step to get a firm bid: [NEXT_STEP — detailed walk-through, drawings, material selections]
My name: [MY_NAME], [COMPANY_NAME]
Phone: [PHONE]

Write a follow-up message (email or text) that:
1. Thanks them for the walk-through
2. Presents the estimate range clearly
3. Explains what's included and what the variables are
4. Sets up the next step to get to a firm bid
5. Creates appropriate urgency around availability

Under 200 words.
```

---

### Scope of Work Document
*Use when creating a detailed scope of work document for a signed client.*

```
Write a detailed scope of work document for a signed contractor project.

Company: [COMPANY_NAME]
Client: [CLIENT_NAME], [CLIENT_ADDRESS]
Project: [PROJECT_NAME]
Contract date: [CONTRACT_DATE]
Start date: [START_DATE]
Completion date: [COMPLETION_DATE]

Scope of work (be detailed — this becomes the contract reference):
[SCOPE_ITEM_1]
[SCOPE_ITEM_2]
[SCOPE_ITEM_3]
[SCOPE_ITEM_4]
[SCOPE_ITEM_5]

Not included (explicit exclusions):
[EXCLUSION_1]
[EXCLUSION_2]
[EXCLUSION_3]

Client responsibilities:
[CLIENT_MUST_PROVIDE_OR_DO]

Permits: [WHO_PULLS_PERMITS — contractor or owner]
Material allowances: [ALLOWANCES — e.g., "$2,500 for tile selection"]
Change order process: [CHANGE_ORDER_POLICY]
Contract value: $[TOTAL]
Payment schedule: [PAYMENT_SCHEDULE]

Format as a professional SOW that both parties can reference to resolve any scope dispute.
```

---

### Bid for Government or Commercial Contract
*Use when bidding on a public project, RFP, or commercial contract.*

```
Write a formal bid for a government or commercial contract.

Bidder: [COMPANY_NAME], [LICENSE], [INSURANCE]
Project: [PROJECT_NAME], [PROJECT_NUMBER — if applicable]
Owner/issuer: [OWNER_OR_AGENCY]
Bid due date: [DUE_DATE]
Project location: [ADDRESS]
Scope of work bid: [SCOPE_SUMMARY]

Bid breakdown:
- Category 1: [ITEM], quantity: [QTY], unit cost: $[UNIT], total: $[TOTAL]
- Category 2: [ITEM], quantity: [QTY], unit cost: $[UNIT], total: $[TOTAL]
- General conditions: $[GC_COST]
- Overhead and profit: [%]
- Total bid: $[TOTAL_BID]

Qualifications and exclusions: [WHAT'S_NOT_INCLUDED]
Timeline proposed: [TIMELINE]
Bonding capacity: [BONDING — if applicable]
References: [REFERENCES — available upon request or list]

Format as a formal bid document appropriate for submission to a public agency or commercial owner.
```

---

### Pricing Justification — When You're Higher Than Competitors
*Use when a client questions your price after getting competing bids.*

```
Write a pricing justification message for a client who received a lower competing bid.

My company: [COMPANY_NAME]
My bid: $[MY_BID]
Competitor bid: $[COMPETITOR_BID]
Price difference: $[DIFFERENCE]
What makes my bid higher: [REASONS — materials quality, warranty, experience, insurance, timeline reliability, etc.]
Risks of the lower bid: [RISKS — without badmouthing: what questions they should ask the other contractor]
My track record: [PROOF — years in business, similar projects, references]

Write a message that:
1. Acknowledges the price difference directly
2. Explains what's included in my bid that may not be in the lower one
3. Gives them 3 questions to ask any contractor (that differentiate me without direct attack)
4. Ends with confidence — our price reflects our standard of work

Professional and confident. Not defensive.
```

---

### Material Allowance Explanation
*Use when explaining material allowances to a client in a proposal.*

```
Write a clear explanation of material allowances in a contractor proposal.

Project: [PROJECT_TYPE]
Allowance item: [ITEM — e.g., tile, fixtures, countertops, flooring]
Allowance amount: $[ALLOWANCE]
Why it's an allowance vs. a fixed price: [REASON — client selection pending, range depends on grade]
What happens if they choose below the allowance: [CREDIT_BACK — how credits are handled]
What happens if they choose above: [OVERAGE — how overages are billed]
Example selections at various price points: [LOW_EXAMPLE], [MID_EXAMPLE], [HIGH_EXAMPLE]

Write an explanation section for the proposal that:
1. Defines what an allowance means clearly
2. States the allowance amount
3. Explains the credit and overage process
4. Gives examples at different price points

Plain language. Clients are often confused by allowances — make it crystal clear.
```

---

### Project Start Delay Notice to Client
*Use when you need to notify a client that the project start is delayed.*

```
Write a message to a signed client about a project start delay.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Originally scheduled start: [ORIGINAL_START]
New expected start: [NEW_START]
Reason for delay: [REASON — permits, prior job, material delay, subcontractor availability]
What we're doing to minimize impact: [MITIGATION]
Impact on completion date (if any): [COMPLETION_IMPACT]

Write a message that:
1. States the delay and new start date upfront
2. Gives an honest reason
3. Shows what you're doing to manage it
4. Reconfirms commitment to quality and the original contract
5. Invites questions

Under 200 words. Professional and straightforward — delays happen; how you communicate them is what matters.
```

---

### Proposal Follow-Up — No Response
*Use when a prospect hasn't responded to a submitted proposal.*

```
Write a follow-up message for a client who hasn't responded to a proposal.

Client: [CLIENT_NAME]
Proposal submitted: [DATE]
Project: [PROJECT_TYPE]
Proposal amount: $[AMOUNT]
Days since submission: [DAYS]
My name: [MY_NAME], [COMPANY_NAME]

Write a follow-up that:
1. Is brief (under 100 words)
2. Doesn't pressure or guilt
3. Opens the door to questions or concerns
4. Mentions availability (my schedule is filling up — natural, not fake)
5. Ends with a simple yes/no/call ask

Warm and confident.
```

---

### Value-Added Extras in a Bid
*Use when you want to differentiate your bid by highlighting added value beyond the base scope.*

```
Write a "value adds" section to include in a contractor proposal.

Project: [PROJECT_TYPE]
Base scope: [BASE_SCOPE]
Added value items I'm including that others may not:
- [VALUE_ADD_1]: [DESCRIPTION AND WHY IT MATTERS]
- [VALUE_ADD_2]: [DESCRIPTION]
- [VALUE_ADD_3]: [DESCRIPTION]
Warranty I'm offering: [WARRANTY_TERMS]
My cleanup/site management approach: [SITE_APPROACH]
Communication promise: [HOW_YOU'LL_COMMUNICATE — daily updates, weekly calls, etc.]

Write a "Why Choose [COMPANY_NAME]" section for the proposal that highlights these differentiators in language that resonates with a homeowner or property owner who has never hired a contractor before.
```

---

### Warranty and Guarantee Statement
*Use when writing the warranty section of a proposal or contract.*

```
Write a contractor warranty and workmanship guarantee statement.

Company: [COMPANY_NAME]
Workmanship warranty: [WORKMANSHIP_WARRANTY — e.g., "1 year on labor", "lifetime on structural work"]
Materials warranty: [MATERIALS_WARRANTY — manufacturer warranty pass-through]
What the warranty covers: [COVERED_ITEMS]
What the warranty does NOT cover: [EXCLUSIONS — client-caused damage, natural disasters, normal wear]
How to make a warranty claim: [CLAIM_PROCESS]
Response time for warranty issues: [RESPONSE_COMMITMENT]

Write a warranty statement for inclusion in our proposals and contracts. Plain language. Covers what a client would actually want to know. Not a legal document — a trust-building statement.
```

---

### Bid Withdrawal Message
*Use when withdrawing a submitted bid due to changed circumstances.*

```
Write a bid withdrawal message to a client.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Bid submitted: [DATE]
Bid amount: $[AMOUNT]
Reason for withdrawal: [REASON — schedule conflict, capacity change, materials cost increase, etc.]
Whether I can re-bid in the future: [YES/NO/MAYBE — with timeframe]

Write a professional, brief message that:
1. States the withdrawal clearly
2. Gives an honest reason
3. Expresses genuine regret
4. Leaves the relationship intact for future work
5. Offers any help I can (referral to another contractor if I know someone reputable)

Under 150 words. Professional and respectful.
```

---

### Subcontractor Bid Request
*Use when soliciting bids from subcontractors for a specific scope of work.*

```
Write a bid request to a subcontractor.

My company: [MY_COMPANY_NAME]
Project: [PROJECT_NAME] at [PROJECT_ADDRESS]
Scope I need bid on: [SCOPE_FOR_SUB — be specific]
Start date: [START_DATE]
Timeline for sub's portion: [SUB_TIMELINE]
Plans/specs available: [YES — attached / NO — describe verbally]
Bid due date: [BID_DUE]
Contact for questions: [MY_NAME], [PHONE_OR_EMAIL]
Insurance requirements: [INSURANCE_REQUIRED — e.g., $1M GL, workers' comp]

Write a bid request that:
1. Describes the scope clearly (specific enough for accurate bidding)
2. States the timeline clearly
3. Notes insurance requirements
4. Gives a firm bid due date
5. Invites questions

Under 200 words. Professional and specific.
```

---

### Change Order Request — Client Initiated
*Use when a client requests changes and you need to document and price the change order.*

```
Write a change order document for a client-requested scope change.

Original contract: [ORIGINAL_CONTRACT_REFERENCE]
Client: [CLIENT_NAME]
Change requested: [CHANGE_DESCRIPTION]
Date requested: [DATE]
Impact on scope: [HOW_ORIGINAL_SCOPE_CHANGES]
Additional labor: [ADDITIONAL_LABOR_HOURS] × $[RATE] = $[LABOR_COST]
Additional materials: $[MATERIALS_COST]
Change order total: $[CHANGE_ORDER_TOTAL]
New contract total: $[ORIGINAL_CONTRACT] + $[CHANGE_ORDER] = $[NEW_TOTAL]
Impact on timeline: [DAYS_ADDED]
New completion date: [NEW_COMPLETION]

Format as a formal change order document that:
1. References the original contract
2. Describes the change clearly
3. Breaks down the cost
4. States the new total and timeline
5. Includes signature lines for both parties

Both parties must sign before change work begins.
```

---

### Proposal for Repeat Client — Streamlined Version
*Use when creating a proposal for a returning client who already knows how you work.*

```
Write a streamlined proposal for a returning client.

Client: [CLIENT_NAME]
Previous work together: [PRIOR_PROJECTS_SUMMARY]
New project: [NEW_PROJECT_DESCRIPTION]
Scope: [SCOPE]
Timeline: [TIMELINE]
Bid: $[BID]
Payment schedule: [PAYMENT_SCHEDULE]

Write a proposal that:
1. Opens by referencing our prior work and outcome (skip the lengthy intro)
2. Presents the scope concisely (they know how I work)
3. States pricing and payment clearly
4. Ends with a direct close (they trust me — make it easy to say yes)

Shorter than a first-time proposal. Assume the relationship — build on it.
```

---

### Unit Price Schedule for Recurring Work
*Use when setting up a unit price schedule for ongoing or repetitive client work.*

```
Write a unit price schedule for a commercial or property management client.

Client/company: [CLIENT_NAME]
Type of recurring work: [WORK_TYPE — e.g., "maintenance repairs", "tenant improvement work", "service calls"]
Agreement term: [TERM — e.g., "valid January 1 – December 31, 20XX"]
Unit prices:
- [WORK_ITEM_1]: $[UNIT_PRICE] per [UNIT — sq ft, hour, each]
- [WORK_ITEM_2]: $[UNIT_PRICE] per [UNIT]
- [WORK_ITEM_3]: $[UNIT_PRICE] per [UNIT]
- Emergency/after-hours rate: $[RATE] per hour (vs. $[STANDARD_RATE] standard)
Minimum call-out fee: $[MINIMUM]
Material markup: [MARKUP_%]
Payment terms: [TERMS]

Format as a professional unit price schedule for attachment to a master service agreement.
```

---

### Risk and Disclaimer Section for Proposals
*Use when adding appropriate disclaimer language to a proposal.*

```
Write a risk and disclaimer section for a contractor proposal.

Project type: [PROJECT_TYPE]
Known potential issues: [POTENTIAL_UNKNOWNS — e.g., hidden water damage, asbestos, structural surprises, unstable soil]
How unknowns will be handled: [CHANGE_ORDER_PROCESS]
Permit and inspection language: [PERMIT_TERMS — who pulls, what's required, delays]
Weather clause: [WEATHER_POLICY — delays, timeline adjustments]
Material price validity: [PRICE_VALIDITY — e.g., "bid valid for 30 days, subject to material price changes"]
Liability limitations: [LIABILITY — appropriate to your jurisdiction]

Write a professional disclaimer/risk section for our proposals that:
1. Sets realistic expectations without scaring off clients
2. Explains our change order process for unknowns
3. Addresses permitting and weather clearly
4. States how long this bid is valid

Note: Review with your attorney for your specific state and situation.
```

---

### Insurance and Licensing Statement
*Use when providing insurance and licensing information to a client or on a bid.*

```
Write a credentials and insurance statement for a contractor proposal.

Company: [COMPANY_NAME]
License type and number: [LICENSE_TYPE], [LICENSE_NUMBER]
Licensed in: [STATE]
General liability insurance: $[GL_COVERAGE] with [INSURANCE_CARRIER]
Workers' compensation: [WORKERS_COMP_CARRIER — or "all work performed by licensed contractor"]
Bonding: [BONDED_AMOUNT — if applicable]
Years in business: [YEARS]
BBB or other accreditations: [ACCREDITATIONS — if applicable]

Write a professional credentials statement for our proposals that:
1. States all licensing and insurance clearly
2. Offers to provide certificates upon request
3. Differentiates us from uninsured or unlicensed contractors (briefly)

Builds trust. Clients who ask about insurance are the right clients.
```

---

*Total prompts in this file: 23*
