# 07 — The Contractor's AI Cheat Sheet

*The 12 most powerful prompts in this toolkit — ready to copy, paste, and use right now*

---

> **How to use this file:** This is your quick-access layer. When you're in the truck, on the job site, or need something fast — start here. Fill in every `[BRACKET]` with your real context before pasting.

---

## THE 12 MOST POWERFUL PROMPTS

---

### 🏆 Prompt 1: The Proposal Cover Letter
*Source: 02-proposal-bidding-prompts.md*
*Why it's here: This is what wins bids. Most contractors just send numbers. A professional letter closes.*

```
Write a professional proposal cover letter for a contracting job with the following details:

Client name: [CLIENT_NAME]
Project address: [PROJECT_ADDRESS]
Project type: [E.G., KITCHEN REMODEL / DECK BUILD / BATHROOM RENOVATION]
Scope summary: [2-3 SENTENCE PLAIN-ENGLISH DESCRIPTION OF THE WORK]
My company: [YOUR_COMPANY_NAME], licensed and insured in [STATE]
Years in business: [X YEARS]
Key differentiator: [WHAT MAKES YOU DIFFERENT — E.G., "ALL WORK DONE BY LICENSED TRADESPEOPLE, NO SUBCONTRACTING"]
Estimated start date: [DATE]
Estimated completion: [DATE OR TIMEFRAME]

The letter should be professional but warm. 3–4 short paragraphs. No fluff. Restate what we're going to do, why we're the right choice, and a clear next step (signing the proposal to confirm the start date).
```

---

### 🏆 Prompt 2: The Line-Item Estimate
*Source: 02-proposal-bidding-prompts.md*
*Why it's here: Clients trust itemized estimates. Lump sums kill deals.*

```
Format a professional line-item estimate for the following scope of work:

Project: [PROJECT_NAME]
Client: [CLIENT_NAME]

Tasks and labor:
[LIST EACH TASK, E.G.:
- Demo existing tile: 4 hours @ $[RATE]/hr
- Install cement board: 6 hours @ $[RATE]/hr
- Tile installation (200 sq ft): 12 hours @ $[RATE]/hr]

Materials:
[LIST EACH MATERIAL:
- Cement board (10 sheets): $[COST]
- Tile (220 sq ft including waste): $[COST]
- Thinset mortar (3 bags): $[COST]]

Subtotal: $[AMOUNT]
Tax ([RATE]%): $[AMOUNT]
TOTAL: $[AMOUNT]

Payment terms: [E.G., 30% deposit, 40% at rough-in, 30% on completion]
Valid for: 30 days
License #: [NUMBER]
Insurance: [CARRIER AND POLICY NUMBER]

Format this as a clean, professional estimate table with sections for Labor, Materials, and Totals. Add a brief scope disclaimer at the bottom: any work beyond the above scope will be quoted separately in writing before proceeding.
```

---

### 🏆 Prompt 3: Scope of Work Document
*Source: 02-proposal-bidding-prompts.md*
*Why it's here: Scope documents prevent disputes. Write one for every job.*

```
Write a detailed Scope of Work document for the following project:

Project: [PROJECT_NAME AND ADDRESS]
Client: [CLIENT_NAME]
Contractor: [YOUR_COMPANY_NAME]

Work to be performed:
[DESCRIBE EACH PHASE OF WORK IN PLAIN LANGUAGE]

Materials to be supplied by contractor:
[LIST MATERIALS]

Materials to be supplied by client:
[LIST IF APPLICABLE, OR "N/A"]

Work NOT included in this scope:
[LIST EXCLUSIONS EXPLICITLY]

Site access requirements:
[E.G., "Client to ensure clear access to work area by 7:00 AM daily"]

Permits required:
[YES/NO, WHO IS RESPONSIBLE FOR PULLING THEM]

The SOW should be clear enough that both a client with no construction experience AND a judge could understand exactly what was and wasn't agreed to. Include a signature line at the bottom.
```

---

### 🏆 Prompt 4: Change Order Request
*Source: 02-proposal-bidding-prompts.md*
*Why it's here: Change orders protect you. Never do extra work without one.*

```
Write a professional Change Order document for additional work requested on an existing project:

Project: [ORIGINAL PROJECT NAME AND ADDRESS]
Original contract date: [DATE]
Change order #: [NUMBER]
Date: [TODAY'S DATE]

Additional work requested: [DESCRIBE WHAT THE CLIENT ASKED FOR]
Reason for change: [CLIENT REQUEST / UNFORESEEN CONDITION / DESIGN CHANGE]

Additional labor: [HOURS AND RATE]
Additional materials: [LIST AND COST]
Additional cost total: $[AMOUNT]
Impact on timeline: [ADD X DAYS TO COMPLETION / NO IMPACT]

New project total including this change order: $[AMOUNT]

Include language that: (1) this work is outside the original scope, (2) payment for this change order is due [TERMS], and (3) work begins only upon signed approval.
```

---

### 🏆 Prompt 5: Difficult Client Response
*Source: 03-client-communication-prompts.md*
*Why it's here: How you handle complaints determines whether you keep the job and the reputation.*

```
Write a professional email response to a client complaint about my contracting work.

The complaint: [DESCRIBE WHAT THE CLIENT IS SAYING — BE SPECIFIC]
The facts of the situation: [WHAT ACTUALLY HAPPENED FROM YOUR PERSPECTIVE]
My desired outcome: [E.G., "KEEP THE CLIENT HAPPY AND FINISH THE JOB" / "PART WAYS PROFESSIONALLY" / "DOCUMENT THE DISPUTE"]

The response should:
- Acknowledge their concern without admitting fault or liability
- State the facts calmly and professionally
- Propose a specific next step with a timeline
- Be under 200 words
- Be professional but not groveling
- Not include any emotional language or defensiveness

Do not include phrases like "I understand your frustration" — be direct and solution-focused.
```

---

### 🏆 Prompt 6: Project Delay Notification
*Source: 03-client-communication-prompts.md*
*Why it's here: Proactive communication about delays builds trust. Silence destroys it.*

```
Write a professional email to notify a client of a project delay.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Original completion date: [DATE]
New estimated completion date: [DATE]
Reason for delay: [BE HONEST: MATERIAL DELAY / PERMIT ISSUE / WEATHER / SUBCONTRACTOR / ADDITIONAL SCOPE DISCOVERED]
What we're doing to minimize the impact: [SPECIFIC ACTIONS]
Next update they'll receive: [DATE AND HOW]

Tone: Professional, accountable, solutions-focused. Don't make excuses — explain facts and what's being done about it. Under 150 words.
```

---

### 🏆 Prompt 7: Review Request Text
*Source: 05-marketing-prompts.md*
*Why it's here: Most of your competitors have 3 Google reviews. This is how you get 50.*

```
Write a short, friendly text message to a satisfied client asking for a Google review.

Client name: [CLIENT_NAME] (or just "first name")
Project completed: [PROJECT TYPE]
The Google review link: [YOUR_GOOGLE_REVIEW_LINK]

Requirements:
- Under 3 sentences
- Feels personal, not automated
- Includes the direct link
- Doesn't pressure or incentivize (violates Google policy)
- Mentions it only takes 2 minutes

Write 3 versions with slightly different tones (warm/casual, professional, brief).
```

---

### 🏆 Prompt 8: Negative Review Response
*Source: 05-marketing-prompts.md*
*Why it's here: Your response to bad reviews is read by every future prospect. Make it count.*

```
Write a professional public response to a negative Google review about my contracting business.

The review text: [PASTE THE REVIEW]
The facts: [WHAT ACTUALLY HAPPENED — KEEP THIS TO YOURSELF, DON'T INCLUDE IN THE RESPONSE IF IT MAKES YOU LOOK BAD]
My preferred resolution: [OFFER A CALL / ALREADY RESOLVED / DISPUTED CLAIM]

The response should:
- Be under 100 words
- Thank them for the feedback (even if unfair)
- Acknowledge their experience without admitting liability
- Offer to resolve offline (include your phone/email)
- Show future readers you handle issues professionally
- Never be defensive or argue facts publicly

Remember: this response is a marketing message to the thousands of people who will read it, not just a reply to this one customer.
```

---

### 🏆 Prompt 9: Payment Reminder — Final Notice
*Source: 03-client-communication-prompts.md*
*Why it's here: Most contractors don't have a system for this. The ones who do get paid.*

```
Write a firm, professional final payment reminder for an overdue invoice.

Client: [CLIENT_NAME]
Invoice #: [INVOICE_NUMBER]
Invoice date: [DATE]
Amount due: $[AMOUNT]
Days overdue: [NUMBER]
Previous reminders sent: [DATE OF FIRST AND SECOND REMINDERS]

This letter should:
- Reference the contract and invoice number
- State the exact amount and due date
- State that this is the final notice before escalation
- Mention next steps (collections / lien / small claims) without sounding like a threat
- Request immediate contact by [DATE] to resolve
- Be professional and factual, not angry

This is a business letter, not a confrontation. Keep it formal and factual.
```

---

### 🏆 Prompt 10: Job Completion Walkthrough Script
*Source: 03-client-communication-prompts.md*
*Why it's here: A good final walkthrough prevents disputes and gets you paid on the spot.*

```
Write a client walkthrough script for the end of a completed job.

Project type: [E.G., KITCHEN REMODEL / DECK BUILD]
Key areas completed: [LIST THE MAIN WORK ITEMS]
Anything the client needs to know about maintenance: [E.G., GROUT CURE TIME, PAINT DRY TIME, HOW TO OPERATE NEW FIXTURES]
Warranty offered: [YOUR WARRANTY TERMS]

The script should:
- Walk through each area of work in logical order
- Include questions to ask the client (getting verbal confirmation everything is satisfactory)
- Cover the maintenance items naturally
- Transition smoothly to requesting final payment
- End with asking for a review

Format as a step-by-step script I can follow in person, 10–15 minutes.
```

---

### 🏆 Prompt 11: Google Business Profile Post
*Source: 05-marketing-prompts.md*
*Why it's here: Free visibility in your local market. Takes 5 minutes.*

```
Write a Google Business Profile post for a recently completed project.

Project type: [E.G., MASTER BATHROOM REMODEL]
Location/neighborhood: [CITY OR NEIGHBORHOOD — DO NOT INCLUDE EXACT ADDRESS]
Key work performed: [2-3 MAIN ITEMS]
Interesting detail or challenge overcome: [E.G., "DISCOVERED AND REPLACED ROTTED SUBFLOOR BEHIND THE SHOWER"]
A good result or happy client outcome: [BRIEF]
Call to action: [E.G., "CALL US FOR A FREE ESTIMATE"]

Requirements:
- 150–200 words
- Local keywords naturally included
- No hashtags (this is Google, not Instagram)
- Conversational professional tone
- End with a call to action
```

---

### 🏆 Prompt 12: Subcontractor Agreement Summary
*Source: 02-proposal-bidding-prompts.md*
*Why it's here: Simple SOW for subs prevents disputes on your own job site.*

```
Write a simple subcontractor scope of work summary for the following job.

Project address: [ADDRESS]
General contractor: [YOUR_COMPANY_NAME]
Subcontractor: [SUB_COMPANY_NAME]
Trade: [E.G., ELECTRICAL / PLUMBING / HVAC / PAINTING]

Scope of work for the subcontractor:
[DESCRIBE EXACTLY WHAT THE SUB IS RESPONSIBLE FOR]

NOT included in subcontractor's scope:
[LIST EXCLUSIONS]

Start date: [DATE]
Completion deadline: [DATE]
Contract amount: $[AMOUNT]
Payment terms: [E.G., NET 30 FROM INVOICE / DRAW SCHEDULE]
License and insurance required: Yes — sub to provide certificate before work begins

Include a brief statement about adherence to safety requirements, cleanup of their work area daily, and cooperation with other trades on-site.
```

---

## QUICK VARIABLE CHEAT SHEET

| Variable | What to put |
|----------|-------------|
| [CLIENT_NAME] | First and last name |
| [PROJECT_ADDRESS] | Full street address |
| [YOUR_COMPANY_NAME] | Your business name |
| [PROJECT_TYPE] | Kitchen remodel, deck build, bathroom, etc. |
| [SCOPE_SUMMARY] | 2-3 sentence plain-language description |
| [START_DATE] | Actual or estimated start date |
| [COMPLETION_DATE] | Realistic target date |
| [INVOICE_NUMBER] | Your invoice numbering system |
| [YOUR_GOOGLE_REVIEW_LINK] | From Google Business Profile > Get more reviews |
| [LICENSE_NUMBER] | Your state contractor's license number |

---

*More prompts in files 02–05. These 12 cover 80% of what you'll need day-to-day.*
