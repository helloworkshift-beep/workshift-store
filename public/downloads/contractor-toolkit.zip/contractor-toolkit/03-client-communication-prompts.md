# 03 — Client Communication Prompts

*22 prompts for project updates, change orders, invoicing, conflict resolution, and relationship management*

---

### Project Kickoff Email
*Use when starting a new project and setting expectations with the client.*

```
Write a project kickoff email for a new construction project.

Client: [CLIENT_NAME], [CLIENT_ADDRESS]
Project: [PROJECT_DESCRIPTION]
Start date: [START_DATE]
First week plan: [FIRST_WEEK_ACTIVITIES]
Point of contact (my side): [MY_NAME], [PHONE], [EMAIL]
Point of contact (their side): [CLIENT_CONTACT_AND_PREFERENCE]
Parking/access instructions needed: [ACCESS_REQUIREMENTS]
Any prep the client needs to do: [CLIENT_PREP_TASKS]
Site hours: [WORK_HOURS]
Expected noise level: [NOISE_CONTEXT — especially for occupied homes]

Write a kickoff email that:
1. Opens with enthusiasm about the project
2. Confirms start date and first week plan
3. Clarifies access and communication expectations
4. Lists anything the client needs to do before day 1
5. Sets the tone for a professional, communicative project experience
```

---

### Weekly Project Progress Update
*Use when sending a regular progress update to a client during an active project.*

```
Write a weekly project progress update.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Week of: [WEEK_OF]
Progress this week: [WHAT_WAS_COMPLETED]
Photos available: [YES/NO]
Any issues encountered: [ISSUES — if any, what they were and how they're being resolved]
What's planned for next week: [NEXT_WEEK_PLAN]
Any decisions needed from client: [DECISIONS_REQUIRED]
Any schedule changes: [SCHEDULE_UPDATE]
Current status vs. timeline: [ON_TRACK / SLIGHTLY_BEHIND — explain if behind]
My name: [MY_NAME]

Write an update that:
1. Leads with progress (what got done)
2. Addresses any issues transparently
3. States what's coming next
4. Makes any client decisions urgent but not pressured
5. Is professional and reassuring

Clients on active projects have anxiety. Good updates reduce callbacks and build trust.
```

---

### Change Order Conversation Opener
*Use when you need to bring up additional costs with a client before formalizing the change order.*

```
Write a message to open the change order conversation with a client.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
What changed or was discovered: [CHANGE_OR_DISCOVERY]
Why it creates additional cost: [REASON]
Estimated additional cost: $[ESTIMATE]
Impact on timeline: [TIMELINE_IMPACT]
How this was discovered: [HOW_FOUND — during demolition, during framing, etc.]

Write a message that:
1. Informs the client immediately upon discovery (not at the end of the week)
2. Explains what was found in plain language
3. Gives a preliminary cost estimate
4. Explains timeline impact
5. Sets up a formal change order document to follow

Proactive and transparent — clients are far more accepting of surprises when they hear about them early and clearly.
```

---

### Payment Request — Progress Milestone
*Use when billing the client for a progress payment milestone.*

```
Write a payment request for a project milestone.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Milestone reached: [MILESTONE — e.g., "framing complete", "rough-in complete", "tile installation complete"]
Amount due at this milestone: $[AMOUNT_DUE]
Per contract payment schedule: [CONTRACT_PAYMENT_REFERENCE]
Payment due by: [DUE_DATE]
Payment methods accepted: [PAYMENT_METHODS]
Invoice attached: [YES/NO]
My name: [MY_NAME], [COMPANY_NAME]

Write a payment request that:
1. References the milestone and confirms it's complete
2. States the amount due and when
3. Makes payment easy
4. Is professional but not impersonal

Under 150 words. Clear and confident.
```

---

### Overdue Payment Follow-Up
*Use when a client hasn't paid a progress payment or final invoice.*

```
Write a follow-up for an overdue payment from a client.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Invoice number: [INVOICE_NUMBER]
Invoice amount: $[AMOUNT]
Due date: [DUE_DATE]
Days overdue: [DAYS_PAST_DUE]
Previous contact (if any): [PRIOR_CONTACT_DATES]
Late fee policy: [LATE_FEE — if applicable]
Project status: [ONGOING/COMPLETE]

Write a follow-up email:

Email 1 (1-7 days overdue): Friendly reminder, assume oversight, state amount and make paying easy.

Email 2 (14+ days overdue): Direct, professional, reference prior reminder, state late fee if applicable, request contact if there's an issue.

Each under 150 words. Firm but not threatening.
```

---

### Difficult Client Situation — Scope Dispute
*Use when a client claims work is included that isn't in the contract.*

```
Write a professional response to a scope dispute with a client.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
What they're claiming: [CLAIM — what they say was included]
What the contract actually says: [CONTRACT_LANGUAGE — quote if possible]
What we've done: [WORK_PERFORMED]
What they're requesting: [REQUEST]
My position: [MY_POSITION]
Resolution I'm willing to offer: [OFFERED_RESOLUTION — if any]

Write a response that:
1. Acknowledges their concern respectfully
2. References the contract language clearly (without being combative)
3. Explains what was and wasn't included
4. Offers a resolution if appropriate
5. Keeps the tone professional — not a fight, a conversation

Factual and calm. Emotion loses disputes; documentation wins them.
```

---

### Project Delay Notification
*Use when weather, materials, or other factors will delay a project.*

```
Write a project delay notification for a client.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Original completion date: [ORIGINAL_DATE]
New expected completion: [NEW_DATE]
Reason for delay: [REASON — weather, material backorder, subcontractor delay]
Impact on subsequent phases: [DOWNSTREAM_IMPACT]
What we're doing to catch up: [MITIGATION_PLAN]
Will there be any cost impact: [YES/NO — if yes, explain]

Write a delay notification that:
1. States the delay and new date immediately
2. Gives an honest explanation
3. Notes what you're doing to minimize the impact
4. Addresses any cost implications clearly
5. Keeps the client's confidence high

Proactive communication prevents dispute. Communicate delays early — not the day before.
```

---

### Deficiency Punchlist Email
*Use when sending a client the project punchlist or their walk-through corrections.*

```
Write a punchlist follow-up email after a project walk-through.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Walk-through date: [DATE]
Punchlist items identified:
- [ITEM_1]: [DESCRIPTION], responsible party: [WHO], timeline to complete: [DATE]
- [ITEM_2]: [DESCRIPTION], timeline: [DATE]
- [ITEM_3]: [DESCRIPTION], timeline: [DATE]
Final payment status: [HELD — amount: $[HELD_AMOUNT] / PAID]
Substantial completion declaration: [YES — project is substantially complete] / [NO — still pending]

Write a punchlist confirmation email that:
1. Documents the items and timeline clearly
2. States who is responsible for each item
3. Clarifies the final payment status
4. Confirms the substantial completion status
5. Sets a date for final sign-off

Professional and organized. The punchlist is a legal document — treat it as one.
```

---

### Warranty Issue Response
*Use when a client contacts you about a warranty-related issue after project completion.*

```
Write a response to a client raising a warranty concern.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION], completed: [COMPLETION_DATE]
Issue they raised: [WARRANTY_COMPLAINT]
Our warranty terms: [WARRANTY_COVERAGE]
Is this covered? [YES / NO / PARTIALLY]
What we'll do: [RESOLUTION — come inspect, repair, partial repair, etc.]
When we can address it: [TIMELINE]
My name: [MY_NAME]

Write a response that:
1. Acknowledges their concern promptly
2. Confirms the warranty coverage
3. States exactly what we'll do and when
4. Sets an appointment or next step

Under 150 words. Professional and responsive — warranty issues resolved quickly protect your reputation.
```

---

### Final Project Completion Email
*Use when sending the final project completion notice and final invoice.*

```
Write a final project completion email.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Completion date: [COMPLETION_DATE]
What was accomplished: [PROJECT_SUMMARY]
Any care instructions: [CARE_NOTES — e.g., "don't seal the grout for 72 hours", "let the paint cure 30 days before washing"]
Final invoice amount: $[FINAL_AMOUNT]
Payment due: [DUE_DATE]
Warranty terms: [WARRANTY_SUMMARY]
Contact for future work: [MY_CONTACT_INFO]
Review request: [YES — include ask / NO]

Write a completion email that:
1. Announces completion with pride
2. Summarizes what was done
3. Provides any care instructions
4. Presents the final invoice
5. Thanks them for the work and mentions future projects
6. Includes a review request if appropriate
```

---

### Reference Check Request
*Use when asking a past client to be a reference for a new prospect.*

```
Write a reference request email to a satisfied past client.

Past client: [CLIENT_NAME]
Project: [PROJECT_COMPLETED]
New prospect referencing: [PROSPECT_NAME]
What I'd like them to do: [REFERENCE_FORMAT — a quick call, email response, specific questions]
Time commitment: [TIME — e.g., "5-minute call", "reply to this email"]
What I'd like them to highlight: [KEY_POINTS — if relevant]

Write a reference request that:
1. Reconnects genuinely (reference the project and outcome)
2. Makes the ask clear and easy
3. Tells them what the prospect is evaluating (so they can be helpful)
4. Offers something in return if appropriate (future discount, etc.)

Under 150 words. Personal and genuine.
```

---

### Client Complaint Response — In Writing
*Use when responding to a formal complaint from a client.*

```
Write a professional response to a formal client complaint.

Client: [CLIENT_NAME]
Complaint: [COMPLAINT_DESCRIPTION]
Our review of what happened: [OUR_REVIEW]
Was the complaint valid? [YES / PARTIALLY / NO — explain]
Resolution being offered: [RESOLUTION]
Timeline to resolve: [TIMELINE]
My name: [MY_NAME], [COMPANY_NAME], [LICENSE_NUMBER]

Write a response that:
1. Acknowledges the complaint professionally
2. States our understanding of what happened
3. Takes appropriate responsibility
4. Offers a specific resolution with a timeline
5. Invites further dialogue
6. Is professional enough to be referenced in any future dispute

Keep emotion out of it. Factual, respectful, and solution-focused.
```

---

### Introduction to Subcontractor
*Use when introducing a subcontractor to your client.*

```
Write a client introduction for a subcontractor who will be working on their project.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Subcontractor: [SUB_COMPANY_NAME], [SUB_CONTACT_NAME]
What they're doing: [SUB_SCOPE]
When they start: [START_DATE]
Their qualifications: [QUALIFICATIONS — licensed, experienced, etc.]
Client's role with them: [HOW_CLIENT_SHOULD_INTERACT — e.g., "contact me directly, not them, for any changes"]
My oversight role: [HOW_I'M_SUPERVISING]

Write a brief introduction that:
1. Names the subcontractor and what they're doing
2. Assures the client this person is qualified and vetted
3. Clarifies the client's communication chain (through me, not directly to sub)
4. Gives the start date and what to expect

Reassures the client. They hired you — remind them you're still in charge.
```

---

### Site Inspection Request to Client
*Use when requesting a client walk-through at a project milestone.*

```
Write a request for a client site visit or walk-through.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Milestone: [MILESTONE — what's been completed that warrants a walk]
Purpose: [PURPOSE — get approval to proceed, review selections, demonstrate work, etc.]
Time needed: [VISIT_DURATION]
Proposed dates: [DATE_OPTION_1], [DATE_OPTION_2]
Address: [JOB_SITE_ADDRESS]
My name: [MY_NAME], [PHONE]

Write an invitation that:
1. States why the walk is important at this stage
2. Proposes two date options
3. States how long it will take
4. Makes confirming easy

Under 100 words.
```

---

### Design Decision Request
*Use when the client needs to make a material or design selection before work can proceed.*

```
Write a message requesting a client decision on a material or design choice.

Client: [CLIENT_NAME]
Project: [PROJECT_DESCRIPTION]
Decision needed: [WHAT_THEY_NEED_TO_DECIDE — e.g., tile color, paint selection, fixture model]
Deadline to decide: [DECISION_DEADLINE — when work will stop if undecided]
Impact of delay: [IMPACT — schedule delay, additional cost, etc.]
Options I recommend (if any): [MY_RECOMMENDATION]
Where to see samples: [WHERE_TO_SELECT — showroom, I'll bring samples, online link]

Write a message that:
1. Clearly states what they need to decide
2. Sets the deadline (firm but respectful)
3. Notes the consequence of delay
4. Makes the decision process as easy as possible
5. Offers your recommendation if relevant

Under 150 words. Clear and urgent without being pushy.
```

---

### Client Referral Thank You
*Use when thanking a past client for referring new business.*

```
Write a referral thank you note to a client who sent you new business.

Referring client: [REFERRING_CLIENT_NAME]
Project you did for them: [PRIOR_PROJECT]
New referral they sent: [NEW_CLIENT_NAME] — project: [NEW_PROJECT]
Referral reward (if any): [REWARD — e.g., "$100 off their next project", "home improvement gift card"]
My name: [MY_NAME]

Write a thank you that:
1. Is personal and specific (references their project)
2. Expresses genuine gratitude
3. Delivers the reward clearly (if applicable)
4. Reminds them you're always available for their next project

Under 100 words. Human and warm.
```

---

### End-of-Season Check-In
*Use when reaching out to past clients to offer seasonal maintenance or upcoming project conversations.*

```
Write a seasonal check-in email to past clients.

Season: [FALL / SPRING / WINTER]
My company: [COMPANY_NAME]
Services relevant this season: [SEASONAL_SERVICES — e.g., "gutter cleaning, winterizing, roof inspection"]
Past project for this client: [PRIOR_PROJECT]
Offer or reason to reach out: [REASON_TO_CONNECT]
My name: [MY_NAME]
Contact: [PHONE_OR_EMAIL]

Write a check-in that:
1. References the prior work together
2. Offers seasonal services that are genuinely relevant
3. Doesn't feel like a mass email
4. Ends with an easy next step

Under 150 words. Feels like a neighbor, not a marketing email.
```

---

*Total prompts in this file: 22*
