# 06 — Workflow SOPs

*5 complete systems for your most time-intensive contracting tasks — powered by AI*

---

> **How to use this file:** Each SOP is a repeatable, step-by-step process. Follow the steps in order, use the referenced prompt files at each stage, and replace the example inputs with your own. The goal isn't just to use AI — it's to have a *system* that produces consistent, professional output every time.

---

## SOP A: Win the Bid — From Site Visit to Signed Contract

**What this produces:** A polished proposal that beats competitors on professionalism
**When to run it:** After every qualifying site visit or inbound lead
**Time commitment:** 45 minutes (vs. 3–5 hours manually)
**Prompt file:** `02-proposal-bidding-prompts.md`

---

### The Bid-Winning System

**Before you start (10 minutes): Document your site visit**

Gather these raw inputs before opening your AI tool:

- [ ] Client name and contact info
- [ ] Project address and property type
- [ ] Scope of work (exact tasks in plain language)
- [ ] Materials needed and your preferred suppliers
- [ ] Your labor estimate (hours per task)
- [ ] Key constraints (access hours, HOA rules, permit requirements)
- [ ] Your timeline estimate
- [ ] Any special conditions or client concerns noted during the visit

---

**Step 1 — Set context (2 minutes)**

Open your AI tool and paste the system prompt from `01-quick-start-guide.md` to establish your contractor persona.

---

**Step 2 — Generate the detailed scope of work (10 minutes)**

Use **Prompt: Scope of Work Document** from `02-proposal-bidding-prompts.md`.

Fill in every bracket with your site visit notes. Be specific about materials and tasks.

---

**Step 3 — Build the line-item estimate (10 minutes)**

Use **Prompt: Professional Line-Item Estimate** from `02-proposal-bidding-prompts.md`.

Include your actual labor rates and material costs. The AI will format it professionally.

---

**Step 4 — Write the cover letter / proposal narrative (10 minutes)**

Use **Prompt: Proposal Cover Letter** from `02-proposal-bidding-prompts.md`.

This is what separates you from competitors who just email a number. A brief, professional narrative explains your approach and builds trust.

---

**Step 5 — Review and send**

- Read the full proposal as your client would
- Verify all numbers match your actual estimate
- Add your company logo, license number, and insurance info
- Send as a PDF, never a Word doc

---

## SOP B: Handle a Difficult Client Conversation

**What this produces:** A professional, de-escalating response to upset or unreasonable clients
**When to run it:** Any time a client is pushing back on price, timeline, or work quality
**Prompt file:** `03-client-communication-prompts.md`

---

### The De-Escalation System

**Step 1 — Write out what happened (5 minutes)**

Before generating anything, write a 3–5 sentence summary of the situation:
- What the client is upset about
- What you actually did / what the facts are
- What outcome you want (keep the contract, adjust scope, etc.)

---

**Step 2 — Draft your response (10 minutes)**

Use **Prompt: Difficult Client Response** from `03-client-communication-prompts.md`.

Be factual. Don't add emotional language in the brackets — just the facts.

---

**Step 3 — Review with these questions:**
- Does it acknowledge the client's concern without admitting fault?
- Does it propose a concrete next step?
- Is the tone professional and calm (not defensive)?
- Is it under 200 words? (Longer = harder to read = more tension)

---

**Step 4 — Decide your channel**

- Minor issue → Email is fine
- Major dispute → Call first, then follow up with email summary
- Payment dispute → Certified letter, save everything

---

## SOP C: Request and Respond to Reviews

**What this produces:** A steady stream of 5-star reviews on Google
**When to run it:** Within 48 hours of every completed job
**Prompt file:** `05-marketing-prompts.md`

---

### The Review-Getting System

**Step 1 — Capture the moment (day of completion)**

Before you leave the job site:
- Take photos of your best work
- Ask the client verbally: "Was everything to your satisfaction?"
- If yes: "Would you mind leaving us a quick review on Google? It really helps small businesses like ours."

---

**Step 2 — Send the follow-up text (same day)**

Use **Prompt: Review Request Text** from `05-marketing-prompts.md`.

Keep it short. Under 3 sentences. Include the direct Google review link.

---

**Step 3 — Respond to every review within 24 hours**

For 5-star reviews: Use **Prompt: 5-Star Review Response**
For 3-star reviews: Use **Prompt: Neutral Review Response**
For 1-2 star reviews: Use **Prompt: Negative Review Response**

Never copy-paste the same response to multiple reviews — Google notices.

---

## SOP D: Collect an Overdue Payment

**What this produces:** Payment, while preserving the relationship
**When to run it:** Any invoice past 14 days due
**Prompt file:** `03-client-communication-prompts.md`

---

### The Payment Collection Sequence

**Day 14 past due — Friendly reminder**
Use **Prompt: Payment Reminder — First Notice** (friendly, assumes it's an oversight)

**Day 21 past due — Firm follow-up**
Use **Prompt: Payment Reminder — Second Notice** (firm, references payment terms)

**Day 30 past due — Final notice**
Use **Prompt: Payment Reminder — Final Notice** (states consequences, certified mail)

**Day 45+ — Escalation**
At this point you're past AI prompts — consult your attorney or small claims process.

---

**Always remember:**
- Reference your contract and invoice number in every communication
- Keep all correspondence in writing
- Never threaten anything you're not prepared to follow through on

---

## SOP E: Build Your Job Portfolio Entry

**What this produces:** A polished portfolio case study for your website
**When to run it:** After every significant project
**Prompt file:** `05-marketing-prompts.md`

---

### The Portfolio System

**Step 1 — Document the job (immediately after completion)**

Capture while it's fresh:
- Project type and brief description
- The challenge or problem (what the client needed)
- What you did and how you solved it
- Before and after photos
- Measurable results (sq ft, timeline, budget)
- Client quote (ask permission first)

**Step 2 — Write the case study**

Use **Prompt: Portfolio Case Study** from `05-marketing-prompts.md`.

**Step 3 — Write the short social caption**

Use **Prompt: Project Completion Social Post** from `05-marketing-prompts.md`.

Post to your Google Business Profile, Facebook, and Instagram. Tag the neighborhood or city.

---
