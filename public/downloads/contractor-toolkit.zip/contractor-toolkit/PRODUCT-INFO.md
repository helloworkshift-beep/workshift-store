# PRODUCT INFO — The Contractor's AI Prompt Toolkit

---

## Product Details

| Field | Value |
|-------|-------|
| **Product Name** | The Contractor's AI Prompt Toolkit |
| **Version** | 1.0 |
| **Format** | 7 Markdown files (digital download) |
| **Total Prompts** | 90+ ready-to-use AI prompts |
| **Support** | helloworkshift@gmail.com |

---

## Who It's For

General contractors, specialty tradespeople, and handymen who want to write better bids, manage client communication professionally, document their projects, and build a strong reputation — without spending hours at a desk.

---

## What's Included

| File | Description | Prompt Count |
|------|-------------|--------------|
| `01-quick-start-guide.md` | Setup, system prompt, best practices | — |
| `02-proposal-bidding-prompts.md` | Bids, proposals, scope of work | 23 |
| `03-client-communication-prompts.md` | Client updates, change orders, conflict resolution | 22 |
| `04-project-management-prompts.md` | Schedules, subs, documentation | 18 |
| `05-marketing-prompts.md` | Reviews, referrals, social media | 17 |
| `06-workflow-sops.md` | 5 complete contractor workflow playbooks | — |
| `07-cheat-sheet.md` | Top 15 prompts + variable quick reference | 15 |

---

*For support: helloworkshift@gmail.com*
*Last updated: 2026*
