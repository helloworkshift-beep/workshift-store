# 🏗️ The Contractor's AI Prompt Toolkit

**90+ AI prompts for general contractors, tradespeople, and handymen**

---

## What's Inside

This toolkit gives contractors, handymen, and tradespeople instant access to professional-grade prompts for every part of running a contracting business — from writing bids to managing client expectations to building your reputation online.

Every prompt is:
- **Trade-specific** — Built for real contractor work and job site realities
- **Structured** — Uses `[BRACKET VARIABLES]` so you can customize in minutes
- **Immediately usable** — Designed to produce estimates, emails, and posts you can send today

---

## File Guide

| File | Contents | Prompts |
|------|----------|---------|
| [01-quick-start-guide.md](01-quick-start-guide.md) | How to use this toolkit effectively | — |
| [02-proposal-bidding-prompts.md](02-proposal-bidding-prompts.md) | Bids, proposals, scope of work, pricing | 23 |
| [03-client-communication-prompts.md](03-client-communication-prompts.md) | Client updates, change orders, conflict resolution | 22 |
| [04-project-management-prompts.md](04-project-management-prompts.md) | Schedules, subcontractor management, documentation | 18 |
| [05-marketing-prompts.md](05-marketing-prompts.md) | Reviews, social media, referrals, reputation | 17 |
| [06-workflow-sops.md](06-workflow-sops.md) | 5 complete contractor workflow playbooks | — |
| [07-cheat-sheet.md](07-cheat-sheet.md) | Top 15 power prompts + quick reference | 15 |

**Total: 90+ prompts**

---

## Who This Is For

- **General contractors** managing residential or commercial projects
- **Specialty tradespeople** (electricians, plumbers, HVAC, roofers, etc.)
- **Handymen** looking to professionalize their business
- **Remodeling contractors** handling multiple clients and projects simultaneously

---

*Built for contractors who build things right.*
