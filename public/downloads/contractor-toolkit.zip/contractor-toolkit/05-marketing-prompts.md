# 05 — Marketing Prompts

*17 prompts for building your reputation, getting referrals, social media, and growing your contracting business*

---

### Google Review Request — Text
*Use after completing a project to ask a satisfied client for a review.*

```
Write a Google review request text to a completed project client.

Client: [CLIENT_FIRST_NAME]
Project completed: [PROJECT_TYPE]
Google review link: [REVIEW_LINK]
My name: [MY_NAME], [COMPANY_NAME]

Write a brief, personal text that: thanks them for the project, makes the review ask naturally, provides the link. Under 75 words. Not a mass text — a personal note.
```

---

### Response to 5-Star Review
*Use when replying to a positive contractor review.*

```
Write a response to a 5-star contractor review.

Reviewer: [REVIEWER_NAME]
What they said: "[REVIEW_TEXT]"
Specific detail to acknowledge: [SPECIFIC_DETAIL]
Company: [COMPANY_NAME]

Write a response under 75 words that thanks them by name, acknowledges something specific from their review, and invites future work.
```

---

### Response to Negative Review
*Use when a client leaves a negative review and you need to respond professionally.*

```
Write a professional response to a negative contractor review.

Review: "[NEGATIVE_REVIEW_TEXT]"
What actually happened: [YOUR_ACCOUNT]
Was it valid? [YES/PARTIALLY/NO]
Resolution offered: [RESOLUTION]
My name: [MY_NAME], [COMPANY_NAME]

Write a response that: acknowledges the concern, is factual not emotional, takes responsibility where appropriate, invites direct contact to resolve. Under 150 words. Future clients are reading this.
```

---

### Before/After Project Social Post
*Use when showcasing a completed project on Instagram or Facebook.*

```
Write a before/after social media post for a completed project.

Platform: [INSTAGRAM/FACEBOOK]
Project type: [PROJECT — e.g., "kitchen remodel", "deck addition", "bathroom renovation"]
Before state: [BEFORE_DESCRIPTION]
After state: [AFTER_DESCRIPTION]
What makes this project special: [HIGHLIGHT]
Location: [CITY_STATE — optional]
Hashtags: [YES/NO]

Write a caption that: leads with the result, briefly describes the transformation, connects to the homeowner's experience, ends with a CTA or engagement question. Under 200 words.
```

---

### Project Portfolio Description
*Use when describing a completed project for your website or portfolio.*

```
Write a project portfolio description for my contractor website.

Company: [COMPANY_NAME]
Project type: [PROJECT_TYPE]
Location: [CITY, STATE — neighborhood if helpful]
Scope: [WHAT_WAS_DONE]
Size: [SQUARE_FOOTAGE / SCOPE_DETAIL]
Timeline: [HOW_LONG_IT_TOOK]
Challenge overcome: [INTERESTING_CHALLENGE — optional]
Result: [OUTCOME]
Client type: [HOMEOWNER / COMMERCIAL — anonymized if preferred]

Write a 150-200 word project description for a portfolio page. Should feel aspirational for a prospective client who has a similar project. Professional but human.
```

---

### Referral Program Announcement
*Use when creating a referral program for past clients.*

```
Write a referral program announcement for past clients.

Company: [COMPANY_NAME]
What referrers get: [REFERRER_REWARD — e.g., "$200 gift card for every signed project referral"]
What referred friends get: [FRIEND_REWARD — e.g., "$200 off their project"]
How to refer: [HOW — text my name and number, forward this email, use a link]
Expiration: [EXPIRATION — if any]
My name: [MY_NAME], [PHONE]

Write an announcement email or text that: leads with the benefit, makes referring easy, feels like a heads-up from someone you know. Under 150 words.
```

---

### Nextdoor / Neighborhood Facebook Post
*Use when introducing your business to a local community group.*

```
Write a neighborhood introduction post for Nextdoor or a local Facebook group.

Company: [COMPANY_NAME]
Location: [CITY/NEIGHBORHOOD]
Years in business: [YEARS]
Services: [TOP_SERVICES]
Differentiator: [WHAT_MAKES_YOU_DIFFERENT]
Offer for neighborhood residents: [INTRO_OFFER — e.g., "free estimates for [NEIGHBORHOOD] residents"]
Contact: [PHONE_OR_WEBSITE]

Write a post that: introduces the business as a neighbor (not an ad), mentions the local connection, offers genuine value, is under 150 words and non-salesy.
```

---

### Testimonial Request Email
*Use when asking a happy client for a written or video testimonial.*

```
Write a testimonial request for a satisfied client.

Client: [CLIENT_NAME]
Project: [PROJECT_COMPLETED]
Outcome: [RESULT]
Format requested: [FORMAT — written quote, Google review, LinkedIn recommendation, video]
Where it will be used: [USE — website, proposal, social media]
My name: [MY_NAME]

Write a request that: references their specific project, makes the ask naturally, tells them what to write about (so they don't face a blank page), makes it easy. Under 150 words.
```

---

### LinkedIn Post — Lessons from a Project
*Use when sharing a professional insight from a recent project on LinkedIn.*

```
Write a LinkedIn post sharing a lesson from a recent project.

My role: [OWNER / PROJECT_MANAGER / FOREMAN], [COMPANY_NAME]
Lesson or insight: [WHAT_YOU_LEARNED]
Story behind it: [BRIEF_PROJECT_STORY — anonymized if needed]
Who benefits from reading this: [TARGET_AUDIENCE — other contractors, homeowners, subs]
CTA: [ENGAGEMENT_ASK — comment, follow, etc.]

Write a post that: opens with a bold statement (not "Today I want to share..."), tells the story briefly, gets to the insight, ends with a question or CTA. 200-350 words.
```

---

### Seasonal Promotion Email to Past Clients
*Use when running a seasonal service promotion for your past client list.*

```
Write a seasonal promotion email to past clients.

Company: [COMPANY_NAME]
Season: [SEASON — spring, fall, etc.]
Services being promoted: [SEASONAL_SERVICES]
Special offer: [OFFER]
Valid through: [DEADLINE]
Why now is the right time: [URGENCY_REASON — weather, availability, materials pricing]
My name: [MY_NAME], [PHONE]

Write an email that: opens with genuine seasonal context (not "WE'RE HAVING A SALE"), presents the offer clearly, creates natural urgency, makes booking easy. Under 200 words.
```

---

### Google Business Profile Description
*Use when writing or updating your Google Business Profile.*

```
Write an optimized Google Business Profile description.

Company: [COMPANY_NAME]
Location: [CITY, STATE]
Service area: [SERVICE_AREA]
Services: [TOP_SERVICES]
Years in business: [YEARS]
License: [LICENSE_INFO]
What makes you different: [DIFFERENTIATOR]
Target keywords: [LOCAL_KEYWORDS — e.g., "general contractor [CITY]", "home remodeling near me"]

Write a description under 750 characters that: mentions company and location naturally, includes top services with keyword placement, highlights differentiator, ends with a CTA. Write 2 versions.
```

---

### "Why Hire a Licensed Contractor" Social Post
*Use when educating potential clients about the importance of licensing and insurance.*

```
Write a social post educating homeowners about hiring licensed contractors.

Company: [COMPANY_NAME]
Platform: [PLATFORM]
Key points to cover: [POINTS — e.g., "insurance protects you", "licensing means inspections", "unlicensed work can void your homeowner's insurance"]
Tone: Educational, not fear-based
My differentiator: [LICENSE_AND_INSURANCE_HIGHLIGHTS]
CTA: [CALL_OR_WEBSITE]

Write a post that: educates homeowners on what to look for when hiring, positions licensed contractors as the right choice, doesn't badmouth competitors but makes the case clearly. 200-300 words.
```

---

### Home Show / Trade Show Booth Copy
*Use when creating marketing copy for a home show booth or display.*

```
Write marketing copy for a home show or trade show booth.

Company: [COMPANY_NAME]
Booth location: [SHOW_NAME], [CITY]
Primary services: [SERVICES]
Target visitor: [TARGET — homeowners planning a remodel, commercial property managers, etc.]
Headline offer: [SHOW_OFFER — e.g., "free estimate for all show attendees", "10% off contracts signed this weekend"]
Our biggest differentiator: [DIFFERENTIATOR]

Write:
1. Booth headline (large banner — 6-8 words, punchy)
2. Sub-headline (20-30 words)
3. 3 bullet points for a display panel (short benefit statements)
4. Show offer call-out
5. A greeting script for when someone walks up to the booth

Professional and inviting.
```

---

### Email Sequence — New Subscriber or Inquiry
*Use when setting up an automated email sequence for new website inquiries.*

```
Write a 3-email follow-up sequence for new leads who inquire about contractor services.

Company: [COMPANY_NAME]
Services: [SERVICES]
Typical project type: [PROJECT_TYPE]
Common client concern: [MAIN_OBJECTION]
CTA: [DESIRED_ACTION — schedule estimate, call, etc.]

Email 1 (same day): Acknowledge inquiry, set expectations for next contact, add one piece of value (tip or FAQ answer)
Email 2 (Day 3): Remind them you're available, address main concern, make it easy to book
Email 3 (Day 7): Last follow-up, light urgency (availability, season), easy out if now isn't the time

Each under 150 words. Personal, not spammy.
```

---

### Year-End Client Thank You Email
*Use when sending a year-end appreciation email to all past clients.*

```
Write a year-end thank you email to past clients.

Company: [COMPANY_NAME]
Year: [YEAR]
Highlight of the year: [BEST_MOMENT_OR_STAT — e.g., "completed 47 projects", "celebrated our 15th year in business"]
What's new next year: [NEXT_YEAR_UPDATE — new services, crew additions, etc.]
Special offer or reason to book early next year: [EARLY_BOOKING_INCENTIVE]
My name: [MY_NAME]

Write a year-end email that: reflects genuinely on the year (not corporate), thanks clients for their trust, previews next year, and plants the seed for future work. Under 250 words. Warm and personal.
```

---

### Case Study — Project Spotlight
*Use when writing a detailed project showcase for your website or social media.*

```
Write a project spotlight / case study for marketing purposes.

Company: [COMPANY_NAME]
Project type: [PROJECT_TYPE]
Client: [CLIENT — anonymized or named with permission]
Location: [CITY — or neighborhood]
Challenge: [CLIENT_CHALLENGE — why they needed the work, what was difficult]
Solution: [WHAT_WE_DID]
Result: [OUTCOME — specific results: timeline met, budget, client reaction]
Quote (if available): "[CLIENT_QUOTE]" — [CLIENT_FIRST_NAME, CITY]

Write a 300-400 word project spotlight with: challenge → solution → result → quote. Professional but human. Should make a prospective client think "that's exactly what I need."
```

---

*Total prompts in this file: 17*
