# 04 — Project Management Prompts

*18 prompts for project schedules, subcontractor management, documentation, and job site operations*

---

### Project Schedule — Master Timeline
*Use when building a master project schedule for a new job.*

```
Write a project master schedule for a construction project.

Company: [COMPANY_NAME]
Project: [PROJECT_NAME] at [PROJECT_ADDRESS]
Client: [CLIENT_NAME]
Contract start date: [START_DATE]
Contract completion date: [END_DATE]

Project phases and activities:
Phase 1 — [PHASE_NAME]: [DESCRIPTION], duration: [DAYS], start: [DATE], end: [DATE]
Phase 2 — [PHASE_NAME]: [DESCRIPTION], duration: [DAYS], start: [DATE], end: [DATE]
Phase 3 — [PHASE_NAME]: [DESCRIPTION], duration: [DAYS], start: [DATE], end: [DATE]
Phase 4 — [PHASE_NAME]: [DESCRIPTION], duration: [DAYS], start: [DATE], end: [DATE]

Critical path items (must complete on time): [CRITICAL_PATH_ITEMS]
Inspections required: [INSPECTIONS — type and timing]
Subcontractor schedule:
- [SUB_1_TRADE]: start [DATE], duration [DAYS]
- [SUB_2_TRADE]: start [DATE], duration [DAYS]
Float/buffer time built in: [BUFFER_DAYS]

Format as a project schedule document. Include a summary bar chart or table format showing phases, start/end dates, and dependencies.
```

---

### Daily Job Log Template
*Use when documenting daily project activities, weather, and crew.*

```
Create a daily job site log template for a construction project.

Company: [COMPANY_NAME]
Project: [PROJECT_ADDRESS]
Format: For completion by the site foreman or superintendent each day

Include fields for:
- Date
- Weather conditions and temperature
- Crew on site (names and trade/role)
- Subcontractors on site
- Materials delivered (material, quantity, supplier)
- Work completed today (description by area/trade)
- Issues or delays encountered
- Safety incidents (if any)
- Visitors to site (inspector, client, etc.)
- Photos taken (yes/no, description)
- Work planned for tomorrow
- Foreman signature and date

Format as a fillable daily log. This document may be used in dispute resolution — make it thorough and professional.
```

---

### Subcontractor Agreement Summary
*Use when setting up a new subcontractor for a project.*

```
Write a subcontractor agreement summary for a specific project.

General contractor: [MY_COMPANY_NAME], [LICENSE], [INSURANCE]
Subcontractor: [SUB_COMPANY_NAME], [LICENSE], [INSURANCE]
Project: [PROJECT_NAME] at [PROJECT_ADDRESS]
Sub's scope of work: [DETAILED_SCOPE]
Start date: [START_DATE]
Completion of sub's scope: [SUB_COMPLETION_DATE]
Contract value: $[SUB_CONTRACT]
Payment terms: [PAYMENT_TERMS — e.g., "paid within 10 days of GC receiving payment from owner"]
Insurance requirements: $[GL_COVERAGE] GL, $[WC_COVERAGE] workers' comp
Any special requirements: [SPECIAL_REQUIREMENTS — site rules, certifications, etc.]
Change order authorization: [CHANGE_PROCESS]
Lien waiver requirements: [LIEN_WAIVER_TERMS]

Write a subcontract summary letter that documents the arrangement clearly. Note: this is a summary, not a substitute for a signed formal subcontract.
```

---

### Material Procurement Schedule
*Use when planning and tracking material orders for a project.*

```
Create a material procurement schedule for a construction project.

Project: [PROJECT_NAME]
Project start date: [START_DATE]
Materials needed:

Category 1 — [CATEGORY, e.g., Framing]:
- [MATERIAL]: quantity [QTY], needed by [DATE], lead time [DAYS], order by [ORDER_DATE]
- [MATERIAL]: quantity [QTY], needed by [DATE], lead time [DAYS], order by [ORDER_DATE]

Category 2 — [CATEGORY]:
- [MATERIAL]: quantity [QTY], needed by [DATE], lead time [DAYS], order by [ORDER_DATE]

Long lead items (order immediately):
- [LONG_LEAD_ITEM]: [DESCRIPTION], lead time: [LEAD_TIME], order date: [ORDER_DATE]

Create a material procurement schedule with: material name, quantity, needed on-site date, supplier, lead time, order-by date, ordered/confirmed status column.

Format as a tracking document that can be updated weekly.
```

---

### RFI (Request for Information) to Architect or Engineer
*Use when submitting a formal Request for Information during a project.*

```
Write a formal Request for Information (RFI) to an architect or engineer.

Project: [PROJECT_NAME]
RFI number: [RFI_NUMBER]
Date: [DATE]
From: [MY_COMPANY_NAME], [MY_NAME], [MY_TITLE]
To: [ARCHITECT/ENGINEER_FIRM], [CONTACT_NAME]
Subject: [RFI_SUBJECT — brief description]
Reference (drawing/spec): [DRAWING_NUMBER_OR_SPEC_SECTION]

Description of information requested:
[DETAILED_QUESTION — what you need to know, including specific location on drawings if applicable]

Why this information is needed:
[REASON — how it affects your work or schedule]

Response needed by: [DATE — to avoid schedule impact]
If no response by this date, we will proceed as follows: [DEFAULT_ACTION — only if applicable]

Format as a formal RFI document. Clear, specific, and professional.
```

---

### Subcontractor Performance Issue
*Use when addressing a performance problem with a subcontractor.*

```
Write a message addressing a performance issue with a subcontractor.

Sub: [SUB_COMPANY_NAME], [SUB_CONTACT]
Project: [PROJECT_NAME]
Issue: [ISSUE — be specific: poor work quality, no-shows, safety violation, late completion]
Impact on the project: [IMPACT — schedule delay, rework required, client complaint]
What was agreed: [CONTRACT_REQUIREMENT — reference the original agreement]
What we're requiring: [REQUIRED_ACTION — fix the work, provide more manpower, comply with schedule]
Deadline: [DEADLINE]
Consequence if not resolved: [CONSEQUENCE — removed from project, withheld payment, etc.]

Write a message that:
1. States the issue factually and specifically
2. References what was agreed
3. States clearly what is required and by when
4. Notes the consequence if not met
5. Remains professional (you may work together again)

This may be referenced in a dispute. Keep it factual.
```

---

### Permit Application Cover Letter
*Use when submitting a permit application to a local building department.*

```
Write a permit application cover letter.

Company: [COMPANY_NAME], [LICENSE_NUMBER], [ADDRESS], [PHONE]
Owner/applicant: [PROPERTY_OWNER_NAME]
Property address: [PROPERTY_ADDRESS], [PARCEL_NUMBER — if applicable]
Project description: [PROJECT_DESCRIPTION]
Estimated construction value: $[CONSTRUCTION_VALUE]
Proposed start date: [START_DATE]
Contractor of record: [CONTRACTOR_NAME], [LICENSE]
Architect/engineer of record (if applicable): [DESIGN_PROFESSIONAL]
Attachments included: [LIST_OF_ATTACHMENTS — plans, applications, etc.]
Contact for questions: [CONTACT_NAME], [PHONE], [EMAIL]

Write a professional permit application cover letter that:
1. Clearly identifies the project and property
2. Provides contractor and license information
3. Lists all attachments
4. Requests timely review given the project schedule
```

---

### Punch List Management Tracker
*Use when creating a punchlist management document for project closeout.*

```
Create a punchlist tracking document for construction project closeout.

Project: [PROJECT_NAME] at [PROJECT_ADDRESS]
Walk-through date: [DATE]
Attended by: [ATTENDEES_AND_COMPANIES]
Final payment: $[FINAL_PAYMENT_AMOUNT] — status: [HELD_PENDING_PUNCHLIST / OTHER]

Punchlist items:
Item 1: [DESCRIPTION], location: [LOCATION], responsible party: [WHO], due date: [DATE], status: Open
Item 2: [DESCRIPTION], location: [LOCATION], responsible party: [WHO], due date: [DATE], status: Open
[Continue for all items]

Completion certification: This punchlist was identified during the project walk-through on [DATE]. Work will be deemed substantially complete upon completion of all items above.

Create a tracking document with: item number, description, location, responsible party, due date, and a completion status column. Include signature lines for both GC and owner.
```

---

### Insurance Certificate Request to Subcontractor
*Use when requesting proof of insurance from a subcontractor before they start work.*

```
Write an insurance certificate request to a subcontractor.

My company: [MY_COMPANY_NAME]
Sub: [SUB_COMPANY_NAME]
Project: [PROJECT_NAME]
Insurance required:
- General Liability: $[GL_AMOUNT] per occurrence / $[AGGREGATE] aggregate
- Workers' Compensation: statutory limits
- Additional insured: [MY_COMPANY_NAME] must be listed as additional insured on GL policy
- Certificate holder: [MY_COMPANY_NAME], [ADDRESS]
Deadline: [DATE — before work begins]
Contact: [MY_NAME], [EMAIL]

Write a professional insurance request that:
1. States what coverage is required
2. Specifies the additional insured requirement clearly
3. Sets a firm deadline before work begins
4. Provides instructions for how to send the certificate

Under 150 words. Professional and specific.
```

---

### Lien Waiver Request
*Use when requesting lien waivers from subcontractors and suppliers.*

```
Write a lien waiver request to a subcontractor or supplier.

From: [MY_COMPANY_NAME]
To: [SUB_OR_SUPPLIER_NAME]
Project: [PROJECT_NAME], [PROJECT_ADDRESS]
Owner: [PROPERTY_OWNER]
Payment being made: $[PAYMENT_AMOUNT] for [WORK_PERIOD]
Lien waiver type needed: [CONDITIONAL_PROGRESS / UNCONDITIONAL_FINAL]
Deadline to return: [DEADLINE]
Return to: [MY_NAME], [EMAIL/ADDRESS]

Write a lien waiver request that:
1. Specifies the project, payment, and type of waiver needed
2. Attaches or references the waiver form (if applicable)
3. Sets a clear deadline
4. Explains why it's required before payment is released

Professional. Lien waivers protect everyone — frame it as standard practice, not a demand.
```

---

### Change Order Log
*Use when creating an ongoing change order log for a project.*

```
Create a change order log template for a construction project.

Project: [PROJECT_NAME] at [PROJECT_ADDRESS]
Original contract value: $[ORIGINAL_CONTRACT]

Change order log format:
- CO Number
- Date issued
- Description of change
- Change order amount (+/-)
- Cumulative contract value
- Status (pending / approved / rejected)
- Client signature date

Include a running summary:
- Original contract: $[AMOUNT]
- Approved change orders: $[CO_TOTAL]
- Current contract value: $[CURRENT_TOTAL]
- Pending change orders: $[PENDING_TOTAL]
- Potential contract value: $[POTENTIAL_TOTAL]

Format as a professional tracking log. Include spaces for reference to original contract sections.
```

---

### Safety Incident Report
*Use when documenting a safety incident or near-miss on a job site.*

```
Write a safety incident report form for a job site incident.

Company: [COMPANY_NAME]
Project: [PROJECT_NAME], [ADDRESS]
Date/time of incident: [DATE_TIME]
Location on site: [LOCATION]
Person(s) involved: [NAMES_AND_ROLES]
Type of incident: [INCIDENT_TYPE — injury, near miss, property damage, etc.]
Description of what happened: [INCIDENT_DESCRIPTION]
Injury or damage: [INJURY_OR_DAMAGE — none / describe]
Medical attention required: [YES/NO — if yes, describe]
Witnesses: [WITNESS_NAMES]
Root cause (preliminary): [CAUSE_ANALYSIS]
Immediate corrective action taken: [CORRECTIVE_ACTION]
Preventive measures going forward: [PREVENTION]
Reported by: [NAME, ROLE, DATE]
Supervisor signature: ________________

This document may be required by OSHA, insurance, and workers' comp. Complete fully and honestly.
```

---

### Subcontractor Pre-Qualification Form
*Use when evaluating a new subcontractor before adding them to your vendor list.*

```
Create a subcontractor pre-qualification questionnaire.

For use by: [MY_COMPANY_NAME]
Purpose: Evaluating new subcontractors before awarding work

Include sections for:
1. Company information (name, address, contact, years in business, number of employees)
2. License information (license number, type, expiration, states)
3. Insurance (GL, workers' comp, umbrella — carrier, limits, expiration)
4. Bonding capacity (if applicable)
5. Financial references (bank reference, credit references)
6. 3 project references (project, owner, contact, value, year)
7. Safety record (EMR rate, OSHA incidents in last 3 years)
8. Quality certifications (if any)
9. Statement of past litigation or claims (yes/no + description if yes)
10. Signature and attestation

Format as a professional form that can be sent to prospective subcontractors.
```

---

### Budget Tracking Summary
*Use when preparing a project budget tracking report for yourself or a client.*

```
Write a project budget tracking summary.

Project: [PROJECT_NAME]
Client: [CLIENT_NAME]
Contract value: $[CONTRACT_VALUE]
As of date: [DATE]

Budget tracking:
Category 1 — [CATEGORY]: budgeted $[BUDGET], spent to date $[SPENT], remaining $[REMAINING], variance [+/-$VAR]
Category 2 — [CATEGORY]: budgeted $[BUDGET], spent $[SPENT], remaining $[REMAINING], variance
[Continue for all categories]

Total budgeted: $[TOTAL_BUDGET]
Total spent to date: $[TOTAL_SPENT]
Remaining budget: $[REMAINING]
Approved change orders: $[APPROVED_COs]
Revised total: $[REVISED_TOTAL]
Projected over/under: $[PROJECTION]

Write a brief narrative summary (3-5 sentences) explaining the budget status, any variances, and whether there are concerns going forward.
```

---

### Project Closeout Checklist
*Use when ensuring all project closeout tasks are completed before releasing final payment.*

```
Create a project closeout checklist.

Company: [COMPANY_NAME]
Project: [PROJECT_NAME] at [PROJECT_ADDRESS]
Contract value: $[CONTRACT]
Final payment amount: $[FINAL_PAYMENT]

Include checklist items for:
1. Construction completion (punchlist complete, site cleaned, equipment removed)
2. Documentation (as-builts, warranty documents, permit card, final inspection sign-off)
3. Financial (all subcontractor final invoices received, lien waivers collected from all parties)
4. Legal (final change orders executed, all claims resolved)
5. Client (walk-through completed, sign-off obtained, keys/access cards returned)
6. Permits and inspections (final inspection passed, certificate of occupancy received if required)
7. Safety (all hazmat removed, MSDS records filed, OSHA log updated)
8. Quality (all warranty items documented and communicated to owner)

Format as a numbered checklist with responsible party and sign-off fields.
```

---

*Total prompts in this file: 18*
