# 06 — Workflow SOPs

*5 complete end-to-end workflow playbooks for a financial advisor's most time-intensive recurring tasks*

---

## SOP 1: Quarterly Client Review Cycle (4-Day Workflow)

*Complete workflow for preparing, running, and following up on quarterly client reviews*

---

### Day 1: Prep (Morning)

**Step 1: Pull the client list**
Identify all clients due for a quarterly touchpoint. Segment by: review meeting needed, email update only, phone check-in only.

**Step 2: Generate performance reports**
Pull portfolio performance reports from your custodian. Capture: QTD return, YTD return, benchmark comparison, current vs. target allocation.

**Step 3: Draft market commentary email (use Prompt 4 from `04-investment-analysis-prompts.md`)**
Fill in the bracket variables:
```
Quarter: [Q + YEAR]
Key market events: [LIST 3 — Fed action, earnings, geopolitical, economic data]
S&P 500 performance: [RETURN]
Bond market: [CONTEXT]
What this means for clients: [YOUR INTERPRETATION]
Key takeaway: [YOUR MESSAGE]
```

### Day 1: Prep (Afternoon)

**Step 4: Personalize for each client segment**
For each review client:
- Retrieve their most recent meeting notes
- Flag any open items or outstanding action items
- Note any life events or changes since last meeting
- Check beneficiary designations are current

**Step 5: Generate agenda and talking points (use Prompt 8 from `02-client-communication-prompts.md`)**
For each client meeting:
- Portfolio value and performance
- Planning updates
- Any open items from last meeting
- Questions to ask

---

### Day 2: Send Outreach

**Step 6: Send quarterly update emails**
Send the market commentary + portfolio summary to email-only clients. Use Prompt 4 from Communication as the template.

**Step 7: Schedule meetings**
Send meeting invitations to clients who need a formal quarterly review. Use Prompt 7 (Annual Review Invitation) adapted for quarterly format.

**Step 8: Review meeting prep documents**
For each client meeting scheduled: print or save the agenda, talking points, and portfolio report.

---

### Day 3: Run the Meetings

**Step 9: Meeting structure (45-60 minutes)**
1. Personal check-in (5 min) — how are they doing, anything new in their life?
2. Market context (5 min) — brief summary of what happened
3. Portfolio review (10 min) — performance, allocation, changes
4. Planning updates (15 min) — open items, new planning topics
5. Action items (5 min) — what we're each doing after the meeting
6. Forward look (5 min) — what's coming up, next touchpoint

**Step 10: Take notes in real time**
Capture: decisions made, questions raised, action items, any new personal information, emotional tone/mood of client.

---

### Day 4: Follow-Up

**Step 11: Send post-meeting summary email (use Prompt 22 from `02-client-communication-prompts.md`)**
Within 24 hours of each meeting:
- Summary of topics discussed
- Decisions made
- My action items with deadlines
- Their action items with deadlines
- Next meeting date

**Step 12: Execute action items**
- Rebalancing trades (if approved)
- Account changes
- Document requests
- Referrals to CPA / attorney / insurance

**Step 13: Update CRM**
- Log meeting notes
- Update next review date
- Flag any follow-up items
- Update client profile with new personal information

**Quality check:** Every client who had contact this quarter (meeting, email, or call) is logged. No client is forgotten.

---

## SOP 2: New Client Onboarding Communication Sequence (30-Day Workflow)

*Complete communication sequence for onboarding a new client from signing to first meeting*

---

### Day 1 — Signed Agreement: Welcome

**Email 1: Welcome Letter (use Prompt 1 from `02-client-communication-prompts.md`)**
- Send within 24 hours of signed agreement
- Welcome, acknowledge their goals, outline next steps
- Attach any onboarding forms needed

### Days 2-5 — Paperwork Phase

**Email 2: Paperwork Status (as needed)**
- Confirm receipt of completed forms
- Note any missing items with deadline
- Reassure them things are moving forward

**Email 3: Account Transfer Status (use Prompt 2 from `02-client-communication-prompts.md`)**
- Once transfer is initiated
- Timeline and what to expect
- Who to contact with questions

### Day 7 — Planning Meeting Confirmation

**Email 4: First Meeting Confirmation (use Prompt 3 from `02-client-communication-prompts.md`)**
- Confirm date, time, format
- List documents to bring or prepare
- Set expectations for the meeting outcome

### Day 14-21 — First Planning Meeting

**Meeting agenda:**
1. Review their complete financial picture (data gathering)
2. Identify planning priorities
3. Discuss investment strategy and risk tolerance
4. Set expectations for the planning process

**Post-meeting (use Prompt 22 from `02-client-communication-prompts.md`)**
- Send meeting summary within 24 hours
- List action items for both parties
- Confirm timeline for financial plan delivery

### Day 30 — Plan Delivery

**Financial plan document delivered**
- Walk through plan in a second meeting or video call
- Confirm next quarterly review date
- Set annual review on the calendar

**Welcome to your CRM workflow** — client is now in the ongoing review cycle.

---

## SOP 3: Market Volatility Response Protocol

*What to do when markets drop significantly and clients need proactive communication*

---

### Trigger: Market drops 5-10% in a week, or client calls with concern

**Within 24 hours:**

**Action 1: Segment your client base**
- Tier 1 (call immediately): Clients in or near retirement, anxious personalities, anyone who called or emailed
- Tier 2 (proactive email): All other investment clients
- Tier 3 (monitor): No action needed unless they reach out

**Action 2: Draft volatility email (use Prompt 5 from `02-client-communication-prompts.md`)**
```
Market situation: [SPECIFIC — % decline, timeframe, cause]
Key message: [WHAT YOU WANT THEM TO TAKE AWAY]
Portfolio action being taken: [SPECIFIC — rebalancing? tax-loss harvesting? nothing? why?]
Plan status: [HOW DOES THIS AFFECT THEIR PLAN — be specific]
Call to action: [OFFER A CALL IF THEY WANT TO TALK]
```

**Action 3: Call Tier 1 clients**
Script for the call:
1. "I wanted to call proactively — I know market moves like this can feel unsettling."
2. "Here's what's happening and why: [2-3 sentences]"
3. "Here's how your portfolio is positioned: [specific to their allocation]"
4. "Here's your plan status: [on track despite this]"
5. "Any questions, or anything on your mind?"

**Action 4: Review portfolios for rebalancing opportunities**
- Does any account drift beyond policy bands? → Execute rebalancing
- Any tax-loss harvesting opportunities? → Execute and communicate

**Action 5: Send market commentary (use Prompt 1 from `04-investment-analysis-prompts.md`)**
Broader context email within 48 hours.

**Follow-up within 1 week:**
- Check in with anyone who called or seemed worried
- Log all client contacts in CRM
- Update any plans affected by sustained market change

---

## SOP 4: Annual Financial Plan Meeting Preparation (5-Day Workflow)

*Comprehensive prep workflow for annual comprehensive planning review meetings*

---

### Day 1: Client Research

**Pull and review:**
- Complete client file — notes from the past 12 months
- Portfolio performance — annual return, allocation, changes
- Financial plan status — on track for each goal?
- Life events since last annual meeting
- Open items from prior meeting

**Identify:**
- What changed in their life this year?
- What planning opportunities did we miss or defer?
- What should we proactively address?

### Day 2: Plan Update

**Update the financial plan with:**
- Current asset values
- Updated income assumptions (salary changes, Social Security, RMDs)
- Updated goals (any changes discussed during the year)
- Current insurance coverage review
- Beneficiary designation check

**Run projections:**
- Retirement readiness (use Prompt 1 from `03-financial-planning-prompts.md`)
- Education funding status (if applicable)
- Net worth change year-over-year

### Day 3: Meeting Prep Document

**Generate meeting agenda and talking points (use Prompt 8 from `02-client-communication-prompts.md`)**

Structure the meeting agenda:
1. Year in review — personal and financial
2. Portfolio review — performance, allocation, changes
3. Plan status — are we on track?
4. New year priorities — what we focus on in the next 12 months
5. Life planning — anything coming up we should prepare for?
6. Open Q&A
7. Action items

### Day 4: Send Pre-Meeting Materials

**Email the client:**
- Meeting confirmation and agenda
- Any pre-meeting homework (updated cash flow, insurance policies, recent tax return)
- Questions to think about before the meeting

### Day 5: Run the Meeting + Follow-Up

**During the meeting:**
- Take notes on everything personal (life changes, goals, concerns)
- Get decisions made and documented
- Set the agenda for the next 12 months

**After the meeting (within 24 hours):**
- Send meeting summary (use Prompt 22 from `02-client-communication-prompts.md`)
- Execute any immediate action items
- Update CRM with all new information
- Set next annual meeting date

---

## SOP 5: Referral Cultivation and Follow-Up Sequence

*Complete workflow for turning client relationships into referrals*

---

### Ongoing: Create Referral Conditions

**Monthly check-in:**
After any meeting or positive client interaction, ask yourself:
- Did I deliver exceptional value today?
- Is this client someone who talks to peers in similar situations?
- Have I made it easy for them to refer me?

**Quarterly action:**
Identify 3-5 clients most likely to refer based on:
- Longevity and trust
- Positive outcomes delivered
- Social/community connectedness
- Similar peers who might benefit

### When a Client Gives You a Referral

**Within 24 hours:**
Send thank-you email (use Prompt 23 from `02-client-communication-prompts.md`) — genuine, specific, brief.

**Within 48 hours:**
Contact the referred prospect (use Prompt 7 from `05-business-development-prompts.md`) — introduce yourself, reference the mutual connection, propose a call.

**After meeting the prospect:**
Update the referring client: "I had a great conversation with [first name] — thank you again for the introduction. I'll take great care of them."

### Referral Cultivation Email Sequence

**Step 1: Post-significant-win email**
After a major planning win (hitting a milestone, navigating a crisis, completing a major plan):
→ Send a "here's what we accomplished together" email
→ Naturally creates referral conditions without asking

**Step 2: Value-add content**
Periodically share content that makes clients think of peers:
- "Forward to a friend who might be approaching retirement"
- "Share this with a colleague who has RSUs to plan"

**Step 3: The direct ask (use Prompt 6 from `05-business-development-prompts.md`)**
After 12+ months with a satisfied client:
- Specific, personalized ask
- Clear description of who benefits
- Low pressure, easy to do

**Referral tracking:**
- Log every referral in CRM
- Track the source, status, and outcome of every referred prospect
- Recognize and thank referral sources regardless of outcome

**Closing the loop:**
After a referral becomes a client:
→ Write a personal note to the referring client
→ Consider a thank-you gift per your firm's compliance guidelines

---

*Return to: `07-cheat-sheet.md` → Top 15 power prompts and 10 Golden Rules*
