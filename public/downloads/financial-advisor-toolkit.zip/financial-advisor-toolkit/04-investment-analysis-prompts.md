# 04 — Investment Analysis Prompts

*20 prompts for portfolio commentary, market analysis, rebalancing rationale, and investment education*

---

**Prompt 1: Market Volatility Commentary**

*When to use: Writing a client-facing explanation of current market turbulence*

```
Write a calm, professional market volatility commentary for client distribution.

Current market situation: [DESCRIBE — e.g., "S&P 500 down 12% YTD driven by [SPECIFIC FACTORS]"]
Primary causes of volatility: [LIST 2-3 KEY DRIVERS]
Historical context: [COMPARABLE HISTORICAL PERIODS — e.g., "this is the 4th correction of 10%+ since 2015"]
Bond market behavior: [CONTEXT]
My interpretation: [YOUR VIEW OF WHETHER THIS IS TEMPORARY, STRUCTURAL, OR UNCERTAIN]
What we're doing (or not doing): [PORTFOLIO ACTION OR DELIBERATE INACTION]
What clients should do: [TYPICALLY: STAY COURSE / CONSIDER REBALANCING / OPPORTUNITY TO ADD]

Write a 3-4 paragraph commentary that:
1. Acknowledges what's happening directly (don't minimize)
2. Provides historical context that is genuinely calming (not dismissive)
3. Explains the mechanism driving volatility in plain English
4. States clearly what we're doing and why
5. Ends with a grounding statement about their long-term goals

Add disclaimer: Past performance does not guarantee future results. This is not a recommendation to buy or sell any security.
```

---

**Prompt 2: Portfolio Rebalancing Rationale Letter**

*When to use: Explaining to a client why you're rebalancing their portfolio*

```
Write a client letter explaining a portfolio rebalancing decision.

Client: [CLIENT NAME]
Trigger for rebalancing: [DRIFT FROM TARGET ALLOCATION / SCHEDULED ANNUAL REBALANCE / LIFE CHANGE / MARKET OPPORTUNITY]
Before rebalancing allocation: [E.G., "70% equity, 30% fixed income — drifted to 80% equity, 20% fixed income"]
Target allocation: [E.G., "65% equity, 35% fixed income"]
After rebalancing allocation: [RESULT]
Trades being made: [DESCRIBE GENERALLY — e.g., "trimming equity positions that appreciated, adding to fixed income"]
Tax implications (if any): [WILL THERE BE CAPITAL GAINS? IN WHAT ACCOUNTS?]
Why now: [RATIONALE — e.g., "equity markets are at all-time highs, locking in gains and reducing risk is appropriate"]

Write a letter that:
1. Explains what rebalancing is (briefly, in one sentence)
2. States what the portfolio drifted to and what we're returning it to
3. Explains why this benefits them in plain language
4. Notes any tax implications honestly
5. Connects the rebalancing to their stated risk tolerance and investment policy
6. Does NOT recommend specific securities by name without appropriate disclosures

Plain language. No jargon. 2-3 paragraphs.
```

---

**Prompt 3: Asset Allocation Explanation**

*When to use: Explaining a client's recommended asset allocation and the rationale*

```
Write an asset allocation explanation for a client.

Client: [CLIENT NAME]
Age: [AGE]
Risk tolerance assessment: [CONSERVATIVE / MODERATE / MODERATE-AGGRESSIVE / AGGRESSIVE]
Time horizon: [YEARS UNTIL FUNDS ARE NEEDED]
Primary goal for this portfolio: [RETIREMENT / EDUCATION / WEALTH BUILDING / INCOME]

Recommended allocation: 
- [ASSET CLASS 1 — e.g., US Large Cap Equity]: [%]
- [ASSET CLASS 2 — e.g., International Equity]: [%]
- [ASSET CLASS 3 — e.g., Fixed Income]: [%]
- [ASSET CLASS 4 — e.g., Real Assets/REITs]: [%]
- [ASSET CLASS 5 — e.g., Cash/Equivalents]: [%]

Why this allocation for this client: [YOUR RATIONALE]

Write a client-facing allocation explanation that:
1. Explains why this allocation matches their specific risk tolerance and time horizon
2. Describes the role of each major asset class (what it's there to do)
3. Explains the diversification benefit in plain terms ("not all eggs in one basket" upgraded version)
4. Notes what could cause this to change (life event, market conditions, approaching retirement)
5. Shows how this aligns with their Investment Policy Statement (or creates one)

Tone: Educational and confident. Clients should feel they understand why their money is allocated this way.
```

---

**Prompt 4: Fed Rate Decision — Client Impact Explanation**

*When to use: After a Federal Reserve rate decision, explaining the impact to clients*

```
Write a client communication explaining a Federal Reserve rate decision and its implications.

Decision: [RATE INCREASE / DECREASE / HOLD] of [AMOUNT] basis points
Current federal funds rate: [RATE %]
Fed's stated reasoning: [BRIEF SUMMARY OF FED'S RATIONALE]
Impact on bonds: [DIRECTION AND BRIEF EXPLANATION]
Impact on equities: [BRIEF ASSESSMENT]
Impact on savings rates: [FOR CLIENT CASH HOLDINGS]
Impact on mortgages/borrowing: [IF RELEVANT TO CLIENT BASE]
My view on what this means: [YOUR INTERPRETATION]
Portfolio changes made or not made: [DESCRIBE]

Write a brief, clear client communication (under 300 words) that:
1. States what the Fed did in one sentence
2. Explains why the Fed made this decision in plain language (no "monetary policy normalization" language)
3. Describes the near-term impact on their portfolio
4. Notes any portfolio adjustments made or the rationale for no changes
5. Puts it in perspective — this is one data point in a long-term plan

Add disclaimer: This is not a recommendation to buy or sell any security.
```

---

**Prompt 5: Explaining a Losing Position to a Client**

*When to use: A specific holding in a client's portfolio has declined significantly*

```
Write a client communication explaining a significant loss in a portfolio holding.

Client: [CLIENT NAME]
Position: [SECURITY / FUND / ASSET CLASS NAME — describe generally if a specific security]
Current loss: [% DECLINE and $ AMOUNT]
Time held: [DURATION]
Why we owned it originally: [INVESTMENT THESIS AT PURCHASE]
What happened: [WHY IT DECLINED — honest explanation]
Current assessment: [STILL APPROPRIATE TO HOLD / SHOULD BE SOLD / REDUCED]
Action taken or recommended: [SELL / HOLD / ADD / REBALANCE]
Tax considerations: [TAX LOSS HARVESTING OPPORTUNITY? TAX IMPACT OF SELLING?]

Write a client communication that:
1. States the loss clearly — don't hide it or over-soften it
2. Explains the original investment thesis and why we bought it
3. Gives an honest explanation of what changed
4. States the current recommendation and why
5. Acknowledges if this was a mistake vs. an unexpected market development
6. Does not make excuses — takes professional responsibility

Tone: Accountable and professional. Clients respect advisors who are honest about losses more than those who spin them.
```

---

**Prompt 6: Investment Policy Statement Summary**

*When to use: Creating or explaining an Investment Policy Statement for a client*

```
Write an Investment Policy Statement (IPS) summary for a client.

Client: [CLIENT NAME(S)]
Investment goal: [PRIMARY OBJECTIVE — retirement income, wealth building, education, etc.]
Time horizon: [YEARS UNTIL FUNDS NEEDED]
Risk tolerance: [FORMAL ASSESSMENT RESULT OR DESCRIBED]
Return objective: [TARGET RETURN RANGE or BENCHMARK]
Income needs: [CURRENT INCOME NEEDS FROM PORTFOLIO if any]
Liquidity needs: [ANY PLANNED WITHDRAWALS — timing, amount]
Tax considerations: [TAX BRACKET, ACCOUNT TYPES — taxable vs. tax-deferred]
Restrictions: [ANY ETHICAL/RELIGIOUS RESTRICTIONS, CONCENTRATED POSITIONS, EMPLOYER STOCK RULES]

Rebalancing policy:
- Threshold-based: [TRIGGER BANDS — e.g., ±5% from target]
- Time-based: [ANNUAL / QUARTERLY REVIEW]

Write an IPS document that:
1. States the investment objectives clearly
2. Documents the target asset allocation with rationale
3. Establishes the rebalancing rules
4. Notes any investment restrictions or special considerations
5. Defines what success looks like (benchmark, absolute return, or income-based metric)
6. Serves as the standing document guiding all portfolio decisions

This document governs the investment relationship. Write it to stand the test of time and market cycles.
```

---

**Prompt 7: Annual Performance Attribution Summary**

*When to use: Explaining annual portfolio performance and what drove returns*

```
Write an annual performance attribution summary for a client.

Client: [CLIENT NAME]
Calendar year: [YEAR]
Portfolio return (gross): [%]
Portfolio return (net of fees): [%]
Benchmark return: [% — describe the benchmark]
Relative performance: [OUTPERFORMED / UNDERPERFORMED by X%]

Attribution breakdown:
- Asset allocation contribution: [OVER/UNDERWEIGHT TO WHICH ASSET CLASSES HELPED/HURT]
- Security selection contribution (if applicable): [SPECIFIC POSITIONS THAT HELPED/HURT]
- Fees and costs: [$AMOUNT IMPACT]
- Tax management activity: [ANY TAX-LOSS HARVESTING OR GAIN DEFERRAL IMPACT]

Best-performing holdings: [TOP 2-3]
Worst-performing holdings: [BOTTOM 2-3]
Biggest portfolio changes this year: [WHAT CHANGED AND WHY]

Write an attribution summary that:
1. Shows overall performance in context (absolute and vs. benchmark)
2. Explains what drove the performance (not just reports it)
3. Highlights specific contributions honestly (both positive and negative)
4. Notes what we'd do differently in hindsight (if anything)
5. Looks forward: any strategy adjustments for next year?

This should give the client a genuine understanding of what they paid for in advisory services. Be honest.
```

---

**Prompt 8: Concentrated Position Risk Analysis**

*When to use: A client holds too much of their wealth in a single stock or employer shares*

```
Write a concentrated position analysis and recommendation for a client.

Client: [CLIENT NAME]
Concentrated position: [STOCK / COMPANY NAME — use general description if compliance requires]
Current value of position: [$AMOUNT]
Cost basis: [$AMOUNT — embedded gain if applicable]
% of total portfolio: [%]
Source: [EMPLOYER STOCK / INHERITED / FOUNDER SHARES / LONG-TERM HOLD]
Client's emotional attachment to this position: [HIGH — "my dad worked there" / LOW / NEUTRAL]
Tax situation: [CAPITAL GAINS RATE, OTHER INCOME, ROOM TO REALIZE GAINS]

Options to address concentration:
1. Gradual diversification (selling X% per year)
2. Tax-loss harvesting elsewhere to offset gains
3. Charitable giving strategies (donor-advised fund, CRT)
4. Covered call / collar strategy (note: discuss with appropriate securities license)
5. Hold as-is with concentration acknowledged

Write a concentrated position analysis that:
1. States the risk clearly with a real-world scenario ("if this stock drops 50%, you lose $X")
2. Gives a non-judgmental explanation of why concentration is risky
3. Presents options with estimated tax cost and risk reduction for each
4. Makes a recommendation with specific timeline
5. Acknowledges the emotional component if relevant

Do NOT dismiss the client's attachment to the position — address it respectfully.
```

---

**Prompt 9: Bond Market Explanation for Nervous Client**

*When to use: A client is confused or alarmed by bond market behavior, especially rising rates*

```
Write a plain-English explanation of bond market dynamics for a client concerned about their fixed income holdings.

Client concern: [WHAT THEY'RE WORRIED ABOUT — e.g., "my bonds lost value when rates went up", "why am I holding bonds if they're losing money?"]
Current bond market situation: [DESCRIBE — rate environment, credit spreads, duration of their holdings]
Their bond holdings: [BRIEF DESCRIPTION — short/intermediate/long duration, fund names generally, % of portfolio]
Their time horizon for these bonds: [WHY WE HOLD THEM — income, stability, diversification]

Write a bond explanation that:
1. Explains the relationship between interest rates and bond prices in one clear analogy
2. Addresses their specific situation (how their portfolio was affected)
3. Explains why we hold bonds even when they lose value in rising rate environments
4. Notes the reinvestment benefit in rising rate environments (higher future income)
5. Addresses whether any changes are warranted
6. Reassures without dismissing the concern

Analogy to use: [YOUR PREFERRED — e.g., "buying a house for the long term" / "the see-saw metaphor" / let AI suggest one]
```

---

**Prompt 10: Retirement Income Drawdown Strategy Explanation**

*When to use: Explaining to a retiring client how they will actually withdraw money from their portfolio*

```
Write a retirement income drawdown strategy explanation for a client entering retirement.

Client: [CLIENT NAME(S)]
Portfolio value at retirement: [$AMOUNT]
Accounts: [IRA $X, Roth IRA $X, 401(k) $X, taxable $X]
Monthly income needed from portfolio: [$AMOUNT after guaranteed income]
Planned withdrawal rate: [%] annually
Withdrawal strategy: [DESCRIBE — e.g., systematic withdrawal, bucket strategy, income floor + upside]
Account sequence: [WHICH ACCOUNTS THEY'LL DRAW FROM IN WHICH ORDER — typically taxable first, then tax-deferred, then Roth]
RMD timing: [STARTS AGE 73 — explain impact]

Write an explanation of the withdrawal strategy that:
1. Explains how they'll actually access their money each month (mechanics)
2. Explains the account sequencing and why (tax efficiency)
3. Addresses sequence of returns risk and the mitigation strategy
4. Shows the mathematical sustainability of the strategy (safe withdrawal rate context)
5. Explains what we'll monitor and when we'll adjust
6. Answers the question they actually have: "Will the money last?"

This is one of the most important conversations in the planning relationship. Make it clear and reassuring.
```

---

**Prompt 11: ESG / Socially Responsible Investing Overview**

*When to use: A client wants to know about ESG or values-aligned investing*

```
Write an ESG/socially responsible investing overview for a client interested in values-aligned investing.

Client: [CLIENT NAME]
Their values concern: [ENVIRONMENT / SOCIAL / GOVERNANCE / SPECIFIC EXCLUSION — e.g., tobacco, weapons, fossil fuels]
Current portfolio: [BRIEF DESCRIPTION — does it already have any ESG exposure?]
Portfolio size: [$AMOUNT]
Primary goal: [MAXIMIZE ESG ALIGNMENT / AVOID SPECIFIC SECTORS / INTEGRATE FACTORS WITHOUT SACRIFICING RETURN]
Performance priority: [RETURNS MATTER EQUALLY / WILLING TO ACCEPT SLIGHTLY LOWER RETURNS / RETURNS ARE SECONDARY TO VALUES]

Write an ESG overview that:
1. Defines ESG clearly (environmental, social, governance — what each means)
2. Explains the different approaches (exclusion, integration, impact, shareholder engagement)
3. Addresses the performance question honestly (the research is mixed — don't oversell or undersell)
4. Shows implementation options for their specific values
5. Notes the additional monitoring and cost implications
6. Recommends an approach and next steps

Be honest about trade-offs. Clients who invest this way deserve accurate information, not marketing.
```

---

**Prompt 12: Alternative Investment Explanation**

*When to use: Explaining alternative investments (private equity, real assets, annuities) to a client*

```
Write a plain-language explanation of an alternative investment product for a client.

Product type: [PRIVATE EQUITY / REAL ESTATE FUND / ANNUITY / STRUCTURED PRODUCT / HEDGE FUND / OTHER]
Specific product (if discussing one): [DESCRIBE — or keep general]
How it works: [MECHANICS IN SIMPLE TERMS]
Return expectations: [RANGE OR BENCHMARK]
Risk profile: [RISKS INVOLVED]
Liquidity: [HOW LIQUID OR ILLIQUID IS THIS?]
Fee structure: [COSTS INVOLVED]
Minimum investment: [$AMOUNT]
Why we're considering it for this client: [RATIONALE — diversification, income, inflation hedge]
Client's sophistication level: [BASIC / INTERMEDIATE / SOPHISTICATED INVESTOR]

Write an explanation that:
1. Explains what this is in plain English (no jargon, or jargon explained)
2. Describes how it works without technical complexity
3. Clearly states the risks — especially liquidity risk
4. Explains what role it plays in their portfolio
5. Shows the fees honestly
6. Addresses the question: "Is this appropriate for me?"

Do NOT oversell. Clients who understand what they own make better decisions.
```

---

**Prompt 13: Tax-Loss Harvesting Explanation**

*When to use: Explaining a tax-loss harvesting opportunity or transaction to a client*

```
Write a client explanation of a tax-loss harvesting opportunity.

Client: [CLIENT NAME]
Current market situation: [WHY THERE'S A HARVESTING OPPORTUNITY — positions with losses]
Specific positions with losses: [DESCRIBE GENERALLY — fund type, approximate loss amount]
Estimated tax savings: [$AMOUNT or RANGE]
Replacement investment: [WHAT WE'RE BUYING TO MAINTAIN MARKET EXPOSURE]
Wash sale rule: [EXPLAIN HOW WE'RE COMPLYING — 30-day rule on same/substantially identical securities]
Net impact on portfolio: [SAME MARKET EXPOSURE / SLIGHT CHANGE — describe]

Write an explanation (under 250 words) that:
1. Explains tax-loss harvesting in one clear sentence
2. Shows the specific opportunity and estimated tax savings in dollar terms
3. Explains the replacement investment to maintain exposure
4. Notes the wash sale rule and how we're navigating it
5. Gets client confirmation to proceed (or describes that you're proceeding per their investment policy)

This is a concrete service value-add. Make the benefit clear and specific.
```

---

**Prompt 14: New Market High — Should I Change Anything Letter**

*When to use: Client asks whether to change strategy when markets are at all-time highs*

```
Write a response to a client who is worried about investing or staying invested when markets are at all-time highs.

Client: [CLIENT NAME]
Their concern: [SPECIFIC WORRY — e.g., "should we move to cash?", "seems like a bad time to add money", "is the market overvalued?"]
Their allocation: [CURRENT ALLOCATION]
Their time horizon: [YEARS UNTIL THEY NEED THE MONEY]
Plan status: [ON TRACK / AHEAD / BEHIND]
Specific action they're considering: [WHAT THEY WANT TO DO]
My recommendation: [STAY THE COURSE / CONSIDER ADJUSTMENT — specific]

Write a response that:
1. Takes their concern seriously — don't dismiss it
2. Provides historical context on all-time highs (how common they are, what typically follows)
3. Explains why time in market vs. timing the market matters for their specific situation
4. Addresses their specific proposed action with a clear recommendation
5. Connects back to their plan — the plan was built for this kind of uncertainty

Provide one specific data point about market timing to ground the response in evidence.
Tone: Educational, calm, and advisory — not dismissive or condescending.
```

---

**Prompt 15: Behavioral Finance — Helping a Client Through Loss Aversion**

*When to use: A client is about to make a fear-driven decision during a market decline*

```
Write a client communication addressing loss aversion during a market decline.

Client: [CLIENT NAME]
Market situation: [DECLINE DETAILS — % down, timeframe]
Client's proposed action: [WHAT THEY WANT TO DO — sell, go to cash, stop contributions]
Their emotional state (as you read it): [FEARFUL / PANICKED / RATIONAL BUT UNCERTAIN]
Their portfolio impact if they execute their plan: [DOLLAR IMPACT AND LONG-TERM EFFECT]
Their plan status: [HOW THIS CHANGES THEIR LONG-TERM PLAN]
Historical precedent relevant to their situation: [REFERENCE TO A COMPARABLE PERIOD — 2009, 2020, 2022]

Write a communication that:
1. Validates their feeling (market declines ARE uncomfortable — acknowledge it)
2. Presents the behavioral finance concept of loss aversion without being condescending
3. Shows the mathematical cost of selling at the wrong time with their specific numbers
4. References a historical parallel where staying the course worked
5. Offers a middle ground if they need to "do something" (e.g., slight tactical adjustment vs. full cash)
6. Requests a call to discuss before any action

Do NOT lecture. Do NOT use the phrase "stay the course" without specific context. Do NOT minimize their fear.
```

---

**Prompt 16: New Account Investment Summary**

*When to use: After funding a new account, explaining how the money was invested*

```
Write a new account investment summary for a client.

Client: [CLIENT NAME]
Account type: [IRA / TAXABLE / 403B ROLLOVER / ETC.]
Amount invested: [$AMOUNT]
Date invested: [DATE]
Investment strategy: [DESCRIBE THE PORTFOLIO STRATEGY]
Holdings summary: [BRIEF DESCRIPTION — asset classes and approximate allocation]
Why this portfolio for this account: [RATIONALE — tax location, goal, risk level]
Expected income from this portfolio: [DIVIDENDS/INTEREST ESTIMATED ANNUALLY if relevant]
First review timing: [WHEN WE'LL NEXT REVIEW]

Write a brief summary (under 300 words) confirming how the money was invested, why, and what happens next. Clients want to know their money is working and understand the basic structure.
```

---

**Prompt 17: Inflation Impact Explanation**

*When to use: Helping a client understand how inflation affects their savings and retirement plan*

```
Write a client explanation of inflation's impact on their financial plan.

Client: [CLIENT NAME]
Current inflation rate: [%]
Client age and retirement timeline: [DETAILS]
Portfolio: [BRIEF DESCRIPTION]
Inflation-sensitive concerns: [PURCHASING POWER EROSION / FIXED INCOME REAL RETURN / RETIREMENT INCOME SUSTAINABILITY]
Inflation hedges in their portfolio: [TIPS / REAL ESTATE / COMMODITIES / EQUITIES — what they have]
Gap in inflation protection: [ANYTHING MISSING?]
Specific concern they've raised: [IF ANY]

Write an inflation explanation that:
1. Quantifies inflation's impact in real dollars (e.g., "at 3% inflation, $100 today buys $74 in 10 years")
2. Shows the specific impact on their retirement income needs
3. Describes how their portfolio is (and isn't) protected
4. Makes a specific recommendation if there's a gap
5. Addresses the fixed income / bond real return question specifically

Make the math tangible. Generic "inflation erodes purchasing power" language is not useful.
```

---

**Prompt 18: Year-End Investment Tax Planning Summary**

*When to use: Reviewing end-of-year investment tax positioning for a client*

```
Write a year-end investment tax planning summary.

Client: [CLIENT NAME]
Tax situation: [INCOME LEVEL / MARGINAL RATE / EXPECTED CHANGES NEXT YEAR]
Realized gains YTD: [$AMOUNT — short-term vs. long-term]
Realized losses YTD: [$AMOUNT]
Positions with unrealized gains: [DESCRIBE GENERALLY]
Positions with unrealized losses: [DESCRIBE — harvesting opportunities?]
Roth conversion opportunity: [YES — amount / NO]
IRA or 401(k) contribution room remaining: [$AMOUNT]
Charitable giving plans: [QCD ELIGIBLE? DAF STRATEGY?]
Deadline: December 31

Write a year-end tax planning summary that:
1. Shows the current realized gain/loss position
2. Identifies specific tax-saving opportunities with dollar estimates
3. Prioritizes the actions by impact and urgency
4. Notes what needs to happen before December 31
5. Flags items to discuss with their CPA

Add note: For final tax decisions, coordinate with their CPA.
```

---

**Prompt 19: Explaining Dollar-Cost Averaging to a New Investor**

*When to use: Onboarding a new investor or explaining a systematic investment strategy*

```
Write a plain-English explanation of dollar-cost averaging for a client.

Client: [CLIENT NAME]
Investment situation: [NEW INVESTOR / STARTING SYSTEMATIC CONTRIBUTIONS / ASKING ABOUT LUMP SUM vs. DCA]
Amount to invest: [$TOTAL — lump sum available OR monthly amount]
Investment timeline: [YEARS]
Market context: [CURRENT MARKET CONDITION — volatile / all-time high / recovering / other]
Their specific question: [WHAT THEY'VE ASKED]

Write an explanation that:
1. Defines dollar-cost averaging in one clear sentence
2. Uses a concrete example with actual numbers (not hypothetical percentages)
3. Explains when DCA makes sense vs. lump-sum investing
4. Addresses the psychological benefit alongside the mathematical argument
5. Makes a specific recommendation for their situation
6. Connects to the systematic savings habit as the underlying goal

Keep it under 300 words. Make the math tangible and the recommendation clear.
```

---

**Prompt 20: Portfolio Review Presentation Script**

*When to use: Preparing talking points for a formal portfolio review meeting*

```
Write a portfolio review presentation script for a client meeting.

Client: [CLIENT NAME(S)]
Meeting date: [DATE]
Portfolio value: [$CURRENT] vs. [$X ago — percentage change]
YTD performance: [%] vs. benchmark [%]
Portfolio allocation (current vs. target): [DESCRIBE ANY DRIFT]
Major market events this period: [2-3 EVENTS]
Changes made since last meeting: [TRADES / REBALANCING / STRATEGY CHANGES]
Agenda items: [LIST — performance review, planning updates, strategy discussion, questions]
Specific topic to address: [ANY KNOWN CLIENT CONCERN OR QUESTION]

Write a meeting script with:
1. Opening (personal connection + meeting agenda — 2 minutes)
2. Market context section (3 minutes — what happened and why)
3. Portfolio performance section (5 minutes — numbers, attribution, context)
4. Planning updates section (5 minutes — any plan changes, life events)
5. Action items review (what was agreed last time, what's been done)
6. Discussion / questions (what to ask them)
7. Close and next steps

Format as a script with [TALKING POINTS] and [TRANSITION PHRASES] between sections.
```

---

*Next: `05-business-development-prompts.md` → 18 prompts for prospecting, referrals, and practice growth*
