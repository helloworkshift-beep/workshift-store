# 💰 The Financial Advisor's AI Prompt Toolkit

**90+ battle-tested AI prompts for financial advisors, wealth managers, and financial planners**

---

## What's Inside

This toolkit gives you instant access to high-quality, copy-paste-ready prompts for every part of a financial advisor's workflow — from drafting client reports to prospecting new clients, from building financial plans to handling difficult client conversations.

Every prompt is:
- **Specific** — Built for real financial advisory work, not generic business writing
- **Structured** — Uses `[BRACKET VARIABLES]` so you can customize in seconds
- **Compliant-aware** — Designed to produce professional output you review and edit before sending
- **Actionable** — Produces output you can actually use with clients

---

## File Guide

| File | Contents | Prompts |
|------|----------|---------|
| [01-quick-start-guide.md](01-quick-start-guide.md) | Setup, system prompts, compliance tips | — |
| [02-client-communication-prompts.md](02-client-communication-prompts.md) | Client emails, reports, meeting prep, updates | 25 |
| [03-financial-planning-prompts.md](03-financial-planning-prompts.md) | Retirement plans, goal analysis, plan summaries | 22 |
| [04-investment-analysis-prompts.md](04-investment-analysis-prompts.md) | Portfolio commentary, market updates, rebalancing | 20 |
| [05-business-development-prompts.md](05-business-development-prompts.md) | Prospect outreach, referral asks, event follow-ups | 18 |
| [06-workflow-sops.md](06-workflow-sops.md) | 5 complete workflow playbooks | — |
| [07-cheat-sheet.md](07-cheat-sheet.md) | Top 15 power prompts + Golden Rules | 15 |

**Total: 90+ prompts**

---

## Who This Is For

- **Independent Financial Advisors (RIAs and IARs)** running their own practice
- **Wealth Managers** at broker-dealers or RIA firms
- **Financial Planners (CFPs)** serving retail clients
- **Associate Advisors** building their client communication skills
- **Branch Managers** who want to standardize team communication quality

---

## ⚠️ Compliance Notice

These prompts generate draft content for your review. **Always:**
- Review all AI-generated content before sending to clients
- Ensure output complies with your firm's compliance policies and FINRA/SEC requirements
- Remove or replace any specific investment recommendations that require disclosure
- Add required disclosures, disclaimers, and footnotes per your compliance department

AI is a writing accelerant, not a compliance substitute.

---

## How to Use

1. Start with **[01-quick-start-guide.md](01-quick-start-guide.md)** — set up your system prompt
2. Bookmark **[07-cheat-sheet.md](07-cheat-sheet.md)** — your daily quick reference
3. Use **[02-client-communication-prompts.md](02-client-communication-prompts.md)** for client-facing work
4. Use **[06-workflow-sops.md](06-workflow-sops.md)** for complete end-to-end workflows

---

*Built for advisors who want to serve more clients without burning out.*
