# 02 — Client Communication Prompts

*25 prompts for client emails, quarterly updates, meeting prep, difficult conversations, and annual reviews*

---

## NEW CLIENT ONBOARDING

---

**Prompt 1: Welcome Letter — New Client**

*When to use: After signing a new client — sets the tone for the relationship*

```
You are an experienced financial advisor writing a warm, professional welcome letter to a new client. This letter should build excitement about the relationship, set clear expectations for the onboarding process, and make the client feel confident they made the right choice.

Write a welcome letter for:
- Client name(s): [CLIENT NAME(S)]
- Type of client: [INDIVIDUAL / COUPLE / BUSINESS OWNER / RETIREE]
- Primary financial goals discussed: [GOALS — e.g., retirement in 8 years, funding two kids' college, protecting business assets]
- Next steps in onboarding: [WHAT HAPPENS NEXT — e.g., data gathering meeting on [DATE], completing account transfer paperwork]
- My name and firm: [ADVISOR NAME], [FIRM NAME]

The letter should:
1. Express genuine welcome and appreciation for their trust
2. Briefly acknowledge the primary goals they've shared
3. Outline the next 3-4 steps in the onboarding process with a timeline
4. Set expectations for how communication will work going forward (how often, what format)
5. Give them a direct contact method for questions
6. Close warmly and confidently

Tone: Professional but warm. This is a relationship business. Length: 3-4 short paragraphs.
```

---

**Prompt 2: Account Transfer Status Update**

*When to use: Keeping new clients informed during the account transfer process, which often creates anxiety*

```
Write a brief, reassuring email updating a new client on the status of their account transfer.

Client: [CLIENT NAME]
Accounts being transferred: [ACCOUNT TYPES AND APPROXIMATE VALUES]
Current status: [WHERE IN THE TRANSFER PROCESS — e.g., "paperwork submitted to [OLD FIRM], processing typically takes 5-10 business days"]
Expected completion: [DATE RANGE]
Any issues or delays: [NONE / DESCRIBE ISSUE AND RESOLUTION]
What happens next: [NEXT STEP AFTER TRANSFER COMPLETES]

The email should:
- Be brief (3 paragraphs max)
- Acknowledge that transfers can feel uncertain and reassure them things are on track
- Give a specific next-step so they know what to expect
- Encourage them to reach out with any questions

Do NOT make the email sound like a form letter — use the client's name and specific account details.
```

---

**Prompt 3: First Planning Meeting Confirmation and Prep**

*When to use: Confirming the first financial planning meeting and helping clients prepare*

```
Write an email confirming a new client's first financial planning meeting and explaining how they can prepare.

Client: [CLIENT NAME]
Meeting date and time: [DATE/TIME]
Meeting format: [IN-PERSON / VIDEO CALL — PLATFORM]
Meeting goal: [WHAT THIS FIRST MEETING ACCOMPLISHES — e.g., comprehensive data gathering, reviewing their current situation, setting planning priorities]
Documents to bring or send: [LIST — e.g., most recent tax return, account statements, current insurance policies, estate documents]
What they'll get from the meeting: [OUTCOME — e.g., "By the end of this meeting, we'll have a clear picture of your full financial situation and a prioritized list of what we'll tackle first"]
Advisor name: [NAME]

Make the email feel organized and confidence-inspiring. They should feel like they're in capable hands. Keep it to 4-5 paragraphs.
```

---

## ONGOING CLIENT COMMUNICATION

---

**Prompt 4: Quarterly Portfolio Review Email**

*When to use: Sending quarterly performance updates to clients*

```
You are a financial advisor writing a quarterly portfolio review email to a client. This email should contextualize performance, reinforce the long-term strategy, and invite a conversation — without making any specific promises about future returns.

Client: [CLIENT NAME]
Quarter: [Q1/Q2/Q3/Q4 YEAR]
Portfolio value: [CURRENT VALUE]
Performance this quarter: [RETURN %] vs. [BENCHMARK] return of [BENCHMARK %]
YTD performance: [YTD RETURN %]
Key market events this quarter: [2-3 NOTABLE MARKET EVENTS]
Portfolio changes made this quarter: [ANY REBALANCING, ADDITIONS, OR CHANGES — or "none"]
Upcoming action items: [ANYTHING CLIENT NEEDS TO DO OR DECIDE]

The email should:
1. Open with a brief market context (2-3 sentences — what happened this quarter)
2. Share their portfolio's performance in the context of their goals, not just the benchmark
3. Briefly explain any changes made and why
4. Reinforce the long-term strategy
5. Invite a call or meeting if they have questions
6. Include a placeholder for required performance disclosures

Length: 4-5 paragraphs. Tone: Confident, informative, relationship-focused.

Do NOT lead with raw performance numbers — lead with context and goals first.
Do NOT make any forward-looking performance guarantees.
```

---

**Prompt 5: Market Volatility Check-In Email**

*When to use: When markets drop significantly and clients may be anxious — proactive outreach*

```
Write a proactive client email during a period of market volatility. This email should be sent BEFORE clients call worried — it should be reassuring, specific, and grounded in their personal plan.

Client: [CLIENT NAME OR "All clients in my [SEGMENT] segment"]
Market situation: [DESCRIBE — e.g., "S&P 500 down [X]% over the past [TIMEFRAME]", "bond markets experiencing significant rate volatility"]
Specific concern for this client: [WHAT MAKES THIS CLIENT PARTICULARLY VULNERABLE TO WORRY — e.g., "she's 18 months from retirement", "he tends to track markets daily and called during the last correction"]
Their portfolio allocation: [BRIEF DESCRIPTION — e.g., "60/40 portfolio", "conservative allocation with 3 years of cash equivalents for income needs"]
Their financial plan status: [HOW WELL-POSITIONED THEY ARE — e.g., "on track for retirement at 65 even in a continued downturn scenario"]
Action being taken (if any): [REBALANCING / NOTHING REQUIRED / TAX-LOSS HARVESTING OPPORTUNITY]

The email should:
1. Acknowledge what's happening in markets (honest, not dismissive)
2. Connect the volatility to THEIR specific plan (not generic "stay the course" platitudes)
3. Explain what you're watching and what, if anything, you're doing
4. Reinforce why their plan was built for exactly this kind of environment
5. Offer a call for anyone who wants to talk through it
6. Keep it under 300 words — anxious clients don't read long emails

Do NOT use phrases like "Don't panic" — that makes people more anxious, not less.
Do NOT minimize the volatility — acknowledge it honestly before pivoting to context.
```

---

**Prompt 6: Life Event Acknowledgment Email**

*When to use: A client experiences a major life event — marriage, divorce, birth, death, job change, inheritance*

```
Write an empathetic, professional email to a client acknowledging a major life event and opening a conversation about any financial planning implications.

Client: [CLIENT NAME]
Life event: [EVENT — e.g., "recently widowed", "just sold their business for $2.3M", "getting divorced", "had their first child", "recently diagnosed with serious illness", "received a large inheritance"]
Emotional context: [HOW THEY MIGHT BE FEELING — is this joyful, painful, stressful, complicated?]
Financial implications to address: [WHAT NEEDS TO HAPPEN FINANCIALLY — e.g., beneficiary updates, estate documents, tax planning, cash flow planning, insurance review]
Urgency: [IMMEDIATE ACTION NEEDED / CAN WAIT FOR NEXT MEETING / JUST CHECKING IN]

The email should:
1. Acknowledge the event with genuine warmth — this is human first, financial second
2. Not immediately pivot to finances (let them breathe first)
3. Gently note that there may be some planning items worth discussing when the time is right
4. Offer to meet, call, or just be a resource
5. Be appropriately brief — this isn't the time for a financial lecture

For painful events: Empathy comes before everything else. Mention finances only lightly.
For joyful events: Celebrate first, then offer to ensure the planning matches the new chapter.
```

---

**Prompt 7: Annual Review Meeting Invitation**

*When to use: Scheduling annual comprehensive planning reviews*

```
Write an email inviting a client to their annual financial review meeting.

Client: [CLIENT NAME]
How long they've been a client: [X YEARS]
Key things to cover in this review: [3-4 AGENDA ITEMS — e.g., "reviewing your retirement income projection", "updating beneficiaries following your daughter's birth", "discussing Roth conversion strategy ahead of your retirement"]
Proposed meeting dates: [DATE OPTIONS]
Meeting format: [IN-PERSON / VIDEO]
Time needed: [DURATION — typically 60-90 minutes]
Any actions for them before the meeting: [BRING DOCUMENTS / NOTHING NEEDED]

Write an email that:
1. Frames the annual review as a genuine value event, not a check-in obligation
2. Briefly teases the specific topics you'll cover (makes them feel seen, not generic)
3. Offers concrete next steps to schedule
4. Feels personalized to someone you've worked with for [X YEARS]

Make it easy for them to say yes to a meeting. Length: 3 paragraphs.
```

---

**Prompt 8: Annual Review Meeting Agenda and Summary Prep**

*When to use: Preparing talking points and an agenda before a client's annual review*

```
Create a comprehensive annual review meeting agenda and advisor talking points for the following client.

Client: [CLIENT NAME(S)]
Ages: [AGES]
Years as client: [YEARS]
Current portfolio value: [VALUE]
Current portfolio allocation: [ALLOCATION]
Last year's return: [RETURN %]
Primary financial goals: [GOALS]
Current financial plan status: [ON TRACK / BEHIND / AHEAD — with specifics]
Major life changes in the past year: [ANY CHANGES — job, family, health, estate]
Open planning items from last meeting: [ANY ITEMS LEFT FROM PRIOR MEETING]
Items I want to raise this meeting: [YOUR AGENDA ITEMS]

Produce:
1. A meeting agenda (7-10 items) with time allocation
2. Talking points for each agenda item (2-4 bullets per item)
3. Questions to ask the client to uncover new planning needs
4. Any action items to have ready before the meeting
5. A "what I want them to leave feeling" goal statement

Format as a clean advisor prep document I can print and bring to the meeting.
```

---

**Prompt 9: Client Birthday / Milestone Note**

*When to use: Celebrating client birthdays, anniversaries, or significant milestones*

```
Write a brief, genuine personal note to a client for [OCCASION: birthday / work anniversary / retirement milestone / 10-year client anniversary].

Client name: [NAME]
Occasion: [DESCRIBE THE OCCASION]
Personal detail to reference: [SOMETHING YOU KNOW ABOUT THEM — a hobby, family member, achievement, or shared memory]
Financial milestone (if relevant): [E.G., "You officially crossed $1M in your retirement accounts this month"]
My name: [YOUR NAME]

This note should feel like it came from a human who genuinely knows and cares about this person — not a CRM auto-send. Under 150 words. Warm, specific, and brief.

Do NOT include any sales pitch, upsell, or financial advice in a personal milestone note.
```

---

**Prompt 10: Required Minimum Distribution (RMD) Reminder**

*When to use: Alerting clients approaching or past RMD age about required distributions*

```
Write a clear, helpful email reminding a client about their Required Minimum Distribution obligation.

Client: [CLIENT NAME]
Age: [AGE]
First RMD year or ongoing: [FIRST YEAR / ONGOING]
RMD accounts: [IRA / 401(k) / INHERITED IRA — describe]
Estimated RMD amount for this year: [$AMOUNT]
Deadline: [DATE — typically December 31]
Distribution options: [HOW THEY'VE ELECTED TO RECEIVE IT — check, reinvest in taxable, direct to charity via QCD, etc.]
Tax implications: [BRIEF NOTE — e.g., "this will add approximately $X to your taxable income this year"]
Action needed from client: [WHAT THEY NEED TO DO — confirm, nothing, fill out form]

Write an email that:
1. Clearly states what an RMD is (briefly — even if they know)
2. Gives their specific numbers
3. Explains the tax implication in plain language
4. States clearly what action, if any, they need to take
5. Offers to answer questions

Note: Add standard disclaimer that this is not tax advice and to consult a CPA.
```

---

## DIFFICULT CONVERSATIONS

---

**Prompt 11: Bad Performance Quarter — Proactive Communication**

*When to use: After a difficult quarter when client portfolios underperformed expectations*

```
Write a proactive email to a client after a period of portfolio underperformance, before they call to complain.

Client: [CLIENT NAME]
Portfolio performance: [RETURN %] vs [BENCHMARK RETURN %]
Time period: [QUARTER / YTD / TRAILING 12 MONTHS]
Why the underperformance happened: [HONEST EXPLANATION — e.g., "overweight value stocks vs. growth", "international allocation lagged domestic", "bond duration hurt as rates rose"]
Is the strategy still sound: [YES — WITH EXPLANATION / WE'RE MAKING ADJUSTMENTS]
Adjustments being made (if any): [DESCRIBE OR "none at this time"]
Their plan status despite performance: [HOW DOES THIS AFFECT THEIR LONG-TERM PLAN]

The email should:
1. Be direct — don't bury the underperformance
2. Explain why it happened in plain language (not excuses, but honest context)
3. Address whether the strategy is still appropriate for their goals
4. Tell them if anything is changing and why
5. Invite a conversation
6. Not be defensive or make promises about recovery

Tone: Honest, accountable, calm. Length: 4-5 paragraphs.
```

---

**Prompt 12: Client Wants to Make an Emotional Investment Decision**

*When to use: A client wants to sell everything, chase a hot stock, or make a fear-driven change*

```
Write a client email responding to a request to make an emotionally-driven financial decision that may not be in their best interest.

Client: [CLIENT NAME]
What they want to do: [DESCRIBE THE REQUEST — e.g., "sell everything and go to cash", "put $50K into [SPECIFIC MEME STOCK]", "take a large early withdrawal from their IRA"]
Why they want to do it: [THEIR STATED REASON — fear, FOMO, family pressure, etc.]
Why this concerns me: [YOUR PROFESSIONAL CONCERN]
The actual impact on their plan: [WHAT HAPPENS IF THEY DO THIS — in numbers or outcomes]
What I'm recommending instead: [YOUR ALTERNATIVE RECOMMENDATION]

Write an email that:
1. Acknowledges their concern without dismissing it
2. Gives them the professional context they need (specific impact, not generic warnings)
3. Offers an alternative that addresses their underlying concern
4. Ultimately respects that it's their money — doesn't lecture
5. Requests a call before any action is taken

Tone: Empathetic but professional. You're their advisor, not their parent. Don't be preachy.
```

---

**Prompt 13: Fee Increase Notification Letter**

*When to use: Notifying clients of an advisory fee change*

```
Write a professional, transparent letter notifying a client of a change in advisory fees.

Client: [CLIENT NAME]
Current fee structure: [DESCRIBE CURRENT FEES — e.g., "0.85% annually on assets under management"]
New fee structure: [NEW FEE — e.g., "1.00% annually"]
Effective date: [DATE]
Reason for the change: [HONEST EXPLANATION — e.g., "expanded services including financial planning, tax coordination, and estate planning review"]
What's new or improved: [LIST WHAT THEY'RE GETTING FOR THE HIGHER FEE]
Dollar impact: [E.G., "On a $500K portfolio, this represents approximately $750 more per year"]
Grandfather clause or timing: [ANY GRACE PERIOD OR PHASE-IN]
How to ask questions: [CONTACT METHOD]

Write a letter that:
1. Is direct — state the change early, don't bury it
2. Explains the value being added (don't just justify the increase, show the value)
3. Is transparent about the dollar impact
4. Gives them time and an easy way to ask questions or discuss
5. Expresses your commitment to their financial success

Do NOT be defensive. Confident advisors communicate fee changes confidently.
```

---

**Prompt 14: Client Who Is Not Engaging / Going Dark**

*When to use: A client has stopped responding to calls and emails — re-engagement outreach*

```
Write a re-engagement email to a client who has become unresponsive over the past [TIMEFRAME].

Client: [CLIENT NAME]
How long they've been unresponsive: [TIMEFRAME — e.g., "3 months"]
Last meaningful interaction: [WHAT WAS DISCUSSED / DECIDED]
Account value: [$AMOUNT]
Anything notable about their accounts: [ANY CHANGES, CONCERNS, OR OPPORTUNITIES THEY'RE MISSING]
Possible reasons for disengagement: [IF KNOWN — life event, dissatisfaction, busy period]
My goal for this email: [RE-ENGAGE AND SCHEDULE A MEETING / ENSURE NOTHING IS WRONG / FIND OUT IF THEY WANT TO CONTINUE]

Write a brief, warm email that:
1. Acknowledges the time that's passed without being accusatory
2. Gives them a reason to respond (something specific about their account or plan)
3. Asks a low-friction question — not a meeting request immediately
4. Leaves the door open without pressure
5. Is short — 2-3 paragraphs max

Do NOT send a guilt trip. Do NOT start with "I've been trying to reach you."
```

---

**Prompt 15: Responding to a Client Complaint**

*When to use: A client has raised a formal or informal complaint about service, fees, or performance*

```
Write a professional, empathetic response to a client complaint.

Client: [CLIENT NAME]
Their complaint: [DESCRIBE THE COMPLAINT — specifically what they said and how they raised it]
Is the complaint valid: [YES — WE MADE AN ERROR / PARTIALLY VALID / NOT VALID — EXPLAIN]
What actually happened (factual account): [YOUR VERSION OF EVENTS]
What we're doing about it: [SPECIFIC RESOLUTION OR NEXT STEP]
Compensation or remediation offered (if any): [OR NONE]
Who is handling this: [YOU / COMPLIANCE / SENIOR ADVISOR]

Write a response that:
1. Thanks them for raising the issue (even if painful)
2. Acknowledges their frustration without admitting fault prematurely
3. States clearly what happened or what you're investigating
4. States specifically what you're doing to resolve it and by when
5. Invites a call if they want to discuss further
6. Maintains the relationship even if the complaint is not fully valid

Note: Flag this draft for compliance review before sending if the complaint could have regulatory implications.
```

---

## CLIENT EDUCATION & VALUE-ADD

---

**Prompt 16: Year-End Financial Planning Checklist Email**

*When to use: Sending a year-end action list to clients in Q4*

```
Write a helpful year-end financial planning checklist email for clients.

Client or segment: [INDIVIDUAL CLIENT NAME / "All clients" / "Pre-retiree clients"]
Key year-end items relevant to this client: [SELECT APPLICABLE — e.g., tax-loss harvesting, Roth conversion, RMD, 401(k) max contributions, HSA contribution, charitable giving, estate document review, FSA spend-down]
Their specific situation: [ANY INDIVIDUAL CLIENT CONTEXT — optional]
Deadline to act: [DATE — typically December 31 for most items]
What you'll handle vs. what they handle: [DIVIDE RESPONSIBILITIES CLEARLY]

Write an email that:
1. Creates appropriate urgency without panic
2. Lists each action item clearly with a brief explanation of why it matters
3. Distinguishes between things I'm handling vs. things they need to do
4. Keeps each item to 2-3 sentences max
5. Ends with a call to action (reply, call, or meeting)

Format: Short intro, numbered or bulleted list, brief close. Under 400 words.
```

---

**Prompt 17: Tax Season Coordination Email**

*When to use: Coordinating with clients during tax preparation season*

```
Write an email to a client coordinating financial planning inputs during tax season.

Client: [CLIENT NAME]
CPA or tax preparer: [NAME / "their own accountant"]
Documents being sent to their CPA: [LIST — 1099s, K-1s, year-end statements, cost basis reports]
Information I need from them or their CPA: [E.G., "confirm final AGI to assess Roth conversion opportunity", "let me know if any large capital gains are expected from other sources"]
Planning opportunities to flag: [E.G., Roth conversion, backdoor Roth, bunching deductions, QCD strategy]
Timeline: [WHEN TAX DOCUMENTS ARRIVE / FILING DEADLINE]

Write a brief, organized email that:
1. Tells them what documents are being sent and when
2. Asks for any specific information needed
3. Mentions any planning opportunities worth discussing before filing
4. Coordinates the handoff between me and their tax preparer
5. Keeps accounting/tax decisions clearly in the CPA's lane

Add standard note: This is not tax advice; all tax decisions should be made with their CPA.
```

---

**Prompt 18: Social Security Claiming Strategy Summary**

*When to use: Summarizing a client's Social Security claiming options and your recommendation*

```
Write a clear client summary of Social Security claiming strategy options.

Client: [CLIENT NAME(S)]
Current age(s): [AGES]
Eligible SS benefit at 62: [$AMOUNT/month] for [NAME]
Full retirement age benefit: [$AMOUNT/month at age 67 for NAME]
Delayed benefit at 70: [$AMOUNT/month]
Spouse benefit (if applicable): [DESCRIBE SPOUSE'S SITUATION]
Health considerations: [E.G., "both in good health with family history of longevity" / "primary earner has health concerns"]
Other income sources in retirement: [PENSION / RENTAL INCOME / PART-TIME WORK / OTHER]
My recommendation: [WHAT YOU'RE RECOMMENDING AND WHY]

Write a summary that:
1. Explains the claiming options in plain English (not actuarial tables)
2. Shows the key trade-offs in dollars (break-even analysis if relevant)
3. Addresses the key considerations for their specific situation
4. States your recommendation clearly with rationale
5. Notes what you need from them to finalize (or if it's already decided)

Format: 2-3 paragraphs + a simple comparison table. Under 400 words.
```

---

**Prompt 19: Medicare Transition Planning Email**

*When to use: Client is approaching age 65 and needs to navigate Medicare enrollment*

```
Write an educational email to a client approaching Medicare eligibility.

Client: [CLIENT NAME]
Current age / months to age 65: [CURRENT AGE / TIMELINE]
Current health insurance: [COBRA / EMPLOYER / ACA MARKETPLACE / SPOUSE'S PLAN]
Working past 65: [YES — CONTINUING EMPLOYER COVERAGE / NO — NEEDS MEDICARE AT 65]
Spouse situation: [DESCRIBE IF RELEVANT]
Medicare enrollment window: [INITIAL ENROLLMENT PERIOD DATES]
Key decisions they need to make: [ORIGINAL MEDICARE + MEDIGAP / MEDICARE ADVANTAGE — summarize tradeoff briefly]
Referral to insurance specialist: [YES / WILL HANDLE IN-HOUSE]

Write an email that:
1. Gives them a clear timeline for when to act
2. Explains Original Medicare vs. Medicare Advantage in simple terms (2-3 sentences each)
3. Flags the enrollment windows and penalties for missing them
4. Explains how Medicare interacts with any employer coverage
5. Offers a meeting to work through the decision together
6. Notes that you'll refer them to a Medicare specialist for the specific plan selection

Keep it under 500 words. This is an introduction, not a comprehensive guide.
```

---

**Prompt 20: Estate Plan Review Prompt Letter**

*When to use: Recommending a client review and update their estate documents*

```
Write a letter recommending that a client review and update their estate planning documents.

Client: [CLIENT NAME]
How long since their last estate plan review: [TIMEFRAME / "Unknown — we've never discussed it"]
Triggering event (if any): [LIFE EVENT — e.g., birth of grandchild, marriage, new assets, change in state residency, recent illness in family]
Key issues I suspect: [OUTDATED BENEFICIARIES / OLD TRUST DOCUMENTS / NO PLAN AT ALL / ASSETS OUTSIDE ESTATE PLAN]
Estate attorney referral: [DO YOU HAVE A REFERRAL READY? NAME IF YES]
Urgency level: [ROUTINE / SHOULD ADDRESS WITHIN 6 MONTHS / URGENT]

Write a letter that:
1. Explains why estate plan reviews matter in non-scary, non-morbid terms
2. References their specific situation without being alarmist
3. Lists 3-4 concrete things that may need updating
4. Recommends a meeting to review what we know
5. If referring to an attorney, makes that feel like a coordinated service, not a pass-off

Tone: Caring and practical. Estate planning is self-care, not death planning.
```

---

**Prompt 21: Beneficiary Update Reminder**

*When to use: Prompting a client to review and update beneficiary designations*

```
Write a brief email reminding a client to review their beneficiary designations on retirement accounts and insurance policies.

Client: [CLIENT NAME]
Accounts with beneficiaries on file: [LIST — IRA, 401(k), life insurance, etc.]
Last beneficiary review date: [DATE / "Not on record"]
Reason for prompt: [ROUTINE ANNUAL REVIEW / LIFE EVENT — specify]
Any known outdated designations: [E.G., "Ex-spouse still listed on IRA from 2011" — if known]
How to update: [STEPS OR OFFER TO HANDLE IT]

Write a short, direct email (under 200 words) that makes beneficiary updates feel straightforward and important — not bureaucratic. Include a simple reminder of why this matters with a specific real-world example.
```

---

**Prompt 22: Post-Meeting Summary Email**

*When to use: Sending a summary of decisions made and next steps after any client meeting*

```
Write a post-meeting summary email following a client review or planning meeting.

Client: [CLIENT NAME]
Meeting date: [DATE]
Topics discussed: [LIST KEY TOPICS]
Decisions made: [LIST ANY DECISIONS — e.g., "agreed to increase 401(k) contribution to max", "decided to delay Roth conversion until next year", "approved rebalancing to target allocation"]
My action items: [WHAT I'M DOING AFTER THE MEETING — with deadlines]
Client action items: [WHAT THEY NEED TO DO — with deadlines]
Next meeting: [DATE OR "TBD"]
Any open items to resolve: [ANYTHING LEFT UNDECIDED]

Write a clear, organized follow-up email that:
1. Thanks them for their time
2. Summarizes key decisions concisely
3. Lists my action items and their action items clearly (bullet list format)
4. Confirms the next touchpoint
5. Invites questions

This email serves as the written record of the meeting. Keep it clear and specific — not conversational.
```

---

**Prompt 23: Referral Thank You Email**

*When to use: Thanking a client after they refer someone to you*

```
Write a sincere thank you email to a client who referred a prospect to you.

Client who referred: [CLIENT NAME]
Referred prospect: [FIRST NAME ONLY / JUST "your friend" if preferred]
Context of referral: [HOW THE REFERRAL CAME UP — e.g., "mentioned us at your golf league", "gave our name to your colleague who's retiring", "sent us a direct introduction"]
Status of the referral: [MEETING SCHEDULED / IN PROGRESS / JUST INTRODUCED]
Anything personal to mention: [ANY SHARED CONTEXT WITH THE CLIENT]

Write a genuine thank you note that:
1. Expresses authentic appreciation (not scripted)
2. Acknowledges that their trust means everything to the practice
3. Commits to taking great care of the person they referred
4. Keeps it brief — under 150 words
5. Does NOT ask for another referral in the thank you

This note should feel like it came from a human, not a referral-tracking system.
```

---

**Prompt 24: Client Newsletter — Market Commentary Section**

*When to use: Writing the market commentary section of a client newsletter or update*

```
Write a market commentary section for a client newsletter covering [MONTH/QUARTER YEAR].

Key market events this period: [LIST 3-5 MAJOR EVENTS — e.g., Fed rate decision, earnings season results, geopolitical developments, economic data releases]
S&P 500 performance: [RETURN]
Bond market performance: [GENERAL DIRECTION AND CONTEXT]
What this means for our clients: [YOUR INTERPRETATION FOR TYPICAL CLIENT PORTFOLIO]
Key theme or takeaway message: [THE MAIN POINT YOU WANT CLIENTS TO UNDERSTAND]
Tone: [CALM / CAUTIOUS / REASSURING / OBJECTIVE]

Write a 3-4 paragraph market commentary that:
1. Summarizes what happened without overwhelming clients with data
2. Provides context and your professional interpretation
3. Connects back to long-term principles (stay diversified, don't react emotionally, etc.)
4. Ends with a forward-looking statement that's honest about uncertainty

Add standard disclaimer: Past performance does not guarantee future results. This is not investment advice.

Do NOT make any specific predictions about future market direction.
```

---

**Prompt 25: Client "Happy Path" Progress Email**

*When to use: Sharing genuinely positive news about a client's financial progress*

```
Write an email sharing good news about a client's financial progress milestone.

Client: [CLIENT NAME]
Milestone reached: [DESCRIBE — e.g., "hit $1M in retirement savings", "fully funded college savings for both kids 3 years early", "officially debt-free", "on track for retirement 2 years earlier than originally projected"]
Context of why this is meaningful: [WHAT THEY SACRIFICED OR WORKED HARD FOR TO GET HERE]
What it means for their plan going forward: [ANY CHANGES TO THE PLAN OR STRATEGY]
Celebratory tone: [WARM / PROFESSIONAL / UNDERSTATED]

Write an email that celebrates this moment genuinely. Under 200 words. Make them feel good about the work they've done — not just the number. This is their victory.

Do NOT turn this into a sales opportunity. Just celebrate.
```

---

*Next: `03-financial-planning-prompts.md` → 22 prompts for retirement plans, goal analysis, and planning documents*
