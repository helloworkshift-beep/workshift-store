# 07 — Cheat Sheet

*Top 15 power prompts + 10 Golden Rules for financial advisors using AI*

---

## Top 15 Power Prompts (Copy-Ready)

---

**#1 — Instant Quarterly Review Email**
```
Write a quarterly portfolio review email for [CLIENT NAME]. Their portfolio is worth [$VALUE], returned [X%] this quarter vs. the [BENCHMARK] return of [Y%]. Key market events: [3 EVENTS]. Portfolio changes this quarter: [CHANGES OR "NONE"]. Their primary goal is [GOAL]. Tone: confident, relationship-focused, non-alarmist. 4-5 paragraphs. End with an invitation to connect.
```

**#2 — Market Volatility Proactive Email**
```
Write a brief proactive email to [CLIENT NAME] during current market volatility. Market is [DOWN X% / CONTEXT]. Their portfolio is [ALLOCATION]. Their plan status is [ON TRACK / CONTEXT]. I am [TAKING THIS ACTION / NOT MAKING CHANGES BECAUSE REASON]. Under 300 words. Acknowledge the drop, provide context, explain our position, invite a call. Do NOT say "don't panic."
```

**#3 — Post-Meeting Summary**
```
Write a post-meeting follow-up email for [CLIENT NAME] after our meeting on [DATE]. We discussed: [TOPICS]. Decisions made: [LIST]. My action items: [LIST WITH DEADLINES]. Their action items: [LIST OR "NONE"]. Next meeting: [DATE OR "TBD"]. Clear, concise, organized format.
```

**#4 — Referral Thank You**
```
Write a genuine thank-you note to [CLIENT NAME] for referring [FIRST NAME OF REFERRAL]. We've worked together for [X YEARS]. Keep it under 150 words. Warm, specific, no sales pitch, no immediate ask for another referral. 
```

**#5 — Retirement Gap Analysis**
```
Write a retirement gap analysis for [CLIENT NAME(S)], ages [AGES], retiring at [AGE]. Current savings: [$AMOUNT]. Monthly income target: [$AMOUNT]. Current projection: [$AMOUNT/month from portfolio]. SS: [$AMOUNT/month]. Gap: [$AMOUNT/month]. Available levers: [SAVE MORE / WORK LONGER / SPEND LESS]. Make it honest, constructive, and include a specific action path.
```

**#6 — Life Event Check-In**
```
Write an empathetic, professional email to [CLIENT NAME] acknowledging they [RECENTLY WIDOWED / GETTING DIVORCED / RECEIVED A LARGE INHERITANCE / OTHER LIFE EVENT]. Acknowledge the event warmly — don't jump to finances immediately. Gently note there may be planning items when the time is right. Offer to be a resource. Under 200 words.
```

**#7 — Roth Conversion Analysis Summary**
```
Summarize a Roth conversion analysis for [CLIENT NAME], age [AGE], retiring at [AGE]. Current IRA: [$AMOUNT]. Current marginal rate: [X%]. Expected retirement rate: [Y%]. Estimated RMD at 73: [$AMOUNT/year]. Conversion amount considered: [$AMOUNT]. Funds to pay tax: [AVAILABLE / NOT]. Should they convert? If so, full or partial? When? Show the break-even math. Recommend consulting CPA.
```

**#8 — Year-End Tax Planning Email**
```
Write a year-end financial planning checklist email for [CLIENT NAME / SEGMENT]. Key year-end items for them: [LIST — RMD, Roth conversion, tax-loss harvesting, 401k max, HSA, charitable giving, FSA]. Deadline: December 31. Format: short intro, numbered list with 2-sentence explanation per item, action steps. Under 400 words.
```

**#9 — Beneficiary Update Reminder**
```
Write a brief email reminding [CLIENT NAME] to review beneficiary designations on their [IRA / 401K / LIFE INSURANCE — list]. Last reviewed: [DATE / "not on record"]. Reason: [LIFE EVENT / ROUTINE]. Include one specific real-world example of why this matters (e.g., ex-spouse or old designation). Under 200 words. Make it feel important, not bureaucratic.
```

**#10 — New Client Welcome Letter**
```
Write a welcome letter to new client(s) [NAME(S)]. They are [TYPE — couple / individual / retiree]. Primary goals discussed: [LIST]. Next steps: [STEPS WITH DATES]. My name and firm: [NAME / FIRM]. Warm, professional, organized. 3-4 short paragraphs. Make them feel confident they made the right choice.
```

**#11 — Fee Increase Notification**
```
Write a transparent fee increase letter to [CLIENT NAME]. Current fee: [X%]. New fee: [Y%]. Effective: [DATE]. Reason: [EXPANDED SERVICES — list]. Dollar impact: [AMOUNT/YEAR on their $X portfolio]. New or improved services: [LIST]. Direct, transparent, confident. 3-4 paragraphs. Include easy way to ask questions.
```

**#12 — Emotional Investment Decision Response**
```
Write a response email to [CLIENT NAME] who wants to [SELL EVERYTHING / BUY SPECULATIVE STOCK / TAKE EARLY WITHDRAWAL]. Their reason: [THEIR RATIONALE]. Impact on their plan: [SPECIFIC DOLLARS / OUTCOME]. My recommendation: [ALTERNATIVE]. Acknowledge their concern without dismissing it. Give professional context. Request a call before action. Not preachy.
```

**#13 — Social Security Claiming Summary**
```
Write a Social Security claiming strategy summary for [CLIENT NAME(S)], ages [AGES]. SS benefits: [$X at 62 / $Y at 67 / $Z at 70] for [NAME]. Spouse benefit: [DESCRIBE OR N/A]. Health: [CONTEXT]. My recommendation: [WHAT AND WHY]. Show the break-even math. 2-3 paragraphs + simple comparison table. Under 400 words.
```

**#14 — LinkedIn Educational Post**
```
Write a LinkedIn post on [TOPIC]. Target audience: [WHO]. Key insight: [MAIN TAKEAWAY]. Tone: [CONVERSATIONAL / PROFESSIONAL]. Call to action: [DM / COMMENT / LINK]. 150-250 words. Short paragraphs. Hook opening (NOT "As a financial advisor..."). End with non-pushy CTA. 2-3 hashtags.
```

**#15 — Annual Value Recap Email**
```
Write an end-of-year value recap email for [CLIENT NAME]. Planning accomplishments this year: [LIST 4-6 SPECIFIC ITEMS]. Financial progress: [NET WORTH / SAVINGS / GOALS ADVANCED]. Things we navigated: [MARKET EVENTS / LIFE EVENTS]. New year priorities: [2-3 ITEMS]. Genuine, specific, not a brag. 3-4 paragraphs.
```

---

## 10 Golden Rules for Financial Advisors Using AI

---

**Rule 1: AI drafts. You sign.**
Every piece of client communication that leaves your desk bears your name and your professional reputation. Read everything. Edit everything. Own it.

**Rule 2: Be specific about client context.**
"My retired client" gives AI nothing. "[CLIENT NAME], age 67, $1.2M portfolio, 60/40 allocation, worried about sequence of returns risk in early retirement" gives AI everything it needs. Specificity is the multiplier.

**Rule 3: Compliance check every client-facing output.**
AI doesn't know your firm's approved language, FINRA rules, or your state's requirements. Build a compliance review step into your workflow for any external communication.

**Rule 4: Never use AI for tax or legal advice.**
AI will happily write tax advice and estate planning specifics. Your job is to add the right disclaimers and refer to the right professionals. AI doesn't know your client's specific tax situation.

**Rule 5: Use it most for the writing, least for the judgment.**
AI excels at producing a first draft in seconds. It is not good at knowing whether this is the right time to ask for a referral, whether a client needs to hear hard truth gently or directly, or whether the relationship is ready for a fee increase conversation. Keep judgment in-house.

**Rule 6: Feed it the numbers, not just the descriptions.**
"Large portfolio" is vague. "$1.2M" is specific. "Approaching retirement" is vague. "Retiring in 28 months" is specific. AI math requires specific inputs.

**Rule 7: Generate multiple drafts for important communications.**
For any high-stakes client communication (bad news, fee change, emotional situation), generate 2-3 drafts with different tones and pick the best elements from each.

**Rule 8: Preserve your voice.**
After AI drafts, read it aloud. Does it sound like you? If not, edit until it does. Your long-term clients will notice if your emails suddenly sound different. Your voice is a relationship asset.

**Rule 9: Use the system prompt every session.**
Set your persona and context at the start of every AI session. Don't rely on the AI's generic financial understanding — give it your specialization, your client type, and your communication style.

**Rule 10: Measure what it saves you.**
Track how much time AI saves you each week. That time should go into higher-value activities: deeper client conversations, business development, continuing education. If it's just going to inbox zero, you're not extracting the full value.

---

## Quick Reference: Situation → Prompt File

| Situation | File | Prompt # |
|-----------|------|---------|
| Client worried about markets | Communication | #5 |
| Quarterly review email | Communication | #4 |
| Life event acknowledgment | Communication | #6 |
| Retirement planning status | Planning | #1, #2 |
| Roth conversion question | Planning | #11 |
| Beneficiary reminder | Communication | #21 |
| Market drop explanation | Investment | #1 |
| Portfolio rebalancing | Investment | #2 |
| Asking for a referral | Business Dev | #6 |
| Prospect follow-up | Business Dev | #1 |
| LinkedIn content | Business Dev | #9 |
| Year-end checklist | Communication | #16 |
| Annual review prep | Communication | #8 |
| Fee increase notification | Communication | #13 |

---

*Start here. Come back daily. The more you use it, the faster you get.*
