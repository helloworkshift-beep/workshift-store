# 05 — Business Development Prompts

*18 prompts for prospecting, referral cultivation, COI relationships, and practice marketing*

---

**Prompt 1: Prospect Follow-Up After Initial Meeting**

*When to use: Following up after a first meeting with a prospect*

```
Write a follow-up email to a prospect after our first meeting.

Prospect name: [NAME]
Meeting date: [DATE]
What we discussed: [KEY TOPICS — their situation, goals, concerns]
What they seemed most interested in: [AREA OF INTEREST]
Any concerns or hesitations they expressed: [IF ANY]
What I offered to do next: [ANALYSIS / PROPOSAL / FOLLOW-UP CALL]
Next step proposed: [SPECIFIC — e.g., "send a sample financial plan", "schedule a second meeting", "provide a fee quote"]
Their timeline (if known): [WHEN THEY WANT TO MAKE A DECISION]

Write a follow-up email that:
1. Thanks them for their time (briefly — not sycophantically)
2. Demonstrates you listened by referencing a specific detail from the conversation
3. Delivers the promised next step or sets a timeline for it
4. Moves toward a concrete next action without being pushy
5. Is warm and professional — you're building a relationship, not closing a sale
6. Leaves the door open without pressure

Length: 3-4 short paragraphs. Do NOT attach a dense proposal in the first follow-up.
```

---

**Prompt 2: Prospect Financial Assessment Letter**

*When to use: After a discovery meeting, sending a preliminary financial assessment to a prospect*

```
Write a preliminary financial assessment summary for a prospect.

Prospect: [NAME]
Their situation (as you understand it): [FINANCIAL SITUATION SUMMARY]
Primary goals: [THEIR STATED GOALS]
Key gaps or issues identified: [WHAT YOU NOTICED THAT NEEDS ATTENTION]
How you could help: [SPECIFIC WAYS YOUR PRACTICE ADDRESSES THEIR SITUATION]
Proposed approach: [WHAT WORKING WITH YOU WOULD LOOK LIKE]
Fee structure: [YOUR FEES — briefly]
Next step: [WHAT YOU'RE PROPOSING]

Write a 1-2 page assessment that:
1. Summarizes their situation as you understand it (shows you listened)
2. Identifies 3-5 specific planning gaps or opportunities
3. Briefly explains how you would address each one
4. Describes the process of working together (discovery → plan → implementation → ongoing)
5. States your fee structure honestly
6. Asks for a decision on next steps

This is your most important business development document. It should show expertise without overwhelming. Make them think "this advisor understands my situation."
```

---

**Prompt 3: LinkedIn Connection Request Message**

*When to use: Connecting with a prospect or COI on LinkedIn*

```
Write a LinkedIn connection request message.

Target: [NAME and TITLE / ROLE]
How I know them or found them: [MUTUAL CONNECTION / EVENT / THEIR CONTENT / COLD]
Common ground: [SHARED INDUSTRY / GEOGRAPHY / PROFESSION / INTEREST]
Why I'm connecting: [MY GENUINE REASON — networking, potential referral relationship, interested in their work]

Write a connection request (under 300 characters — LinkedIn limit for connection messages) that:
- Feels personal, not templated
- States why I'm reaching out
- Does NOT pitch services immediately
- Invites a conversation or notes what I appreciate about their work

Also write a follow-up message to send after they accept (under 200 words) that moves toward a brief introduction call without being a hard sell.
```

---

**Prompt 4: COI Relationship Email — CPA**

*When to use: Building or maintaining a referral relationship with a CPA*

```
Write an introductory or relationship-building email to a CPA.

CPA name: [NAME] at [FIRM]
How I know them: [MUTUAL CLIENT / NETWORKING EVENT / REFERRAL FROM / COLD OUTREACH]
Mutual clients (if any): [DESCRIBE WITHOUT VIOLATING CONFIDENTIALITY — "we share several small business owner clients"]
What I offer CPAs in this relationship: [CO-PLANNING VALUE, TAX COORDINATION, REFERRAL RECIPROCITY]
Specific reason for reaching out: [TAX SEASON CO-PLANNING / SPECIFIC CLIENT OPPORTUNITY / INTRODUCTION]
What I'm proposing: [COFFEE / BRIEF CALL / JOIN NEWSLETTER / SPECIFIC PROPOSAL]

Write an email that:
1. Is brief — CPAs are busy, especially in tax season
2. Shows I understand their role and value their expertise
3. Makes a clear, low-friction ask
4. Positions me as a collaborative partner, not a sales person trying to poach their clients
5. Offers something of value (co-planning process, client coordination, educational content)

Length: 2-3 short paragraphs. CPA time is the scarcest resource in a referral relationship.
```

---

**Prompt 5: Estate Attorney Referral Partnership Email**

*When to use: Building a referral relationship with an estate planning attorney*

```
Write a relationship-building email to an estate planning attorney.

Attorney name: [NAME] at [FIRM]
How I know them: [HOW WE MET / CONNECTED]
What I bring to this relationship: [CLIENT REFERRALS, FINANCIAL PLANNING CONTEXT FOR ESTATE WORK, COORDINATION]
What I'm looking for: [ESTATE PLANNING REFERRALS FOR CLIENTS WITHOUT DOCUMENTS, COLLABORATIVE PLANNING]
Specific reason for reaching out: [I.E., MUTUAL CLIENT, NETWORKING EVENT, REFERRAL SOURCE RECOMMENDATION]
Ask: [COFFEE MEETING / PHONE CALL / JOIN MY NEWSLETTER]

Write a brief email that:
1. Establishes common ground or mutual connection
2. Describes my practice and the clients I work with (who I'd refer)
3. Shows genuine interest in their work and expertise
4. Proposes a specific low-pressure first step
5. Does NOT over-pitch — this is a relationship, not a transaction

Tone: Collegial and professional. These relationships are built over years.
```

---

**Prompt 6: Asking an Existing Client for a Referral**

*When to use: Requesting a referral from a satisfied client in a natural, non-awkward way*

```
Write an email asking a satisfied client for a referral.

Client name: [NAME]
How long they've been a client: [YEARS]
Something specific we've accomplished together: [A WIN — e.g., "we got you on track for retirement", "completed your estate plan", "navigated the market volatility together"]
Type of referral I'm looking for: [DESCRIBE IDEAL CLIENT — e.g., "business owners approaching retirement", "families with young kids who need planning", "colleagues at your company who have RSUs to plan around"]
What I'll do with the referral: [HOW I TREAT REFERRALS — initial conversation, no obligation, etc.]
Current capacity: [AM I TAKING NEW CLIENTS?]

Write an email that:
1. Leads with acknowledgment of the relationship and what we've done together
2. Asks naturally — not awkwardly or desperately
3. Gives them a specific description of who might benefit (makes referrals easy)
4. Reassures them about how referrals are handled
5. Removes the pressure — "no obligation" for anyone they mention
6. Is brief — under 200 words

The ask should feel like a natural extension of the relationship, not a sales tactic.
```

---

**Prompt 7: Referral Introduction Email**

*When to use: Introducing a referred prospect to your practice*

```
Write an introduction email to a prospect referred by an existing client.

My name: [NAME], [FIRM]
Referred by: [CLIENT NAME — only with their permission]
Prospect name: [NAME]
What I know about them: [WHAT THE REFERRING CLIENT SHARED — briefly]
How I can help them: [BASED ON WHAT I KNOW]
What I'm proposing: [INTRODUCTORY CALL / MEETING — low commitment first step]
What the first meeting involves: [BRIEF DESCRIPTION — no-obligation conversation]

Write an email that:
1. Establishes the connection (referred by [name] who suggested I reach out)
2. Shows I've done a bit of homework — knows something about their situation
3. Describes what I do in 1-2 sentences (brief, specific, not generic)
4. Makes a clear, easy ask for a 20-30 minute introductory call
5. Removes pressure — no obligation, no pitch in the first meeting
6. Is brief and confident

Length: 3 short paragraphs max.
```

---

**Prompt 8: Seminar / Workshop Follow-Up Email**

*When to use: Following up with attendees after a prospect education event*

```
Write a follow-up email to attendees of a financial education seminar or workshop.

Event: [TITLE AND TOPIC — e.g., "Retirement Ready: Planning for Life After Work"]
Event date: [DATE]
Attendee: [NAME — or use "Dear [NAME]" placeholder for bulk customization]
Key topics covered: [3-4 MAIN POINTS FROM THE EVENT]
What they received: [HANDOUTS / SLIDES / OTHER RESOURCES]
What I'm offering next: [COMPLIMENTARY CONSULTATION / ADDITIONAL RESOURCE / INVITE TO NEXT EVENT]
Main ask: [SCHEDULE A BRIEF CALL / RESPOND WITH QUESTIONS]

Write a follow-up email that:
1. Thanks them for attending with genuine appreciation
2. Briefly summarizes the key takeaway (reminds them why it was worth their time)
3. Delivers any promised follow-up resources
4. Makes a warm, low-pressure offer for a next step
5. Does NOT immediately push for a financial planning engagement

Length: 3-4 short paragraphs. Send within 48 hours of the event.
```

---

**Prompt 9: Social Media / LinkedIn Post — Educational Content**

*When to use: Creating educational content to share on LinkedIn or social media*

```
Write a LinkedIn post on a financial planning topic.

Topic: [E.G., "5 mistakes people make when rolling over a 401(k)", "The one thing most people get wrong about Social Security", "Why market volatility is normal — and what to do about it"]
Key insight: [THE MAIN TAKEAWAY YOU WANT TO SHARE]
Target audience: [WHO THIS IS FOR — e.g., "pre-retirees in their 50s", "small business owners", "high earners in their 40s"]
Call to action: [WHAT YOU WANT READERS TO DO — DM me, comment, visit website, schedule a call]
My tone: [PROFESSIONAL / CONVERSATIONAL / EDUCATIONAL / MIX]

Write a LinkedIn post that:
1. Starts with a hook that stops the scroll (not "As a financial advisor...")
2. Delivers genuine value in 150-250 words
3. Uses short paragraphs and white space (LinkedIn reads differently than email)
4. Ends with a clear but non-pushy call to action
5. Sounds like a human expert, not a compliance document
6. Includes 2-3 relevant hashtags

Do NOT start with "I'm excited to share..." or "As a [TITLE]..." — those are instant scroll-past lines.
```

---

**Prompt 10: Client Appreciation Event Invitation**

*When to use: Inviting clients to an appreciation event or educational dinner*

```
Write an invitation email for a client appreciation event.

Event type: [DINNER / COCKTAIL RECEPTION / EDUCATIONAL WORKSHOP / SPORTS EVENT / WINERY TOUR / OTHER]
Event name: [TITLE]
Date and time: [DATE/TIME]
Location: [VENUE NAME AND ADDRESS]
What they'll experience: [BRIEF DESCRIPTION — wine tasting + retirement planning discussion, educational speaker + dinner, client networking, etc.]
Can they bring guests: [YES — how many / NO]
RSVP deadline: [DATE]
RSVP method: [EMAIL / PHONE / LINK]
Capacity: [LIMITED SEATS — creates appropriate urgency]
Host: [YOUR NAME AND FIRM]

Write an invitation that:
1. Creates genuine excitement about the event
2. Gives all the logistics clearly
3. Emphasizes the exclusive / appreciation angle without being over-the-top
4. Makes RSVP-ing easy
5. Has a warm, welcoming tone that reflects the relationship

Length: 3-4 paragraphs. Invitations should feel like invitations, not marketing emails.
```

---

**Prompt 11: Prospect Who Went Dark — Re-Engagement Email**

*When to use: A prospect went through discovery but stopped responding before becoming a client*

```
Write a re-engagement email to a prospect who has gone quiet.

Prospect name: [NAME]
Last interaction: [DATE AND WHAT WAS DISCUSSED]
Where they were in the process: [JUST MET / SENT PROPOSAL / COMPLETING PAPERWORK]
Why they may have gone quiet: [IF KNOWN — got busy, comparing advisors, life event, price concern]
What I want to achieve: [GET THEM ON A CALL / FIND OUT THEIR STATUS / CLOSE THE RELATIONSHIP GRACEFULLY]
Anything new I can offer: [NEW SERVICE, RELEVANT MARKET UPDATE, EVENT INVITATION]

Write an email that:
1. Is brief and genuine — no passive aggression or guilt
2. Gives them a reason to respond (new information or event, not just "checking in")
3. Acknowledges time has passed without making it awkward
4. Offers an easy out if they've decided not to move forward (this actually gets responses)
5. Doesn't pitch again — just reconnects

The goal is to get a response — yes, no, or maybe. All three are useful.
Length: 2-3 paragraphs.
```

---

**Prompt 12: Google / Yelp Review Request**

*When to use: Asking a satisfied client to leave a review*

```
Write an email asking a satisfied client to leave a review.

Client: [NAME]
Platform: [GOOGLE / LINKEDIN / YELP — or let them choose]
What we've accomplished together: [SPECIFIC ACHIEVEMENT OR VALUE DELIVERED]
Why reviews matter for my practice: [BRIEF — helps others in similar situations find me]
Link to review page: [URL PLACEHOLDER]
Time estimate: [2-3 MINUTES]

Write a brief, genuine email that:
1. Leads with the relationship and the milestone
2. Asks naturally without feeling transactional
3. Makes it easy with a direct link and time estimate
4. Doesn't over-explain or create pressure
5. Thanks them in advance

Note: Check compliance requirements for testimonials / reviews in your state and firm before requesting. Requirements vary by firm and have recently changed under SEC marketing rule updates.

Under 150 words.
```

---

**Prompt 13: Prospect Niche Market Introduction Letter**

*When to use: Cold outreach to a specific niche market (e.g., physicians, tech employees with RSUs, teachers near retirement)*

```
Write an introduction letter to a prospect in a specific professional niche.

Target niche: [PHYSICIANS / TECH EMPLOYEES WITH EQUITY COMP / TEACHERS/STATE EMPLOYEES / FEDERAL EMPLOYEES / AIRLINE PILOTS / OTHER]
What makes this niche unique financially: [SPECIFIC FINANCIAL COMPLEXITY FOR THIS GROUP]
My expertise with this niche: [HOW MANY CLIENTS IN THIS NICHE / WHAT YOU'VE HELPED THEM WITH]
Target prospect: [NAME / TITLE / PRACTICE / EMPLOYER if known]
How I found them: [PROFESSIONAL ASSOCIATION / REFERRAL / EVENT / LINKEDIN]
Specific financial issue most common in this niche: [THE PAIN POINT]
Call to action: [INTRODUCTORY CALL / EVENT INVITATION / RESOURCE DOWNLOAD]

Write an introduction letter that:
1. Demonstrates immediate relevance (you know their specific financial situation)
2. Shows proof of expertise in their specific situation (not generic)
3. Addresses one specific common financial pain point for this group
4. Makes a low-commitment ask
5. Sounds like it was written for them specifically, not merged from a template

Specialization is the clearest way to differentiate. This letter should make them think "this advisor gets my situation."
```

---

**Prompt 14: Podcast / Media Outreach Email**

*When to use: Reaching out to a podcast, local news outlet, or publication to be a guest or quoted expert*

```
Write a media outreach email pitching myself as a financial expert guest or source.

Target: [PODCAST NAME / PUBLICATION / JOURNALIST NAME]
Their audience: [DESCRIBE]
My expertise: [SPECIFIC AREAS AND CREDENTIALS]
Relevant topic I can speak to: [SPECIFIC TOPIC TIMELY AND RELEVANT TO THEIR AUDIENCE]
Why I'm a good fit: [2-3 REASONS — specific expertise, local angle, unique perspective]
Recent work or credibility: [PUBLICATIONS, SPEAKING, CREDENTIALS, CLIENT RESULTS IF SHAREABLE]
My ask: [GUEST SPOT / QUOTED EXPERT / CONTRIBUTED ARTICLE]

Write a media pitch email that:
1. Gets to the point immediately — what you're offering and why it's valuable for their audience
2. Shows you know their audience and format
3. Gives 2-3 specific topics with short descriptions
4. Is under 200 words — journalists and podcasters are busy
5. Includes clear contact and credentials

Do NOT send a long biography. Do NOT explain what financial advising is. Do NOT use "I'm passionate about helping people."
```

---

**Prompt 15: End-of-Year Client Value Recap Email**

*When to use: Sending an annual summary of the value delivered to each client*

```
Write an end-of-year value recap email for a client.

Client: [NAME]
Year: [YEAR]
Planning accomplishments this year: [LIST 4-6 SPECIFIC THINGS DONE — plans updated, tax strategies executed, insurance reviewed, estate documents, etc.]
Financial progress: [NET WORTH CHANGE / SAVINGS ACHIEVED / GOALS ADVANCED]
Things we navigated together: [MARKET VOLATILITY / LIFE EVENTS / MAJOR DECISIONS]
Upcoming items in the new year: [2-3 KEY THINGS PLANNED]
Gratitude note: [SOMETHING SPECIFIC ABOUT THE RELATIONSHIP]

Write an email that:
1. Summarizes the year's value in specific, concrete terms (not "we reviewed your portfolio")
2. Ties financial progress to what it means for their life goals
3. Expresses genuine appreciation for the relationship
4. Sets up the new year with a forward-looking note
5. Does NOT read like a sales pitch or performance brag

Length: 3-4 paragraphs. This email shows the fee was worth it.
```

---

**Prompt 16: Prospect Proposal — Comprehensive Financial Planning**

*When to use: Writing a formal proposal for a financial planning engagement*

```
Write a financial planning engagement proposal for a prospect.

Prospect: [NAME(S)]
Their situation: [BRIEF SUMMARY — ages, assets, goals, key concerns]
Services proposed: [COMPREHENSIVE FINANCIAL PLAN / INVESTMENT MANAGEMENT / ONGOING ADVISORY / COMBINATION]
Fee structure: [DESCRIBE — AUM %, flat fee, retainer, one-time planning fee]
Annual fee estimate: [$AMOUNT based on their situation]
What the engagement includes: [LIST DELIVERABLES — plan document, quarterly reviews, tax coordination, etc.]
What the first 90 days look like: [ONBOARDING PROCESS]
Why your firm: [2-3 SPECIFIC DIFFERENTIATORS]

Write a 2-page proposal that:
1. Starts with their situation and goals (not your firm's history)
2. Proposes a specific engagement and explains what they'll receive
3. Shows the fee clearly with a value justification
4. Describes the client experience in concrete terms
5. Includes a clear acceptance step
6. Feels personalized, not like a template

The best proposals win on empathy + clarity, not length.
```

---

**Prompt 17: Competitor Comparison Response**

*When to use: A prospect is comparing you to another advisor and asks you to differentiate*

```
Write a response to a prospect who is comparing my services to another advisory firm or robo-advisor.

Competitor type: [WIREHOUSE FIRM / INDEPENDENT RIA / ROBO-ADVISOR / BANK / INSURANCE-BASED ADVISOR]
What I know about the competitor: [BRIEFLY — their typical fees, services, approach]
My firm's approach: [DESCRIBE YOUR SERVICE MODEL]
Key differences: [WHAT YOU DO THAT THEY DON'T OR DO BETTER]
Prospect's specific concern: [PRICE / BREADTH OF SERVICE / PERSONAL ATTENTION / CREDENTIALS / OTHER]
My fee vs. theirs (if known): [COMPARISON]

Write a response that:
1. Is confident without being disparaging about the competitor
2. Focuses on what I offer rather than what they lack
3. Directly addresses the prospect's specific concern
4. Uses questions to understand what matters most to them (discovery, not pitch)
5. Helps them evaluate the right criteria for their decision

Tone: Confident, helpful, and collaborative. You're helping them make the right decision — not just win the business.
```

---

**Prompt 18: Practice Vision Statement and Bio**

*When to use: Writing or updating your professional biography for website, LinkedIn, or proposals*

```
Write a professional biography for a financial advisor.

Advisor name: [NAME], [CREDENTIALS — CFP, CFA, etc.]
Years of experience: [X YEARS]
Firm: [FIRM NAME]
Specialty or niche: [AREA OF FOCUS — e.g., retirement planning for pre-retirees, comprehensive planning for business owners, etc.]
Ideal client: [DESCRIBE THE PERSON YOU SERVE BEST]
What makes your approach different: [2-3 SPECIFIC DIFFERENTIATORS]
Education: [DEGREES / CERTIFICATIONS]
Personal background (optional): [HOMETOWN / FAMILY / HOBBY — humanizing details]
Community involvement: [IF RELEVANT]
Tone: [FORMAL / WARM AND PERSONAL / MIX]

Write a 200-word bio that:
1. Opens with who you help and how (not with where you went to school)
2. Communicates your philosophy or approach in one sentence
3. Lists credentials without leading with them
4. Includes one human detail that makes you memorable
5. Ends with a call to connect or learn more
6. Sounds like a real person, not a mutual fund prospectus

Also write a 50-word "elevator bio" for proposals and email signatures.
```

---

*Next: `06-workflow-sops.md` → 5 complete end-to-end workflow playbooks*
