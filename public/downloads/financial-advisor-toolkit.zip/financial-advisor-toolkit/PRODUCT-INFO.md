# PRODUCT INFO — The Financial Advisor's AI Prompt Toolkit

*Internal reference for sales, marketing, and distribution*

---

## Product Details

| Field | Value |
|-------|-------|
| **Product Name** | The Financial Advisor's AI Prompt Toolkit |
| **Price** | $67 |
| **Format** | 7 Markdown files (digital download) |
| **Total Prompts** | 90+ ready-to-use AI prompts |

---

## Sales Description (200 words)

Financial advisors spend too much of their week on documents that don't require their expertise — drafting client update emails, writing quarterly commentary, preparing meeting summaries, crafting prospecting messages. Meanwhile, the work that actually grows a practice — deepening client relationships, finding new clients, giving better advice — gets squeezed.

**The Financial Advisor's AI Prompt Toolkit** gives you 90+ professionally crafted AI prompts built specifically for financial advisory work. Not generic email templates — precise, context-rich prompts that produce client letters, financial plan summaries, investment commentary, prospect outreach, and meeting prep you can actually send.

Every prompt includes bracketed variables you fill in with real client data. Paste in context, get professional output in seconds. Then spend your time on what advisors are actually paid for: relationships and judgment.

This toolkit covers your full workflow: client communication, financial planning documents, investment analysis commentary, and business development. Five complete workflow SOPs walk you through your most time-intensive recurring tasks step-by-step.

**Stop writing when you should be advising. Start here.**

---

## Target Audience

**Primary:** Independent RIAs and IARs with 50–300 client households. Typically 3–15 years of experience. Manages $25M–$300M AUM. Responsible for all client communication, planning, and business development.

**Secondary:**
- Associate advisors building communication skills and client management systems
- Financial planners at broker-dealer firms with heavy documentation requirements
- CFPs running solo or small team practices
- Branch managers standardizing team communication templates

---

## All Included Files

| File | Description | Prompt Count |
|------|-------------|--------------|
| `01-quick-start-guide.md` | Setup guide, compliance tips, system prompts, how to use bracket variables | — |
| `02-client-communication-prompts.md` | Client emails, quarterly updates, meeting prep, hard conversation scripts, annual review letters | 25 prompts |
| `03-financial-planning-prompts.md` | Retirement income planning, goal-setting summaries, estate planning narratives, plan presentation scripts | 22 prompts |
| `04-investment-analysis-prompts.md` | Portfolio commentary, market volatility responses, rebalancing rationale, asset allocation explanations | 20 prompts |
| `05-business-development-prompts.md` | Prospect outreach, referral asks, COI relationship emails, event follow-ups, LinkedIn content | 18 prompts |
| `06-workflow-sops.md` | 5 SOPs: Quarterly review cycle, new client onboarding communication, market volatility response protocol, annual planning meeting prep, referral follow-up sequence | 5 SOPs |
| `07-cheat-sheet.md` | Top 15 power prompts + 10 Golden Rules for advisors using AI | 15 prompts |

**Total: 90+ prompts, 5 workflow SOPs**

---

*Last updated: March 2026*
