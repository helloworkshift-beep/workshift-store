# 03 — Financial Planning Prompts

*22 prompts for retirement planning, goal analysis, financial plan summaries, and life planning conversations*

---

**Prompt 1: Retirement Readiness Assessment Summary**

*When to use: Summarizing a client's retirement readiness after running plan projections*

```
Write a clear, client-friendly retirement readiness summary based on the following financial data.

Client: [CLIENT NAME(S)]
Ages: [AGES]
Target retirement age: [AGE]
Current savings: [BREAKDOWN — IRA $X, 401k $X, taxable $X]
Monthly savings rate: [$AMOUNT / MONTH or YEAR]
Estimated Social Security: [$AMOUNT/month at age [AGE]]
Pension (if any): [$AMOUNT/month]
Target retirement income needed: [$AMOUNT/month in today's dollars]
Current projection at target retirement age: [$PROJECTED PORTFOLIO VALUE]
Plan status: [ON TRACK / BEHIND BY X% / AHEAD OF SCHEDULE]
Key assumptions used: [RETURN RATE %, INFLATION %, RETIREMENT DURATION YEARS]

Write a 1-2 page summary that:
1. States clearly whether they're on track — don't bury the answer
2. Translates portfolio projections into monthly income terms (what can they spend?)
3. Identifies the top 2-3 factors most affecting their plan
4. If behind: gives specific, actionable levers to improve (savings rate, retirement age, spending)
5. Uses plain language — replace "Monte Carlo probability" with "in X out of 100 scenarios"
6. Ends with recommended next steps

Format: Use headers and short paragraphs. Avoid jargon. This document goes directly to the client.
```

---

**Prompt 2: Retirement Income Plan Summary**

*When to use: Documenting the income strategy for a client entering or near retirement*

```
Write a retirement income plan summary for a client transitioning into or near retirement.

Client: [CLIENT NAME(S)]
Retirement date: [ACTUAL OR TARGET DATE]
Monthly income needed: [$AMOUNT]
Income sources:
- Social Security: [$AMOUNT/month starting age X for NAME, $AMOUNT for NAME 2]
- Pension: [$AMOUNT/month if applicable]
- Part-time work: [$AMOUNT/month for [DURATION] if applicable]
- Required Minimum Distributions: [ESTIMATED AMOUNT/year starting age 73]
- Other guaranteed income: [ANNUITY / RENTAL / ETC.]
Portfolio: [$TOTAL VALUE, allocation breakdown]
Withdrawal strategy: [DESCRIBE — e.g., "systematic withdrawal from IRA, dividends from taxable, bond ladder for first 5 years"]
Key risks to address: [SEQUENCE OF RETURNS / LONGEVITY / INFLATION / HEALTHCARE COSTS]

Write a 2-3 page income plan summary that:
1. Shows the income "layers" (guaranteed vs. portfolio-based vs. flexible)
2. Explains how the gap between guaranteed income and total need will be funded
3. Describes the withdrawal sequencing strategy and why
4. Addresses each key risk with a specific mitigation strategy
5. Gives a year-by-year income table for the first 10 years (placeholder format)
6. States the monitoring plan — when will we review this?

This is the document we review together annually. It should be comprehensive but readable.
```

---

**Prompt 3: Retirement Gap Analysis**

*When to use: Showing a client exactly how far behind they are and what it takes to close the gap*

```
Write a retirement gap analysis for a client whose plan shows a shortfall.

Client: [CLIENT NAME(S)]
Ages: [AGES]
Target retirement age: [AGE]
Projected retirement income at current savings rate: [$AMOUNT/month]
Target retirement income: [$AMOUNT/month]
Annual shortfall: [$AMOUNT]
Gap in portfolio terms at retirement: [$AMOUNT]
Years until retirement: [YEARS]

Available levers to close the gap:
- Increasing savings: [CURRENT SAVINGS RATE vs. what they could potentially save]
- Working longer: [FLEXIBILITY ON RETIREMENT AGE?]
- Reducing retirement income target: [ANY FLEXIBILITY HERE?]
- Taking more investment risk: [APPROPRIATE TO CONSIDER?]
- Part-time work in retirement: [REALISTIC FOR THEM?]

Write a candid but constructive gap analysis that:
1. States the gap clearly without sugarcoating it
2. Shows the impact of each available lever (e.g., "working 2 extra years closes 40% of the gap")
3. Presents a realistic path forward that combines 2-3 levers
4. Frames this as a solvable problem, not a crisis (if it is)
5. Recommends a specific action plan with timeline

Tone: Honest, direct, and encouraging. Clients need truth, not false comfort — but also hope, not despair.
```

---

**Prompt 4: Education Savings Plan Summary**

*When to use: Creating a college savings plan document for clients with children*

```
Write a college savings plan summary for a family.

Parents: [CLIENT NAME(S)]
Child/children: [NAMES AND AGES]
Target college: [TYPE — e.g., "in-state public university", "private university", "unknown — planning for both scenarios"]
Current 529 balance(s): [$AMOUNT per child]
Monthly contribution: [$AMOUNT]
Years until first enrollment: [YEARS]
Projected college cost at enrollment: [$ANNUAL COST — use 4-5% inflation on current $X/year]
Coverage goal: [FULL / 4 YEARS / PARTIAL — describe]
Current projection at enrollment: [$PROJECTED 529 VALUE]
On track to meet goal: [YES / NO / PARTIALLY]

Write a college savings summary that:
1. Shows current vs. needed at enrollment in plain terms
2. Addresses the gap with specific contribution recommendations
3. Explains the 529 contribution limits and gift tax considerations
4. Discusses the trade-off between funding college vs. retirement (if relevant)
5. Notes what happens to the 529 if the child doesn't go to college
6. Recommends any additional vehicles (UTMA, savings bonds, etc.) if appropriate

Plain language. Parents want to know: "Are we on track?" and "What do we do next?"
```

---

**Prompt 5: Cash Flow Analysis and Budget Planning**

*When to use: Helping a client understand and optimize their monthly cash flow*

```
Write a cash flow analysis and optimization plan for a client.

Client: [CLIENT NAME]
Gross monthly income: [$AMOUNT from all sources]
Net monthly income (after tax): [$AMOUNT]
Fixed expenses: [LIST — mortgage $X, car $X, insurance $X, subscriptions $X]
Variable expenses: [LIST — groceries $X, dining $X, entertainment $X, misc $X]
Current savings/investments: [$AMOUNT/month — where it goes]
Debt payments: [LIST — credit card $X, student loan $X, car loan $X]
High-interest debt (>6%): [LIST WITH BALANCES AND RATES]
Financial goals competing for cash flow: [LIST — retirement, college, emergency fund, debt payoff, home purchase]

Write a cash flow analysis that:
1. Shows the current cash flow snapshot (income, expenses, savings)
2. Identifies 2-3 areas where cash flow could be optimized
3. Prioritizes competing financial goals with a recommended allocation
4. Creates a specific "every dollar" monthly plan
5. Addresses high-interest debt with a payoff strategy
6. Shows how small changes compound over time (e.g., "$300/month more to retirement = $X at retirement")

Tone: Practical and non-judgmental. Cash flow conversations can feel like a spending lecture — avoid that.
```

---

**Prompt 6: Life Insurance Needs Analysis**

*When to use: Determining how much life insurance a client needs*

```
Write a life insurance needs analysis for a client.

Client: [CLIENT NAME]
Age: [AGE], health: [GENERAL HEALTH STATUS]
Spouse/partner: [NAME, AGE — or N/A]
Dependents: [CHILDREN WITH AGES — or N/A]
Annual income to replace: [$AMOUNT]
Years to replace income: [UNTIL YOUNGEST CHILD IS 18 / UNTIL SPOUSE REACHES X AGE]
Outstanding debts to cover: [MORTGAGE $X, OTHER DEBTS $X]
Final expenses: [$10-15K STANDARD]
College funding gap: [$AMOUNT if applicable]
Existing life insurance coverage: [EMPLOYER $X, INDIVIDUAL $X]
Investment assets that could be used: [$AMOUNT if applicable]

Write a life insurance analysis that:
1. Shows the total need calculation step by step
2. Compares need to current coverage
3. States the coverage gap clearly
4. Recommends a coverage type (term / whole / universal) with rationale for their situation
5. Notes factors that affect cost (age, health, occupation)
6. Acknowledges this is a starting point and recommends a formal insurance quote

Add note: Coverage recommendations should be confirmed with a licensed insurance professional.
```

---

**Prompt 7: Disability Insurance Review**

*When to use: Reviewing or recommending disability insurance coverage*

```
Write a disability insurance review for a client.

Client: [CLIENT NAME]
Age: [AGE]
Occupation: [OCCUPATION AND INCOME — $AMOUNT/year]
Employer-provided short-term disability: [COVERAGE — % of income, duration]
Employer-provided long-term disability: [COVERAGE — % of income, duration, definition of disability]
Individual disability policy (if any): [COVERAGE DETAILS]
Current coverage gap: [CALCULATE — monthly income vs. covered amount]
Monthly expenses to cover: [$AMOUNT]
Emergency fund (months of expenses): [X MONTHS]
Other income sources if disabled: [SPOUSE INCOME, RENTAL, INVESTMENTS]

Write a disability insurance review that:
1. Explains why disability insurance matters more than most clients realize (statistics on probability)
2. Shows their current monthly coverage gap in dollars
3. Evaluates the adequacy of employer-provided coverage
4. Recommends whether individual disability coverage is needed
5. Notes key policy features to look for (own-occupation definition, residual disability, COLA rider)
6. Suggests next step (seek individual policy quotes, review employer plan)

Keep it under 400 words. Disability insurance is often overlooked — make the case clearly.
```

---

**Prompt 8: Emergency Fund and Liquidity Planning**

*When to use: Establishing or reviewing a client's liquidity and emergency fund strategy*

```
Write an emergency fund and liquidity planning summary.

Client: [CLIENT NAME]
Monthly essential expenses: [$AMOUNT]
Current liquid savings (checking + savings): [$AMOUNT]
Current months of expenses in liquid savings: [X MONTHS]
Recommended coverage: [3-6 months for employed / 6-12 months for self-employed / custom for this client]
Gap to recommended level: [$AMOUNT NEEDED]
Monthly capacity to build emergency fund: [$AMOUNT/month available]
Other liquid assets that could serve as backup: [TAXABLE BROKERAGE, HOME EQUITY LINE, ETC.]
Special liquidity needs: [BUSINESS OWNER PAYROLL / PROPERTY TAXES / VARIABLE INCOME]

Write a short emergency fund plan (under 300 words) that:
1. States their current position and whether it's adequate
2. If inadequate: gives a specific savings target and timeline to reach it
3. Explains where to hold emergency funds (HYSA recommendation)
4. Addresses any special circumstances (variable income, business owner)
5. Distinguishes between emergency fund and investment accounts — these serve different purposes
```

---

**Prompt 9: Debt Payoff Strategy**

*When to use: Creating a debt elimination plan for a client carrying significant debt*

```
Write a debt payoff strategy for a client.

Client: [CLIENT NAME]
Outstanding debts:
[LIST EACH DEBT:
- Debt 1: [TYPE], Balance $X, Rate X%, Min payment $X/month
- Debt 2: [TYPE], Balance $X, Rate X%, Min payment $X/month
- Debt 3: [TYPE], Balance $X, Rate X%, Min payment $X/month]
Extra cash available for debt payoff each month: [$AMOUNT above minimums]
Priority goals alongside debt payoff: [RETIREMENT SAVINGS / EMERGENCY FUND / OTHER]
Client preference (if stated): [DEBT AVALANCHE — highest rate first / DEBT SNOWBALL — smallest balance first / NO PREFERENCE]

Write a debt payoff plan that:
1. Compares avalanche vs. snowball approaches with the math (total interest paid, time to payoff)
2. Makes a recommendation based on their situation and psychology
3. Creates a specific month-by-month payoff order with estimated dates
4. Shows the intersection with investment priorities (e.g., "always get employer 401k match before extra debt payments")
5. Calculates total interest saved vs. minimum payments
6. Gives a milestone map to keep them motivated

Format: Brief narrative + table showing payoff order, monthly payment, payoff date, and interest saved.
```

---

**Prompt 10: Pre-Retirement Checklist and Timeline**

*When to use: Creating a 3-5 year countdown plan for clients approaching retirement*

```
Write a pre-retirement planning checklist and timeline for a client.

Client: [CLIENT NAME(S)]
Ages: [AGES]
Target retirement date: [DATE — X years away]
Current status on key items: [BRIEF OVERVIEW OF WHERE THEY STAND]

Areas to cover:
- Savings and investment optimization
- Social Security claiming strategy
- Medicare enrollment planning
- Healthcare bridge (if retiring before 65)
- Asset allocation shift
- Estate plan review
- Beneficiary updates
- Pension decisions (if applicable)
- Income withdrawal strategy
- Debt elimination
- Housing decisions
- Identity and purpose in retirement

Create a year-by-year pre-retirement checklist covering:
- 5 years out: [ITEMS TO ADDRESS]
- 3 years out: [ITEMS TO ADDRESS]
- 2 years out: [ITEMS TO ADDRESS]
- 1 year out: [ITEMS TO ADDRESS]
- 6 months out: [ITEMS TO ADDRESS]
- 30 days out: [ITEMS TO ADDRESS]

For each item: a brief description of what it involves and why the timing matters. This document should be genuinely useful — not a generic checklist, but calibrated to their specific situation.
```

---

**Prompt 11: Roth Conversion Analysis**

*When to use: Evaluating whether a Roth conversion makes sense for a client*

```
Write a Roth conversion analysis for a client.

Client: [CLIENT NAME]
Current age: [AGE]
Retirement age: [TARGET]
Current traditional IRA / 401(k) balance: [$AMOUNT]
Current annual income: [$AMOUNT]
Current marginal tax rate: [%]
Expected retirement income (and tax rate): [$AMOUNT, %]
Expected RMDs at age 73: [ESTIMATED ANNUAL AMOUNT]
Heirs and estate considerations: [ANY INHERITANCE PLANNING ANGLE]
Conversion amount being considered: [$AMOUNT]
Funds available outside IRA to pay the tax: [YES $X / NO]
Tax-rate environment outlook: [YOUR VIEW]

Write a Roth conversion analysis that:
1. Explains the Roth conversion concept in plain English (2-3 sentences)
2. Shows the tax cost of converting now vs. the benefit of tax-free growth
3. Calculates the break-even point (how many years to recoup the tax paid)
4. Considers the RMD impact if they don't convert
5. Makes a recommendation with rationale (convert full amount / partial / not recommended)
6. Suggests the optimal conversion amount and timing
7. Flags the impact on current year AGI and any phase-outs triggered

Add note: Recommend client review with their CPA before executing any conversion.
```

---

**Prompt 12: Financial Plan Annual Review Summary**

*When to use: Documenting the annual financial plan review and updating the plan narrative*

```
Write an annual financial plan review summary for a client.

Client: [CLIENT NAME(S)]
Review date: [DATE]
Year reviewed: [YEAR]

Progress this year:
- Net worth change: [FROM $X TO $X — change of $X]
- Portfolio performance: [RETURN %]
- Savings accomplished: [AMOUNT SAVED]
- Goals completed or advanced: [LIST]
- Major life changes: [ANY]

Plan updates made:
- [LIST CHANGES TO ASSUMPTIONS, STRATEGY, OR GOALS]

Current plan status:
- Retirement: [ON TRACK / BEHIND / AHEAD — specific]
- Education savings: [STATUS if applicable]
- Emergency fund: [STATUS]
- Insurance: [STATUS]
- Estate plan: [STATUS]

Priority actions for next year: [3-5 SPECIFIC ITEMS]

Write a 1-2 page annual plan review summary that:
1. Starts with a "state of the plan" headline (1-2 sentences on overall status)
2. Summarizes the year's financial progress
3. Highlights plan changes and why they were made
4. Shows the path forward for the next 12 months
5. Lists priority action items with owner and timing
6. Ends with a statement of the long-term goal and confidence in the direction

Tone: Reflective, forward-looking, and collaborative. This documents a year of partnership.
```

---

**Prompt 13: New Client Financial Planning Intake Summary**

*When to use: After the first comprehensive data gathering meeting, summarizing what you learned*

```
Write a new client planning intake summary based on the following information gathered.

Client: [CLIENT NAME(S)]
Ages: [AGES]
Occupation(s): [OCCUPATION(S) AND INCOME(S)]
Family situation: [MARRIED / SINGLE / DEPENDENTS]

Assets:
[LIST ALL ASSETS WITH APPROXIMATE VALUES]

Liabilities:
[LIST ALL DEBTS WITH BALANCES AND RATES]

Income: [$GROSS / YEAR]
Expenses: [APPROXIMATE MONTHLY or ANNUAL]

Insurance coverage: [LIFE / DISABILITY / LONG-TERM CARE / OTHER — current status]
Estate documents: [WILL / TRUST / POWERS OF ATTORNEY — current status]
Benefits: [EMPLOYER 401K MATCH / PENSION / STOCK / HSA — status]

Primary financial goals (in their words): [WHAT THEY TOLD YOU]
Primary concerns (in their words): [WHAT WORRIES THEM]
Values and priorities: [WHAT MATTERS MOST TO THEM]

Write a comprehensive intake summary (2-3 pages) that:
1. Profiles their complete financial picture
2. Identifies the top 3-5 planning priorities in order
3. Notes any urgent items (insurance gaps, no estate documents, high-interest debt)
4. Outlines the initial planning scope and what we'll tackle first
5. Reflects their stated values and goals — this is their plan, not a generic plan

This document becomes the foundation of the planning relationship. It should feel like it was written by someone who listened carefully.
```

---

**Prompt 14: Long-Term Care Planning Conversation Guide**

*When to use: Facilitating a long-term care planning discussion with a client in their 50s-60s*

```
Write a long-term care planning discussion guide and client summary.

Client: [CLIENT NAME(S)]
Ages: [AGES]
Family long-term care history: [PARENTS / SIBLINGS — any relevant experience with LTC?]
Health status: [GENERAL HEALTH]
Net worth and portfolio: [$AMOUNT]
Portfolio percentage that could fund LTC self-insured: [ASSESSMENT]
Risk tolerance for LTC costs: [HIGH / MEDIUM / LOW concern about depleting assets]
Existing LTC insurance: [NONE / DESCRIBE IF EXISTS]
Housing situation: [OWN HOME / CONDO / OTHER]

Write a long-term care planning guide that:
1. Opens with the statistics that matter (probability of needing care, average costs, average duration)
2. Explains the 4 primary strategies: self-insure, traditional LTC insurance, hybrid/combo policies, Medicaid planning
3. Evaluates which approach fits their financial situation
4. Addresses the common objection: "I'll have Medicare / my kids will take care of me"
5. Makes a recommendation and next step (get quotes? Add to plan? Self-insure formally?)
6. Notes the ideal age range to act (underwriting gets harder in late 60s)

Tone: Direct but not fear-mongering. LTC planning is easy to avoid — make it feel manageable.
```

---

**Prompt 15: Goal Prioritization Exercise Summary**

*When to use: After a goal-setting conversation, documenting the agreed priorities*

```
Write a goal prioritization summary from a client planning conversation.

Client: [CLIENT NAME(S)]
Goals discussed:
[LIST ALL GOALS MENTIONED — e.g., retire at 60, pay off mortgage, fund kids' college, take annual international trip, leave inheritance, start a small business, buy vacation home]

Constraints:
- Monthly savings capacity: [$AMOUNT]
- Current debt obligations: [$AMOUNT/month]
- Timeline: [AGES AND KEY DATES]
- Risk tolerance: [CONSERVATIVE / MODERATE / AGGRESSIVE]

What matters most to them (their stated values): [DESCRIBE — what did they say is most important?]

Write a goal prioritization summary that:
1. Lists all goals mentioned, ranked by priority (as agreed in conversation)
2. Notes the financial requirement and timeline for each goal
3. Identifies any conflicts between goals (e.g., retire early AND fund full college = tension)
4. Recommends which goals to fund first and the rationale
5. Notes which goals are "on hold" and what would need to change to activate them
6. Frames this as the foundation for the financial plan

This document should reflect what THEY said matters, not what a generic plan would assume.
```

---

**Prompt 16: Estate Planning Overview for Client**

*When to use: Educating a client about estate planning basics and their current gaps*

```
Write an estate planning overview document for a client.

Client: [CLIENT NAME(S)]
Ages: [AGES]
Marital status: [STATUS]
Children: [NAMES AND AGES]
Grandchildren: [IF RELEVANT]
Approximate estate value: [$AMOUNT — assets + life insurance]
Current documents: [WHAT THEY HAVE — will, trust, POA, healthcare directive — or "none"]
Primary estate concern: [WHAT THEY WORRY ABOUT — e.g., protecting kids in blended family, minimizing estate taxes, ensuring business succession, protecting a special needs dependent]
State of residence: [STATE — affects estate law]

Write a 2-page estate planning overview that:
1. Explains the core estate planning documents and why each matters (will, trust, POA, healthcare directive)
2. Identifies their current gaps based on what they have
3. Addresses their specific primary concern
4. Notes any estate tax considerations based on estate size
5. Explains the beneficiary designation layer (often more important than the will)
6. Recommends a meeting with an estate attorney with a specific agenda
7. Notes what the advisor handles vs. what the attorney handles

Tone: Clear and practical. Estate planning seems complicated — make it feel manageable.
```

---

**Prompt 17: Business Owner Retirement Planning Summary**

*When to use: Helping a business owner understand their retirement plan options*

```
Write a retirement plan options summary for a self-employed business owner.

Client: [CLIENT NAME]
Business type: [SOLE PROPRIETOR / S-CORP / C-CORP / PARTNERSHIP / LLC]
Annual business income (net): [$AMOUNT]
Number of employees (W-2): [NUMBER — affects plan options]
Current retirement savings: [$AMOUNT in what vehicles]
Tax situation: [MARGINAL RATE %, LOOKING TO REDUCE TAXABLE INCOME]
Age: [AGE]
Retirement timeline: [TARGET AGE]

Compare the following retirement plan options and recommend:
1. SEP-IRA — contribution limits, pros, cons, admin burden
2. SIMPLE IRA — contribution limits, pros, cons, admin burden
3. Solo 401(k) — contribution limits, pros, cons, admin burden
4. Defined Benefit / Cash Balance Plan — for high-income owners wanting maximum contribution

For each: show the maximum annual contribution given their income, estimated tax savings, and key considerations.

Write a comparison document that:
1. Leads with the recommendation for their specific situation
2. Shows the contribution limit comparison table
3. Explains the decision trade-offs (simplicity vs. contribution limit vs. admin cost)
4. Notes the interaction with any employee plan requirements
5. Recommends a next step (set up plan, upgrade current plan, add defined benefit)

Add note: Implementation should involve a CPA and/or third-party administrator.
```

---

**Prompt 18: Inheritance / Windfall Planning Summary**

*When to use: Helping a client process and plan for a large inheritance or financial windfall*

```
Write a windfall planning summary for a client who has received or will receive a significant amount of money.

Client: [CLIENT NAME]
Windfall source: [INHERITANCE / HOME SALE / BUSINESS SALE / SETTLEMENT / LOTTERY — describe briefly]
Amount: [$AMOUNT]
Timing: [ALREADY RECEIVED / EXPECTED IN X MONTHS]
Current financial situation: [BRIEF OVERVIEW — debt, savings, income]
Client's emotional state: [OVERWHELMED / EXCITED / GRIEVING (inheritance) / CALM]
Their initial instincts about the money: [WHAT THEY WANT TO DO — often impulsive]

Write a windfall planning document that:
1. Acknowledges the significance of this moment (especially if it involves grief)
2. Recommends a "pause period" before making major decisions (typically 3-6 months)
3. Addresses immediate priorities (parking the money safely while planning)
4. Outlines the planning framework: taxes, debt, goals, investment
5. Identifies the most impactful uses for their specific situation
6. Warns against common mistakes (large gifts to family, major purchases, risky investments)
7. Recommends next steps in priority order

Tone: Calm and grounded. People make poor decisions with windfalls. Be the steady hand.
```

---

**Prompt 19: Financial Plan for a Newly Single Client**

*When to use: A client is going through divorce or is recently widowed and needs a complete financial reassessment*

```
Write a financial planning roadmap for a client navigating a major marital transition.

Client: [CLIENT NAME]
Situation: [RECENTLY WIDOWED / GOING THROUGH DIVORCE / RECENTLY DIVORCED]
Age: [AGE]
Income: [CURRENT INCOME — employed/not, amount]
Assets likely to retain: [DESCRIBE AFTER SETTLEMENT IF DIVORCE / FULL ESTATE IF WIDOWED]
Immediate concerns: [WHAT THEY'RE MOST WORRIED ABOUT — cash flow, insurance, beneficiaries, housing]
Children: [AGES AND CUSTODY SITUATION IF DIVORCE]
Prior financial arrangement: [WHO MANAGED MONEY / WERE THEY INVOLVED IN FINANCES?]

Write a planning roadmap that:
1. Acknowledges the emotional difficulty without over-dwelling on it
2. Identifies the immediate priority actions (60-90 days) — insurance, beneficiaries, accounts
3. Establishes a new financial picture (income, expenses, assets, goals as a single person)
4. Addresses specific planning needs: survivor benefits, QDRO (divorce), COBRA or new insurance
5. Outlines medium-term planning (6-18 months): rebuilding plan, investment strategy, housing
6. Offers reassurance that this is manageable with the right planning

Tone: Empathetic and practical. They need a clear path forward, not more overwhelm.
```

---

**Prompt 20: Financial Plan for Clients Nearing Business Sale**

*When to use: Client is planning to sell a business in the next 1-5 years*

```
Write a pre-business sale financial planning summary.

Client: [CLIENT NAME]
Business: [DESCRIPTION]
Estimated sale value: [$AMOUNT range]
Expected timeline to sale: [YEARS]
Business structure: [S-CORP / C-CORP / LLC / SOLE PROP]
Personal assets outside business: [$AMOUNT]
Planned use of proceeds: [RETIREMENT / INVEST / NEW VENTURE / MIX]
Estate size post-sale: [ESTIMATE — does it cross federal estate tax threshold?]
Current planning in place: [WHAT'S BEEN DONE — any trust, buy-sell, key person insurance]

Write a pre-sale planning summary covering:
1. Tax implications of the sale (capital gains, structure matters — asset sale vs. stock sale)
2. Strategies to reduce the tax burden (installment sale, QSBS exclusion, opportunity zones, charitable trusts — note which apply)
3. What to do with the proceeds — investment sequencing and diversification strategy
4. Estate planning implications post-sale
5. Retirement timeline — does this sale change when they can retire?
6. Key advisors needed: CPA, M&A attorney, financial advisor, estate attorney

This is a complex planning scenario. Write it in a way that shows the complexity while making it feel navigable with the right team.
```

---

**Prompt 21: Medicare and Retirement Healthcare Costs Summary**

*When to use: Helping a client understand and plan for healthcare costs in retirement*

```
Write a retirement healthcare cost planning summary.

Client: [CLIENT NAME(S)]
Ages: [AGES]
Target retirement age: [AGE — especially if before 65]
Current health insurance: [EMPLOYER / ACA / COBRA]
Health status and family history: [BRIEF — affects cost planning assumptions]
Medicare eligibility: [AGE 65 or will they retire before?]
Pre-Medicare gap: [NUMBER OF YEARS without employer coverage before Medicare]
Current out-of-pocket healthcare costs: [$AMOUNT/year]

Write a healthcare cost planning summary that:
1. Quantifies the healthcare cost challenge in retirement (average couple spends $X over retirement)
2. Addresses the pre-Medicare gap strategy (ACA marketplace options, COBRA, spouse coverage)
3. Explains Medicare Part A, B, C, D in plain language with cost estimates
4. Recommends a Medicare supplement vs. Advantage approach for their situation
5. Shows the HSA strategy (if still eligible — "stealth IRA" for healthcare)
6. Builds healthcare into their retirement income projection with a specific annual estimate
7. Notes that long-term care is a separate (and larger) risk to address

This is one of the most underestimated retirement risks. Make the numbers real.
```

---

**Prompt 22: Values-Based Financial Planning Discovery**

*When to use: Before writing a financial plan, capturing what the client truly values and wants*

```
Write a values-based financial planning discovery summary.

Client: [CLIENT NAME(S)]

Responses to explore in a planning conversation (use these as discussion questions, then summarize the answers):

1. "What does money allow you to do that you care about most?"
2. "If you could accomplish one financial goal in the next 5 years, what would it be?"
3. "What is your biggest financial fear?"
4. "When you imagine retirement, what does a typical day look like?"
5. "Who are the most important people your financial decisions need to support?"
6. "What would you regret NOT doing with your money if money weren't a constraint?"
7. "What was the most meaningful thing you ever spent money on?"

Client's answers: [PASTE THEIR RESPONSES OR SUMMARIZE WHAT THEY SAID]

Write a 1-page planning discovery summary that:
1. Captures their core values in financial terms
2. Identifies the goals behind their goals (the "why," not just the "what")
3. Notes any tensions between stated values and current behavior
4. Frames the financial plan in terms of what they're building toward — not just numbers
5. Serves as a reference document throughout the planning relationship

This is the most important document in the plan. It ensures we're building a plan around their life, not around a spreadsheet.
```

---

*Next: `04-investment-analysis-prompts.md` → 20 prompts for portfolio commentary, market updates, and investment analysis*
