# 01 — Quick Start Guide

*How to get maximum value from this toolkit in the first 10 minutes*

---

## The 3-Minute Setup

### Step 1: Pick Your AI Tool
These prompts work with any modern LLM. Recommended:
- **ChatGPT (GPT-4o)** — Best for iterative drafts and client emails
- **Claude (Sonnet or Opus)** — Best for long-form planning documents and nuanced client letters
- **Gemini Advanced** — Good for research-heavy analysis prompts

### Step 2: Set a System Prompt (Optional but Powerful)
Paste this at the start of any new conversation to establish context:

```
You are an experienced CFP and wealth manager with 15+ years advising high-net-worth clients on retirement planning, investment management, and estate planning. You write with empathy, clarity, and professionalism. You never use financial jargon without explaining it. Your writing builds client trust by being specific, honest about uncertainty, and focused on outcomes that matter to clients — not products or performance. All output is draft material for a licensed advisor to review, edit, and approve before use.
```

**Customize this system prompt with your specific context:**
```
You are a financial advisor who specializes in [YOUR NICHE: e.g., retirement planning for pre-retirees, small business owners, women in transition]. Your typical client is [CLIENT PROFILE]. You work at [FIRM TYPE: independent RIA / wirehouse / bank]. Your communication style is [FORMAL / WARM AND CONVERSATIONAL / DIRECT].
```

### Step 3: Fill In the Brackets
Every prompt uses `[BRACKET VARIABLES]` in ALL CAPS. Before you paste, replace every bracket with your real client data. The more specific you are, the better the output.

**Bad:**
```
[CLIENT NAME] = our client
[PORTFOLIO VALUE] = a lot
```

**Good:**
```
[CLIENT NAME] = Margaret and David Chen
[PORTFOLIO VALUE] = $1.2M
[CONCERN] = running out of money in retirement, specifically worried about healthcare costs after age 75
```

---

## Compliance Best Practices

⚠️ **Always review AI output before sending to clients.** These prompts generate drafts — not compliance-approved communications.

**Before sending anything:**
- [ ] Read for accuracy — did AI make up any numbers or facts?
- [ ] Check for specific investment recommendations that require disclosure
- [ ] Add required disclaimers per your compliance department
- [ ] Confirm anything time-sensitive is still current
- [ ] Review for your firm's required language and approved terminology

**Prompts that require extra care:**
- Any market commentary or performance attribution
- Specific investment recommendations or security names
- Tax-related advice (always note "consult a tax professional")
- Estate planning specifics (always note "consult an estate attorney")

---

## Power Techniques

### Technique 1: Personalize with Client Data
The more client-specific context you give, the better:
```
[CLIENT NAME] = Tom and Susan Wheeler, ages 58 and 56
[SITUATION] = Tom recently retired from Boeing with a pension of $4,200/month. Susan still works as a nurse, plans to retire in 3 years. They have $840K in a rollover IRA, $180K in Susan's 403(b), and $95K in a joint taxable account. Their home is paid off. Two adult children.
[CONCERN] = Worried about healthcare gap between Susan's retirement and Medicare eligibility at 65.
```

### Technique 2: Tone Calibration
Add a tone instruction to any prompt:
- *"Write this in a warm, reassuring tone — this client is anxious about market volatility"*
- *"This is a sophisticated investor — use more technical language and skip the basics"*
- *"Keep this brief — my client prefers bullet points over paragraphs"*

### Technique 3: The Draft-and-Refine Loop
1. Generate a first draft
2. Read critically — is it accurate? Does it sound like you?
3. Add a follow-up: *"Revise this to be more empathetic in the opening paragraph"*
4. One final edit in your own voice before sending

### Technique 4: Scenario Variants
```
Write three versions of this client email:
- Version 1: Client is calm and just wants facts
- Version 2: Client is anxious and needs reassurance
- Version 3: Client is frustrated and considering leaving
```

### Technique 5: The Compliance Pre-Check
After generating any client-facing content:
```
Review the above draft. Flag any: (1) specific investment recommendations that would require a disclosure, (2) claims about future performance, (3) tax advice that should be referred to a CPA, (4) estate planning specifics that should be referred to an attorney. List each flag with the specific sentence and why it needs review.
```

---

## Common Mistakes to Avoid

❌ **Using AI output without reading it** — AI can confidently state incorrect numbers. Always verify.

❌ **Skipping the system prompt** — Even a brief persona setup dramatically improves output.

❌ **Being vague with client context** — "my retired client" produces generic output. Specific context produces specific, useful drafts.

❌ **Over-relying on AI for compliance decisions** — AI does not know your firm's policies, FINRA rules, or client suitability requirements.

❌ **Sending without your own voice** — Every draft should be edited so it sounds like you, not like a robot.

---

## Recommended Use Cases by Situation

| Situation | Go-To Prompts |
|-----------|--------------|
| Quarterly review prep | Planning #1, Planning #3 |
| Client is worried about market | Investment #2, Investment #5 |
| New client onboarding letter | Communication #1, Communication #2 |
| Annual review meeting prep | Communication #8, Planning #10 |
| Client referred a prospect | Business Dev #1, Business Dev #4 |
| Asking for a referral | Business Dev #6, Business Dev #7 |
| Client experiencing life event | Communication #12, Planning #6 |
| Market volatility response | Investment #1, Investment #4 |

---

## File Navigation

- **Client Communication** → [02-client-communication-prompts.md](02-client-communication-prompts.md)
- **Financial Planning** → [03-financial-planning-prompts.md](03-financial-planning-prompts.md)
- **Investment Analysis** → [04-investment-analysis-prompts.md](04-investment-analysis-prompts.md)
- **Business Development** → [05-business-development-prompts.md](05-business-development-prompts.md)
- **Workflow SOPs** → [06-workflow-sops.md](06-workflow-sops.md)
- **Quick Reference** → [07-cheat-sheet.md](07-cheat-sheet.md)

---

*Start with the cheat sheet if you're in a hurry. Start with client communication prompts if you have emails to write today.*
