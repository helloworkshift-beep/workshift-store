# 🏆 The Scrum Master's AI Prompt Toolkit

**Version 1.0 | Professional Edition**

---

## Welcome, Scrum Master

You've invested in the most powerful AI prompt library built specifically for Scrum Masters and agile coaches. This toolkit gives you 80+ battle-tested prompts, 5 complete workflow SOPs, and a quick-reference cheat sheet — everything you need to run smoother sprints, coach better teams, and communicate with confidence.

---

## 📁 What's Inside

| File | Contents | Prompts |
|------|----------|---------|
| `01-quick-start-guide.md` | Setup, best practices, how to use this toolkit | — |
| `02-ceremonies-prompts.md` | Sprint planning, retrospectives, standups, reviews, refinement | 25 |
| `03-team-coaching-prompts.md` | Impediment removal, conflict, motivation, psychological safety | 20 |
| `04-stakeholder-communication-prompts.md` | Status updates, velocity reports, escalations, exec summaries | 20 |
| `05-agile-transformation-prompts.md` | Health checks, maturity assessments, training, metrics | 15 |
| `06-workflow-sops.md` | 5 complete end-to-end workflow playbooks | — |
| `07-cheat-sheet.md` | Top 15 power prompts, quick reference card | 15 |

**Total prompts: 80+**

---

## 🚀 Quick Start (5 Minutes)

1. **Read** `01-quick-start-guide.md` first — it covers the prompt system and customization tips
2. **Identify** your most pressing need (ceremony prep? team issue? stakeholder update?)
3. **Navigate** to the relevant file and find your prompt
4. **Customize** the `[BRACKETED]` fields with your specific context
5. **Paste** into ChatGPT, Claude, Gemini, or any AI assistant

---

## 💡 Best Results Tips

- **More context = better output.** Fill in every `[BRACKET]` with real details
- **Iterate.** Run a prompt, review the output, then ask follow-up questions
- **Stack prompts.** Use a planning prompt to prep, then a coaching prompt to debrief
- **Save your outputs.** Build a library of AI-generated artifacts tailored to your team

---

## 🔧 Compatible With

- ChatGPT (GPT-4o, GPT-4)
- Claude (3.5 Sonnet, Opus)
- Google Gemini Pro/Ultra
- Microsoft Copilot
- Any instruction-following LLM

---

## 📋 Use Cases at a Glance

**For Daily Work**
→ Standup facilitation scripts, impediment tracking, daily coaching nudges

**For Sprint Events**
→ Planning facilitation, retrospective formats, review agendas, refinement sessions

**For Team Health**
→ Conflict resolution, motivation, psychological safety, performance conversations

**For Leadership**
→ Exec summaries, velocity reports, roadmap communications, escalation emails

**For Transformation**
→ Maturity assessments, training materials, adoption plans, agile metrics

---

## ⚖️ License & Usage

This toolkit is licensed for **single-user professional use**. You may:
- ✅ Use all prompts for your own professional work
- ✅ Adapt and customize prompts for your team/organization
- ✅ Generate and share AI outputs with colleagues

You may not:
- ❌ Redistribute, resell, or share the prompt files themselves
- ❌ Include these prompts in any commercial product without written permission

---

## 🆘 Support

Questions or feedback? Reach out through the platform where you purchased this toolkit.

---

*Built by practitioners, for practitioners. Happy facilitating!* 🎯
