# 03 — Team Coaching Prompts
## Impediment Removal · Team Conflict · Motivation · Psychological Safety · Coaching Conversations · Performance Issues

---

> **20 prompts** to help you coach individuals and teams through challenges, build high-performing cultures, and navigate the human side of agile.

---

## 🚧 IMPEDIMENT REMOVAL

---

**Prompt 1: Impediment Root Cause Analyzer**

*When to use:* When an impediment has been on your radar for more than a few days and keeps coming back despite your attempts to resolve it.

```
Act as an experienced agile coach helping me diagnose and remove a persistent impediment.

The impediment: [DESCRIBE the blocker clearly]
How long it has existed: [X days/weeks]
Who it affects: [ROLE(S) or whole team]
Impact on the team: [DESCRIBE: e.g., blocking 2 stories, causing 20% capacity loss, causing team frustration]
What I've already tried: [LIST actions taken]
Why those attempts haven't worked: [YOUR ASSESSMENT]
Who has authority to resolve this: [ROLE/DEPARTMENT]
Organizational context: [E.g., bureaucratic company, startup, matrix org]

Please provide:
1. Root cause analysis (5 Whys applied to this impediment)
2. The real blocker beneath the surface issue
3. Three resolution strategies ranging from quick fix to systemic fix
4. Stakeholders I need to influence and how to approach each
5. An escalation plan if this isn't resolved in [X] days
6. How to protect the team from this impediment while resolution is in progress
```

---

**Prompt 2: Impediment Escalation Strategy**

*When to use:* When an impediment is beyond your authority to remove and you need to escalate to management, leadership, or another department.

```
I need to escalate an impediment to leadership and want to do it effectively. Help me prepare.

The impediment: [DESCRIBE]
Business impact (quantified if possible): [E.g., blocking $X in value, delaying release by Y weeks, causing Z% rework]
Time it has been unresolved: [X days/weeks]
Previous resolution attempts: [LIST]
Who I need to escalate to: [ROLE/LEVEL, e.g., VP Engineering, PMO Director]
Their known priorities/concerns: [DESCRIBE what they care about]
Political sensitivity: [ANY CONTEXT about relationships, org dynamics]

Help me prepare:
1. A 2-minute verbal escalation pitch for a hallway conversation
2. A written escalation email (professional, data-driven, solution-oriented)
3. Three resolution options I can present (with tradeoffs)
4. How to frame this as a business problem, not a team complaint
5. Follow-up strategy if I don't hear back in [X] days
6. How to update my team while escalation is in progress
```

---

**Prompt 3: Dependency Map & Resolution Plan**

*When to use:* When your team is blocked by dependencies on other teams, third-party vendors, or shared services, and you need a systematic approach to managing them.

```
Help me map and manage cross-team dependencies that are impacting my team's delivery.

My team: [TEAM NAME and what they build]
Dependent teams/systems:
- [DEPENDENCY 1]: [WHAT WE NEED] — [CURRENT STATUS: e.g., waiting 2 weeks, partially resolved]
- [DEPENDENCY 2]: [WHAT WE NEED] — [CURRENT STATUS]
- [DEPENDENCY 3]: [WHAT WE NEED] — [CURRENT STATUS]
[Add more]

Sprint/release timeline pressure: [DESCRIBE any deadlines]
Org structure: [E.g., SAFe, multiple Scrum teams, fully independent teams]

Please provide:
1. A dependency risk matrix (severity × likelihood for each dependency)
2. Resolution strategies for each dependency (negotiate, decouple, escalate, accept risk)
3. A communication plan for each dependent team
4. How to visualize dependencies for my team's sprint board
5. How to raise dependency issues at program level (if applicable)
6. A template for a dependency agreement between teams
```

---

## 🤝 TEAM CONFLICT

---

**Prompt 4: Team Conflict Diagnostic**

*When to use:* When you're sensing or observing interpersonal tension, team dysfunction, or recurring conflict patterns that are affecting team performance.

```
Act as an executive coach helping me navigate team conflict as a Scrum Master.
I will describe the situation and you will help me understand it and respond effectively.

The conflict situation: [DESCRIBE as objectively as possible — who, what, when, observable behaviors]
Duration: [How long has this been going on?]
People involved: [Use roles, not names: e.g., "Senior Developer," "Junior QA," "Product Owner"]
Observable impact on team: [DESCRIBE: e.g., people avoiding each other, passive-aggressive comments in retro, decreased velocity]
My current relationship with each person: [DESCRIBE — do they trust you?]
Have I already intervened? [YES/NO — if yes, what happened]

Please give me:
1. A conflict pattern diagnosis (what type of conflict is this: task, process, relationship, values?)
2. Root cause hypotheses (what might really be driving this)
3. Intervention options from least to most direct
4. Specific language to use when addressing each person individually
5. How to bring this to the team level without making it worse
6. When to involve HR or a manager (escalation criteria)
7. How to monitor for improvement over the next 2 weeks
```

---

**Prompt 5: One-on-One Conflict Conversation Guide**

*When to use:* Before a difficult 1:1 conversation with a team member who is involved in conflict, performing poorly, or exhibiting disruptive behavior.

```
Help me prepare for a difficult one-on-one conversation with a team member.

Context: [DESCRIBE the situation — use the person's role, not name]
My relationship with this person: [DESCRIBE — new SM, trusted advisor, distant, adversarial]
The specific behavior I need to address: [DESCRIBE observable behaviors, not character judgments]
Impact of the behavior: [HOW it's affecting the team, sprint, or product]
What I believe the person's perspective is: [YOUR BEST GUESS at how they see the situation]
My goal for this conversation: [E.g., understand their perspective, agree on behavior change, offer support]

Please help me:
1. Open the conversation (exact words for the first 30 seconds)
2. Use a coaching framework (e.g., GROW, SBI, Nonviolent Communication) for this conversation
3. Ask powerful questions that invite reflection, not defensiveness
4. Handle the most likely defensive responses
5. Close with a clear, agreed next step
6. Follow up appropriately afterward
7. Know when to hand this off to the manager or HR
```

---

**Prompt 6: Team Meeting Conflict De-escalation**

*When to use:* When conflict erupts in a meeting (planning, retro, or standup) and you need to intervene in real time and then process it afterward.

```
A conflict erupted during one of our team meetings and I need help managing it and following up.

What happened: [DESCRIBE the incident — where, what was said, how others reacted]
Who was involved: [ROLES]
How I responded in the moment: [DESCRIBE your actual response]
Outcome of the meeting: [Did you continue? End early? Was the issue resolved?]
Team's current state: [DESCRIBE the atmosphere now]

Please help me with:
1. An assessment of how the situation was handled (honest and constructive)
2. What I could have said in the moment to de-escalate effectively
3. A "repair" conversation to have with the team at the next meeting
4. Individual follow-up messages for the people directly involved
5. A retrospective activity to address the underlying team dynamic
6. Language to use if it happens again in a future meeting
7. How to create norms or agreements that reduce the likelihood of recurrence
```

---

## 💪 MOTIVATION & ENGAGEMENT

---

**Prompt 7: Team Motivation Reset**

*When to use:* When the team seems disengaged, going through the motions, or has lost connection to why the work matters — often after a difficult sprint or prolonged crunch.

```
My team is showing signs of low motivation and disengagement. Help me diagnose and address this.

Signs I'm observing: [DESCRIBE: e.g., quiet standups, less creativity in retros, people doing minimum viable work, increased sick days]
Duration of this pattern: [X weeks/sprints]
Likely contributing factors: [YOUR ASSESSMENT: e.g., long sprint without meaningful release, organizational changes, tedious work, unclear direction]
Team size: [X] people
Team's history: [E.g., high-performer team that hit a wall, new team still forming, team post-merger]

Please provide:
1. A motivation diagnosis framework (apply intrinsic motivation theory to this situation)
2. Three short-term interventions I can try this sprint
3. Three longer-term structural changes to create sustainable motivation
4. A team conversation I can facilitate to understand what's driving this
5. Individual coaching approaches for different motivation styles on a team
6. How to involve the Product Owner and leadership in the solution
7. Leading indicators I should track to know if motivation is improving
```

---

**Prompt 8: Recognition & Appreciation System**

*When to use:* When you want to build a culture of recognition on your team, or when team members feel their work goes unnoticed — especially in remote teams.

```
Help me design a meaningful recognition and appreciation system for my Scrum team.

Team context:
- Size: [X] people
- Remote/in-person/hybrid: [TYPE]
- Current recognition culture: [DESCRIBE: e.g., non-existent, only top-down from manager, informal shoutouts]
- Team's communication tools: [SLACK/TEAMS/EMAIL/OTHER]
- Budget available for recognition: [NONE/SMALL ($X/month)/MODERATE]
- Team personality: [E.g., introverted engineers who find public praise awkward / extroverted team who loves celebrations]

Design a recognition system that includes:
1. Peer-to-peer recognition rituals (ceremony-based and ongoing)
2. Scrum Master recognition practices for specific achievements
3. Templates for specific recognition messages (completing a tough sprint goal, unblocking a teammate, going above and beyond)
4. How to make recognition feel genuine rather than formulaic
5. Ways to celebrate team wins vs. individual wins
6. A monthly "team wins" summary for the Product Owner and stakeholders
```

---

**Prompt 9: Team Energy & Wellbeing Check-In**

*When to use:* When you're worried about team burnout, unsustainable pace, or when you want to proactively monitor team wellbeing before it becomes a crisis.

```
Help me design a team wellbeing and energy monitoring practice for my Scrum team.

Context:
- Team size: [X] people
- Current pace: [DESCRIBE: e.g., we've been at 110% capacity for 3 sprints, normal pace, post-launch recovery]
- Signals of concern: [DESCRIBE any early warning signs you've noticed]
- Remote or in-person: [TYPE]
- Team's openness to discussing wellbeing: [HIGH/MEDIUM/LOW]
- Organization's culture around work-life balance: [DESCRIBE]

Please help me create:
1. A non-intrusive team energy check-in ritual (weekly or bi-weekly)
2. A "team health thermometer" I can run during retrospectives
3. Specific questions to surface burnout risk without being alarmist
4. How to address a team member who is clearly struggling
5. Sustainable pace practices I can advocate for with the Product Owner
6. How to have a conversation with leadership about workload when the team is at risk
7. Signs that this has moved beyond my scope and needs HR or management involvement
```

---

## 🛡️ PSYCHOLOGICAL SAFETY

---

**Prompt 10: Psychological Safety Assessment**

*When to use:* When you want to measure and improve the level of psychological safety on your team — particularly before designing retros, coaching plans, or team workshops.

```
Help me assess and improve psychological safety on my Scrum team.

Observable behaviors suggesting psychological safety issues:
- [BEHAVIOR 1: e.g., people don't speak up in planning, ideas get shot down]
- [BEHAVIOR 2: e.g., retro feedback is always positive, no one raises real issues]
- [BEHAVIOR 3: e.g., new team member is silent in all meetings]
[Add observations]

Team size: [X] people
Team tenure (how long working together): [X months/years]
Any recent events that may have damaged trust: [DESCRIBE or "none"]
Leadership style of manager above the team: [DESCRIBE]

Please provide:
1. A psychological safety score estimate based on the behaviors described
2. The 4 stages of psychological safety and where this team likely is
3. Three activities I can facilitate to build psychological safety
4. Specific facilitation techniques to create safety in ceremonies
5. How to model psychological safety myself as Scrum Master
6. How to address a team leader or senior member who shuts down others
7. A 60-day psychological safety improvement plan
```

---

**Prompt 11: Safe Space Facilitation Techniques**

*When to use:* Before designing any team session — especially retrospectives and conflict discussions — when you want to ensure everyone feels safe to contribute.

```
Give me a toolkit of facilitation techniques that build psychological safety in team sessions.

Session type: [RETROSPECTIVE/PLANNING/CONFLICT DISCUSSION/TEAM WORKSHOP/OTHER]
Team size: [X] people
Session format: [IN-PERSON/REMOTE/HYBRID]
Known safety challenges: [DESCRIBE: e.g., one senior member dominates, anonymous feedback gets personal, fear of blame]
Session duration: [X minutes]
Team maturity with safety practices: [HAVEN'T TRIED THIS/SOME EXPERIENCE/COMFORTABLE]

Please provide:
1. Three opening rituals that establish psychological safety at the start of sessions
2. Anonymous vs. non-anonymous participation options and when to use each
3. Ground rules language I can propose at the start
4. Specific facilitation moves when someone's idea gets dismissed
5. How to handle "elephant in the room" topics that no one names
6. Closing rituals that reinforce trust and psychological safety
7. How to debrief the safety of the session itself with the team
```

---

## 🎯 COACHING CONVERSATIONS

---

**Prompt 12: GROW Coaching Conversation Planner**

*When to use:* Before a structured coaching conversation with a team member — whether for development, performance improvement, or career growth.

```
Help me plan and facilitate a GROW model coaching conversation.

Coachee role: [E.g., Senior Developer, Junior QA, Product Owner]
Topic to coach on: [DESCRIBE the development area or challenge]
My relationship with this person: [DESCRIBE — peer, direct report, team member I support]
What I know about their perspective: [DESCRIBE]
What I want them to arrive at themselves (not prescribe): [YOUR COACHING GOAL]
Time available for the conversation: [X minutes]

For each stage of GROW, give me:

GOAL:
- 3 questions to help them articulate a clear goal
- How to help them be specific vs. vague

REALITY:
- 4 questions to explore their current situation without judgment
- How to surface blind spots gently

OPTIONS:
- 5 questions to generate creative options
- How to add ideas without taking over

WILL:
- 3 questions to create commitment
- How to establish accountability without micromanaging

Plus: How to open and close the conversation, and what to document afterward.
```

---

**Prompt 13: Team Member Career Development Conversation**

*When to use:* When a team member asks about growth, seems bored or disengaged, or when you want to proactively invest in someone's development.

```
Help me facilitate a career development conversation with a team member.

Team member role: [CURRENT ROLE]
Approximate tenure in this role: [X months/years]
What I've observed about their strengths: [DESCRIBE]
What I've observed about their growth areas: [DESCRIBE]
What I suspect they want from their career: [YOUR GUESS — they may not have said explicitly]
Our organization's growth paths available: [DESCRIBE options: e.g., tech lead, principal engineer, agile coaching]

Help me:
1. Open the conversation in a way that feels genuine, not performative
2. Ask questions to understand their real aspirations (they may be afraid to say)
3. Connect their current work to their growth path
4. Co-create a development plan with actionable steps
5. Identify opportunities within the current sprint/project for growth
6. Set up a follow-up rhythm that doesn't feel like micromanagement
7. Handle the case where their desired path doesn't currently exist in the org
```

---

**Prompt 14: Agile Mindset Coaching Prompt**

*When to use:* When a team member (or the whole team) is stuck in a waterfall or command-and-control mindset and resistant to agile ways of working.

```
Coach me on how to shift a team member's mindset toward agile principles.

The person's role: [E.g., Senior Developer, Project Manager transitioning to Scrum]
Their current mindset pattern: [DESCRIBE specific behaviors: e.g., wants to plan everything upfront, resists changing requirements, hoards information, can't accept uncertainty]
Their background: [E.g., 15 years in waterfall, ex-military, from a compliance-heavy industry]
What they seem to value: [PREDICTABILITY/CONTROL/CERTAINTY/STATUS/OTHER]
My relationship with them: [DESCRIBE]
How long this pattern has been present: [X months]

Please help me:
1. Understand why this person might be resistant (empathy-first analysis)
2. Find the bridges between their values and agile values
3. Have a conversation that meets them where they are
4. Use specific examples from our context to illustrate agile benefits
5. Give them small, low-risk experiments to try
6. Know when to accept the resistance vs. escalate to management
7. Track incremental mindset shifts over time
```

---

## 📉 PERFORMANCE ISSUES

---

**Prompt 15: Underperformance Coaching Framework**

*When to use:* When a team member's output, attitude, or contribution is consistently below expectations and you need to address it without overstepping your role as Scrum Master (not manager).

```
Help me navigate a team member underperformance situation as a Scrum Master.

IMPORTANT: I am the Scrum Master, not this person's direct manager. Help me stay within my appropriate scope.

The situation: [DESCRIBE the performance gap — observable behaviors and outcomes, not personal judgments]
Duration: [How long has this been happening?]
Impact on the team: [DESCRIBE how this affects sprint delivery, team morale, or product quality]
Has the manager been involved? [YES/NO — if yes, what has happened]
My relationship with this team member: [DESCRIBE]
The team member's self-awareness: [DO THEY SEEM AWARE of the issue?]

Help me:
1. Clarify which aspects of this are in my scope (SM) vs. the manager's scope
2. Have a non-threatening coaching conversation to understand what's driving this
3. Offer support and resources within my authority
4. Document observations professionally (in case manager needs to be involved)
5. Protect team morale from the impact of this underperformance
6. Know when and how to loop in the manager
7. Avoid becoming the de facto performance manager when I shouldn't be
```

---

**Prompt 16: High Performer Retention Coaching**

*When to use:* When a high-performing team member shows signs of disengagement, burnout, or potential departure — and you want to retain them.

```
Help me design a retention coaching plan for a high-performing team member who may be at risk of leaving.

Team member role: [ROLE]
Why I think they're at risk: [DESCRIBE warning signs: e.g., LinkedIn activity, less enthusiasm, mentioned wanting more challenge]
Their known motivators: [DESCRIBE what energized them in the past]
Current work they're doing: [DESCRIBE — is it challenging enough?]
What the org can and cannot offer: [DESCRIBE constraints]
My relationship with them: [DESCRIBE]

Please help me:
1. Have a retention conversation without it feeling desperate or pressuring
2. Understand what they actually need (may differ from what I assume)
3. Create a meaningful development opportunity within the current team
4. Advocate for them with leadership (what to say, to whom)
5. Design sprint assignments that better match their skills and growth goals
6. Know what I can promise vs. what I need manager approval for
7. What to do if they confirm they're leaving
```

---

**Prompt 17: New Team Member Integration Plan**

*When to use:* When a new person joins the team and you want to ensure they integrate successfully into the team culture and agile practices — not just technically.

```
Help me create a comprehensive onboarding plan for a new team member joining a Scrum team.

New team member details:
- Role: [ROLE]
- Experience level: [JUNIOR/MID/SENIOR]
- Agile experience: [NONE/SOME/EXPERIENCED]
- Start date: [DATE]
- Joining during sprint: [SPRINT NUMBER, with X days remaining]

Team context:
- Team size: [X] people
- Team maturity: [NEW/EXPERIENCED/HIGH-PERFORMING]
- Current team culture: [DESCRIBE]
- Biggest integration risks: [DESCRIBE: e.g., strong existing cliques, highly technical vocabulary, fast pace]

Create:
1. A 30-60-90 day onboarding plan (agile practices focus)
2. Day 1 agenda for my time with them
3. Questions to ask in week 1 to understand their background and needs
4. How to introduce them at ceremonies without making it awkward
5. A "buddy system" design: who should be paired with them and why
6. Milestones for integration success
7. Early warning signs of struggling integration and how to address them
```

---

**Prompt 18: Team Norms & Working Agreement Facilitator**

*When to use:* When forming a new team, after a difficult team period, or when existing team norms are no longer working.

```
Help me facilitate a team working agreement session.

Context:
- Is this a new team or existing team? [NEW/EXISTING]
- If existing: what has broken down? [DESCRIBE the team norm problems]
- Team size: [X] people
- Remote/in-person/hybrid: [TYPE]
- Session length available: [X minutes]
- Current trust level on the team: [HIGH/MEDIUM/LOW]

Please provide:
1. A facilitated working agreement session agenda
2. The categories to cover: communication, meetings, quality, conflict, decisions, etc.
3. Exact facilitation questions for each category
4. How to move from individual preferences to team agreements (consensus process)
5. How to handle disagreements about norms
6. A template document for the final working agreement
7. How to revisit and update working agreements over time
8. How to address violations of working agreements without becoming the "rule police"
```

---

**Prompt 19: Team Performance Retrospective**

*When to use:* Quarterly or after significant milestones when you want to do a deeper team performance review beyond the standard sprint retrospective.

```
Help me design and facilitate a quarterly team performance retrospective.

Team: [TEAM NAME]
Quarter being reviewed: [Q? YEAR]
Key metrics from the quarter:
- Average velocity: [X] points/sprint
- Sprint goal achievement rate: [X]%
- Defect rate or quality metric: [DESCRIBE]
- Team happiness/satisfaction score (if measured): [SCORE or "not measured"]
- Key releases or milestones achieved: [LIST]
- Key impediments or failures: [LIST]

Please design:
1. A 2-hour quarterly retrospective agenda
2. Metrics presentation framework (how to share data without it feeling like a report card)
3. Three deeper reflection activities (not standard sprint retro activities)
4. A team strengths and growth areas synthesis exercise
5. How to set team-level OKRs or improvement goals for next quarter
6. A celebration moment for meaningful achievements
7. How to share the outcomes with the team's manager and stakeholders
```

---

**Prompt 20: Scrum Master Self-Reflection & Development**

*When to use:* Monthly or after a particularly challenging sprint when you want to reflect on your own effectiveness as a Scrum Master and identify growth areas.

```
Act as an executive coach helping me reflect on my effectiveness as a Scrum Master and identify development areas.

My experience as a Scrum Master: [X years/months]
Current team context: [BRIEF DESCRIPTION]
Biggest challenge I'm facing right now: [DESCRIBE]
Recent wins I'm proud of: [DESCRIBE 2-3]
Feedback I've received (positive or critical): [DESCRIBE or "none formally"]
What I feel I'm weakest at: [DESCRIBE honestly]
What I feel I'm strongest at: [DESCRIBE]

Please help me:
1. Apply a Scrum Master competency framework to assess where I am
2. Identify my top 2-3 growth edges based on what I've described
3. Create a personal development plan for the next 90 days
4. Suggest resources (books, courses, communities) for my specific development areas
5. Design a personal retrospective practice I can do monthly
6. Define what "leveling up" as a Scrum Master looks like for me specifically
7. Identify a mentor or coaching relationship I might seek out
```

---

*End of Team Coaching Prompts — 20 prompts total*
