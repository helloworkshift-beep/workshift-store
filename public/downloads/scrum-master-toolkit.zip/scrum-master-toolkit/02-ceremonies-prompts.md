# 02 — Ceremonies Prompts
## Sprint Planning · Retrospectives · Daily Standups · Sprint Reviews · Backlog Refinement

---

> **25 prompts** to facilitate every Scrum ceremony with confidence, structure, and professionalism.

---

## 🗓️ SPRINT PLANNING

---

**Prompt 1: Sprint Planning Session Designer**

*When to use:* 24–48 hours before sprint planning when you need to structure the full session agenda, time-boxes, and facilitation flow.

```
You are an experienced Scrum Master facilitating a sprint planning session. 
Help me design a complete sprint planning agenda for the following context:

Team: [TEAM NAME]
Team size: [NUMBER] people ([ROLES, e.g., 4 developers, 1 QA, 1 designer])
Sprint length: [1/2/3] weeks
Sprint number: [NUMBER]
Sprint start date: [DATE]
Available capacity this sprint: [HOURS or STORY POINTS]
Key constraints or considerations: [E.g., 2 people on vacation, major release this sprint, new team member joining]
Product goal focus area: [BRIEF DESCRIPTION OF WHAT YOU'RE BUILDING]

Please provide:
1. A full timed agenda for the sprint planning session
2. Facilitation tips for each agenda item
3. Questions to ask the team at each stage
4. Common pitfalls to watch for in this type of planning session
5. A sprint goal template we can fill in together
```

---

**Prompt 2: Sprint Goal Crafter**

*When to use:* During or after sprint planning when the team struggles to articulate a clear, meaningful sprint goal that goes beyond "finish the stories."

```
Act as a Scrum Master helping a development team craft a powerful sprint goal. 

Our team is working on: [PRODUCT/FEATURE DESCRIPTION]
This sprint's selected backlog items focus on: [THEMES OR EPICS]
The business outcome we're trying to achieve: [BUSINESS OBJECTIVE]
Our stakeholders care most about: [STAKEHOLDER PRIORITY]
Sprint length: [LENGTH]

Help us craft:
1. Three sprint goal options (ranging from conservative to ambitious)
2. For each option, explain the "why" that connects to business value
3. A test for each goal: "How will we know we achieved this?"
4. One sentence to communicate this goal to non-technical stakeholders

Format each goal using the structure: "By the end of this sprint, [WHO] can [DO WHAT] so that [VALUE]."
```

---

**Prompt 3: Capacity Planning Calculator**

*When to use:* Before sprint planning when you need to calculate realistic team capacity accounting for meetings, time off, and focus time.

```
Help me calculate and present sprint capacity for my team.

Sprint duration: [X] weeks ([X] working days)
Team members and their availability:
- [PERSON 1 ROLE]: [X]% available this sprint (reason: [e.g., vacation days 3-5])
- [PERSON 2 ROLE]: [X]% available this sprint
- [PERSON 3 ROLE]: [X]% available this sprint
- [Add more as needed]

Known events that consume capacity this sprint:
- Sprint ceremonies total: approximately [X] hours per person
- [OTHER MEETINGS/EVENTS and hours]
- [COMPANY EVENTS, all-hands, etc.]

Our team's historical velocity: [X] story points per sprint
Our team's definition of "available hours" for dev work: [X] hours/day per person

Please:
1. Calculate total available person-days and recommended story point capacity
2. Flag any risks with this sprint's capacity
3. Recommend a realistic commitment range (min/max story points)
4. Suggest how to communicate capacity constraints to the Product Owner
```

---

**Prompt 4: Backlog Item Breakdown for Planning**

*When to use:* During sprint planning when a user story is too large or unclear to confidently commit to. Use to break it down with the team.

```
I'm a Scrum Master helping my team break down a large or unclear user story during sprint planning.

The user story: [PASTE USER STORY HERE]
Current story point estimate: [POINTS or "not yet estimated"]
Acceptance criteria (if any): [PASTE OR DESCRIBE]
Technical context: [BRIEF DESCRIPTION of how this fits in the system]
Team's concern or confusion: [WHY the team is struggling with this story]

Please help me:
1. Identify why this story might be too large (INVEST criteria analysis)
2. Suggest 3–5 ways to vertically slice this story into smaller, independently valuable pieces
3. Draft acceptance criteria for each smaller story
4. Provide facilitation questions I can ask the team to help them split it themselves
5. Flag any hidden dependencies or risks we should discuss
```

---

**Prompt 5: Sprint Planning Retrospective (Planning for Planning)**

*When to use:* After a sprint planning that felt inefficient, ran over time, or left the team uncertain. Use to improve the next planning session.

```
Our sprint planning session just ended and I want to reflect on how to improve it. 
Act as an agile coach giving me honest, constructive feedback.

What happened:
- Session length: [PLANNED vs ACTUAL duration]
- Number of attendees: [X]
- Stories discussed: [X] stories, committed to [X]
- Problems we encountered: [DESCRIBE: e.g., ran out of time, too much debate on estimates, PO wasn't prepared]
- Team energy/engagement level: [HIGH/MEDIUM/LOW] — [DESCRIBE]
- Sprint goal clarity at the end: [CLEAR/SOMEWHAT CLEAR/UNCLEAR]

Please give me:
1. A root cause analysis of what went wrong
2. Three concrete changes to make for next sprint planning
3. Facilitation techniques to address the specific problems I described
4. A pre-planning checklist for both me (SM) and the Product Owner
5. How to bring this up constructively with the team
```

---

## 🔄 RETROSPECTIVES

---

**Prompt 6: Retrospective Format Selector**

*When to use:* When you want to move beyond the standard "What went well / What didn't / Actions" format and need a fresh retrospective structure.

```
I'm a Scrum Master planning a retrospective and want to try a new format. Help me select and customize the best retrospective format for our situation.

Team context:
- Team size: [NUMBER] people
- Time together as a team: [E.g., 6 months, newly formed, 2 years]
- Current team mood/dynamics: [DESCRIBE: e.g., burnt out after a tough sprint, excited about a big launch, conflict between two members]
- Last retrospective format used: [FORMAT NAME or "standard start/stop/continue"]
- Key issue we need to address this sprint: [MAIN THEME: e.g., communication, technical debt, deployment issues]
- Retrospective time available: [X minutes]
- Remote or in-person: [REMOTE/IN-PERSON/HYBRID]

Please:
1. Recommend the top 3 retrospective formats for our situation with a brief explanation of each
2. For your top recommendation, provide a complete facilitation script with timing
3. Include the exact prompts/questions to ask for each activity
4. Suggest digital tools if we're remote
5. Provide 3–5 action item templates we can fill in together
```

---

**Prompt 7: Retrospective Facilitator Script**

*When to use:* The day before or day of your retrospective. Use to generate a word-for-word facilitation script you can follow confidently.

```
Write me a complete, word-for-word facilitation script for a [X]-minute retrospective using the [FORMAT NAME, e.g., 4Ls, Sailboat, Mad Sad Glad, Rose Bud Thorn] format.

Team context:
- Team: [TEAM NAME], [X] people
- Sprint just completed: Sprint [NUMBER]
- Notable events this sprint: [DESCRIBE: e.g., we hit our sprint goal, we had a major bug in production, we welcomed a new team member]
- Main tension or theme to address: [DESCRIBE]
- Team engagement history: [E.g., tends to be quiet, very vocal, one dominant voice]

Script should include:
1. Opening and check-in activity (with exact words to say)
2. Setting the stage / retrospective prime directive
3. Transition words between each phase
4. Facilitator prompts when the room goes silent
5. How to manage dominant voices and draw out quiet members
6. Closing and action item commitment ritual
7. What to do if the team gets stuck on blame or negativity

Use natural, conversational language — this is what I'll actually say out loud.
```

---

**Prompt 8: Action Item Accountability Generator**

*When to use:* After a retrospective, when you need to document action items clearly and create a follow-up system that actually works.

```
Help me create a structured action item tracking system from our retrospective.

Retrospective themes and raw action items discussed:
[PASTE OR DESCRIBE THE ACTION ITEMS THE TEAM IDENTIFIED]

Team size: [X] people
Sprint length: [X] weeks
Where we track work: [JIRA/TRELLO/AZURE DEVOPS/NOTION/OTHER]

For each action item, help me:
1. Rewrite it as a SMART action item (Specific, Measurable, Assignable, Realistic, Time-bound)
2. Identify the right owner (role, not name)
3. Define what "done" looks like
4. Set a check-in point (mid-sprint or next retro)

Then provide:
5. A template for how I'll open the next retrospective reviewing these items
6. A gentle follow-up message I can send mid-sprint to the action item owners
7. Criteria for closing vs. carrying over an action item
```

---

**Prompt 9: Difficult Retrospective Recovery**

*When to use:* After a retrospective that went sideways — devolved into blame, had conflict, or ended with no actionable outcomes.

```
I just facilitated a retrospective that didn't go well and I need help processing what happened and planning a recovery.

What happened: [DESCRIBE in detail — e.g., two team members argued, the team vented for 45 minutes with no solutions, everyone was disengaged]
Root cause I suspect: [YOUR HYPOTHESIS]
Number of people involved: [X]
How the session ended: [DESCRIBE]
Team relationships after the session: [DESCRIBE current tension level]

Help me:
1. Analyze what likely went wrong from a facilitation perspective (be honest)
2. Determine whether I need a follow-up session or can address this next sprint
3. Draft a message to send to the team acknowledging the session
4. Design a repair activity for the next retrospective
5. Identify coaching techniques to use with specific individuals (describe as "the dominant voice," "the withdrawn member," etc.)
6. Reflect on what I as facilitator could do differently
```

---

**Prompt 10: Remote Retrospective Engagement Pack**

*When to use:* When your distributed team's retrospectives feel flat, participation is low, or you're getting the same 3 people doing all the talking.

```
Design a high-engagement remote retrospective experience for my distributed team.

Team details:
- Team size: [X] people
- Time zones represented: [LIST TIME ZONES]
- Video platform: [ZOOM/TEAMS/MEET]
- Collaboration tools available: [MIRO/MURAL/FIGMA/JAMBOARD/etc.]
- Main engagement problems: [DESCRIBE: e.g., camera fatigue, people multitask, quiet members never speak]
- Sprint theme/focus: [WHAT THIS RETRO SHOULD FOCUS ON]

Please provide:
1. A complete [X]-minute remote retrospective design with timing
2. Specific activities that work well for remote teams (not just online versions of in-person activities)
3. Techniques to increase camera and participation (warm-up activities, voting mechanics, etc.)
4. How to handle time zone challenges
5. A digital board template description I can set up in [TOOL]
6. Energy management tips for back-to-back video calls
```

---

## ☀️ DAILY STANDUP

---

**Prompt 11: Standup Health Diagnostic**

*When to use:* When your daily standup feels like a status report to you rather than a team coordination meeting, runs over time, or has low energy.

```
Act as an agile coach. Diagnose the health of our daily standup and give me a fix plan.

Current standup format: [DESCRIBE: e.g., each person answers 3 questions in round-robin]
Average duration: [X minutes] (timebox is [X minutes])
Number of attendees: [X]
Remote or in-person: [REMOTE/IN-PERSON/HYBRID]
Problems I'm observing:
- [PROBLEM 1: e.g., people report to me, not each other]
- [PROBLEM 2: e.g., it regularly runs 20+ minutes]
- [PROBLEM 3: e.g., same people talk, others say "no blockers" and zone out]

Team maturity: [NEW TEAM/EXPERIENCED/MIXED]

Please give me:
1. Root cause analysis for each problem I described
2. Three alternative standup formats to try
3. Facilitation experiments to run over the next 2 weeks
4. Exact phrases to use when redirecting off-topic conversations
5. How to facilitate the team into owning their own standup (without me)
6. Metrics to track whether the standup improves
```

---

**Prompt 12: Standup Facilitation Scripts**

*When to use:* When you want variety in how you open and run standups to keep energy high and prevent routine from killing engagement.

```
Write me 10 different standup opening scripts for a Scrum Master to use on different days. 
Each should be under 30 seconds when read aloud.

Context:
- Team size: [X] people
- Team personality: [DESCRIBE: e.g., engineering-focused, loves data, creative/design team, customer-service oriented]
- Current sprint phase: [EARLY/MID/END OF SPRINT]
- Team energy lately: [HIGH/MEDIUM/LOW]

For each opening, include:
1. The exact words to say
2. The transition question to kick off the first speaker
3. When to use this particular opening (mood/context it fits best)

Vary the tone: some energetic, some reflective, some humor-based, some data-driven.
After the 10 openings, add 5 "redirect phrases" I can use when the standup starts becoming a problem-solving session.
```

---

**Prompt 13: Walking the Board Facilitator Guide**

*When to use:* When transitioning from person-by-person standups to a board-focused format, or when you want to coach the team to focus on work rather than individuals.

```
Help me transition our daily standup from a round-robin update format to a "walk the board" format.

Current setup:
- Board tool: [JIRA/TRELLO/AZURE DEVOPS/PHYSICAL BOARD/OTHER]
- Sprint board columns: [LIST YOUR COLUMNS, e.g., To Do, In Progress, In Review, Done]
- Team size: [X] people
- Current pain points with round-robin format: [DESCRIBE]

Please provide:
1. A step-by-step explanation of "walking the board" I can share with my team
2. The exact facilitation script for leading a walk-the-board standup
3. Questions to ask at each board column
4. How to identify bottlenecks and blocked items during the walk
5. How to keep the whole standup under [X] minutes
6. Common resistance points from team members and how to address them
7. A 2-week transition plan from old format to new
```

---

## 📊 SPRINT REVIEW

---

**Prompt 14: Sprint Review Agenda Designer**

*When to use:* Before each sprint review to design an engaging, stakeholder-focused agenda that showcases value — not just features.

```
Design a complete sprint review agenda for the following context:

Team: [TEAM NAME]
Sprint number: [NUMBER]
Sprint goal: [SPRINT GOAL TEXT]
Was sprint goal achieved? [YES/NO/PARTIALLY — explain]
Sprint review duration: [X minutes]
Expected attendees: [DESCRIBE: e.g., Product Owner, 3 stakeholders from marketing, 2 executives, full dev team]
Items completed this sprint: [LIST KEY COMPLETED ITEMS]
Items not completed (if any): [LIST + BRIEF REASON]
Key decisions needed from stakeholders today: [DESCRIBE]

Please create:
1. A timed sprint review agenda
2. Opening statement to set context and expectations
3. A demo script structure for each completed item
4. Questions to solicit meaningful stakeholder feedback (not just "looks good!")
5. How to handle incomplete work professionally
6. Closing summary template that previews the next sprint
7. How to keep executives engaged without losing technical depth
```

---

**Prompt 15: Stakeholder Feedback Facilitator**

*When to use:* During or after a sprint review when you need to draw out meaningful feedback rather than just "thumbs up" responses.

```
I'm a Scrum Master facilitating feedback during a sprint review. Help me design questions and activities to get genuine, actionable stakeholder feedback.

What we're demoing: [DESCRIBE THE FEATURES/INCREMENTS being shown]
Stakeholder types in the room: [DESCRIBE: e.g., business owner, end users, compliance team, sales]
Time available for feedback: [X minutes]
A specific decision we need their input on: [DESCRIBE]
Previous feedback quality: [DESCRIBE: e.g., stakeholders tend to say "looks great" without specific input]

Please provide:
1. Five open-ended feedback questions tailored to each stakeholder type
2. A structured feedback activity (e.g., silent brainstorm + dot voting) with facilitation guide
3. How to synthesize feedback in real time during the session
4. Phrases to use when feedback is vague or overly positive
5. How to document and share back stakeholder feedback to the team
6. Follow-up questions for after the meeting
```

---

## 🗂️ BACKLOG REFINEMENT

---

**Prompt 16: Backlog Refinement Session Facilitator**

*When to use:* Before or during backlog refinement when you want a structured approach to making stories sprint-ready.

```
Act as a Scrum Master facilitating a backlog refinement session. Help me design and run an effective session.

Team context:
- Team size: [X] people
- Refinement session length: [X minutes]
- Stories to review: [NUMBER] items
- Refinement cadence: [WEEKLY/BI-WEEKLY/AS-NEEDED]
- Current backlog health issues: [DESCRIBE: e.g., stories are too large, poor acceptance criteria, unclear priorities]
- Product Owner engagement: [HIGH/MEDIUM/LOW — describe]

Please provide:
1. A timed refinement session agenda
2. A "story readiness checklist" I can use to evaluate each item (INVEST + team-specific criteria)
3. Facilitation techniques for estimating quickly (Planning Poker tips, T-shirt sizing guide)
4. Questions to ask the PO when stories are unclear
5. How to handle rabbit holes and time-boxing story discussions
6. A "definition of ready" template the team can adopt
7. How to track and report on backlog health over time
```

---

**Prompt 17: User Story Quality Reviewer**

*When to use:* Before refinement when you want to pre-review stories and flag issues before the team wastes time on poorly formed items.

```
Act as an expert agile coach reviewing user stories for quality and sprint readiness.

Please review the following user stories and for each one:
1. Score it against INVEST criteria (Independent, Negotiable, Valuable, Estimable, Small, Testable)
2. Identify missing or weak acceptance criteria
3. Flag any hidden assumptions or dependencies
4. Suggest specific improvements to the story text
5. Rate sprint readiness: READY / NEEDS WORK / SEND BACK

User stories to review:
[PASTE YOUR USER STORIES HERE — one per section]

Context about our system/product: [BRIEF DESCRIPTION]
Our team's definition of ready: [PASTE YOUR DEFINITION OF READY or "not yet defined"]
Sprint length: [X weeks]
```

---

**Prompt 18: Estimation Calibration Workshop**

*When to use:* When your team's estimates are consistently off — either systematically too optimistic or too pessimistic — and you want to recalibrate.

```
Help me design and facilitate an estimation calibration workshop for my Scrum team.

The problem: [DESCRIBE: e.g., we consistently underestimate by 30%, we have no reference stories, we argue about points rather than complexity]
Team size: [X] people
Estimation method currently used: [PLANNING POKER/T-SHIRT SIZING/BUCKETS/NO METHOD]
Sprint length: [X weeks]
Average velocity: [X points] over last [X] sprints
Stories typically estimated per sprint: [NUMBER]

Please provide:
1. A 60-minute calibration workshop agenda
2. How to establish reference/baseline stories
3. A facilitated process for building consensus on what 1, 3, 5, 8, 13 points "feel like"
4. Activities to align on complexity vs. effort vs. time
5. How to handle outliers during planning poker
6. A post-workshop document summarizing our team's estimation guidelines
7. How to measure whether calibration improved over the next 3 sprints
```

---

**Prompt 19: "Definition of Done" Builder**

*When to use:* When your team's Definition of Done is missing, outdated, inconsistently applied, or causing quality issues at release time.

```
Help me facilitate a "Definition of Done" (DoD) workshop with my Scrum team.

Current situation: [E.g., we have no DoD / our DoD is outdated / team members apply it inconsistently]
Product type: [WEB APP/MOBILE APP/API/DATA PIPELINE/EMBEDDED SOFTWARE/OTHER]
Current quality pain points: [DESCRIBE: e.g., bugs found in production, failed UAT, missing documentation]
Team roles involved: [LIST: e.g., developers, QA, UX designer, DevOps]
Stakeholder quality expectations: [DESCRIBE]
Compliance or regulatory requirements (if any): [DESCRIBE or "none"]

Please provide:
1. A structured DoD workshop agenda (45–60 minutes)
2. A starter DoD checklist tailored to our product type
3. Facilitation questions to get team buy-in (not just "I'm telling you this is the DoD")
4. How to differentiate DoD from Acceptance Criteria
5. How to layer DoD: story level vs. sprint level vs. release level
6. A process to review and evolve the DoD over time
7. How to enforce the DoD without becoming the "quality police"
```

---

**Prompt 20: Sprint Velocity Analysis & Forecasting**

*When to use:* When preparing for sprint planning and needing to present data-driven capacity recommendations, or when stakeholders ask about delivery predictability.

```
Help me analyze our sprint velocity data and create a forecast for upcoming sprints.

Velocity data (last [X] sprints):
Sprint [N-5]: [X] points
Sprint [N-4]: [X] points
Sprint [N-3]: [X] points
Sprint [N-2]: [X] points
Sprint [N-1]: [X] points
Sprint [N]: [X] points

Factors affecting recent sprints: [E.g., Sprint N-2 had 2 people on vacation, Sprint N had a major incident]
Upcoming known capacity impacts: [DESCRIBE]
Total backlog remaining: [X] points (approximate)
Key release or milestone date: [DATE]

Please provide:
1. Statistical analysis: average, median, and range of our velocity
2. A recommended capacity range for the next sprint
3. A release forecast: when we might complete the current backlog at current velocity
4. How to present this data to a Product Owner who wants a specific date commitment
5. Risk factors that could affect the forecast
6. Visualizations to suggest (I'll create them in [EXCEL/SHEETS/JIRA/other])
```

---

**Prompt 21: Pre-Sprint Planning Checklist Generator**

*When to use:* At the end of each sprint when you want to ensure everything is in place before the next planning session begins.

```
Create a comprehensive pre-sprint planning checklist for a Scrum Master.

Our sprint planning is: [DATE and TIME]
Sprint length: [X weeks]
Team size: [X] people
Known challenges for next sprint: [DESCRIBE]
Product Owner's readiness: [DESCRIBE: e.g., backlog is groomed / PO hasn't prioritized yet]

Generate a checklist covering:
1. Backlog readiness (stories, acceptance criteria, estimates)
2. Team capacity confirmation
3. Dependency identification and resolution
4. Technical readiness (environments, tooling, access)
5. Stakeholder alignment on sprint goal direction
6. My facilitation preparation as Scrum Master
7. Room/tool setup for the planning session

For each checklist item, include:
- What "done" looks like
- Who is responsible (SM, PO, Dev Team)
- When it should be completed before planning
```

---

**Prompt 22: Sprint Kickoff Announcement**

*When to use:* At the start of each sprint when you want to energize the team and communicate the sprint goal clearly to everyone, including stakeholders.

```
Write a sprint kickoff announcement for our team and stakeholders.

Sprint number: [NUMBER]
Sprint dates: [START DATE] to [END DATE]
Sprint goal: [SPRINT GOAL TEXT]
Key stories we're committing to: [LIST 3-5 MAIN ITEMS]
Team capacity: [X]% (any notable absences or constraints)
Key dependencies or risks: [DESCRIBE or "none identified"]
Exciting context or milestone: [E.g., "This sprint completes our MVP feature set" or "First sprint with our new QA process"]

Write two versions:
1. A Slack/Teams message for the development team (casual, energizing, under 150 words)
2. A stakeholder email (professional, value-focused, under 200 words)

For both, include the sprint goal prominently and end with a clear call-to-action or what stakeholders can expect.
```

---

**Prompt 23: Mid-Sprint Health Check**

*When to use:* At the midpoint of a sprint when you want to assess whether the team is on track or needs to adjust scope, effort, or focus.

```
Help me conduct a structured mid-sprint health check for my team.

Sprint context:
- Sprint number: [NUMBER]
- Days completed: [X] of [X total days]
- Story points committed: [X]
- Story points completed so far: [X]
- Story points in progress: [X]
- Blockers currently open: [NUMBER and brief description]
- Sprint goal status: [ON TRACK/AT RISK/OFF TRACK]
- Team observations: [DESCRIBE any behavioral or dynamic issues you've noticed]

Please provide:
1. An assessment of sprint health based on the data
2. Questions to ask in today's standup to surface hidden risks
3. Decision framework: should we scope-adjust, get help, or push forward?
4. How to communicate mid-sprint adjustments to the Product Owner
5. Team support interventions if you spot signs of overload or disengagement
6. A one-paragraph summary I can share in our team channel
```

---

**Prompt 24: Sprint Closeout Checklist**

*When to use:* In the final 1–2 days of a sprint to ensure all deliverables, documentation, and handoffs are complete before the sprint ends.

```
Create a sprint closeout checklist and process for my Scrum team.

Sprint ending: [DATE]
What was completed: [LIST COMPLETED ITEMS]
What was not completed: [LIST INCOMPLETE ITEMS + REASON]
Any production releases this sprint: [YES/NO — if yes, describe]
Technical debt incurred: [DESCRIBE or "none documented"]
Team feedback (informal): [DESCRIBE team's mood/observations]

Generate:
1. A technical closeout checklist (code merged, tests passing, documentation updated, etc.)
2. A product closeout checklist (PO acceptance, demo prep, stakeholder communications)
3. A process to handle incomplete stories (carry forward vs. return to backlog)
4. How to capture and communicate sprint metrics (velocity, goal achievement, quality)
5. A retrospective priming activity I can assign before the retro
6. A message to the team acknowledging the sprint's work
```

---

**Prompt 25: Sprint Review Demo Script Builder**

*When to use:* Before the sprint review when team members are nervous about demoing or when past demos have been disorganized or too technical.

```
Help me create demo scripts for our sprint review.

Sprint review date: [DATE]
Demo audience: [DESCRIBE: e.g., executive sponsors, end users, mixed technical/business]
Total demo time available: [X minutes]
Items to demo:
1. [FEATURE/STORY 1 — brief description]
2. [FEATURE/STORY 2 — brief description]
3. [FEATURE/STORY 3 — brief description]
[Add more as needed]

Who is demoing each item: [ROLE, e.g., "Developer 1," "Designer," "QA Lead"]
Technical level of audience: [TECHNICAL/MIXED/NON-TECHNICAL]

For each demo item, create:
1. A 2–3 minute demo script (what to say, what to click/show)
2. The business value statement to lead with (not technical details)
3. A transition line to the next demo
4. Anticipated questions and suggested answers
5. What NOT to show (common demo anti-patterns)

Also provide: an opening script for whoever kicks off the review, and a closing script for the Scrum Master.
```

---

*End of Ceremonies Prompts — 25 prompts total*
