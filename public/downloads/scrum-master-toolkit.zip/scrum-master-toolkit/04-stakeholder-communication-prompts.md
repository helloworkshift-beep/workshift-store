# 04 — Stakeholder Communication Prompts
## Status Updates · Velocity Reports · Impediment Escalations · Release Communications · Executive Summaries

---

> **20 prompts** to help you communicate with clarity, credibility, and confidence across every stakeholder audience.

---

## 📊 STATUS UPDATES

---

**Prompt 1: Sprint Status Update Generator**

*When to use:* Mid-sprint or end-of-sprint when you need to communicate progress to stakeholders who weren't in the sprint review.

```
Write a professional sprint status update for stakeholders.

Sprint details:
- Sprint number: [NUMBER]
- Sprint dates: [START] to [END]
- Sprint goal: [SPRINT GOAL TEXT]
- Sprint goal status: [ON TRACK / AT RISK / ACHIEVED / NOT ACHIEVED]
- Story points committed: [X]
- Story points completed: [X]
- Stories completed: [LIST KEY COMPLETED ITEMS — 3-5 bullet points]
- Stories in progress: [LIST]
- Stories not started: [LIST]
- Current blockers: [DESCRIBE or "none"]
- Key decisions needed from stakeholders: [DESCRIBE or "none"]

Write two versions:
1. A concise Slack/Teams status update (under 200 words, use emojis sparingly, bullet points)
2. A formal email status update (under 400 words, professional tone, suitable for email to VP/Director level)

Both versions should lead with the sprint goal status, highlight value delivered (not just tasks), and end with a clear call-to-action or next steps.
```

---

**Prompt 2: Sprint Status Dashboard Narrative**

*When to use:* When your organization uses a dashboard for tracking (Jira, Azure DevOps, etc.) and you need to write the narrative commentary that gives the numbers context.

```
Write narrative commentary for our sprint status dashboard.

Dashboard metrics this sprint:
- Burndown chart status: [DESCRIBE: e.g., on track, behind by 20%, ahead of pace]
- Velocity (this sprint vs. average): [X points this sprint / [X] average]
- Stories completed vs. committed: [X of Y]
- Bug count: [X open / X closed this sprint]
- Technical debt stories worked: [X]
- Team capacity used: [X]%
- Deployment frequency: [X deploys this sprint]

Notable events that explain the data: [DESCRIBE: e.g., we had a production incident on day 3, 2 team members were sick]
The story behind the numbers: [YOUR INTERPRETATION of what's really happening]
Key message you want stakeholders to take away: [DESCRIBE]

Write:
1. A 100-word executive summary for the dashboard header
2. Commentary for each key metric (2-3 sentences each explaining the "so what")
3. Risk statement: what stakeholders should watch for next sprint
4. An optional positive highlight to balance any negative metrics
```

---

**Prompt 3: Weekly Progress Email Template**

*When to use:* When you send a recurring weekly update to a broader stakeholder group and want a consistent, credible format that people actually read.

```
Create a reusable weekly progress email template for a Scrum team.

Stakeholder audience: [DESCRIBE: e.g., product leadership, business sponsors, cross-functional partners]
Their main concerns: [DESCRIBE what they care about most: e.g., release dates, budget, feature completion]
Format preferences: [E.g., short bullets they can skim, narrative they read on mobile, visual dashboard link]
Our product: [BRIEF DESCRIPTION]
Cadence: [WEEKLY/BI-WEEKLY]

Create a template with:
1. Subject line formula (fill-in-the-blank format)
2. Header section: sprint status in one sentence + RAG indicator (Red/Amber/Green)
3. "What we completed" section (bullet format, value-focused not task-focused)
4. "What we're working on" section
5. "What's at risk / blocked" section with a clear ask if applicable
6. "Coming up" section (next sprint preview)
7. Optional: Team spotlight or learning of the week
8. Footer with links, meeting schedule, or "questions?" prompt

Include 3 example versions: one Green sprint, one Amber sprint, one Red sprint with escalation.
```

---

**Prompt 4: Scope Change Communication**

*When to use:* When the team needs to adjust sprint scope mid-sprint and you need to communicate this to stakeholders without creating panic or eroding trust.

```
Help me communicate a mid-sprint scope change to stakeholders.

What is changing: [DESCRIBE what is being removed, reduced, or swapped in the sprint]
Why it's changing: [DESCRIBE the reason — be honest but diplomatic]
Impact on sprint goal: [DESCRIBE: does the sprint goal still stand? Is it at risk?]
Impact on the release or roadmap: [DESCRIBE downstream effects]
Stakeholder who will be most affected: [ROLE and why they'll care]
Stakeholder who approved or is aware: [DESCRIBE who knows]
My recommended framing: [HOW you want to present this]

Write:
1. A message to the Product Owner confirming the scope change and rationale
2. A stakeholder communication email that's transparent without being alarming
3. Talking points for a verbal conversation with the most affected stakeholder
4. How to document the scope change for sprint records
5. Suggested language for the sprint review to address the change
```

---

**Prompt 5: Release Date Risk Communication**

*When to use:* When data suggests a release date is at risk and you need to proactively communicate this to leadership before they discover it themselves.

```
Help me proactively communicate a release date risk to leadership.

Original release date committed: [DATE]
Current forecast based on velocity: [DATE RANGE]
Gap: [X weeks/days later than committed]
Root cause of the risk: [DESCRIBE: e.g., scope grew 30%, velocity is lower than expected, dependencies not resolved]
Mitigation options available:
1. [OPTION 1: e.g., reduce scope to hit original date]
2. [OPTION 2: e.g., add resources]
3. [OPTION 3: e.g., negotiate new date]
Business impact of a delayed release: [DESCRIBE: e.g., customer commitments, revenue, market window]
Who I'm communicating to: [ROLE: e.g., VP Product, C-suite, external client]

Help me create:
1. A one-page risk summary document (headline, situation, options, recommendation)
2. A meeting request email to set up the conversation
3. Talking points for the in-person discussion
4. How to present the options without seeming like I'm making excuses
5. How to present the recommendation professionally
6. Follow-up communication after the decision is made
```

---

## 📈 VELOCITY & METRICS REPORTS

---

**Prompt 6: Velocity Report Narrative**

*When to use:* When stakeholders ask about team velocity, want to understand capacity trends, or you're presenting metrics in a quarterly business review.

```
Help me write a velocity report narrative for stakeholders.

Velocity data:
[PASTE LAST 6-10 SPRINTS OF VELOCITY DATA]
Example format:
Sprint 20: 38 pts | Sprint 21: 45 pts | Sprint 22: 41 pts | Sprint 23: 29 pts (2 sick) | Sprint 24: 44 pts | Sprint 25: 47 pts

Notable context for each sprint (if relevant):
[DESCRIBE any anomalies: team changes, incidents, holidays, large stories]

Audience: [E.g., VP of Engineering, Product Director, external client, executive sponsor]
Their question or concern: [WHAT THEY WANT TO KNOW: e.g., "Why are we slower than last quarter?" / "Can we do more?"]

Write:
1. A velocity trend analysis in plain English (not just numbers)
2. Key insights: what the data actually means for delivery
3. Explanation of anomaly sprints without making excuses
4. A forward-looking forecast based on the trend
5. Recommended velocity range to use for planning purposes
6. One clear "so what" message for executives
7. Answers to the 3 most likely questions they'll ask
```

---

**Prompt 7: Agile Metrics Presentation Builder**

*When to use:* Before a quarterly business review, program increment review, or leadership presentation where you need to showcase team performance through metrics.

```
Help me build a metrics presentation for [AUDIENCE: e.g., executive team, steering committee, program leadership].

Metrics available:
- Velocity trend: [DESCRIBE or paste data]
- Sprint goal achievement rate: [X]% over last [X] sprints
- Lead time (idea to production): [X days average]
- Cycle time: [X days average]
- Defect rate: [X bugs per sprint / X% escaped to production]
- Team happiness score: [SCORE or "not measured"]
- Deployment frequency: [X per sprint/week/month]

Business context:
- What the team shipped in this period: [LIST KEY RELEASES]
- Business outcomes achieved: [DESCRIBE]
- Key improvements made: [DESCRIBE process/quality improvements]

Please create:
1. A presentation outline (5-7 slides)
2. The "story" to tell with these metrics (not just data, but narrative)
3. Slide titles and key messages for each slide
4. How to handle metrics that aren't great
5. Anticipate the top 5 executive questions and prepare answers
6. A one-page handout summary
```

---

**Prompt 8: ROI of Agile Report**

*When to use:* When leadership questions the value of agile practices or when you need to justify Scrum Master overhead, agile tooling, or training investments.

```
Help me build a compelling ROI case for agile practices in our organization.

Our context:
- Organization type: [E.g., software company, enterprise IT, startup]
- How long we've been practicing agile: [X months/years]
- Team size we support: [X people across X teams]
- Audience skeptics: [WHO is questioning the value and what they're saying]

Data I have available:
- Before agile: [DESCRIBE: e.g., waterfall project average timeline, defect rates, cost overruns]
- After agile: [DESCRIBE current metrics]
- Other relevant data: [DESCRIBE]

If I don't have comparative data, indicate that and work with estimates.

Help me build:
1. A compelling ROI narrative (time saved, quality improved, delivery speed)
2. How to quantify "soft" benefits (team morale, customer satisfaction, adaptability)
3. Analogies and examples I can use with non-technical executives
4. A one-page summary document
5. Answers to common objections: "We could achieve this without agile," "Scrum Masters are expensive," etc.
6. Recommended metrics to start tracking now for future ROI reports
```

---

## 🚨 IMPEDIMENT ESCALATIONS

---

**Prompt 9: Impediment Escalation Email**

*When to use:* When you need to formally escalate a blocker to management via written communication and want to be perceived as solution-oriented rather than complaining.

```
Write a professional impediment escalation email.

To: [ROLE of recipient, e.g., Engineering Director]
From: [Your role]
Subject line: Suggest one

The impediment: [DESCRIBE clearly and specifically]
Business impact: [QUANTIFY if possible: e.g., blocking X sprint stories worth Y points, delaying release by Z weeks, costing an estimated $X in rework]
Duration unresolved: [X days/weeks]
What I've already tried: [LIST actions taken]
Why it's beyond my authority to resolve: [EXPLAIN]
What I need from the recipient: [SPECIFIC ASK — decision, action, introduction, resources]
Desired resolution timeline: [BY WHEN]

Write a professional email that:
1. Opens with the business impact (not the complaint)
2. Provides clear, fact-based context (no blame)
3. Shows what you've already done
4. Presents 2-3 solution options with your recommendation
5. Makes a specific, reasonable ask
6. Has a clear call-to-action and deadline
7. Is under 300 words

Also provide: a verbal version for if I catch them in the hallway (90 seconds or less).
```

---

**Prompt 10: Cross-Team Dependency Escalation**

*When to use:* When another team's delays or decisions are blocking your team and direct peer-to-peer resolution hasn't worked.

```
Help me escalate a cross-team dependency issue to leadership.

My team: [TEAM NAME] — working on [BRIEF DESCRIPTION]
Blocking team: [TEAM NAME] — responsible for [BRIEF DESCRIPTION]
The dependency: [WHAT we need from them]
Timeline: [WHEN we need it and what happens if we don't get it]
Attempts to resolve directly: [DESCRIBE conversations with the other team's SM/lead/manager]
Why it hasn't resolved: [YOUR ASSESSMENT: capacity, priority conflict, technical complexity, politics]
Escalation target: [WHO has authority over both teams]

Help me:
1. Frame this as a systemic issue, not a "they're bad" complaint
2. Write a joint escalation note (fair to both teams)
3. Prepare for a three-way conversation (my team, their team, shared leadership)
4. Propose dependency resolution options that work for both teams
5. What to do if the blocking team can't or won't deliver on our timeline
6. How to document this for future PI/sprint planning to prevent recurrence
```

---

**Prompt 11: Budget & Resource Request**

*When to use:* When you need to request additional resources, tooling budget, training budget, or headcount to remove a systemic impediment.

```
Help me write a business case for a resource or budget request.

What I'm requesting: [DESCRIBE: e.g., additional developer, agile coaching subscription, test environment upgrade, CI/CD tooling]
Estimated cost: [$X one-time / $X/month]
The problem this solves: [DESCRIBE the current impediment or pain]
Business impact of NOT getting this: [QUANTIFY: velocity lost, bugs, time wasted, team churn risk]
Business impact of getting it: [QUANTIFY: time saved, quality improved, team capacity gained]
Who approves this: [ROLE]
Their known priorities: [DESCRIBE what they care about most: cost reduction, speed, quality]

Write:
1. A one-page business case document
2. An executive summary (5 sentences max)
3. ROI calculation or justification even if imprecise
4. Objection handling: top 3 reasons they might say no, and my responses
5. A verbal pitch version for a 2-minute conversation
6. Implementation timeline and first success metric
```

---

## 📣 RELEASE COMMUNICATIONS

---

**Prompt 12: Release Announcement**

*When to use:* When your team ships a significant release and you want to communicate it in a way that highlights business value and builds team pride.

```
Write a release announcement for internal and external stakeholders.

Release details:
- Release name/version: [E.g., v2.4, "Summer Release," Sprint 24 Release]
- Release date: [DATE]
- What's included: [LIST key features, improvements, and fixes]
- What problems this solves for users: [DESCRIBE in user terms, not technical terms]
- Key metrics or outcomes expected: [E.g., "reduces checkout time by 40%," "eliminates manual data entry for X workflow"]
- Who worked on this: [TEAM NAME or description]
- Documentation/release notes link: [URL or "TBD"]

Write three versions:
1. Internal team Slack celebration message (enthusiastic, credit the team, under 100 words)
2. Internal stakeholder email (professional, value-focused, with feature summary, under 300 words)
3. External user communication (customer-friendly, benefit-focused, no internal jargon, under 200 words)

For all versions: lead with the value to the user/business, not the features themselves.
```

---

**Prompt 13: Release Retrospective Report**

*When to use:* After a major release to document what the team learned, share outcomes with leadership, and improve the release process.

```
Help me write a release retrospective report for stakeholders and leadership.

Release details:
- Release version/name: [NAME]
- Release date (planned vs. actual): [PLANNED: DATE / ACTUAL: DATE]
- Scope: [WHAT was released — high level]
- Team: [X] people over [X] sprints

Delivery metrics:
- Original scope vs. final scope: [DESCRIBE any scope changes]
- Budget/time: [ON TRACK / OVER by X%]
- Quality: [Defects in production, P1 incidents after release, etc.]
- Team health during delivery: [DESCRIBE]

Key learnings:
- What went well: [LIST]
- What didn't go well: [LIST]
- What we'll do differently next time: [LIST]

Write:
1. An executive summary (one page, leadership-ready)
2. A process improvements section
3. A "team highlights" section celebrating the work
4. Metrics comparison: planned vs. actuals
5. Recommendations for the next release cycle
```

---

**Prompt 14: Go-Live Incident Communication**

*When to use:* When something goes wrong after a release and you need to communicate the incident status and resolution plan to stakeholders clearly and calmly.

```
Help me write an incident communication during a go-live issue.

Incident details:
- What happened: [DESCRIBE the issue]
- When it started: [TIME and DATE]
- Who is affected: [NUMBER of users / which user groups / which features]
- Severity: [SEV 1/2/3 or HIGH/MEDIUM/LOW]
- Current status: [INVESTIGATING / MITIGATED / RESOLVED]
- Root cause (if known): [DESCRIBE or "under investigation"]
- What the team is doing right now: [DESCRIBE active response]
- Estimated time to resolution: [X hours or "TBD"]

Write:
1. Initial incident notification (send within 15 minutes): short, factual, calm
2. Status update template (send every [X] minutes/hours until resolved)
3. Resolution announcement once fixed
4. Post-incident summary for leadership (after the fact)
5. Customer-facing language if users need to be notified
6. What NOT to say in incident communications (phrases to avoid)
```

---

## 🎯 EXECUTIVE SUMMARIES

---

**Prompt 15: Quarterly Agile Program Summary**

*When to use:* For quarterly business reviews, board updates, or steering committee meetings where you need to summarize agile delivery across multiple sprints or teams.

```
Write a quarterly program summary for executive leadership.

Quarter: [Q? YEAR]
Teams covered: [NUMBER and names of teams, if multiple]
Sprints in this quarter: [NUMBER]

Delivery summary:
- Major features/products released: [LIST]
- Business outcomes achieved: [DESCRIBE value delivered]
- Total story points delivered: [X] (across [X] sprints)
- Sprint goal achievement rate: [X]%
- Quality metrics: [DESCRIBE]

Challenges encountered: [LIST major impediments, risks, or misses]
How challenges were resolved: [DESCRIBE]

Team highlights: [E.g., new hires, certifications, process improvements adopted]

Looking ahead (next quarter):
- Key priorities: [LIST]
- Risks on the horizon: [DESCRIBE]
- Resources or decisions needed: [DESCRIBE]

Write:
1. A 1-page executive summary (scannable, no jargon)
2. A 3-minute verbal summary script
3. 5 headline bullets for the first slide of a presentation
4. Top 3 takeaways you want executives to remember
5. Questions you anticipate and prepared answers
```

---

**Prompt 16: Executive Briefing on Agile Progress**

*When to use:* When a senior executive asks for an ad-hoc update on team progress, and you have minutes (not days) to prepare.

```
Help me prepare a 5-minute executive briefing on our team's agile progress.

Who I'm briefing: [ROLE and what they care about]
Context for the meeting: [E.g., they asked for an update in passing, this is a formal 1:1, they have a board meeting tomorrow]
Key points I need to cover:
1. [POINT 1]
2. [POINT 2]
3. [POINT 3]
What I want them to DO after this briefing: [E.g., approve a resource request, unblock a decision, simply be informed]
What I'm worried they'll ask: [DESCRIBE your concern]

Write:
1. A 5-minute briefing script (timed)
2. A one-page leave-behind summary
3. Answers to the 3 questions I'm worried about
4. How to make the ask (if I need something from them) without seeming demanding
5. Closing line that keeps the door open for follow-up
```

---

**Prompt 17: Roadmap Communication for Non-Technical Stakeholders**

*When to use:* When you need to communicate a complex technical roadmap to business stakeholders who care about outcomes, not features.

```
Help me translate our technical roadmap into business language for non-technical stakeholders.

Technical roadmap items:
[LIST THE TECHNICAL FEATURES, EPICS, OR INITIATIVES on the roadmap]

For each item, I'll tell you:
- Technical name: [NAME]
- What it actually does: [PLAIN ENGLISH DESCRIPTION]
- Business problem it solves: [DESCRIBE]
- Who benefits: [USER GROUP or BUSINESS AREA]
- Estimated delivery: [SPRINT/QUARTER]

Audience: [DESCRIBE: e.g., CMO, sales leadership, operations director, board]
Their key concern: [E.g., "When can sales use this?" / "Does this help us comply with regulation X?"]

Please:
1. Rewrite each roadmap item in outcome-focused, jargon-free language
2. Group items by business theme (not technical epic)
3. Create a "Now / Next / Later" roadmap view in plain language
4. Summarize the quarter in one sentence per business area benefiting
5. Anticipate and address the top business concern embedded in this roadmap
6. Create a FAQ section for common questions
```

---

**Prompt 18: Stakeholder Expectation Reset**

*When to use:* When stakeholder expectations are misaligned with reality — they expect more scope, faster delivery, or different priorities than what's possible.

```
Help me reset stakeholder expectations in a professional, trust-preserving way.

The misalignment: [DESCRIBE specifically what they expect vs. what is realistic]
How the gap formed: [DESCRIBE: e.g., early estimates taken as commitments, scope crept, velocity changed]
The stakeholder: [ROLE and their decision-making authority]
The relationship: [STRONG/NEUTRAL/STRAINED]
What I need them to accept: [DESCRIBE the new reality]
What's non-negotiable (they can't change): [DESCRIBE constraints]
What's negotiable (I can offer options): [DESCRIBE]

Help me:
1. Open the conversation without triggering defensiveness
2. Present the facts with data (not opinions)
3. Acknowledge how the misalignment formed (without throwing anyone under the bus)
4. Present 2-3 options they can choose from
5. Guide them to a decision that works for the team
6. Rebuild trust for future expectation-setting
7. Document the new agreement so it doesn't drift again
```

---

**Prompt 19: Product Owner Alignment Email**

*When to use:* When you need to align your Product Owner on agile principles, prioritization, or decisions that affect the team — via written communication.

```
Help me write a professional alignment communication to our Product Owner.

The situation: [DESCRIBE the misalignment or issue — e.g., PO keeps changing sprint scope, PO is not available for refinement, PO is prioritizing internal requests over user value]
Business impact of the issue: [DESCRIBE how this affects the team and product]
My relationship with the PO: [DESCRIBE — collaborative, strained, new relationship]
What I want to achieve: [DESCRIBE the change in behavior or understanding you're seeking]
What I am NOT trying to do: [E.g., blame them, get them in trouble with management]

Write:
1. A professional email that opens with shared goals (not the complaint)
2. Clear description of the current impact (fact-based)
3. A specific ask or proposed working agreement
4. A collaborative tone that invites dialogue rather than demands compliance
5. A subject line that gets opened
6. Optional: A framework for a follow-up conversation
```

---

**Prompt 20: End-of-Project Retrospective Communication**

*When to use:* At the conclusion of a major project or program to formally communicate outcomes, lessons learned, and team achievements to all stakeholders.

```
Help me write an end-of-project retrospective communication for all stakeholders.

Project details:
- Project name: [NAME]
- Duration: [START DATE] to [END DATE]
- Team involved: [DESCRIBE]
- Original objectives: [LIST]
- What was actually delivered: [LIST — be honest about any gaps]
- Business value realized: [DESCRIBE outcomes, not features]

Metrics:
- On time: [YES/PARTIALLY/NO — explain]
- On budget: [YES/PARTIALLY/NO — explain]  
- Quality: [DESCRIBE]
- Team satisfaction: [DESCRIBE]

Key learnings: [LIST what you'd do differently]
Key successes: [LIST what worked exceptionally well]

Write:
1. A stakeholder communication email announcing project close (professional, balanced)
2. A leadership summary document (1 page)
3. A team "win letter" celebrating the team's contributions
4. A lessons-learned summary for the organization's knowledge base
5. Recommendations for future projects of this type
```

---

*End of Stakeholder Communication Prompts — 20 prompts total*
