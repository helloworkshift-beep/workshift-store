# 07 — The Scrum Master's AI Prompt Cheat Sheet
## Top 15 Power Prompts + 10 Golden Rules

---

> **How to use this file:** These are the 15 highest-impact prompts from across the entire toolkit — battle-tested, immediately deployable, and effective for the most common and challenging Scrum Master situations. Bookmark this file. Open it first when you're under pressure and need AI help fast.

---

## ⚡ TOP 15 POWER PROMPTS

---

### POWER PROMPT #1
**Retrospective Facilitator Script**
*From: `02-ceremonies-prompts.md` — Prompt 7*

**Why it's a top 15:** A word-for-word facilitation script you can actually read aloud removes the cognitive load of "what do I say next?" and lets you focus 100% on the team. This is the most time-saving prompt in the toolkit.

```
Write me a complete, word-for-word facilitation script for a [X]-minute retrospective using the [FORMAT NAME, e.g., 4Ls, Sailboat, Mad Sad Glad, Rose Bud Thorn] format.

Team context:
- Team: [TEAM NAME], [X] people
- Sprint just completed: Sprint [NUMBER]
- Notable events this sprint: [DESCRIBE: e.g., we hit our sprint goal, we had a major bug in production, we welcomed a new team member]
- Main tension or theme to address: [DESCRIBE]
- Team engagement history: [E.g., tends to be quiet, very vocal, one dominant voice]

Script should include:
1. Opening and check-in activity (with exact words to say)
2. Setting the stage / retrospective prime directive
3. Transition words between each phase
4. Facilitator prompts when the room goes silent
5. How to manage dominant voices and draw out quiet members
6. Closing and action item commitment ritual
7. What to do if the team gets stuck on blame or negativity

Use natural, conversational language — this is what I'll actually say out loud.
```

---

### POWER PROMPT #2
**Sprint Goal Crafter**
*From: `02-ceremonies-prompts.md` — Prompt 2*

**Why it's a top 15:** A weak sprint goal is one of the most common and most damaging Scrum anti-patterns. This prompt generates compelling, business-value-connected goals that teams actually care about.

```
Act as a Scrum Master helping a development team craft a powerful sprint goal. 

Our team is working on: [PRODUCT/FEATURE DESCRIPTION]
This sprint's selected backlog items focus on: [THEMES OR EPICS]
The business outcome we're trying to achieve: [BUSINESS OBJECTIVE]
Our stakeholders care most about: [STAKEHOLDER PRIORITY]
Sprint length: [LENGTH]

Help us craft:
1. Three sprint goal options (ranging from conservative to ambitious)
2. For each option, explain the "why" that connects to business value
3. A test for each goal: "How will we know we achieved this?"
4. One sentence to communicate this goal to non-technical stakeholders

Format each goal using the structure: "By the end of this sprint, [WHO] can [DO WHAT] so that [VALUE]."
```

---

### POWER PROMPT #3
**Impediment Root Cause Analyzer**
*From: `03-team-coaching-prompts.md` — Prompt 1*

**Why it's a top 15:** Most impediments that persist for more than 3 days are symptoms of deeper problems. This prompt applies the 5 Whys rigorously to find the real issue and build a resolution strategy that sticks.

```
Act as an experienced agile coach helping me diagnose and remove a persistent impediment.

The impediment: [DESCRIBE the blocker clearly]
How long it has existed: [X days/weeks]
Who it affects: [ROLE(S) or whole team]
Impact on the team: [DESCRIBE: e.g., blocking 2 stories, causing 20% capacity loss, causing team frustration]
What I've already tried: [LIST actions taken]
Why those attempts haven't worked: [YOUR ASSESSMENT]
Who has authority to resolve this: [ROLE/DEPARTMENT]
Organizational context: [E.g., bureaucratic company, startup, matrix org]

Please provide:
1. Root cause analysis (5 Whys applied to this impediment)
2. The real blocker beneath the surface issue
3. Three resolution strategies ranging from quick fix to systemic fix
4. Stakeholders I need to influence and how to approach each
5. An escalation plan if this isn't resolved in [X] days
6. How to protect the team from this impediment while resolution is in progress
```

---

### POWER PROMPT #4
**Impediment Escalation Email**
*From: `04-stakeholder-communication-prompts.md` — Prompt 9*

**Why it's a top 15:** The way you escalate defines how leadership perceives you. This prompt produces a professional, solution-oriented escalation that positions you as a business partner — not a complainer.

```
Write a professional impediment escalation email.

To: [ROLE of recipient, e.g., Engineering Director]
From: [Your role]
Subject line: Suggest one

The impediment: [DESCRIBE clearly and specifically]
Business impact: [QUANTIFY if possible: e.g., blocking X sprint stories worth Y points, delaying release by Z weeks, costing an estimated $X in rework]
Duration unresolved: [X days/weeks]
What I've already tried: [LIST actions taken]
Why it's beyond my authority to resolve: [EXPLAIN]
What I need from the recipient: [SPECIFIC ASK — decision, action, introduction, resources]
Desired resolution timeline: [BY WHEN]

Write a professional email that:
1. Opens with the business impact (not the complaint)
2. Provides clear, fact-based context (no blame)
3. Shows what you've already done
4. Presents 2-3 solution options with your recommendation
5. Makes a specific, reasonable ask
6. Has a clear call-to-action and deadline
7. Is under 300 words

Also provide: a verbal version for if I catch them in the hallway (90 seconds or less).
```

---

### POWER PROMPT #5
**Psychological Safety Assessment**
*From: `03-team-coaching-prompts.md` — Prompt 10*

**Why it's a top 15:** Teams can't improve what they can't talk about. Low psychological safety is the root cause of shallow retrospectives, silent standups, and unaddressed dysfunction. This prompt gives you a framework to measure and systematically improve it.

```
Help me assess and improve psychological safety on my Scrum team.

Observable behaviors suggesting psychological safety issues:
- [BEHAVIOR 1: e.g., people don't speak up in planning, ideas get shot down]
- [BEHAVIOR 2: e.g., retro feedback is always positive, no one raises real issues]
- [BEHAVIOR 3: e.g., new team member is silent in all meetings]
[Add observations]

Team size: [X] people
Team tenure (how long working together): [X months/years]
Any recent events that may have damaged trust: [DESCRIBE or "none"]
Leadership style of manager above the team: [DESCRIBE]

Please provide:
1. A psychological safety score estimate based on the behaviors described
2. The 4 stages of psychological safety and where this team likely is
3. Three activities I can facilitate to build psychological safety
4. Specific facilitation techniques to create safety in ceremonies
5. How to model psychological safety myself as Scrum Master
6. How to address a team leader or senior member who shuts down others
7. A 60-day psychological safety improvement plan
```

---

### POWER PROMPT #6
**Sprint Status Update Generator**
*From: `04-stakeholder-communication-prompts.md` — Prompt 1*

**Why it's a top 15:** Stakeholder communication is where Scrum Masters get their reputation. This prompt generates polished, value-focused status updates that keep stakeholders informed and highlight your team's impact — in two formats for two audiences.

```
Write a professional sprint status update for stakeholders.

Sprint details:
- Sprint number: [NUMBER]
- Sprint dates: [START] to [END]
- Sprint goal: [SPRINT GOAL TEXT]
- Sprint goal status: [ON TRACK / AT RISK / ACHIEVED / NOT ACHIEVED]
- Story points committed: [X]
- Story points completed: [X]
- Stories completed: [LIST KEY COMPLETED ITEMS — 3-5 bullet points]
- Stories in progress: [LIST]
- Stories not started: [LIST]
- Current blockers: [DESCRIBE or "none"]
- Key decisions needed from stakeholders: [DESCRIBE or "none"]

Write two versions:
1. A concise Slack/Teams status update (under 200 words, use emojis sparingly, bullet points)
2. A formal email status update (under 400 words, professional tone, suitable for email to VP/Director level)

Both versions should lead with the sprint goal status, highlight value delivered (not just tasks), and end with a clear call-to-action or next steps.
```

---

### POWER PROMPT #7
**Team Health Check Designer**
*From: `05-agile-transformation-prompts.md` — Prompt 1*

**Why it's a top 15:** This is your quarterly reset button. A well-designed health check surfaces what's truly working and what isn't — before small problems become big ones. It also gives you data to present to leadership about team progress.

```
Help me design and facilitate a team health check assessment for my Scrum team.

Team context:
- Team name: [NAME]
- Team size: [X] people
- Time together: [X months/years]
- Previous health check: [DATE or "never done one"]
- Known areas of concern: [DESCRIBE]
- Areas where the team is strong: [DESCRIBE]

Please:
1. Design a 12-dimension team health check covering: agile ceremonies, technical practices, team dynamics, product clarity, stakeholder relationships, continuous improvement, delivery reliability, quality, autonomy, learning, wellbeing, and purpose
2. For each dimension, provide:
   - 3 diagnostic questions
   - A 1-5 scoring rubric with descriptions for each score
   - Green/Amber/Red health indicators
3. Create a facilitation guide for running the health check session (60 minutes)
4. Design a visual "health radar" description I can build in a spreadsheet
5. Provide a template for the health check report
6. Create a 90-day improvement plan structure based on common low-score areas
```

---

### POWER PROMPT #8
**GROW Coaching Conversation Planner**
*From: `03-team-coaching-prompts.md` — Prompt 12*

**Why it's a top 15:** The best Scrum Masters are coaches, not coordinators. The GROW model is the gold standard coaching framework, and this prompt builds a complete conversation plan for any 1-on-1 situation — from performance issues to career growth.

```
Help me plan and facilitate a GROW model coaching conversation.

Coachee role: [E.g., Senior Developer, Junior QA, Product Owner]
Topic to coach on: [DESCRIBE the development area or challenge]
My relationship with this person: [DESCRIBE — peer, direct report, team member I support]
What I know about their perspective: [DESCRIBE]
What I want them to arrive at themselves (not prescribe): [YOUR COACHING GOAL]
Time available for the conversation: [X minutes]

For each stage of GROW, give me:

GOAL:
- 3 questions to help them articulate a clear goal
- How to help them be specific vs. vague

REALITY:
- 4 questions to explore their current situation without judgment
- How to surface blind spots gently

OPTIONS:
- 5 questions to generate creative options
- How to add ideas without taking over

WILL:
- 3 questions to create commitment
- How to establish accountability without micromanaging

Plus: How to open and close the conversation, and what to document afterward.
```

---

### POWER PROMPT #9
**Quarterly Agile Program Summary**
*From: `04-stakeholder-communication-prompts.md` — Prompt 15*

**Why it's a top 15:** This prompt makes you look excellent at QBRs and steering committee meetings. It transforms raw delivery data into a polished executive narrative that shows business impact — not just story point counts.

```
Write a quarterly program summary for executive leadership.

Quarter: [Q? YEAR]
Teams covered: [NUMBER and names of teams, if multiple]
Sprints in this quarter: [NUMBER]

Delivery summary:
- Major features/products released: [LIST]
- Business outcomes achieved: [DESCRIBE value delivered]
- Total story points delivered: [X] (across [X] sprints)
- Sprint goal achievement rate: [X]%
- Quality metrics: [DESCRIBE]

Challenges encountered: [LIST major impediments, risks, or misses]
How challenges were resolved: [DESCRIBE]

Team highlights: [E.g., new hires, certifications, process improvements adopted]

Looking ahead (next quarter):
- Key priorities: [LIST]
- Risks on the horizon: [DESCRIBE]
- Resources or decisions needed: [DESCRIBE]

Write:
1. A 1-page executive summary (scannable, no jargon)
2. A 3-minute verbal summary script
3. 5 headline bullets for the first slide of a presentation
4. Top 3 takeaways you want executives to remember
5. Questions you anticipate and prepared answers
```

---

### POWER PROMPT #10
**Scrum Master Self-Reflection & Development**
*From: `03-team-coaching-prompts.md` — Prompt 20*

**Why it's a top 15:** Great Scrum Masters grow continuously. This prompt is your personal retrospective — it applies the same rigor you bring to your team to your own professional development. Use it monthly for compounding growth.

```
Act as an executive coach helping me reflect on my effectiveness as a Scrum Master and identify development areas.

My experience as a Scrum Master: [X years/months]
Current team context: [BRIEF DESCRIPTION]
Biggest challenge I'm facing right now: [DESCRIBE]
Recent wins I'm proud of: [DESCRIBE 2-3]
Feedback I've received (positive or critical): [DESCRIBE or "none formally"]
What I feel I'm weakest at: [DESCRIBE honestly]
What I feel I'm strongest at: [DESCRIBE]

Please help me:
1. Apply a Scrum Master competency framework to assess where I am
2. Identify my top 2-3 growth edges based on what I've described
3. Create a personal development plan for the next 90 days
4. Suggest resources (books, courses, communities) for my specific development areas
5. Design a personal retrospective practice I can do monthly
6. Define what "leveling up" as a Scrum Master looks like for me specifically
7. Identify a mentor or coaching relationship I might seek out
```

---

### POWER PROMPT #11
**New Team Member Integration Plan**
*From: `03-team-coaching-prompts.md` — Prompt 17*

**Why it's a top 15:** Onboarding is a moment of high leverage. How you handle the first 30 days sets the trajectory for the next year. This prompt turns a vague "get them up to speed" to a structured 90-day integration system.

```
Help me create a comprehensive onboarding plan for a new team member joining a Scrum team.

New team member details:
- Role: [ROLE]
- Experience level: [JUNIOR/MID/SENIOR]
- Agile experience: [NONE/SOME/EXPERIENCED]
- Start date: [DATE]
- Joining during sprint: [SPRINT NUMBER, with X days remaining]

Team context:
- Team size: [X] people
- Team maturity: [NEW/EXPERIENCED/HIGH-PERFORMING]
- Current team culture: [DESCRIBE]
- Biggest integration risks: [DESCRIBE: e.g., strong existing cliques, highly technical vocabulary, fast pace]

Create:
1. A 30-60-90 day onboarding plan (agile practices focus)
2. Day 1 agenda for my time with them
3. Questions to ask in week 1 to understand their background and needs
4. How to introduce them at ceremonies without making it awkward
5. A "buddy system" design: who should be paired with them and why
6. Milestones for integration success
7. Early warning signs of struggling integration and how to address them
```

---

### POWER PROMPT #12
**Agile Transformation Roadmap**
*From: `05-agile-transformation-prompts.md` — Prompt 10*

**Why it's a top 15:** Whether you're launching a new transformation or inheriting a stalled one, this prompt generates a phased roadmap that leadership can fund, teams can follow, and stakeholders can track. The most strategic prompt in the toolkit.

```
Help me design an agile transformation roadmap for [ORGANIZATION/DEPARTMENT].

Organization context:
- Industry: [INDUSTRY]
- Size of transformation: [X] teams / [X] total people
- Current state: [DESCRIBE how work is done today — waterfall, hybrid, chaos, etc.]
- Trigger for transformation: [E.g., competitive pressure, new CTO, failed projects]
- Executive sponsorship level: [STRONG/MODERATE/WEAK]
- Budget available: [DESCRIBE or "unknown"]
- Target timeline: [X months/years to get to defined state]
- Key resistance anticipated: [DESCRIBE]

Please create:
1. A phased transformation roadmap (Phase 1: Foundation, Phase 2: Practice, Phase 3: Optimize, Phase 4: Scale)
2. Key activities and milestones for each phase
3. Success metrics for each phase
4. Governance model for the transformation
5. Change management plan: how to bring people along
6. Risk register for common transformation pitfalls
7. How to demonstrate early wins to sustain momentum
8. A one-page executive summary of the roadmap
```

---

### POWER PROMPT #13
**Resistance to Agile Handling Guide**
*From: `05-agile-transformation-prompts.md` — Prompt 11*

**Why it's a top 15:** Resistance is inevitable in any transformation. This prompt doesn't just give you talking points — it classifies the *type* of resistance (technical, political, personal, cultural) and builds tailored strategies for each kind. A must-have for any SM in a change environment.

```
Help me develop a strategy for addressing resistance to agile transformation.

The resistance I'm facing:
- Who is resisting: [DESCRIBE: roles, levels, departments]
- What they're saying (their stated objections): [LIST VERBATIM if possible]
- What might really be driving the resistance: [YOUR ASSESSMENT: e.g., fear of job change, loss of control, past failed agile attempts]
- Intensity of resistance: [LIGHT/MODERATE/SIGNIFICANT]
- Key decision-maker's position: [SUPPORTIVE/NEUTRAL/RESISTANT]

Organization context:
- Type: [E.g., large enterprise, government, family-owned business]
- Culture: [E.g., hierarchy-driven, risk-averse, innovation-focused]
- Previous agile attempts: [DESCRIBE success/failure history]

Please help me:
1. Classify each type of resistance (technical, political, personal, cultural)
2. Develop tailored response strategies for each type
3. Identify who I need to win over first (influence map)
4. Create "safe experiments" I can propose to skeptics
5. Build a coalition of early adopters
6. Communication messaging for different resistance personas
7. Know when resistance is telling me something valid about the transformation approach
```

---

### POWER PROMPT #14
**Sprint Velocity Analysis & Forecasting**
*From: `02-ceremonies-prompts.md` — Prompt 20*

**Why it's a top 15:** Stakeholders want dates. Scrum Masters deal in probabilities. This prompt bridges the gap — it takes your velocity data and generates a credible, statistically-grounded forecast that you can present with confidence.

```
Help me analyze our sprint velocity data and create a forecast for upcoming sprints.

Velocity data (last [X] sprints):
Sprint [N-5]: [X] points
Sprint [N-4]: [X] points
Sprint [N-3]: [X] points
Sprint [N-2]: [X] points
Sprint [N-1]: [X] points
Sprint [N]: [X] points

Factors affecting recent sprints: [E.g., Sprint N-2 had 2 people on vacation, Sprint N had a major incident]
Upcoming known capacity impacts: [DESCRIBE]
Total backlog remaining: [X] points (approximate)
Key release or milestone date: [DATE]

Please provide:
1. Statistical analysis: average, median, and range of our velocity
2. A recommended capacity range for the next sprint
3. A release forecast: when we might complete the current backlog at current velocity
4. How to present this data to a Product Owner who wants a specific date commitment
5. Risk factors that could affect the forecast
6. Visualizations to suggest (I'll create them in [EXCEL/SHEETS/JIRA/other])
```

---

### POWER PROMPT #15
**Retrospective Format Selector**
*From: `02-ceremonies-prompts.md` — Prompt 6*

**Why it's a top 15:** The "what went well / what didn't / what to improve" format loses its power after the first few uses. This prompt matches the *right* retrospective format to the *specific moment* your team is in — and gives you a complete facilitation plan for that format.

```
I'm a Scrum Master planning a retrospective and want to try a new format. Help me select and customize the best retrospective format for our situation.

Team context:
- Team size: [NUMBER] people
- Time together as a team: [E.g., 6 months, newly formed, 2 years]
- Current team mood/dynamics: [DESCRIBE: e.g., burnt out after a tough sprint, excited about a big launch, conflict between two members]
- Last retrospective format used: [FORMAT NAME or "standard start/stop/continue"]
- Key issue we need to address this sprint: [MAIN THEME: e.g., communication, technical debt, deployment issues]
- Retrospective time available: [X minutes]
- Remote or in-person: [REMOTE/IN-PERSON/HYBRID]

Please:
1. Recommend the top 3 retrospective formats for our situation with a brief explanation of each
2. For your top recommendation, provide a complete facilitation script with timing
3. Include the exact prompts/questions to ask for each activity
4. Suggest digital tools if we're remote
5. Provide 3–5 action item templates we can fill in together
```

---

---

## 🏆 10 GOLDEN RULES OF PROMPTING FOR SCRUM MASTERS

These rules apply every time you use AI as a Scrum Master. Internalize them and your results will consistently outperform generic AI usage.

---

### GOLDEN RULE #1
**Always give the AI your role and context first.**

AI models produce generic output when given generic input. The moment you establish "I am a Scrum Master" and describe your specific team, sprint, and situation, output quality jumps dramatically. Every prompt in this toolkit begins with this context-setting for a reason. Never skip it.

> ✅ "I am a Scrum Master for a 6-person cross-functional team in a regulated fintech environment..."
> ❌ "Write me a sprint retrospective agenda."

---

### GOLDEN RULE #2
**Replace every [BRACKET] before running the prompt.**

Brackets are placeholders — they exist so you remember to add your specific information. A prompt with even one unreplaced bracket will produce output calibrated to the generic placeholder, not your actual situation. Do a bracket scan before every prompt submission.

> ✅ Scan for `[` in your prompt. If you see any, fill them in.
> ❌ Submitting "Team: [TEAM NAME]" — you'll get output that sounds oddly generic.

---

### GOLDEN RULE #3
**The first output is a draft, not the final answer.**

AI's first response is almost always a good starting point, not a finished artifact. Your job is to iterate: "Make this more concise," "Adjust the tone for a skeptical senior manager," "Add a section on risks," "Remove the bullet points, I need this in prose." Three rounds of iteration produces output you'd be proud to put your name on.

---

### GOLDEN RULE #4
**Quantify your context wherever possible.**

"The team is struggling" is weak context. "The team has missed the sprint goal 3 out of 4 sprints, velocity has dropped 30% in 2 months, and two developers haven't spoken directly in a week" is strong context. Specific numbers and observable facts produce far more targeted and useful AI output.

---

### GOLDEN RULE #5
**Use AI before conversations, not instead of them.**

AI helps you prepare — it generates scripts, options, frameworks, and drafts. It doesn't replace the actual conversation with your team, your PO, or your stakeholders. The human moment — the facilitation, the coaching, the difficult conversation — is irreplaceable. Use AI to show up to those moments better prepared.

---

### GOLDEN RULE #6
**Tell the AI what format you need the output in.**

Default AI output is usually formatted for reading on a screen. But you might need: a slide outline, a Slack message, a Word document, a facilitation script you'll read aloud, or a table you can paste into Excel. Specify your format explicitly and you'll spend far less time reformatting.

> Examples: "Format this as a bulleted Slack message under 200 words" / "Give me this as a numbered script I can read aloud" / "Output this as a markdown table"

---

### GOLDEN RULE #7
**Use negative constraints to sharpen the output.**

Tell the AI what you *don't* want, not just what you do. This is one of the most underused prompting techniques. Scrum Masters communicate with real humans in specific organizational cultures — generic AI phrasing often doesn't fit.

> Examples: "Avoid corporate jargon" / "Don't suggest anything that requires budget approval" / "Keep it under 300 words — this is a busy VP" / "Don't give me theoretical frameworks — I need practical, actionable steps"

---

### GOLDEN RULE #8
**Ask for options, not one answer.**

When facing a decision — retrospective format, escalation strategy, coaching approach, sprint goal wording — always ask for 2–4 options. Options give you and your team agency. They prevent the "the AI told me to" dynamic and replace it with "here are three approaches, which resonates with you?" Options are also naturally better quality because the AI has to consider multiple perspectives to generate them.

---

### GOLDEN RULE #9
**Keep your AI context window warm for complex situations.**

For complex, multi-part challenges (a difficult team dynamic, a major escalation, a transformation problem), don't start a new conversation each time. Keep the same conversation thread alive and add context as it develops. The AI builds a richer model of your situation over multiple exchanges — and produces increasingly relevant output as a result.

---

### GOLDEN RULE #10
**Your professional judgment is the final filter.**

AI output can be wrong, tone-deaf, legally risky, or culturally mismatched to your organization. You are the professional. You know your team, your organization, and the political landscape. Treat AI output as a highly capable first draft from a smart assistant who has never met your stakeholders. Edit with your expertise. The combination of AI speed + your judgment is unbeatable.

---

---

## 📋 QUICK REFERENCE CARD

| Situation | Power Prompt # | File |
|---|---|---|
| Planning a retrospective | #15, then #1 | 02 |
| Sprint goal is weak | #2 | 02 |
| Blocker won't resolve | #3 → #4 | 03 → 04 |
| Stakeholder status update | #6 | 04 |
| Executive quarterly summary | #9 | 04 |
| Team feels unsafe or stuck | #5 | 03 |
| Coaching a team member | #8 | 03 |
| New team member joining | #11 | 03 |
| Quarterly team health review | #7 | 05 |
| Agile transformation planning | #12 | 05 |
| Resistance to agile | #13 | 05 |
| Stakeholder wants a date | #14 | 02 |
| SM personal development | #10 | 03 |

---

*The Scrum Master's AI Prompt Toolkit — Version 1.0*
