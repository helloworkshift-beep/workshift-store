# 06 — Workflow SOPs
## 5 Complete End-to-End Playbooks for Scrum Masters

---

> These Standard Operating Procedures (SOPs) show you exactly how to combine the prompts in this toolkit into complete, repeatable workflows. Each SOP tells you **which file to open, which prompt to use, when to use it, and what to do with the output.**

---

## HOW TO USE THESE SOPs

Each SOP is structured as a linear workflow with numbered steps. At each step:

- **→ Prompt File** tells you which file contains the prompt to use
- **⏱ Timing** tells you when to run this step
- **💡 Tips** gives facilitation or execution advice
- **Output** describes what you produce and what you do with it

---

## SOP #1: Sprint Kickoff System
### From Planning to a Confident First Standup

**Overview:** This SOP covers the 48-hour window from the end of one sprint to the first standup of the new one. Follow it every sprint to ensure your team starts aligned, energized, and clear on what they're building.

**Total time investment:** ~3–5 hours of SM preparation across 2 days

---

### PHASE 1: PRE-PLANNING PREP (48 hours before Sprint Planning)

**Step 1: Generate the Pre-Sprint Planning Checklist**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 21 — Pre-Sprint Planning Checklist Generator

⏱ **Timing:** 48 hours before sprint planning session

Run this prompt to get a complete checklist customized to your sprint context. Share the PO checklist with your Product Owner immediately so they have time to prepare the backlog.

**Output:** A tailored checklist with SM prep items, PO prep items, and team prep items.

💡 **Tip:** Copy the PO section into an email or Slack message and send it to your PO with a deadline of 24 hours before planning. The single biggest cause of poor sprint planning is an unprepared backlog — this prompt addresses that directly.

---

**Step 2: Run Capacity Planning**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 3 — Capacity Planning Calculator

⏱ **Timing:** 24–48 hours before sprint planning

Gather information from the team: who is out, what's on the calendar, any known disruptions. Run the prompt with this information.

**Output:** A calculated capacity recommendation (story point range) and talking points for your planning session.

💡 **Tip:** Present the capacity range at the start of planning before any stories are discussed. This sets a realistic ceiling and prevents overcommitment. Write the range on the whiteboard or digital equivalent.

---

### PHASE 2: SPRINT PLANNING SESSION

**Step 3: Design the Planning Agenda**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 1 — Sprint Planning Session Designer

⏱ **Timing:** 24 hours before planning

Run this prompt to get a timed agenda with facilitation notes. Adjust the output to match your team's specific dynamics.

**Output:** A minute-by-minute agenda for the planning session.

💡 **Tip:** Print or share the agenda at the start of planning. Teams focus better when they can see the time structure. Assign someone as timekeeper if your planning tends to run long.

---

**Step 4: Facilitate Backlog Item Breakdown (as needed)**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 4 — Backlog Item Breakdown for Planning

⏱ **Timing:** During planning, when a story is unclear or oversized

Have this prompt ready. When the team gets stuck on a story, step out for 60 seconds, run the prompt, and come back with clarifying questions and split options to present.

**Output:** Facilitation questions and story split suggestions to unblock the room.

💡 **Tip:** Don't try to run AI prompts live in front of the team (it breaks flow). Instead, use a brief break or a parallel screen to run the prompt, then return with the output framed as your own facilitation questions.

---

**Step 5: Craft the Sprint Goal**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 2 — Sprint Goal Crafter

⏱ **Timing:** Midway through planning, after committed stories are clear

Run this prompt with the context of what stories were selected and the business objective. Present the three goal options to the team and facilitate a collaborative decision.

**Output:** Three sprint goal options; team selects and refines one.

💡 **Tip:** Never dictate the sprint goal — always give the team options and let them choose. Ownership of the goal is the first step to commitment. The "By the end of this sprint..." format from the prompt works extremely well.

---

**Step 6: Create the Sprint Kickoff Announcement**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 22 — Sprint Kickoff Announcement

⏱ **Timing:** Immediately after planning ends

Run this prompt to create a stakeholder-ready sprint kickoff communication. Post it in your team channel and relevant stakeholder channels.

**Output:** A Slack/Teams post (or email) announcing the sprint, the goal, and key commitments.

💡 **Tip:** A public sprint kickoff message creates accountability and keeps stakeholders informed without requiring a meeting. It also gives remote or asynchronous stakeholders context they'd otherwise miss.

---

### PHASE 3: SPRINT LAUNCH (Day 1 of the Sprint)

**Step 7: Run the First Standup Well**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 12 — Standup Facilitation Scripts

⏱ **Timing:** First standup of the new sprint

Use the "sprint kickoff standup" facilitation script variation to open with energy and re-affirm the sprint goal. Go around the team in a way that connects each person's work to the sprint goal.

**Output:** A facilitation script for the first standup that's energizing and goal-focused.

💡 **Tip:** The first standup sets the tone for the entire sprint. Spend 30 extra seconds connecting the sprint goal to the team's purpose. Avoid letting day-one standup devolve into "what did you do yesterday" — instead ask "what will you do today to make progress on our sprint goal?"

---

### PHASE 4: REVIEW (After Next Sprint Planning)

**Step 8: Retrospect on Your Planning Process**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 5 — Sprint Planning Retrospective (Planning for Planning)

⏱ **Timing:** Within 24 hours of sprint planning ending

Even if planning went well, run a brief self-reflection. If planning struggled, use this prompt to diagnose what to fix.

**Output:** 3 specific improvements for next sprint's planning session.

💡 **Tip:** Keep a running "planning improvement log" in a notes doc. Track one improvement per sprint. Over 10 sprints, your planning will be dramatically better than where you started.

---

**SOP #1 Summary Checklist:**

| Step | Action | Timing | Prompt |
|------|--------|--------|--------|
| 1 | Generate pre-planning checklist | T-48h | 02: Prompt 21 |
| 2 | Calculate team capacity | T-24/48h | 02: Prompt 3 |
| 3 | Design planning agenda | T-24h | 02: Prompt 1 |
| 4 | Backlog item breakdown (as needed) | During planning | 02: Prompt 4 |
| 5 | Craft sprint goal | Mid-planning | 02: Prompt 2 |
| 6 | Create kickoff announcement | Post-planning | 02: Prompt 22 |
| 7 | Facilitate first standup | Day 1 | 02: Prompt 12 |
| 8 | Retrospect on planning | Post-sprint | 02: Prompt 5 |

---

---

## SOP #2: Retrospective Facilitation Playbook
### Pre / During / Post — A Complete Facilitation System

**Overview:** Most Scrum Masters under-prepare for retrospectives and over-rely on the same format. This SOP walks you through a complete retrospective system that produces meaningful insights and real action items — every sprint.

**Total time investment:** ~2–3 hours of preparation; varies for facilitation

---

### PHASE 1: PRE-RETROSPECTIVE PREP (24–48 hours before)

**Step 1: Assess the Team's Current State**

→ **Prompt File:** `03-team-coaching-prompts.md`
→ **Prompt:** Prompt 9 — Team Energy & Wellbeing Check-In

⏱ **Timing:** 48 hours before the retrospective

Before designing the retro, understand how the team is actually feeling. If the sprint was brutal, a fun creative format might feel tone-deaf. If energy is high, a deeper introspective format could be powerful.

**Output:** A sense of the team's current emotional state and energy level to inform format selection.

💡 **Tip:** You can run a quick 3-question anonymous pulse check in Slack/Teams with emoji reactions (🟢/🟡/🔴) to get this data before the retro. Ask: "Rate the sprint: energy level, collaboration quality, and sprint goal satisfaction."

---

**Step 2: Select the Retrospective Format**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 6 — Retrospective Format Selector

⏱ **Timing:** 24–48 hours before the retrospective

Provide the team state, the main theme to address, and constraints (time, remote/in-person). The AI will recommend 3 formats and help you choose the best one.

**Output:** A chosen retrospective format with rationale.

💡 **Tip:** Don't repeat the same format more than 3 sprints in a row. Rotate formats to keep the team engaged. The AI's top recommendation is usually solid — trust it unless you have a specific reason not to.

---

**Step 3: Generate the Full Facilitation Script**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 7 — Retrospective Facilitator Script

⏱ **Timing:** 24 hours before the retrospective

This is the most important prep step. A word-for-word script means you can focus on the team during facilitation instead of figuring out what to say next.

**Output:** A complete, word-for-word facilitation script you can print or have on a second screen.

💡 **Tip:** Read the script out loud once before the session. Edit any phrasing that doesn't sound like you. The script is a guide, not a prison — deviate when the moment calls for it.

---

**Step 4: Check for Psychological Safety Risks**

→ **Prompt File:** `03-team-coaching-prompts.md`
→ **Prompt:** Prompt 11 — Safe Space Facilitation Techniques

⏱ **Timing:** Before any retrospective where psychological safety may be a concern

If there's been recent conflict, a difficult sprint, or you have a team member who tends to dominate — use this prompt to prepare safety techniques and ground rules.

**Output:** Opening rituals, ground rules language, and facilitation moves for a psychologically safe retrospective.

💡 **Tip:** Even for healthy teams, open every retrospective by reading the Prime Directive: *"Regardless of what we discover, we understand and truly believe that everyone did the best job they could, given what they knew at the time, their skills and abilities, the resources available, and the situation at hand."* It takes 20 seconds and changes the room.

---

### PHASE 2: DURING THE RETROSPECTIVE

**Step 5: Opening — Establish the Container**

Use the opening ritual from your facilitation script (Step 3). Start with a brief check-in that is low-risk (not "how are you feeling about the sprint" — that's too loaded as an opener).

**Good openers:**
- "One word to describe the sprint"
- "Emoji check-in: what emoji represents your last two weeks?"
- "High, low, or interesting from this sprint — one sentence each"

⏱ **Timing:** First 5–10 minutes of the session

---

**Step 6: Main Retrospective Activity**

Follow your facilitation script. Key facilitation moves:

- **When the room goes silent:** Use the silence prompts from your script ("What are we not saying?")
- **When one voice dominates:** "Let's hear from someone who hasn't spoken yet."
- **When it gets blame-y:** "Let's focus on systems and processes, not individuals."
- **When you're running out of time:** Use the time-boxing from your script to keep moving.

💡 **Tip:** Focus on depth over breadth. It's better to deeply explore two themes and create one meaningful action item than to surface eight themes and produce zero follow-through.

---

**Step 7: Action Item Commitment**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 8 — Action Item Accountability Generator

⏱ **Timing:** Final 15 minutes of the session (or use between sessions)

After themes emerge, use this prompt (either before the session with anticipated themes, or during a break) to generate an accountability structure for action items.

**Output:** SMART action items with owners, deadlines, and follow-up checkpoints.

💡 **Tip:** Never close a retrospective with more than 3 action items. "A team that tries to do everything improves nothing." Pick the highest-impact item and make it non-negotiable for next sprint.

---

**Step 8: Handle Difficult Dynamics (if needed)**

→ **Prompt File:** `02-ceremonies-prompts.md`
→ **Prompt:** Prompt 9 — Difficult Retrospective Recovery

⏱ **Timing:** During the session if things go sideways — OR — use to prepare before a retrospective you know will be difficult

If conflict erupts, blame spirals, or the team disengages mid-retro, having the recovery techniques from this prompt in your back pocket lets you pivot calmly.

💡 **Tip:** If a retrospective goes badly sideways, it's okay to pause and say: "I want to hold space for this, but I think we need a different format for it. Can we take 5 minutes?" Then adapt.

---

### PHASE 3: POST-RETROSPECTIVE

**Step 9: Communicate Action Items to the Team**

Immediately after the retrospective, post a summary to the team channel. Include:
- Top 2–3 themes discussed
- Action items (owner + deadline)
- A note of appreciation for the team's honesty and engagement

⏱ **Timing:** Within 2 hours of the retrospective ending

💡 **Tip:** Use the exact wording the team agreed to for action items — don't paraphrase. This prevents "that's not what I meant" conversations later.

---

**Step 10: Track Action Items in Sprint Planning**

Add retrospective action items to the sprint backlog (or a dedicated improvement backlog). Review progress at the next retrospective. Open every retro by reviewing last sprint's action items.

⏱ **Timing:** During the next sprint planning session

💡 **Tip:** The quickest way to kill trust in retrospectives is to never follow through on action items. Close the loop, always, even if it's to say "this didn't happen — here's why."

---

**Step 11: Retrospective Trend Analysis (Monthly/Quarterly)**

→ **Prompt File:** `05-agile-transformation-prompts.md`
→ **Prompt:** Prompt 3 — Team Health Trend Report

⏱ **Timing:** Once per month or quarter

Paste your last 3–4 retrospective summaries into this prompt to identify patterns, improvements, and stagnant issues across sprints.

**Output:** A trend analysis showing what's improving, what's stuck, and where to focus next.

---

**SOP #2 Summary Checklist:**

| Step | Action | Timing | Prompt |
|------|--------|--------|--------|
| 1 | Assess team state | T-48h | 03: Prompt 9 |
| 2 | Select retro format | T-24/48h | 02: Prompt 6 |
| 3 | Generate facilitation script | T-24h | 02: Prompt 7 |
| 4 | Check psychological safety risks | T-24h | 03: Prompt 11 |
| 5 | Open session | Start of retro | Script from Step 3 |
| 6 | Facilitate main activity | During retro | Script from Step 3 |
| 7 | Generate action item accountability | Final 15 min | 02: Prompt 8 |
| 8 | Handle difficult dynamics (if needed) | During retro | 02: Prompt 9 |
| 9 | Communicate action items | Within 2h post-retro | — |
| 10 | Track action items in planning | Next sprint | — |
| 11 | Trend analysis | Monthly/quarterly | 05: Prompt 3 |

---

---

## SOP #3: Impediment Escalation Process
### From Identification to Resolution — A Systematic Approach

**Overview:** Impediments that linger destroy team morale and erode trust in the Scrum Master. This SOP gives you a systematic process for logging, escalating, and resolving blockers — and for communicating about them professionally throughout.

**Total time investment:** Varies by impediment severity; each step takes 15–60 minutes

---

### PHASE 1: IDENTIFICATION & DIAGNOSIS

**Step 1: Log the Impediment**

As soon as an impediment is identified (in standup, in planning, via a team member), log it with:
- Description (what, specifically, is blocked)
- Who it affects and how
- When it was first identified
- Impact on the sprint / team

⏱ **Timing:** Same day the impediment is identified

💡 **Tip:** Keep a simple impediment log (spreadsheet, Jira board, or even a Slack channel). Visibility of the log — to the team and stakeholders — creates accountability for resolution.

---

**Step 2: Run Root Cause Analysis**

→ **Prompt File:** `03-team-coaching-prompts.md`
→ **Prompt:** Prompt 1 — Impediment Root Cause Analyzer

⏱ **Timing:** Within 24 hours of identifying the impediment (sooner for critical blockers)

Don't skip this step — many "impediments" are symptoms of a deeper problem. Running the 5 Whys via this prompt often reveals the real issue and a more effective resolution path.

**Output:** Root cause analysis, three resolution strategies (quick fix to systemic), and a list of stakeholders to engage.

💡 **Tip:** The "real blocker beneath the surface" section of this prompt's output is often the most valuable. Pay close attention to it — it frequently reveals organizational dysfunction that a surface fix won't solve.

---

### PHASE 2: ATTEMPT RESOLUTION (Days 1–3)

**Step 3: Try to Resolve at Your Level**

Before escalating, exhaust your options:
- Direct conversation with the blocking party
- Peer-level negotiation with another team or department
- Creative workaround that unblocks the team temporarily
- Removing the blocked story from the sprint to protect velocity

⏱ **Timing:** Days 1–3 after impediment identification

💡 **Tip:** Never wait more than 3 business days to attempt resolution. After day 3 with no progress, escalation is not optional — it's your job.

---

**Step 4: Prepare the Escalation Strategy**

→ **Prompt File:** `03-team-coaching-prompts.md`
→ **Prompt:** Prompt 2 — Impediment Escalation Strategy

⏱ **Timing:** When your own resolution attempts are failing (Day 2–3)

Before escalating, prepare. This prompt generates a complete escalation package: verbal pitch, written escalation, and solution options.

**Output:** A verbal escalation script (90 seconds), written escalation email (under 300 words), and three solution options with tradeoffs.

💡 **Tip:** Always escalate with solutions, not just problems. Showing up to a manager with "we have a blocker" is frustrating. Showing up with "we have a blocker, and here are three ways we could resolve it — I need your help with option 2" is professional and actionable.

---

### PHASE 3: FORMAL ESCALATION

**Step 5: Write and Send the Escalation Email**

→ **Prompt File:** `04-stakeholder-communication-prompts.md`
→ **Prompt:** Prompt 9 — Impediment Escalation Email

⏱ **Timing:** Day 3–5 if previous steps haven't resolved the impediment

Use the output from Prompt 9 to draft a professional escalation email. Quantify business impact wherever possible (days delayed, story points blocked, dollars at risk).

**Output:** A polished escalation email ready to send.

💡 **Tip:** Before sending, ask yourself: "Does this email make me look like I'm solving a business problem, or venting about a team complaint?" If it's the latter, revise. Escalations should always be framed in business terms, not team terms.

---

**Step 6: Handle Cross-Team Dependencies (if applicable)**

→ **Prompt File:** `04-stakeholder-communication-prompts.md`
→ **Prompt:** Prompt 10 — Cross-Team Dependency Escalation

⏱ **Timing:** When the impediment involves another team's deliverable or decision

Use this prompt when the blocker comes from another team's delay or decision. It generates communication that maintains the peer relationship while still escalating appropriately.

**Output:** A diplomatic but direct cross-team dependency escalation message.

---

### PHASE 4: COMMUNICATION & RESOLUTION

**Step 7: Communicate Status to the Team**

While escalation is in progress, update your team regularly. In standup, briefly note the status of active impediments. Never let the team feel like blockers disappear into a black hole.

⏱ **Timing:** At every standup while impediment is open

**Standup update template:**
> "[Impediment] — Status: [Escalated to X / Waiting on Y / Expected resolution: Z / Workaround in place]. I'll update you as soon as I hear back."

---

**Step 8: Include in Sprint Status Report (if applicable)**

→ **Prompt File:** `04-stakeholder-communication-prompts.md`
→ **Prompt:** Prompt 1 — Sprint Status Update Generator

⏱ **Timing:** If the impediment is affecting sprint delivery, include in the status report

When communicating sprint status, call out active impediments and their resolution status. This keeps stakeholders from being surprised.

---

**Step 9: Close the Loop**

When the impediment is resolved:
- Update the impediment log (status: resolved, resolution date, what fixed it)
- Notify the team
- Notify anyone involved in escalation with a brief "thank you + resolution" note
- Capture the systemic fix (if applicable) for the agile transformation backlog

⏱ **Timing:** Same day the impediment is resolved

💡 **Tip:** Keep your impediment log forever. It becomes invaluable during agile health reviews and when onboarding new stakeholders to your team's context.

---

**SOP #3 Summary:**

| Step | Action | Timing | Prompt |
|------|--------|--------|--------|
| 1 | Log the impediment | Day 0 | — |
| 2 | Root cause analysis | Day 0–1 | 03: Prompt 1 |
| 3 | Attempt self-resolution | Days 1–3 | — |
| 4 | Prepare escalation strategy | Days 2–3 | 03: Prompt 2 |
| 5 | Write escalation email | Days 3–5 | 04: Prompt 9 |
| 6 | Cross-team dependency (if applicable) | As needed | 04: Prompt 10 |
| 7 | Communicate to team (standup) | Daily | — |
| 8 | Include in sprint status | Per sprint cycle | 04: Prompt 1 |
| 9 | Close the loop | Day resolved | — |

---

---

## SOP #4: New Team Member Onboarding to Scrum
### From Day 1 to Full Integration (30–90 Days)

**Overview:** How a new team member experiences their first sprint determines whether they integrate smoothly or struggle for months. This SOP gives you a systematic approach to onboarding that covers Scrum knowledge, team culture, and ceremony participation.

**Total time investment:** ~4–6 hours of SM investment over 90 days (front-loaded in week 1)

---

### PHASE 1: BEFORE THEY ARRIVE

**Step 1: Create the Onboarding Plan**

→ **Prompt File:** `03-team-coaching-prompts.md`
→ **Prompt:** Prompt 17 — New Team Member Integration Plan

⏱ **Timing:** 3–5 days before the new team member's start date

Run this prompt with full context about the new team member's role, experience level, agile background, and team dynamics. The output is a complete 30-60-90 day plan customized to their situation.

**Output:** A 30-60-90 day onboarding plan (agile focus), Day 1 agenda, Week 1 questions, buddy system design, and early warning signs of struggling integration.

💡 **Tip:** If the new team member has no agile experience, add an extra step in Week 1 — a 45-minute "Agile 101" session just with you. Use Prompt 7 from `05-agile-transformation-prompts.md` to generate the training content.

---

**Step 2: Prepare Training Materials (if needed)**

→ **Prompt File:** `05-agile-transformation-prompts.md`
→ **Prompt:** Prompt 7 — Agile Foundations Training Module

⏱ **Timing:** Before Day 1, if the new team member has limited agile experience

Generate a customized Agile Foundations module for their role (developer, QA, designer, etc.). Keep it under 45 minutes.

**Output:** A role-specific agile foundations training module they can work through in their first week.

💡 **Tip:** Don't make them read the Scrum Guide cold. Customize the training to what they'll actually experience in your team's context. Use the "here's how we do it" framing, not the theoretical framework.

---

**Step 3: Assign a Buddy**

Select a buddy from the team — ideally someone who:
- Has been on the team at least 6 months
- Is at a similar or slightly senior technical level
- Is socially approachable and patient

Brief the buddy on their role: answer questions, introduce to ceremonies, socialize during the first two weeks.

💡 **Tip:** The buddy system is the highest-ROI onboarding move you can make. It removes the "I don't want to bother the SM" barrier and gives new team members a safe person to ask "dumb questions."

---

### PHASE 2: FIRST SPRINT

**Step 4: Day 1 Welcome Session**

Run a personal 1-on-1 welcome session (45–60 minutes) with the new team member. Use the Day 1 agenda from Step 1.

Cover:
- Your role as Scrum Master (servant-leader, not boss)
- Team working agreement and norms
- How ceremonies run on this team
- Where to find information (backlog, wikis, Slack channels)
- Open Q&A

⏱ **Timing:** Day 1, before any ceremonies

💡 **Tip:** Be direct about team culture and dynamics. Tell them what the team is good at and what's still a work in progress. Honest, early context prevents misread situations.

---

**Step 5: Introduce at Ceremonies**

At each ceremony in the first week:
- Standup: Brief introduction ("We have [NAME] joining — they'll be working on [AREA]. Welcome!")
- Sprint Planning: Seat them next to the buddy, give them a low-stakes role (note-taking works well)
- Retrospective (if timing allows): Use a gentle format, explain the Prime Directive before starting

💡 **Tip:** Don't put new team members on the spot in ceremonies. In standup, let them opt in to share rather than defaulting to the team rotation until they're ready. Check in beforehand: "Is it OK if I include you in standup today, or do you want to observe first?"

---

**Step 6: Week 1 Check-In**

At end of Week 1, run a 20-minute 1-on-1 with the questions from the onboarding plan (Step 1). Listen for confusion about roles, team dynamics, or process. Take notes.

⏱ **Timing:** End of Week 1

---

**Step 7: Review Working Agreements with the Full Team**

→ **Prompt File:** `03-team-coaching-prompts.md`
→ **Prompt:** Prompt 18 — Team Norms & Working Agreement Facilitator

⏱ **Timing:** Within the first sprint of the new team member joining

A new team member is an excellent opportunity to revisit and refresh team norms. Use this prompt to facilitate a working agreement refresh session that both reaffirms norms for existing members and includes the new voice.

**Output:** Refreshed team working agreements that include the new team member's perspective.

💡 **Tip:** Frame this as "updating our agreements, not rewriting them." It prevents existing team members from feeling like the new person is changing everything.

---

### PHASE 3: 30–60–90 DAY PROGRESSION

**Step 8: 30-Day Check-In (Coaching Conversation)**

→ **Prompt File:** `03-team-coaching-prompts.md`
→ **Prompt:** Prompt 12 — GROW Coaching Conversation Planner

⏱ **Timing:** Day 28–32

At the 30-day mark, move from "orientation" mode to "coaching" mode. Use the GROW framework prompt to structure a development conversation: how are they settling in? What's going well? What's challenging? What's their goal for the next 30 days?

**Output:** A structured coaching conversation plan for the 30-day check-in.

---

**Step 9: 60-Day Integration Assessment**

At 60 days, assess integration across these dimensions:
- Ceremony participation (contributing, not just attending)
- Team relationship quality (buddy relationship, wider team)
- Technical integration (paired with others, collaborative)
- Agile mindset (understands "why," not just "what")
- Comfort raising impediments and speaking up

If any dimension scores low, take action before the 90-day mark.

⏱ **Timing:** Day 58–65

💡 **Tip:** If by 60 days a team member is still silent in retrospectives and standups, address it directly and kindly in a 1-on-1. Don't let it drift to 90 days — patterns solidify quickly.

---

**Step 10: 90-Day Full Integration Review**

→ **Prompt File:** `03-team-coaching-prompts.md`
→ **Prompt:** Prompt 13 — Team Member Career Development Conversation

⏱ **Timing:** Day 88–95

At 90 days, transition from integration support to ongoing development. Use the career development conversation prompt to co-create a growth plan for the next 6 months.

**Output:** A career development plan that connects their goals to team and organizational goals.

---

**SOP #4 Summary:**

| Step | Action | Timing | Prompt |
|------|--------|--------|--------|
| 1 | Create onboarding plan | 3–5 days pre-start | 03: Prompt 17 |
| 2 | Prepare agile training (if needed) | Pre-start | 05: Prompt 7 |
| 3 | Assign buddy | Pre-start | — |
| 4 | Day 1 welcome session | Day 1 | Onboarding plan |
| 5 | Introduce at ceremonies | Week 1 | — |
| 6 | Week 1 check-in | End of Week 1 | — |
| 7 | Refresh working agreements | Sprint 1 | 03: Prompt 18 |
| 8 | 30-day coaching conversation | Day 28–32 | 03: Prompt 12 |
| 9 | 60-day integration assessment | Day 58–65 | — |
| 10 | 90-day development review | Day 88–95 | 03: Prompt 13 |

---

---

## SOP #5: Quarterly Agile Health Review
### A Full-Team Assessment System for Continuous Improvement

**Overview:** Most teams improve in sprints but plateau over quarters. This SOP gives you a structured quarterly review process that surfaces systemic issues, celebrates progress, and creates a roadmap for the next quarter's improvement.

**Recommended cadence:** Once per quarter (every 12–13 sprints)
**Total time investment:** ~6–8 hours across 3 phases (prep, session, reporting)

---

### PHASE 1: PREPARATION (1 WEEK BEFORE)

**Step 1: Design the Health Check Assessment**

→ **Prompt File:** `05-agile-transformation-prompts.md`
→ **Prompt:** Prompt 1 — Team Health Check Designer

⏱ **Timing:** 5–7 days before the health review session

Generate a 12-dimension health check tailored to your team's context, tenure, and known areas of concern. The output gives you diagnostic questions, scoring rubrics, and Green/Amber/Red indicators for each dimension.

**Output:** A complete health check assessment tool with facilitation guide.

💡 **Tip:** Send the health check questions to team members 48 hours before the session so they can reflect before arriving. Prepared participants give richer, more honest responses than those answering cold.

---

**Step 2: Pull the Last Quarter's Data**

Gather before the session:
- Sprint velocity for each sprint in the quarter
- Retrospective action items and completion rate
- Impediment log (how many raised, how many resolved, average resolution time)
- Story completion rate per sprint
- Any team satisfaction or wellbeing data

⏱ **Timing:** 3–5 days before the session

💡 **Tip:** Quantitative data gives the health check objective grounding. Teams are less likely to inflate their self-assessments when they can see the actual numbers side-by-side.

---

**Step 3: Generate the Trend Report**

→ **Prompt File:** `05-agile-transformation-prompts.md`
→ **Prompt:** Prompt 3 — Team Health Trend Report

⏱ **Timing:** 3–5 days before the session

Paste the last quarter's retrospective summaries and data into this prompt. The output identifies themes, improvements, and persistent issues across the quarter.

**Output:** A trend analysis of what improved, what stagnated, and what regressed over the quarter.

💡 **Tip:** Share this trend report with the team before the health review session. It primes them with context and prevents the "we've already fixed that" disagreements during the session.

---

**Step 4: Prepare the Agile Maturity Assessment (Optional but Recommended)**

→ **Prompt File:** `05-agile-transformation-prompts.md`
→ **Prompt:** Prompt 4 — Agile Maturity Assessment

⏱ **Timing:** 3–5 days before the session

Run a maturity assessment to see where the team sits on the agile maturity spectrum. This provides a framework for the health review discussion and gives a baseline for next quarter.

**Output:** A maturity score across key agile dimensions with a development roadmap.

---

### PHASE 2: THE HEALTH REVIEW SESSION

**Step 5: Facilitate the Health Check**

⏱ **Timing:** 90–120 minute dedicated session (outside regular ceremonies)

Recommended session structure:
- **0:00–0:10** — Welcome, purpose, ground rules (this is a learning conversation, not a performance review)
- **0:10–0:20** — Review last quarter's data (velocity, completion rates, action item follow-through)
- **0:20–0:60** — Team self-assessment by dimension (small groups or individual scores, then group discussion)
- **0:60–0:90** — Identify top 3 focus areas for next quarter
- **0:90–2:00** — Define SMART improvement goals for each focus area

💡 **Tip:** Use "fist of five" or digital voting (Mentimeter, Miro) to get simultaneous scores across dimensions. This prevents anchoring — where the first person's score influences everyone else's.

---

**Step 6: Address Psychological Safety During the Session**

→ **Prompt File:** `03-team-coaching-prompts.md`
→ **Prompt:** Prompt 10 — Psychological Safety Assessment

⏱ **Timing:** Use during session if psychological safety scores low in the health check

If psychological safety comes up as a concern during the health check, use this prompt's framework to facilitate a deeper discussion and create an improvement plan.

**Output:** Concrete actions to improve psychological safety over the next quarter.

---

### PHASE 3: REPORTING & FOLLOW-THROUGH

**Step 7: Generate the Quarterly Health Report**

→ **Prompt File:** `04-stakeholder-communication-prompts.md`
→ **Prompt:** Prompt 15 — Quarterly Agile Program Summary

⏱ **Timing:** Within 48 hours of the health review session

Create a polished quarterly summary for leadership and stakeholders. This report shows the value of your Scrum Master work and demonstrates continuous improvement.

**Output:** A professional quarterly agile summary suitable for VP/Director-level stakeholders.

💡 **Tip:** Include a "what we improved this quarter" section alongside "what we're working on next quarter." Leadership loves to see progress — make it visible.

---

**Step 8: Communicate Health Review Outcomes to the Team**

Within 24 hours of the session, share:
- Health check results (Green/Amber/Red by dimension)
- The top 3 focus areas for next quarter
- Specific improvement commitments with owners and dates
- A brief note of appreciation for the team's engagement

⏱ **Timing:** Within 24 hours

---

**Step 9: Build the Improvement Roadmap into the Sprint Process**

Each quarterly focus area should translate into at least 1–2 actionable items per sprint. Add these as recurring agenda items in retrospectives so they get consistent attention.

⏱ **Timing:** Before the start of the next sprint

💡 **Tip:** Make the quarterly focus areas visible — put them in your team's Slack channel description, your sprint board header, or your retro template. Out of sight is out of mind.

---

**Step 10: Set Up the Next Quarterly Review**

Block calendar time for the next quarterly health review immediately. Teams that schedule improvement work treat it as real work; teams that "plan to do it eventually" never do.

⏱ **Timing:** Same day as the current session ends

---

**Step 11: Update the Agile Transformation Roadmap (if applicable)**

→ **Prompt File:** `05-agile-transformation-prompts.md`
→ **Prompt:** Prompt 10 — Agile Transformation Roadmap

⏱ **Timing:** If your team is part of a broader agile transformation

Feed the health check results back into the transformation roadmap. Teams make the best transformation inputs because they're closest to what's actually working.

---

**SOP #5 Summary:**

| Step | Action | Timing | Prompt |
|------|--------|--------|--------|
| 1 | Design health check | T-7 days | 05: Prompt 1 |
| 2 | Pull quarter's data | T-3/5 days | — |
| 3 | Generate trend report | T-3/5 days | 05: Prompt 3 |
| 4 | Agile maturity assessment | T-3/5 days | 05: Prompt 4 |
| 5 | Facilitate health review session | Session day | Session guide |
| 6 | Address psychological safety (if needed) | During session | 03: Prompt 10 |
| 7 | Generate quarterly health report | T+48h | 04: Prompt 15 |
| 8 | Communicate outcomes to team | T+24h | — |
| 9 | Build improvements into sprint process | Before next sprint | — |
| 10 | Schedule next quarterly review | Same day | — |
| 11 | Update transformation roadmap (if applicable) | Within 1 week | 05: Prompt 10 |

---

---

## QUICK REFERENCE: SOP BY SITUATION

| If you're facing... | Use SOP |
|---|---|
| Starting a new sprint | SOP #1: Sprint Kickoff System |
| Planning or facilitating a retrospective | SOP #2: Retrospective Facilitation Playbook |
| A blocker that won't go away | SOP #3: Impediment Escalation Process |
| A new person joining the team | SOP #4: New Team Member Onboarding |
| End of the quarter / team feeling stuck | SOP #5: Quarterly Agile Health Review |

---

*These SOPs are living documents. As your team grows and your practice matures, adapt them. The best process is the one your team will actually follow.*
