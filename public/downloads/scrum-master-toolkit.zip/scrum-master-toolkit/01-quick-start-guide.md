# 01 — Quick Start Guide

## How to Get the Most from This Toolkit

---

### Understanding the Prompt Format

Every prompt in this toolkit follows a consistent structure:

**TITLE** — What this prompt does in plain English

*When to use* — The specific scenario or trigger that makes this prompt valuable

```
The actual prompt goes here, with [PLACEHOLDER TEXT IN BRACKETS]
that you replace with your real context before pasting into an AI.
```

---

### Step-by-Step: Using a Prompt

**Step 1: Identify your need**
What's happening right now? Sprint planning tomorrow? Team tension this week? Stakeholder asking for a status update? Match your need to the right file.

**Step 2: Read the "When to use" note**
This tells you the ideal scenario. If it matches — great. If it's close but not exact — still use it and adapt.

**Step 3: Copy the prompt**
Copy the full code block. Don't skip the setup lines at the top — they set the AI's context and role.

**Step 4: Replace every [BRACKET]**
Every item in `[SQUARE BRACKETS]` is a placeholder. Replace them all before running the prompt. Missing brackets = generic output.

| Bracket Type | Example | Replace With |
|---|---|---|
| `[TEAM NAME]` | Phoenix Squad | Your actual team name |
| `[SPRINT NUMBER]` | Sprint 23 | Your current sprint |
| `[VELOCITY]` | 42 points | Your team's number |
| `[SPECIFIC ISSUE]` | Two devs not communicating | Real description |
| `[CONTEXT]` | We're mid-quarter, under pressure | Relevant background |

**Step 5: Paste into your AI assistant**
Works with ChatGPT, Claude, Gemini, Copilot — any capable LLM.

**Step 6: Iterate**
The first output is rarely the final artifact. Follow up with:
- "Make this more concise"
- "Add more specific action items"
- "Rewrite this for a non-technical audience"
- "Give me 3 alternative approaches"

---

### Prompt Stacking (Advanced)

The real power comes from combining prompts in sequence:

**Sprint Planning Stack:**
1. `02-ceremonies` → Sprint Planning Context Setter
2. `02-ceremonies` → Capacity Planning Calculator prompt
3. `02-ceremonies` → Sprint Goal Crafting prompt
4. `03-coaching` → Team Motivation Check-In prompt

**Stakeholder Update Stack:**
1. `04-stakeholder` → Sprint Velocity Report prompt
2. `04-stakeholder` → Executive Summary Generator
3. `04-stakeholder` → Risk & Impediment Escalation Email

**Retrospective Stack:**
1. `02-ceremonies` → Retrospective Format Selector
2. `02-ceremonies` → Retro Facilitator Script
3. `03-coaching` → Action Item Follow-Through Coaching prompt

---

### Customization Tips

**Add your team's language.** Before the prompt, add: *"Our team uses [TERM] instead of 'sprint' and [TERM] instead of 'user story'. Use our terminology throughout."*

**Set your AI's persona.** Start sessions with: *"For this conversation, you are an experienced Scrum Master consultant with 10+ years of experience in enterprise software development."*

**Give context once, reuse it.** In a long AI conversation, establish context at the start:
```
Our team context:
- Team: [NAME], [SIZE] people
- Product: [BRIEF DESCRIPTION]
- Current sprint: [NUMBER], [LENGTH]-week sprints
- Tech stack: [LANGUAGES/TOOLS]
- Main challenges: [DESCRIBE]
```
Then run multiple prompts in the same session without repeating context.

**Save winning outputs.** When a prompt generates something excellent, save it. Build your own library of team-specific templates.

---

### Choosing the Right AI Model

| Task | Recommended Model | Why |
|---|---|---|
| Long documents, nuanced coaching | Claude 3.5 Sonnet/Opus | Best at nuance and long context |
| Fast iterations, multiple versions | ChatGPT GPT-4o | Fast, great at structured output |
| Research, real-time info needed | Gemini Pro | Web access, broad knowledge |
| Org already uses Microsoft | Copilot | Integration with M365 |

---

### Red Flags to Avoid

- **Don't share sensitive employee names** in AI prompts — use roles ("Senior Dev," "Tech Lead") instead
- **Don't paste confidential roadmap data** into consumer AI tools — use role descriptions and anonymized numbers
- **Don't take AI output as final** — always review and validate before sharing with stakeholders
- **Don't use outputs verbatim** in formal HR conversations — AI coaching prompts provide frameworks, not legal advice

---

### Your Toolkit at a Glance

```
📂 scrum-master-toolkit/
├── README.md                          ← Start here
├── 01-quick-start-guide.md            ← You are here
├── 02-ceremonies-prompts.md           ← 25 prompts for sprint events
├── 03-team-coaching-prompts.md        ← 20 prompts for team dynamics
├── 04-stakeholder-communication-prompts.md  ← 20 prompts for leadership
├── 05-agile-transformation-prompts.md ← 15 prompts for transformation
├── 06-workflow-sops.md                ← 5 complete workflow playbooks
├── 07-cheat-sheet.md                  ← Top 15 power prompts
└── PRODUCT-INFO.md                    ← Product details
```

---

### Let's Go

Flip to `02-ceremonies-prompts.md` to prep for your next sprint event, or jump directly to the section that solves your most urgent problem.

*Your next great sprint starts with a great prompt.* 🚀
