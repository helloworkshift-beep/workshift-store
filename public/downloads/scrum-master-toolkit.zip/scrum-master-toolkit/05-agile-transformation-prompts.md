# 05 — Agile Transformation Prompts
## Team Health Checks · Maturity Assessments · Training Materials · Agile Adoption · Metrics Reporting

---

> **15 prompts** to help you drive, measure, and sustain agile transformation across teams and organizations.

---

## 🏥 TEAM HEALTH CHECKS

---

**Prompt 1: Team Health Check Designer**

*When to use:* Quarterly or after major changes (new team members, org restructure, product pivot) when you want to formally assess your team's agile health across multiple dimensions.

```
Help me design and facilitate a team health check assessment for my Scrum team.

Team context:
- Team name: [NAME]
- Team size: [X] people
- Time together: [X months/years]
- Previous health check: [DATE or "never done one"]
- Known areas of concern: [DESCRIBE]
- Areas where the team is strong: [DESCRIBE]

Please:
1. Design a 12-dimension team health check covering: agile ceremonies, technical practices, team dynamics, product clarity, stakeholder relationships, continuous improvement, delivery reliability, quality, autonomy, learning, wellbeing, and purpose
2. For each dimension, provide:
   - 3 diagnostic questions
   - A 1-5 scoring rubric with descriptions for each score
   - Green/Amber/Red health indicators
3. Create a facilitation guide for running the health check session (60 minutes)
4. Design a visual "health radar" description I can build in a spreadsheet
5. Provide a template for the health check report
6. Create a 90-day improvement plan structure based on common low-score areas
```

---

**Prompt 2: Squad Health Check (Spotify Model)**

*When to use:* When your organization uses the Spotify model or similar tribe/squad structure and you want to run a health check using the Spotify-inspired framework.

```
Help me facilitate a Spotify-model squad health check for my team.

Squad details:
- Squad name: [NAME]
- Mission: [SQUAD MISSION STATEMENT]
- Size: [X] people
- Chapter/tribe context: [DESCRIBE organizational structure]
- Last health check date: [DATE or "first time"]

The 11 Spotify health check areas: Easy to Release, Suitable Process, Tech Quality, Value, Speed, Mission, Fun, Learning, Support, Pawns or Players, Teamwork

For each area, please:
1. Write 2 discussion questions tailored to our squad context
2. Define what "Awesome," "OK," and "Needs Improvement" look like for our type of work: [DESCRIBE what your squad builds]
3. Provide example conversation starters for each area

Additionally:
4. Design the session flow (90-minute version)
5. Create the trend tracking template to compare across quarters
6. Provide a report template for sharing with the tribe
7. Suggest improvement experiments for common low-scoring areas
```

---

**Prompt 3: Team Health Trend Report**

*When to use:* After running 2+ health checks when you want to analyze trends, report to leadership, and identify systemic patterns.

```
Help me analyze and report on team health trends across multiple health check cycles.

Health check history:
Q[X] [YEAR]: [LIST scores or ratings for each dimension]
Q[X] [YEAR]: [LIST scores or ratings for each dimension]
Q[X] [YEAR]: [LIST scores or ratings for each dimension]

Team changes during this period: [DESCRIBE: e.g., 2 new members joined, manager changed, new product direction]
Significant events: [E.g., major release, incident, org restructure]

Please provide:
1. A trend analysis: what's improving, declining, or stagnant
2. Root cause hypotheses for negative trends
3. Validation that positive trends are sustainable (or flags if they're at risk)
4. A narrative report for leadership (1-2 pages)
5. A visual description for a trend chart I can build
6. Top 3 priority areas to address in the next quarter
7. Recommended interventions for each priority area
```

---

## 📊 MATURITY ASSESSMENTS

---

**Prompt 4: Agile Maturity Assessment**

*When to use:* When your organization wants to formally assess where teams are on their agile journey — for a new engagement, a program review, or a transformation checkpoint.

```
Help me design and conduct an agile maturity assessment for [TEAM/DEPARTMENT/ORGANIZATION].

Scope of assessment: [SINGLE TEAM / MULTIPLE TEAMS / DEPARTMENT-WIDE / ENTERPRISE]
Number of teams: [X]
Agile frameworks in use: [SCRUM / KANBAN / SAFe / LESS / HYBRID]
Industry: [E.g., financial services, healthcare, tech, manufacturing]
How long they've been doing agile: [X months/years]
Trigger for the assessment: [E.g., executive request, program kickoff, transformation checkpoint, team struggling]

Please create:
1. A maturity model with 5 levels (Initial → Defined → Managed → Optimizing → Innovating)
2. For each of these 10 dimensions, define what each maturity level looks like:
   - Sprint ceremonies adherence
   - Backlog management
   - Definition of Done
   - Continuous integration/deployment
   - Cross-functional teamwork
   - Product Owner engagement
   - Impediment removal speed
   - Metrics-driven improvement
   - Stakeholder collaboration
   - Team self-organization
3. An assessment questionnaire (3 questions per dimension)
4. Scoring methodology
5. A recommended maturity level report format
6. Improvement roadmap template by level
```

---

**Prompt 5: Scrum Master Maturity Self-Assessment**

*When to use:* Annually or when seeking certification, promotion, or mentorship — to honestly evaluate your own growth as a Scrum Master or agile coach.

```
Create a comprehensive Scrum Master maturity self-assessment tool.

Assessment areas to cover:
1. Scrum framework knowledge and application
2. Facilitation skills
3. Coaching and mentoring
4. Impediment removal effectiveness
5. Stakeholder management
6. Agile metrics literacy
7. Servant leadership practice
8. Continuous improvement facilitation
9. Organizational change navigation
10. Business acumen and value focus

For each area:
- Define 4 maturity levels: Developing → Practicing → Advanced → Expert
- Provide 4-5 observable behaviors/outcomes for each level
- Create 3 self-reflection questions to determine my level
- Suggest specific growth actions to move to the next level

Additional:
- Create a scoring system and overall maturity profile
- Design a development plan template based on assessment results
- Provide a recommended reading/certification path for each maturity level
- Create a peer-review version so teammates can give feedback
```

---

**Prompt 6: Agile Practice Audit**

*When to use:* When joining a new team as Scrum Master, or when leadership suspects agile practices have drifted from intended standards.

```
Help me conduct an agile practice audit for a team I'm observing/supporting.

Audit context: [E.g., I'm a new SM joining this team / leadership asked me to assess / post-reorganization check]
Team: [BRIEF DESCRIPTION]
Frameworks they claim to use: [SCRUM/KANBAN/OTHER]
Duration of audit: [X days of observation]

Observations I've made so far:
- Ceremonies: [DESCRIBE what you've seen in standups, planning, retros]
- Backlog: [DESCRIBE state of backlog — refined? prioritized? story quality?]
- Board: [DESCRIBE how the board is used — actively managed or stale?]
- Team interactions: [DESCRIBE dynamics in meetings and day-to-day]
- Metrics: [DESCRIBE what metrics they track, if any]
- SM/PO role: [DESCRIBE how these roles function]

Please provide:
1. A structured audit report template
2. Gap analysis: what they say vs. what I observe
3. Prioritized list of practice gaps (high/medium/low impact)
4. Recommended improvement sequence (what to fix first)
5. How to present audit findings without alienating the team
6. A 60-day improvement roadmap
7. Success metrics to track improvement
```

---

## 📚 TRAINING MATERIALS

---

**Prompt 7: Agile Foundations Training Module**

*When to use:* When onboarding a new team to agile, training stakeholders on Scrum basics, or creating educational content for an organization new to agile.

```
Create an "Agile Foundations" training module for [AUDIENCE: e.g., new team members, business stakeholders, managers, executives].

Audience context:
- Background: [E.g., former waterfall PMs, business analysts, technical architects]
- Agile experience: [NONE/LIMITED/SOME]
- What they need to understand: [DESCRIBE outcomes: e.g., why we work this way, how to interact with Scrum teams, what to expect from agile delivery]
- Time available: [X hours/minutes]
- Delivery format: [WORKSHOP/SLIDE DECK/SELF-PACED/LUNCH-AND-LEARN]

Create:
1. A training outline with learning objectives
2. Core content for each section (key concepts in plain language)
3. Three engaging exercises or activities for each major topic
4. Real-world examples and analogies tailored to [INDUSTRY/CONTEXT]
5. A "myth vs. reality" section addressing common agile misconceptions
6. A quiz or knowledge check
7. A "cheat sheet" handout they take away
8. Facilitator notes for delivering this training
```

---

**Prompt 8: Scrum Ceremony Training for Stakeholders**

*When to use:* When stakeholders attend Scrum ceremonies without understanding what's expected of them, or when you want to improve the quality of stakeholder participation.

```
Create a stakeholder guide to Scrum ceremonies.

Target audience: [E.g., business sponsors, product directors, executives, end users]
Their pain points: [DESCRIBE: e.g., they don't know what to do in sprint reviews, they talk too much in planning, they skip ceremonies entirely]
Ceremonies to cover: [Sprint Planning / Sprint Review / Retrospective / Backlog Refinement — select applicable]
Tone: [FORMAL/SEMI-FORMAL/CONVERSATIONAL]

For each ceremony, create a "Stakeholder's Guide" section including:
1. What this ceremony is and why it matters (in business terms)
2. Your role as a stakeholder (observer, participant, decision-maker)
3. What to prepare before attending
4. What great stakeholder participation looks like
5. What NOT to do (common stakeholder anti-patterns)
6. Questions you should be ready to answer
7. How to give useful feedback

Format: Create a one-page visual reference card they can keep and a longer document version.
```

---

**Prompt 9: Agile Leadership Training**

*When to use:* When training managers, directors, or executives on how to lead in an agile environment — particularly around letting go of command-and-control practices.

```
Create an "Agile Leadership" training workshop for managers and directors.

Audience: [ROLE: e.g., middle managers, department directors, VPs]
Their current style: [DESCRIBE: e.g., strong command-and-control, used to detailed project plans, Gantt chart culture]
Their concerns about agile: [DESCRIBE: e.g., "How do I know what my team is doing?", "What do I do all day?", "How do I plan headcount?"]
Organization's agile maturity: [BEGINNING / PROGRESSING / ADVANCED]
Workshop duration: [X hours]

Create:
1. Workshop outline with learning objectives
2. The mindset shift: from managing tasks to enabling teams
3. What agile leaders DO differently (behaviors, not titles)
4. How to provide vision and context without micromanaging
5. Metrics leaders should track (outcome vs. activity metrics)
6. How to remove impediments at the leadership level
7. Interactive exercises: role-play scenarios, case studies
8. A "leader's pledge" activity to commit to new behaviors
9. 30-day challenge: specific actions to take after the training
10. Facilitator guide for delivery
```

---

## 🌱 AGILE ADOPTION

---

**Prompt 10: Agile Transformation Roadmap**

*When to use:* When beginning or restarting an agile transformation initiative and you need a structured plan to present to leadership.

```
Help me design an agile transformation roadmap for [ORGANIZATION/DEPARTMENT].

Organization context:
- Industry: [INDUSTRY]
- Size of transformation: [X] teams / [X] total people
- Current state: [DESCRIBE how work is done today — waterfall, hybrid, chaos, etc.]
- Trigger for transformation: [E.g., competitive pressure, new CTO, failed projects]
- Executive sponsorship level: [STRONG/MODERATE/WEAK]
- Budget available: [DESCRIBE or "unknown"]
- Target timeline: [X months/years to get to defined state]
- Key resistance anticipated: [DESCRIBE]

Please create:
1. A phased transformation roadmap (Phase 1: Foundation, Phase 2: Practice, Phase 3: Optimize, Phase 4: Scale)
2. Key activities and milestones for each phase
3. Success metrics for each phase
4. Governance model for the transformation
5. Change management plan: how to bring people along
6. Risk register for common transformation pitfalls
7. How to demonstrate early wins to sustain momentum
8. A one-page executive summary of the roadmap
```

---

**Prompt 11: Resistance to Agile Handling Guide**

*When to use:* When facing significant organizational resistance to agile adoption — from individual team members, managers, or entire departments.

```
Help me develop a strategy for addressing resistance to agile transformation.

The resistance I'm facing:
- Who is resisting: [DESCRIBE: roles, levels, departments]
- What they're saying (their stated objections): [LIST VERBATIM if possible]
- What might really be driving the resistance: [YOUR ASSESSMENT: e.g., fear of job change, loss of control, past failed agile attempts]
- Intensity of resistance: [LIGHT/MODERATE/SIGNIFICANT]
- Key decision-maker's position: [SUPPORTIVE/NEUTRAL/RESISTANT]

Organization context:
- Type: [E.g., large enterprise, government, family-owned business]
- Culture: [E.g., hierarchy-driven, risk-averse, innovation-focused]
- Previous agile attempts: [DESCRIBE success/failure history]

Please help me:
1. Classify each type of resistance (technical, political, personal, cultural)
2. Develop tailored response strategies for each type
3. Identify who I need to win over first (influence map)
4. Create "safe experiments" I can propose to skeptics
5. Build a coalition of early adopters
6. Communication messaging for different resistance personas
7. Know when resistance is telling me something valid about the transformation approach
```

---

**Prompt 12: Agile Community of Practice Builder**

*When to use:* When you want to create a self-sustaining learning community among Scrum Masters, agile coaches, and agile practitioners within your organization.

```
Help me design and launch an Agile Community of Practice (CoP) for our organization.

Organization context:
- Number of Scrum Masters/agile coaches: [X]
- Number of agile teams: [X]
- Geographic distribution: [LOCAL/REMOTE/GLOBAL]
- Current peer learning culture: [DESCRIBE: e.g., no sharing between teams, informal ad-hoc, strong learning culture]
- Leadership support for CoP: [YES/CONDITIONAL/UNKNOWN]

Design the CoP including:
1. Purpose statement and value proposition
2. Membership: who should join and how
3. Meeting cadence and format (monthly full group + smaller working groups)
4. Topic calendar for the first 6 months
5. How to facilitate knowledge sharing without it becoming a lecture series
6. Governance: how decisions are made, how it evolves
7. How to measure CoP effectiveness
8. How to get leadership buy-in and possibly budget
9. Tools and platforms for async collaboration
10. Launch event agenda
```

---

## 📉 METRICS REPORTING FOR TRANSFORMATION

---

**Prompt 13: Agile Transformation Metrics Dashboard**

*When to use:* When you need to report on the progress and health of an agile transformation program to leadership — beyond just individual team metrics.

```
Help me design an agile transformation metrics dashboard for leadership reporting.

Transformation scope: [X] teams in [DEPARTMENT/ORGANIZATION]
Reporting audience: [E.g., CTO, Transformation Steering Committee, Program Board]
Reporting frequency: [MONTHLY/QUARTERLY]
Current data sources available: [E.g., Jira, survey tools, attendance tracking, production systems]

Design a dashboard covering:
1. Adoption metrics: ceremony adherence, story format compliance, DoD usage
2. Delivery metrics: velocity trends, lead time, deployment frequency, defect rates
3. Team health metrics: health check scores, retrospective action completion, impediment resolution time
4. Business outcome metrics: time-to-market, customer satisfaction, revenue impact (if measurable)
5. People metrics: SM/team engagement, training completion, CoP participation

For each metric, specify:
- What it measures and why it matters
- How to collect the data
- Green/Amber/Red thresholds
- How to trend it over time
- Common misinterpretation and how to prevent it

Also create a one-page transformation health summary for executives.
```

---

**Prompt 14: Agile Survey Design**

*When to use:* When you want to gather quantitative and qualitative data from teams and stakeholders about their agile experience — before or during a transformation.

```
Help me design an agile transformation survey.

Survey purpose: [E.g., baseline before transformation / mid-point check / annual assessment]
Target respondents: [E.g., development team members / Product Owners / Scrum Masters / managers / business stakeholders]
Number of expected respondents: [X]
Survey tool to be used: [GOOGLE FORMS/TYPEFORM/SURVEY MONKEY/MICROSOFT FORMS/OTHER]
Time respondents have to complete: [X minutes]
Anonymous: [YES/NO]

Design a survey covering:
1. Agile ceremony effectiveness (5 questions)
2. Team dynamics and collaboration (5 questions)
3. Product clarity and backlog quality (4 questions)
4. Leadership support and organizational impediments (4 questions)
5. Continuous improvement and learning (4 questions)
6. Individual satisfaction and engagement (3 questions)
7. Open-ended questions for qualitative insight (3 questions)

For each question:
- Write the exact question text
- Specify: Likert scale / multiple choice / open text
- Explain what you'll learn from this question

Also create:
- A cover note to send with the survey link
- An analysis framework for interpreting results
- A presentation template for sharing results
```

---

**Prompt 15: Agile Transformation Case Study Builder**

*When to use:* After a successful (or instructive unsuccessful) transformation to document learnings, share with the organization, or build your professional portfolio.

```
Help me write an agile transformation case study.

The transformation:
- Organization/team (anonymized if needed): [DESCRIBE]
- Duration: [X months/years]
- Scale: [X teams, X people]
- Starting point: [DESCRIBE what it looked like before]
- What was implemented: [DESCRIBE the frameworks, practices, changes introduced]
- Outcomes achieved: [LIST measurable results]
- What didn't work as planned: [DESCRIBE honestly]
- Key lessons learned: [LIST]

Purpose of this case study: [E.g., internal knowledge sharing / conference presentation / portfolio / article]
Target audience: [E.g., other Scrum Masters / executives / agile community]

Write:
1. An executive summary (300 words)
2. Context and challenge section
3. The approach and timeline section
4. Results and metrics section
5. Lessons learned and what we'd do differently
6. Conclusion and key takeaways
7. 5 quotes from team members or stakeholders (fictional but realistic placeholders I can fill with real quotes)
8. A 1-page visual summary version
```

---

*End of Agile Transformation Prompts — 15 prompts total*
