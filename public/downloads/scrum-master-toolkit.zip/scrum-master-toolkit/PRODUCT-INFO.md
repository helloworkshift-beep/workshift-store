# PRODUCT INFO
## The Scrum Master's AI Prompt Toolkit

---

## PRODUCT DETAILS

| Field | Value |
|---|---|
| **Product Name** | The Scrum Master's AI Prompt Toolkit |
| **Version** | 1.0 — Professional Edition |
| **Price** | $57 |
| **Purchase Link** | https://buy.stripe.com/8x2dRbcvL45bcw1bYIgEg02 |
| **Format** | Digital download (7 Markdown files) |
| **Compatible With** | ChatGPT, Claude, Gemini, Copilot, and any capable LLM |

---

## SALES DESCRIPTION (200 words)

Stop staring at a blank screen before every ceremony. The Scrum Master's AI Prompt Toolkit gives you 80+ battle-tested AI prompts specifically designed for the work Scrum Masters do every day — facilitating sprints, coaching teams, removing blockers, and communicating with stakeholders.

Every prompt is pre-engineered with the right context, structure, and instructions so that any AI model produces professional, immediately usable output. Just fill in the brackets with your team's details and go.

Inside you'll find prompts for every ceremony (planning, retrospectives, standups, reviews, refinement), coaching conversations that actually change behavior, impediment escalation emails that make leadership take you seriously, executive summaries that highlight your team's value, and a complete agile transformation playbook.

But prompts alone aren't enough — that's why this toolkit also includes 5 complete Workflow SOPs: end-to-end playbooks for sprint kickoffs, retrospective facilitation, impediment escalation, new team member onboarding, and quarterly health reviews. Each SOP tells you exactly which prompt to use, when, and how to sequence everything for maximum impact.

Whether you're a new Scrum Master building confidence or a seasoned pro wanting to work faster and smarter, this toolkit will save you hours every sprint — and make you look exceptional doing it.

---

## HEADLINE OPTIONS

Choose one as your primary headline. A/B test the others.

**Headline 1 (Pain → Solution):**
> **Stop Reinventing the Wheel Every Sprint. 80+ AI Prompts Built Specifically for Scrum Masters.**

**Headline 2 (Time Savings):**
> **Save Hours Every Sprint. The Complete AI Prompt Library for Scrum Masters Who Want to Facilitate, Coach, and Communicate at Their Best.**

**Headline 3 (Outcome Focused):**
> **Run Better Retros. Remove Blockers Faster. Impress Stakeholders. The Scrum Master's AI Prompt Toolkit.**

**Headline 4 (Authority/Professional Identity):**
> **The AI Prompt Toolkit Every Professional Scrum Master Should Have. 80+ Prompts, 5 SOPs, 1 Cheat Sheet. $57.**

**Headline 5 (Curiosity/Urgency):**
> **What If Every Ceremony You Facilitated This Sprint Was Your Best One Yet? Meet the Scrum Master's AI Prompt Toolkit.**

---

## TARGET AUDIENCE

### Primary Audience
- **Certified Scrum Masters (CSM, PSM, SAFe SM)** actively working with one or more development teams
- **Agile Coaches** who support Scrum Masters or directly facilitate teams
- **Project Managers transitioning to Scrum** who want to accelerate their learning curve

### Secondary Audience
- **Product Owners** who co-facilitate ceremonies and want better prompts for backlog work and stakeholder communication
- **Engineering Managers / Dev Leads** who wear a Scrum Master hat without the formal title
- **Agile consultants** who want ready-made, customizable tools for client engagements

### Audience Characteristics
- Uses AI tools regularly but finds the output generic or not fit for Scrum contexts
- Spends too much time preparing for ceremonies, writing status updates, or drafting escalation communications
- Wants to coach their team more effectively but isn't sure how to structure the conversation
- Is under pressure to demonstrate the value of agile to skeptical leadership
- Works in software development, product, or technology-adjacent teams of 3–15 people
- Experience range: 6 months to 10+ years in Scrum / agile roles

### Pain Points This Product Addresses
1. Ceremony preparation is time-consuming and repetitive
2. Retrospectives feel stale — same format every sprint
3. Blocker escalations feel awkward or fall on deaf ears
4. Hard to communicate team progress in terms leadership cares about
5. Coaching conversations lack structure or don't produce behavior change
6. No system for onboarding new team members to Scrum
7. AI tools produce generic output that doesn't fit the Scrum context

---

## INCLUDED FILES

| # | Filename | Description | Prompt Count |
|---|---|---|---|
| 1 | `01-quick-start-guide.md` | How to use the toolkit, prompt anatomy, best practices, troubleshooting guide | — |
| 2 | `02-ceremonies-prompts.md` | Sprint planning, retrospectives, daily standups, sprint reviews, backlog refinement | 25 |
| 3 | `03-team-coaching-prompts.md` | Impediment removal, team conflict, motivation, psychological safety, coaching conversations, performance issues | 20 |
| 4 | `04-stakeholder-communication-prompts.md` | Status updates, velocity reports, impediment escalations, release communications, executive summaries | 20 |
| 5 | `05-agile-transformation-prompts.md` | Team health checks, maturity assessments, training materials, agile adoption, metrics reporting | 15 |
| 6 | `06-workflow-sops.md` | 5 complete end-to-end workflow SOPs: Sprint Kickoff System, Retrospective Facilitation Playbook, Impediment Escalation Process, New Team Member Onboarding, Quarterly Agile Health Review | — |
| 7 | `07-cheat-sheet.md` | Top 15 power prompts (full text), 10 Golden Rules of Prompting for Scrum Masters, quick-reference card | 15 |

**Total: 80+ prompts across 7 files**

---

## KEY SELLING POINTS (For Sales Copy / Social Media)

- ✅ 80+ prompts engineered specifically for Scrum Masters — not generic business prompts
- ✅ Works with any AI: ChatGPT, Claude, Gemini, Copilot, and more
- ✅ 5 complete SOPs — step-by-step workflow playbooks for the most important SM processes
- ✅ Covers every ceremony: planning, retros, standups, reviews, refinement
- ✅ Coaching prompts built on proven frameworks (GROW, 5 Whys, Psychological Safety Stages)
- ✅ Executive communication prompts that make leadership take you seriously
- ✅ Ready to use immediately — just fill in the brackets and go
- ✅ One-time purchase, yours forever — no subscription
- ✅ Works whether you're new to Scrum or a 10-year veteran

---

## PRICING RATIONALE

At $57, this toolkit is priced at less than one hour of a Scrum Master's time. A typical SM spends 3–5 hours per sprint preparing for ceremonies, drafting communications, and planning coaching conversations. This toolkit reduces that preparation time by an estimated 60–80%, delivering its full value within the first sprint it's used.

**Comparable alternatives:**
- Scrum Master training courses: $300–$2,000
- Agile coaching books: $20–$40 each (without prompts)
- Generic AI prompt packs: $20–$100 (not tailored for Scrum)
- Hiring an agile coach for one day: $1,500–$5,000

At $57, this is the highest-ROI agile tool most Scrum Masters will ever buy.

---

## FREQUENTLY ASKED QUESTIONS

**Q: Which AI tools does this work with?**
A: Any capable large language model — ChatGPT (GPT-4 or newer), Claude (any version), Google Gemini, Microsoft Copilot, or any similar tool. The prompts are model-agnostic.

**Q: I'm new to Scrum. Will this still be useful?**
A: Yes — the Quick Start Guide (File 01) is designed for new Scrum Masters, and the prompts explain what each one does and when to use it. Many buyers report it accelerated their learning significantly.

**Q: I'm an experienced SM. Will I find value?**
A: Experienced SMs report the biggest value from the communication prompts (File 04), the SOPs (File 06), and the cheat sheet (File 07) — they save preparation time without reinventing what already works.

**Q: How long do the files take to learn?**
A: You don't need to read them all upfront. Start with File 01 (30 minutes), then open the file that matches your current need. Most people find a high-value prompt in their first 10 minutes.

**Q: Can I use these prompts for my clients (if I'm a consultant)?**
A: Yes — this is a single-user license for personal and client use. You may use the prompts with your teams and clients. You may not resell or redistribute the files themselves.

---

*Product Version: 1.0 | Last Updated: 2026*
