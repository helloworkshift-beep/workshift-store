# 02 — Strategy & Roadmap Prompts

*25 prompts for PRDs, roadmaps, OKRs, prioritization frameworks, and feature specs*

---

## PRD PROMPTS

---

**Prompt 1: Full PRD Generator**

*When to use: Starting a new feature or initiative from scratch and need to produce a complete PRD quickly*

```
Write a full Product Requirements Document (PRD) for [FEATURE NAME].

Context:
- Product: [PRODUCT NAME AND ONE-SENTENCE DESCRIPTION]
- Target user: [USER PERSONA — role, company size, key pain point]
- Problem being solved: [DESCRIBE THE PROBLEM IN 2-3 SENTENCES]
- Business context: [WHY ARE WE BUILDING THIS NOW — strategic driver, competitive pressure, revenue opportunity]
- Scope: [WHAT IS IN SCOPE AND WHAT IS EXPLICITLY OUT OF SCOPE]
- Timeline: [TARGET LAUNCH QUARTER OR DATE]
- Engineering resources: [NUMBER OF ENGINEERS AND ROUGH CAPACITY]

The PRD should include:
1. Problem Statement (user-centric, data-backed where possible)
2. Goals & Success Metrics (KPIs with target numbers)
3. User Stories (top 5-8, in standard format)
4. Functional Requirements (numbered, grouped by area)
5. Non-Functional Requirements (performance, security, accessibility)
6. Out of Scope (explicit list)
7. Open Questions (unresolved decisions that need input)
8. Dependencies (teams, systems, third parties)
9. Risks & Mitigations
10. Launch Considerations (rollout strategy, comms, support readiness)

Write it in professional PM voice. Be specific. No vague requirements like "should be fast" — say "p99 latency under 300ms." Flag any assumptions you're making.
```

---

**Prompt 2: PRD Executive Summary**

*When to use: You have a detailed PRD and need a crisp 1-page summary for leadership review*

```
Write a 1-page Executive Summary for the following PRD. This summary will be read by [C-SUITE TITLE, e.g., CEO, CPO] who has 3 minutes and will decide whether to greenlight this initiative.

PRD Content:
[PASTE YOUR FULL PRD HERE]

The Executive Summary should include:
- Problem: What customer pain are we solving? (2-3 sentences, user and business framing)
- Solution: What are we building? (3-4 sentences max)
- Why now: What's the strategic or market reason to prioritize this? (2-3 sentences)
- Success metrics: What does winning look like? (3-5 measurable KPIs)
- Investment required: Engineering effort, timeline, dependencies
- Risk: Top 1-2 risks and mitigations
- Ask: What decision or approval do you need?

No jargon. No feature lists. Translate everything to business impact. Bullet points are fine. Max 400 words.
```

---

**Prompt 3: PRD Open Questions Resolver**

*When to use: You have a draft PRD with open questions and need to think through them systematically before a stakeholder review*

```
I'm working on a PRD for [FEATURE NAME] and have the following open questions I need to resolve before the document is ready for review:

[LIST YOUR OPEN QUESTIONS — e.g., 
1. Should we build this as a native feature or rely on a third-party integration?
2. Do we support single user or team-level access for the MVP?
3. How should we handle existing users who have workarounds in place?]

For each question, please:
1. Identify what type of decision this is (technical, business, UX, policy)
2. List the 2-3 most important factors to consider
3. Present 2-3 viable options with brief pros/cons
4. Make a recommendation with rationale
5. Identify who the right decision-maker is (PM, Eng Lead, CPO, CEO, etc.)

Context about the product and team:
- Product: [PRODUCT NAME AND DESCRIPTION]
- Company stage: [SEED / SERIES A / SERIES B / GROWTH]
- Team structure: [RELEVANT TEAM INFO]
- Key constraints: [BUDGET / TIMELINE / TECH STACK CONSTRAINTS]
```

---

**Prompt 4: Functional Requirements Breakdown**

*When to use: You have a feature idea or user story and need to break it down into precise, engineering-ready functional requirements*

```
Break down the following feature into detailed functional requirements ready for engineering estimation.

Feature: [FEATURE NAME AND BRIEF DESCRIPTION]
User goal: [WHAT THE USER IS TRYING TO ACCOMPLISH]
Business goal: [WHAT THE BUSINESS NEEDS FROM THIS FEATURE]

Current system context: [DESCRIBE RELEVANT PARTS OF THE EXISTING PRODUCT OR ARCHITECTURE]

Please produce:
1. **Functional Requirements** — numbered list, written as "The system shall..." or "Users can..." — grouped by: Core Flow, Edge Cases, Error States, Admin/Settings, Notifications/Comms
2. **Data Requirements** — what data needs to be stored, updated, or displayed
3. **Integration Points** — external APIs, internal services, or data sources involved
4. **Permissions & Access Control** — who can do what
5. **Validation Rules** — any business logic or constraints on inputs/outputs

Be specific enough that an engineer could estimate without asking clarifying questions. Flag anything that requires a design decision before it can be fully specified.
```

---

**Prompt 5: Feature Spec for Engineering Handoff**

*When to use: Moving from PRD to a tight engineering handoff spec that reduces back-and-forth with the dev team*

```
Write a feature specification for engineering handoff based on this context:

Feature: [FEATURE NAME]
PRD summary or user story: [PASTE RELEVANT CONTENT]
Design link: [URL OR "TBD"]
Target sprint: [SPRINT NUMBER OR DATE]

The spec should include:
- **Feature Summary** (2-3 sentences, written for an engineer, not a stakeholder)
- **Acceptance Criteria** (explicit, testable — what "done" looks like)
- **API/Endpoint Changes** (if applicable — describe expected inputs/outputs)
- **Data Model Changes** (new fields, tables, relationships)
- **UI Behavior** (state-by-state description of what the user sees and the system does)
- **Error Handling** (every known failure case and expected behavior)
- **Analytics Events** (events to fire, properties to include)
- **Rollout Plan** (feature flag, % rollout, kill switch?)
- **Definition of Done** (checklist: unit tests, integration tests, QA sign-off, monitoring alert, docs updated)

Write it in technical but accessible language. Prioritize precision over polish.
```

---

## ROADMAP PROMPTS

---

**Prompt 6: Quarterly Roadmap Builder**

*When to use: Quarterly planning season and you need to structure your roadmap around company priorities*

```
Help me build a structured product roadmap for [Q + YEAR] for [PRODUCT NAME].

Company context:
- Stage: [SEED / SERIES A / SERIES B / ETC.]
- Company-level OKRs or priorities for this quarter: [LIST 2-4 TOP COMPANY GOALS]
- Revenue target this quarter: [ARR TARGET OR GROWTH GOAL]
- Key strategic bets: [ANY MAJOR STRATEGIC THEMES — e.g., "land enterprise", "expand to new vertical", "reduce churn"]

Engineering capacity: [NUMBER OF ENGINEERS × WEEKS AVAILABLE = ROUGH STORY POINTS OR PERSON-WEEKS]

Candidate initiatives (my working list):
[LIST 6-12 FEATURES, IMPROVEMENTS, OR PROJECTS YOU'RE CONSIDERING]

Please help me:
1. Map each initiative to a company priority (or flag if it doesn't clearly map)
2. Group them into themes (max 3-4 themes)
3. Suggest a Now / Next / Later sequencing based on impact + effort
4. Identify any sequencing dependencies (X must come before Y)
5. Flag capacity risks — what probably doesn't fit this quarter
6. Suggest 2-3 "if we have time" stretch items
7. Draft a one-paragraph roadmap narrative I can share with the team

Format as a structured table plus narrative.
```

---

**Prompt 7: Roadmap Narrative for All-Hands**

*When to use: Presenting the product roadmap at a company all-hands or team meeting and need a compelling story, not just a Gantt chart*

```
Write a compelling roadmap narrative for a company all-hands presentation. This is not a feature list — it's a story about where we're going and why.

Audience: [ALL EMPLOYEES / ENGINEERING TEAM / GO-TO-MARKET TEAM]
Company size: [NUMBER OF EMPLOYEES]
Quarter: [Q + YEAR]
Product: [PRODUCT NAME AND BRIEF DESCRIPTION]

Key roadmap themes for this quarter:
1. [THEME 1 — e.g., "Reliability & Performance"]
2. [THEME 2 — e.g., "Enterprise Readiness"]
3. [THEME 3 — e.g., "User Growth Features"]

Major initiatives:
[LIST 5-8 KEY INITIATIVES WITH 1-SENTENCE DESCRIPTIONS]

Please write:
- An opening hook (why this quarter matters strategically — 2-3 sentences)
- A narrative arc connecting the themes (why these 3 themes, why now, how they connect)
- A 2-3 sentence description of each theme that explains the user/business impact
- A closing that connects the roadmap to the company mission or year-end goal
- 3 "what this means for you" bullets for each major team (Eng, Sales, Support)

Tone: Energizing, clear, confident. No jargon. This is a speech, not a doc.
```

---

**Prompt 8: Roadmap Sequencing Decision**

*When to use: Two or more features are competing for the same sprint slot and you need a structured argument for which to prioritize*

```
Help me make a prioritization decision between the following features competing for the same engineering capacity.

Context:
- Product: [PRODUCT NAME]
- Available capacity: [X ENGINEER-WEEKS]
- Quarter goals: [2-3 KEY GOALS]

Feature A: [NAME]
- Estimated effort: [STORY POINTS OR WEEKS]
- Description: [1-2 SENTENCES]
- Who's asking for it: [CUSTOMERS / SALES / CEO / INTERNAL]
- Expected impact: [DESCRIBE IN TERMS OF REVENUE, RETENTION, ACQUISITION, OR EFFICIENCY]

Feature B: [NAME]
- Estimated effort: [STORY POINTS OR WEEKS]
- Description: [1-2 SENTENCES]
- Who's asking for it: [CUSTOMERS / SALES / CEO / INTERNAL]
- Expected impact: [DESCRIBE IN TERMS OF REVENUE, RETENTION, ACQUISITION, OR EFFICIENCY]

[REPEAT FOR FEATURE C, D IF APPLICABLE]

Please:
1. Evaluate each feature against: Strategic fit, User impact, Revenue impact, Effort, Risk
2. Score each on a 1-5 scale for each dimension with brief rationale
3. Identify any dependencies or sequencing constraints
4. Make a clear recommendation with reasoning
5. Write a 3-sentence explanation I can use when communicating this decision to stakeholders who asked for the losing feature(s)
```

---

## OKR PROMPTS

---

**Prompt 9: OKR Generator for Product Team**

*When to use: Setting quarterly OKRs for your product team and want a first draft that connects to company-level goals*

```
Write a set of OKRs for the [PRODUCT TEAM NAME] team for [Q + YEAR].

Company-level OKRs (the ones we need to support):
[LIST 2-4 COMPANY-LEVEL OBJECTIVES AND KEY RESULTS]

Product team context:
- Team size: [NUMBER OF PMS + ENGINEERS + DESIGNERS]
- Core product area: [DESCRIBE THE PART OF THE PRODUCT THIS TEAM OWNS]
- Last quarter's performance highlights: [1-3 THINGS THAT WENT WELL]
- Last quarter's gaps: [1-2 THINGS WE MISSED OR UNDERDELIVERED]

Key themes for this quarter: [2-3 THEMES OR FOCUS AREAS]

Please write:
- 3 Objectives (ambitious but believable, qualitative statements)
- 3-4 Key Results per Objective (measurable, time-bound, with specific metrics)
- 1 "health metric" per Objective (a leading indicator to watch weekly)
- A brief note on how each Objective maps to a company-level OKR

Make the KRs specific: not "improve NPS" but "increase NPS from 32 to 45 by end of Q2." Not "ship feature X" but "feature X reaches 40% weekly active user adoption within 6 weeks of launch."
```

---

**Prompt 10: OKR Scoring & Retrospective**

*When to use: End of quarter OKR review and need to write up a clear assessment of what you hit, missed, and why*

```
Write an OKR scoring and retrospective for the [PRODUCT TEAM NAME] team for [Q + YEAR].

Our OKRs were:
[PASTE YOUR TEAM'S OKRs]

Actual results:
[FOR EACH KEY RESULT, PROVIDE THE ACTUAL NUMBER ACHIEVED AND CONTEXT]

Please write:
1. **Score each KR** on a 0.0–1.0 scale (0.7 = on target) with a one-line rationale
2. **Score each Objective** as an average of its KRs
3. **What we delivered** — narrative paragraph of accomplishments (2-3 sentences, business framing, not feature list)
4. **What we missed and why** — honest, blame-free analysis of gaps (2-3 sentences per missed KR)
5. **Key learnings** — 3 bullets on what we'd do differently
6. **Carryover items** — what should roll into next quarter's OKRs
7. **Shoutouts** — 2-3 callouts of team or cross-functional contributions worth recognizing

Tone: Honest, direct, constructive. Not defensive. Acknowledge misses without dwelling. Celebrate wins without overselling.
```

---

## PRIORITIZATION FRAMEWORK PROMPTS

---

**Prompt 11: RICE Scoring Framework**

*When to use: You have a backlog of 10+ features and need a defensible, data-driven prioritization before roadmap planning*

```
Help me score and rank the following features using the RICE framework (Reach × Impact × Confidence ÷ Effort).

Product context: [PRODUCT NAME, STAGE, AND PRIMARY METRIC YOU'RE OPTIMIZING FOR]

Feature list:
[LIST EACH FEATURE WITH A 1-2 SENTENCE DESCRIPTION AND ANY DATA YOU HAVE]

For each feature, please:
- **Reach**: Estimate how many users this impacts per quarter (justify the number)
- **Impact**: Score 0.25 (minimal) / 0.5 (low) / 1 (medium) / 2 (high) / 3 (massive) — justify
- **Confidence**: % (100% = data-backed, 80% = strong signal, 50% = hypothesis, 20% = gut)
- **Effort**: Estimate in person-months (use [TEAM SIZE AND COMPOSITION] as baseline)
- **RICE Score**: Calculated result
- **Rank**: Final priority order

After scoring, please:
1. Group features into tiers (Must Do, Should Do, Nice to Have, Later)
2. Flag any features that score low but have strategic value not captured by RICE
3. Identify 2-3 quick wins (high RICE score, low effort)
4. Note any major assumptions that would change the ranking if wrong
```

---

**Prompt 12: Now-Next-Later Roadmap Framing**

*When to use: Communicating your roadmap without committing to specific dates, especially in a fast-moving environment*

```
Help me organize my product roadmap into a Now / Next / Later framework for [PRODUCT NAME].

Current context:
- Stage: [COMPANY STAGE]
- North Star Metric: [METRIC — e.g., weekly active users, ARR, activation rate]
- Key strategic focus: [1-2 SENTENCE DESCRIPTION OF CURRENT STRATEGIC DIRECTION]
- Engineering team size: [NUMBER]

Full feature/initiative list:
[LIST ALL ITEMS YOU'RE CONSIDERING — 10-20 ITEMS]

Please organize these into:
- **Now** (current sprint or this quarter — in progress or starting immediately)
- **Next** (next 1-2 quarters — well-defined, sequenced)
- **Later** (future — directional, not committed)
- **Parking Lot** (good ideas that don't fit the current strategy — don't kill, just defer)

For each item, write a one-sentence rationale for why it belongs in that bucket.

Also:
- Flag any dependencies (X is in Now but requires Y which is in Next — that's a sequencing problem)
- Suggest which "Next" items need a spike or discovery phase before they're ready to build
- Write a 2-sentence "why" for each Now/Next bucket I can use when presenting this to the team
```

---

**Prompt 13: Opportunity Assessment**

*When to use: Evaluating whether a new product area, market segment, or major feature bet is worth pursuing before committing resources*

```
Write a Product Opportunity Assessment for the following idea:

Opportunity: [DESCRIBE THE PRODUCT IDEA, MARKET EXPANSION, OR FEATURE BET IN 2-3 SENTENCES]

Context:
- Current product: [PRODUCT NAME AND BRIEF DESCRIPTION]
- Current customer base: [SIZE, TYPE, KEY SEGMENTS]
- Relevant data or signals: [CUSTOMER REQUESTS, COMPETITOR MOVES, MARKET DATA YOU HAVE]

Please structure the assessment as:
1. **Problem Statement** — What specific user pain or unmet need does this address?
2. **Market Opportunity** — Who are we targeting, how large is the segment, what's the TAM?
3. **Solution Hypothesis** — What are we proposing to build (directional, not detailed)?
4. **Strategic Fit** — How does this connect to current strategy, ICP, and go-to-market?
5. **Competitive Landscape** — Who else is solving this? How is our approach differentiated?
6. **Key Assumptions** — What must be true for this to work? (List 4-6)
7. **Risks** — What could kill this? (Technical, market, competitive, execution)
8. **Effort & Investment Estimate** — Rough order of magnitude (S/M/L/XL)
9. **Recommended Next Step** — What's the smallest experiment to validate the top assumption?
10. **Go / No-Go Recommendation** — With rationale

Be direct in the recommendation. Don't hedge.
```

---

**Prompt 14: Feature Deprecation Decision**

*When to use: Evaluating whether to sunset a feature, and need to make the case (or against the case) with data and user impact analysis*

```
Help me evaluate whether to deprecate [FEATURE NAME] from [PRODUCT NAME].

Feature context:
- What it does: [DESCRIPTION]
- When it was built: [APPROXIMATE DATE]
- Usage data: [MONTHLY ACTIVE USERS, % OF USER BASE, TREND — GROWING/FLAT/DECLINING]
- Maintenance burden: [HOW MUCH ENGINEERING TIME PER MONTH TO MAINTAIN]
- Known users/customers who rely on it: [NUMBER AND TYPE — e.g., "3 enterprise accounts, $400K ARR"]
- Reason for considering deprecation: [TECH DEBT / LOW USAGE / STRATEGY SHIFT / REPLACING WITH SOMETHING BETTER]

Please help me:
1. **Make the case FOR deprecation** — strongest arguments
2. **Make the case AGAINST deprecation** — risks and downsides
3. **Assess user impact** — who is affected, how severely, what workarounds exist
4. **Propose a deprecation strategy** — if we proceed: timeline, migration path, communication plan
5. **Propose an alternative** — if we don't deprecate: how to reduce the maintenance burden while keeping the feature
6. **Recommend a decision** with clear rationale
7. Write a **3-paragraph announcement email** to affected users if we decide to proceed

Tone for the announcement: Empathetic, clear, practical. Give users enough notice to adapt.
```

---

## FEATURE SPEC PROMPTS

---

**Prompt 15: MVP Scope Definition**

*When to use: You have a big feature idea and need to ruthlessly define the minimum viable version worth shipping*

```
Help me define the MVP scope for [FEATURE NAME].

Full vision for this feature (what the ideal version looks like):
[DESCRIBE THE FULL FEATURE IN AS MUCH DETAIL AS YOU HAVE]

Constraints:
- Must launch by: [DATE OR QUARTER]
- Engineering capacity available: [PERSON-WEEKS OR SPRINT CAPACITY]
- Key launch requirement (why we can't wait): [CUSTOMER COMMITMENT / COMPETITIVE PRESSURE / STRATEGIC DEADLINE]

Please help me:
1. **Identify the core job-to-be-done** — what single user outcome must the MVP deliver to be valuable?
2. **Strip to MVP** — what is the absolute minimum that delivers that outcome? (No "nice to haves")
3. **Create a V1 vs V2 vs V3 breakdown** — what goes in which iteration?
4. **Flag MVP risks** — what are we consciously choosing NOT to do in MVP that could be a problem?
5. **Define MVP success criteria** — specific metric that tells us MVP is working before we invest in V2
6. **Write a one-paragraph MVP framing** I can share with engineering and design to align on scope

Key question to answer: "What's the version of this that would make [TARGET USER] genuinely happy, even if it's missing [MOST DESIRED FEATURE]?"
```

---

**Prompt 16: A/B Test Design**

*When to use: Designing an experiment to validate a product hypothesis before committing to full build*

```
Design an A/B test for the following product hypothesis.

Hypothesis: [STATE YOUR HYPOTHESIS — e.g., "If we add a progress bar to the onboarding flow, users will be more likely to complete all 5 steps"]

Product context:
- Product: [PRODUCT NAME]
- Feature/flow being tested: [SPECIFIC FEATURE OR FLOW]
- Current baseline metric: [METRIC AND CURRENT VALUE — e.g., "Onboarding completion rate: 43%"]
- Target metric improvement: [WHAT WOULD CONSTITUTE A WIN — e.g., "5+ percentage point improvement"]
- Monthly traffic to this area: [NUMBER OF USERS OR EVENTS PER MONTH]

Please produce a full A/B test design:
1. **Test name** and hypothesis statement (formatted as "If [change], then [outcome] because [mechanism]")
2. **Control** vs **Variant(s)** — what exactly are we changing?
3. **Primary metric** (the one number that determines win/loss)
4. **Secondary metrics** (guardrail metrics — what we're making sure doesn't break)
5. **Sample size calculation** — minimum users needed per variant to reach 95% confidence (show the logic)
6. **Test duration** — how long to run given traffic volume
7. **Segmentation** — should we run this on all users or a specific segment?
8. **Risks** — what could contaminate results or make interpretation difficult?
9. **Decision criteria** — exact rules for how we'll interpret results (including inconclusive scenarios)
10. **Next steps** — what do we do after each outcome (win/loss/inconclusive)?
```

---

**Prompt 17: Technical Debt Prioritization**

*When to use: Engineering team has identified tech debt items and you need to help decide which to prioritize alongside product work*

```
Help me evaluate and prioritize the following technical debt items for inclusion in our roadmap.

Company context:
- Stage: [STAGE]
- Current product stability: [DESCRIBE — uptime, major incidents, performance issues]
- Team velocity: [HOW TECH DEBT IS CURRENTLY AFFECTING SPEED — e.g., "2-3 days per sprint lost to workarounds"]

Technical debt items from engineering:
[LIST EACH ITEM WITH: NAME, DESCRIPTION, ENGINEERING ESTIMATE, AND WHAT PROBLEM IT CAUSES]

Please:
1. **Categorize each item**: Reliability risk / Velocity drain / Security risk / Scalability blocker / Developer experience
2. **Score each item** on: Business impact (if ignored), Urgency, Effort
3. **Recommend which to include in the next roadmap** and which to defer
4. **Suggest how to frame tech debt items** for non-technical stakeholders (exec summary framing for each top item)
5. **Propose a "20% time" model** — what % of sprint capacity should we allocate to tech debt given our current situation?
6. Write a **2-paragraph tech health update** I can include in my next exec update

The framing I need: "Here's why investing in this is good for the business" — not just "engineers want to clean things up."
```

---

**Prompt 18: Build vs Buy vs Partner Analysis**

*When to use: Deciding whether to build a capability in-house, buy a third-party solution, or partner/integrate with another company*

```
Help me conduct a Build vs Buy vs Partner analysis for [CAPABILITY OR FEATURE AREA].

Context:
- Product: [PRODUCT NAME]
- Capability needed: [DESCRIBE WHAT YOU NEED — e.g., "email deliverability infrastructure", "AI-powered text summarization", "identity verification"]
- Why we need it: [BUSINESS OR USER DRIVER]
- Timeline pressure: [WHEN WE NEED THIS LIVE]

Build option:
- Estimated engineering cost: [PERSON-MONTHS OR "$X RANGE"]
- Technical complexity: [LOW / MEDIUM / HIGH]
- Our team's relevant expertise: [DO WE HAVE THE SKILLS?]

Buy/SaaS options (if you know them):
[LIST VENDORS YOU'RE AWARE OF, OR ASK AI TO SUGGEST THEM]

Partner options:
[ANY INTEGRATION PARTNERS OR WHITE-LABEL POSSIBILITIES]

Please analyze:
1. **Evaluation criteria** — what matters most for this decision (ranked)
2. **Score each option** across: Cost (year 1 and year 3), Time to ship, Control & customization, Scalability, Risk, Strategic value
3. **Make a recommendation** with clear rationale
4. **Identify the key risk of your recommended option** and mitigation
5. **Frame the decision** in a 3-sentence summary I can bring to the leadership team
```

---

**Prompt 19: Post-Launch Feature Review**

*When to use: 4-6 weeks after launch, reviewing a feature's performance and deciding what to do next*

```
Write a post-launch review for [FEATURE NAME], launched [DATE].

Feature summary: [1-2 SENTENCE DESCRIPTION OF WHAT WAS BUILT]

Success metrics (as defined in PRD):
[LIST TARGET METRICS AND CURRENT ACTUALS]

Usage data:
- Adoption rate: [% OF ELIGIBLE USERS WHO USED IT AT LEAST ONCE]
- Retention/repeat usage: [% WHO USED IT MORE THAN ONCE / WEEKLY ACTIVE USERS]
- Key funnel metrics: [RELEVANT CONVERSION RATES OR COMPLETION RATES]
- Feature-specific metrics: [ANY PRODUCT-SPECIFIC METRICS]

Qualitative signals:
- User feedback (support tickets, NPS comments, sales call notes): [SUMMARIZE KEY THEMES]
- Internal team observations: [ANYTHING NOTABLE FROM ENGINEERING, DESIGN, SUCCESS]

Please write a full post-launch review document including:
1. **TL;DR** — 3-bullet executive summary (hit / missed / key insight)
2. **What worked** — analysis of what drove success (or limited it)
3. **What didn't work** — honest assessment of gaps vs goals
4. **User feedback synthesis** — top 3 recurring themes
5. **Metrics deep-dive** — analysis of what the numbers mean, not just what they are
6. **Recommended next actions** — specific actions with owners and timelines:
   - Quick fixes (this sprint)
   - V2 scope (next quarter)
   - Features to sunset or simplify
7. **Key learnings for future launches** — 3 bullets to add to our launch playbook
```

---

**Prompt 20: Product Vision Document**

*When to use: Articulating a multi-year product vision for internal alignment, fundraising, or new team member onboarding*

```
Help me write a product vision document for [PRODUCT NAME].

Context:
- What the product does today: [CURRENT STATE — features, users, business model]
- Current customer base: [WHO USES IT, HOW MANY, KEY USE CASES]
- Company mission: [MISSION STATEMENT]
- 3-year strategic goal: [WHERE THE COMPANY IS TRYING TO GO]
- Key market trends supporting this vision: [2-4 RELEVANT TRENDS]
- Competitors and how we're different: [KEY COMPETITORS AND DIFFERENTIATION]

Please write a product vision document that includes:
1. **Vision Statement** — One sentence. Ambitious. Specific to the product's unique position. Not "we'll be the best X in the world." Should answer: "What does the world look like when this product has fully succeeded?"
2. **The Problem We're Solving** — Deep framing of the user/market problem (1 page max)
3. **Our Approach** — Core principles and philosophy behind how we're solving it (3-5 principles, not features)
4. **The Product We're Building Toward** — Narrative description of the product in 3 years (no feature list — tell the story of a user's experience)
5. **Why We Win** — Our unfair advantages: team, technology, distribution, timing, data
6. **What We're NOT Building** — Explicit scope constraints to keep the team focused
7. **Milestones on the Path** — 3-4 major milestones from now to the vision

Tone: Inspiring but grounded. This isn't a pitch deck — it's a north star document for the team. Write it like you believe it.
```

---

**Prompt 21: Pricing & Packaging Strategy**

*When to use: Evaluating or redesigning your product's pricing tiers and packaging ahead of a launch or pricing review*

```
Help me think through pricing and packaging strategy for [PRODUCT NAME].

Current state:
- Current pricing: [DESCRIBE CURRENT TIERS, PRICES, AND PACKAGING]
- Business model: [SUBSCRIPTION / USAGE-BASED / FREEMIUM / SEAT-BASED / ETC.]
- Average deal size: [ACV FOR DIFFERENT SEGMENTS IF KNOWN]
- Key customer segments: [LIST 2-4 SEGMENTS WITH BRIEF DESCRIPTIONS]

Context:
- Why we're revisiting pricing: [REASON — GROWTH STAGE, COMPETITIVE PRESSURE, NEW FEATURES, EXPANSION REVENUE]
- Pricing comparison to competitors: [WHAT YOU KNOW ABOUT COMPETITOR PRICING]
- Usage patterns: [WHAT ARE POWER USERS DOING DIFFERENTLY FROM LIGHT USERS?]

Please help me:
1. **Identify 2-3 pricing models** worth evaluating (describe each with pros/cons for our stage)
2. **Define value metrics** — what should pricing be anchored to? (seats, events, usage, outcomes)
3. **Recommend a tier structure** — what should each tier include and why?
4. **Identify expansion revenue levers** — how should customers naturally grow their spend?
5. **Flag pricing risks** — what's most likely to cause customer friction or churn?
6. **Suggest a testing approach** — how do we validate pricing without a full public rollout?
7. Write a **2-paragraph pricing narrative** for a customer-facing FAQ explaining "why this pricing"

Note any assumptions you're making about our business model or customer behavior.
```

---

**Prompt 22: Competitive Differentiation Framework**

*When to use: Articulating how your product is genuinely different from competitors, for internal strategy docs, sales enablement, or product positioning*

```
Help me build a competitive differentiation framework for [PRODUCT NAME].

Our product: [DESCRIBE WHAT YOU DO, WHO YOU SERVE, AND YOUR CORE VALUE PROPOSITION]

Key competitors:
1. [COMPETITOR 1]: [BRIEF DESCRIPTION OF WHAT THEY DO AND WHY CUSTOMERS CHOOSE THEM]
2. [COMPETITOR 2]: [BRIEF DESCRIPTION]
3. [COMPETITOR 3]: [BRIEF DESCRIPTION]
[ADD MORE IF NEEDED]

Our strengths (from customer feedback / win data): [LIST WHAT CUSTOMERS LOVE ABOUT US]
Our weaknesses (from loss data / churn feedback): [LIST WHERE WE LOSE]

Please build:
1. **Competitive positioning map** — describe where each competitor sits on 2 key dimensions (suggest the right dimensions for our market)
2. **Feature comparison table** — honest assessment of parity, advantage, and gap for top 10 capabilities
3. **Our right-to-win analysis** — where do we have genuine, defensible advantages?
4. **"Why we lose" analysis** — honest breakdown of deal scenarios where competitors win and why
5. **Differentiation narrative** — a 3-paragraph articulation of why we're genuinely different (not just "we're better")
6. **Product strategy implications** — based on this analysis, what are the 2-3 most important gaps to close?
```

---

**Prompt 23: Product Metrics Framework**

*When to use: Establishing or overhauling your product metrics system — from North Star to input metrics to health metrics*

```
Build a product metrics framework for [PRODUCT NAME].

Product context:
- Product type: [B2B SAAS / CONSUMER APP / MARKETPLACE / DEVELOPER TOOL / ETC.]
- Stage: [STAGE]
- Business model: [SUBSCRIPTION / USAGE / ETC.]
- Current key metrics tracked: [LIST WHAT YOU CURRENTLY MEASURE]
- Core user workflow: [DESCRIBE THE PRIMARY THING USERS DO IN YOUR PRODUCT]

Please build a full metrics framework:
1. **North Star Metric** — the single metric that best captures value delivered to users AND business health. Explain why it's the right one.
2. **Level 2 Input Metrics** — 4-6 metrics that directly drive the North Star (with directional arrows showing the relationship)
3. **Product Health Metrics** — reliability, performance, error rates (3-5 metrics)
4. **Leading vs Lagging indicators** — classify each metric
5. **Metric Definitions** — precise definition for each metric (what counts, what doesn't, time window)
6. **Instrumentation checklist** — what analytics events need to be tracked to calculate each metric
7. **Weekly / Monthly / Quarterly review cadence** — which metrics to review at what frequency
8. **Dashboard structure** recommendation — how to organize these for the exec team vs the product team

Flag any metrics that are commonly tracked but are vanity metrics for our context.
```

---

**Prompt 24: Moonshot / Exploratory Feature Brief**

*When to use: Exploring a bold, longer-horizon product idea that isn't ready for a PRD yet — need a structured exploration document to socialize the idea*

```
Write an exploratory brief for a potential moonshot product bet.

The idea: [DESCRIBE THE BOLD IDEA IN 2-4 SENTENCES]
Why I'm excited about it: [YOUR INTUITION OR SIGNAL THAT PROMPTED THIS — CUSTOMER FEEDBACK, MARKET TREND, TECHNICAL CAPABILITY]

Current product: [PRODUCT NAME AND DESCRIPTION]
Company stage and constraints: [STAGE, TEAM SIZE, KEY CONSTRAINTS]

Please write a 1-2 page exploratory brief that includes:
1. **The Big Idea** — what is this, in plain English?
2. **The Problem It Solves** — for which user, how badly, and why can't they solve it today?
3. **Why Now** — what's changed (technology, market, user behavior) that makes this possible or timely?
4. **The Hypothesis** — what are we betting will be true if this works?
5. **What "winning" looks like** — if this succeeds in 3 years, what does it look like?
6. **Key risks and unknowns** — what could kill this (technical, market, competitive, regulatory)?
7. **Validation approach** — what's the smallest, cheapest way to test the core hypothesis in 4-8 weeks?
8. **Resource ask** — what would it take to run the validation experiment?

This is NOT a PRD. It's a "here's why this deserves 2 weeks of exploration" document. Keep it directional and compelling.
```

---

**Prompt 25: Product Strategy One-Pager**

*When to use: Annual or semi-annual strategy planning, or when you need to align leadership on product direction*

```
Write a Product Strategy One-Pager for [PRODUCT NAME] for [YEAR / H1 / H2].

Context:
- Company mission: [MISSION]
- Company goals for the period: [TOP 2-3 COMPANY GOALS]
- Current product state: [WHERE WE ARE TODAY — ARR, MAU, KEY WINS AND GAPS]
- Market context: [RELEVANT MARKET DYNAMICS, COMPETITIVE SHIFTS, OR CUSTOMER TRENDS]
- Resources available: [TEAM SIZE AND ROUGH CAPACITY]

Please write a tight, one-page strategy document that includes:
1. **Strategic Context** — why this period matters and what's changed (2-3 sentences)
2. **Product Bets** — 3 major bets we're making, each with: the bet, the thesis, the success signal
3. **What We're Optimizing For** — the 1-2 metrics that will tell us if the strategy is working
4. **What We're NOT Doing** — explicit deprioritizations (this is as important as what we're doing)
5. **Key Dependencies** — what do we need from other teams to execute this strategy?
6. **Biggest Risks** — top 2-3 risks to the strategy, with mitigation approach
7. **Review Checkpoints** — when and how will we know if we need to course-correct?

Format it as a document I can share with the entire company. One page max. Dense but readable.
```
