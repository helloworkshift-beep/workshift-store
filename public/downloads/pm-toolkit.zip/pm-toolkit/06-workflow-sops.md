# 06 — Workflow SOPs

*5 complete systems for your most time-intensive PM tasks — powered by AI*

---

> **How to use this file:** Each SOP is a repeatable, step-by-step process. Follow the steps in order, use the referenced prompt files at each stage, and replace the example inputs with your own. The goal isn't just to use AI — it's to have a *system* that produces consistent, professional output every time.

---

## SOP A: Write a Full PRD in 30 Minutes Using AI

**What this produces:** A complete, stakeholder-ready Product Requirements Document
**When to run it:** When you get alignment on building a new feature or initiative
**Time commitment:** 30 minutes (vs. 2–4 hours without AI)
**Prompt file:** `02-strategy-roadmap-prompts.md`

---

### The 30-Minute PRD System

**Before you start (5 minutes): Gather your raw inputs**

You need the following before opening your AI tool. Don't skip this — garbage in, garbage out.

- [ ] Feature name and one-sentence description
- [ ] The user problem (not the feature — the *problem*)
- [ ] Who the user is (persona, role, company size)
- [ ] Why we're building this now (business driver)
- [ ] What's in scope and what's explicitly NOT in scope
- [ ] Target launch date or quarter
- [ ] Engineering capacity (rough estimate)

---

**Step 1 — Set context (2 minutes)**

Open your AI tool and paste the system prompt from `01-quick-start-guide.md`:

```
You are an experienced senior Product Manager at a B2B SaaS startup. You write with clarity, precision, and a bias toward user outcomes over feature lists. You understand engineering constraints, business priorities, and user psychology. When I give you a prompt, produce clean, professional output I can use immediately — no unnecessary preamble or filler.
```

*This primes the AI for the rest of the session. Do this first, every time.*

---

**Step 2 — Generate the PRD skeleton (8 minutes)**

Use **Prompt 1: Full PRD Generator** from `02-strategy-roadmap-prompts.md`.

Fill in every bracket before pasting. The more specific your inputs, the less editing you'll need to do.

**Example input:**
```
Feature: Smart Notification Digest
Product: Workstream — a project management tool for ops teams at mid-market companies
Target user: Operations Manager, 50–500 person company, drowning in tool notifications
Problem: Users are missing critical updates because they're buried in notification noise; 68% of churned users cited "too many irrelevant notifications" in exit surveys
Business context: Reducing churn is our Q2 OKR; this addresses the #1 stated churn reason
Scope: In — daily/weekly digest email, user-controlled frequency settings; Out — in-app notification center redesign (Q3)
Timeline: Q2, targeting end of May
Engineering: 2 engineers, 6-week sprint
```

**What you'll get:** A full PRD draft with problem statement, goals, user stories, success metrics, technical considerations, and risks.

---

**Step 3 — Generate acceptance criteria (5 minutes)**

Without starting a new conversation, follow up with:

```
Now expand the user stories section. For each user story you wrote, add:
- 3–5 acceptance criteria (Given/When/Then format)
- Edge cases to handle
- A "definition of done" checklist item
```

*Staying in the same conversation means the AI has context from your PRD — the output will be much tighter than if you started fresh.*

---

**Step 4 — Generate success metrics (5 minutes)**

Still in the same conversation:

```
Revisit the Goals & Success Metrics section. For each metric you listed:
- Suggest how to measure it (what data source, what tool)
- Define what "good" looks like at 30 days, 60 days, and 90 days post-launch
- Flag any metrics that might be hard to instrument and suggest a proxy
```

---

**Step 5 — Review and edit (10 minutes)**

Paste the full AI output into your PRD template (Notion, Confluence, Google Doc). Do a human review pass:

- [ ] Does the problem statement sound like something a real user would say?
- [ ] Are the success metrics actually measurable with your current tools?
- [ ] Does the scope section clearly say what we're NOT building?
- [ ] Are the user stories written from the user's perspective (not the engineer's)?
- [ ] Does the PRD pass the "could a new engineer understand this?" test?

**Common edit:** The AI will often generate ambitious metrics. Ground them in your actual baseline data.

---

**Output example:**
A completed PRD with: 1-page summary, full problem statement with data, 3 measurable KPIs with 30/60/90-day targets, 6–8 user stories with acceptance criteria, technical risks section, open questions log. **Typical length: 800–1,500 words.**

---
---

## SOP B: Weekly Stakeholder Update System

**What this produces:** A weekly PM update stakeholders actually read
**When to run it:** Every Friday (or your team's end-of-sprint rhythm)
**Time commitment:** 15–20 minutes
**Prompt files:** `03-stakeholder-communication-prompts.md`

---

### The Weekly Update System

**The problem this solves:** Most PM updates are either too long (nobody reads them), too vague ("we made progress"), or too tactical (nobody cares about your Jira tickets). This system produces updates that are strategic, concise, and decision-enabling.

---

**Step 1 — Collect your raw material (5 minutes)**

Before opening your AI tool, jot down:

- What shipped or launched this week
- What's in progress and where it stands
- Blockers or risks that need attention
- Decisions that need to be made by stakeholders
- What's coming next week

Don't overthink this. Even rough bullet points work.

---

**Step 2 — Generate the stakeholder update (5 minutes)**

Use **Prompt 1: Weekly Product Update Email** from `03-stakeholder-communication-prompts.md`.

**Example input:**
```
Product area: Onboarding
Audience: VP of Product, VP of Engineering, VP of Sales
This week:
- Shipped the new welcome email sequence (3 emails, triggered on signup)
- Completed user testing on new empty state designs — 4/5 users understood what to do next (vs. 2/5 previously)
- Bug: checklist completion tracking broken for SSO users — fix in progress, ETA Monday

Blockers: Need a decision on whether to include the product tour for enterprise accounts or keep it optional — waiting on input from Sales on whether enterprise buyers want a guided experience

Next week: A/B test for new onboarding checklist goes live Tuesday, data in 2 weeks

Metrics: Activation rate this week: 34% (up from 31% last week). Time to first value: 4.2 days (target: <3 days)
```

**What you'll get:** A formatted update email ready to send.

---

**Step 3 — Tailor for each audience (3 minutes, optional)**

If you send to multiple audiences (execs vs. engineers vs. sales), use a follow-up prompt:

```
Now rewrite this for an engineering audience. Remove business metrics. Emphasize the technical decisions, what shipped, what's broken, and what's coming up that requires engineering input.
```

Or:

```
Rewrite this for our Sales team. Remove technical details. Emphasize: what new capabilities they can now sell, what's coming that affects their pipeline conversations, and any blockers that involve Sales input.
```

---

**Step 4 — Add the decisions section last (2 minutes)**

Every good stakeholder update ends with a clear ask. If you have a decision to drive, add it explicitly:

```
Add a "Decision Needed" section at the bottom. The decision is: [YOUR DECISION]. The options are: [OPTION A] and [OPTION B]. We need a decision by [DATE] because [CONSEQUENCE OF DELAY]. My recommendation is [YOUR RECOMMENDATION] because [REASON].
```

---

**Step 5 — Review and send**

Read it out loud (seriously). If it takes more than 90 seconds to read aloud, cut it. Your stakeholders will thank you.

**Format checklist:**
- [ ] Subject line is specific ("Onboarding Update — Activation up 3%, Decision Needed on Enterprise Tour")
- [ ] Opens with the most important thing (not "here's what we did this week")
- [ ] Blockers and risks are visible, not buried
- [ ] There's a clear ask or next step

**Output example:**
A 200–400 word update with: a metrics headline, 3–5 bullets of what happened, 1–2 bullets of what's coming, and a decision section if applicable.

---
---

## SOP C: Sprint Kickoff Prep in 20 Minutes

**What this produces:** A sprint brief, team-ready user stories, and an aligned team before the sprint even starts
**When to run it:** The day before or morning of sprint planning
**Time commitment:** 20 minutes
**Prompt files:** `02-strategy-roadmap-prompts.md`, `04-user-story-prompts.md`

---

### The Sprint Kickoff Prep System

**The problem this solves:** Sprint planning meetings that drag for 2+ hours because stories aren't ready, context is missing, or engineers are learning about the work for the first time in the meeting.

---

**Step 1 — Identify the sprint's theme and top priorities (3 minutes)**

Before anything else, answer these three questions in plain text (no AI needed yet):

1. What is the *one thing* this sprint is supposed to accomplish? (The "sprint goal")
2. What are the top 3–5 stories or tasks that must ship this sprint?
3. What are we parking for next sprint that might otherwise creep in?

---

**Step 2 — Generate the sprint brief (5 minutes)**

Use **Prompt 18: Sprint Goal & Brief** from `02-strategy-roadmap-prompts.md`.

**Example input:**
```
Sprint 24 | March 10–21
Theme: "Make onboarding self-serve for SMB accounts"
Priority stories:
1. Empty state redesign for new users
2. Welcome checklist (3-step guided setup)
3. In-app tooltips for core features (create, assign, track)
Team: 3 engineers (full-stack), 1 designer (50% allocation)
Definition of done: All stories pass QA, tooltips reviewed by Content, empty state approved by Design
Not this sprint: Enterprise admin setup, SSO configuration, email notifications
Context: We're building toward our Q2 activation rate OKR (target: 40% by June 1, currently at 34%)
```

**What you'll get:** A 1-page sprint brief with goal, success criteria, scope guardrails, and team alignment points — ready to share in Slack or Confluence before the planning meeting.

---

**Step 3 — Polish your user stories (8 minutes)**

For each story in the sprint, use **Prompt 2: Story Refinement** from `04-user-story-prompts.md`.

Paste your rough story and ask for:
- Refined "As a / I want / So that" format
- 3–5 acceptance criteria in Given/When/Then
- Edge cases
- T-shirt size estimate rationale

**Example — before:**
```
Add tooltips to the main navigation items so users know what each section does
```

**Example — after (AI output):**
```
User Story: As a new user in my first week, I want contextual tooltips on core navigation items, so that I can understand what each section does without leaving the page or reading documentation.

Acceptance Criteria:
- Given I am a new user (< 7 days since signup), when I hover over a core nav item, then a tooltip appears within 300ms with a 1-sentence description and a "learn more" link
- Given I have completed the welcome checklist, when I view the nav, then tooltips no longer appear (I've been onboarded)
- Given I am on mobile, when I tap a nav item, then the tooltip appears as an inline label below the icon
- Given I am an existing user (> 30 days), then tooltips are hidden by default but accessible via "help mode" toggle

Edge cases: Users who signed up before this feature ships should see tooltips for 7 days from feature launch date. Tooltips should not overlap with dropdown menus.

T-shirt size: S–M. UI-only change. Logic for new vs. returning user already exists in the user object.
```

---

**Step 4 — Prepare your planning talking points (4 minutes)**

Use this quick prompt before the meeting:

```
I'm about to run a sprint planning meeting for Sprint [NUMBER]. Our sprint goal is [GOAL]. The top 3 stories are [LIST THEM]. Anticipated risks or dependencies: [LIST ANY].

Give me:
1. A 60-second sprint goal speech I can open the meeting with
2. The 3 most important questions I should ask the team during planning
3. The top risk to flag proactively
```

*This gives you a sharp opening and makes you look prepared without over-scripting the meeting.*

---

**Output example:**
Before the planning meeting, your team has: a shared sprint brief in Confluence/Notion, refined user stories with acceptance criteria already in Jira, and a PM who opens with a clear 60-second goal statement. **Sprint planning goes from 2 hours to 45 minutes.**

---
---

## SOP D: Quarterly Roadmap Review Deck

**What this produces:** A slide-ready quarterly roadmap review presentation
**When to run it:** 1–2 weeks before each quarter ends (or at the start of planning)
**Time commitment:** 45–60 minutes
**Prompt files:** `02-strategy-roadmap-prompts.md`, `05-research-data-prompts.md`, `03-stakeholder-communication-prompts.md`

---

### The Quarterly Roadmap Review System

**The problem this solves:** Roadmap reviews that either turn into Jira ticket recaps (boring, low-value) or vague strategy theater (inspiring but unactionable). This system produces a review that closes the loop on last quarter and sets up the next one with evidence and clarity.

---

**Step 1 — Gather last quarter's inputs (10 minutes)**

Pull together (rough notes are fine):
- [ ] What you committed to last quarter (your original roadmap items)
- [ ] What actually shipped
- [ ] What slipped and why
- [ ] Key metrics: did you hit your OKRs?
- [ ] Top 3 learnings from the quarter (research, data, customer feedback)
- [ ] What's changed in the competitive landscape

---

**Step 2 — Generate the "last quarter" retrospective section (10 minutes)**

Use **Prompt 14: OKR-to-Roadmap Traceability Report** from `05-research-data-prompts.md` to produce your "what we said vs. what we did" analysis.

Then follow up with:

```
Now write a "quarter in review" narrative (300 words) that:
1. Celebrates what shipped and its measured impact
2. Is honest about what slipped, with a brief explanation (not an excuse)
3. Identifies the #1 lesson we're carrying into next quarter
4. Sets up why the Q[NEXT QUARTER] priorities are what they are

Tone: confident, honest, forward-looking. This is for an exec audience.
```

---

**Step 3 — Generate the "next quarter" roadmap narrative (10 minutes)**

Use **Prompt 13: Data-Driven Roadmap Justification** from `05-research-data-prompts.md` for each of your top 2–3 next-quarter initiatives.

Then synthesize with:

```
I have 3 roadmap initiatives for next quarter. Help me present them as a coherent narrative — not a feature list. The initiatives are:
1. [INITIATIVE 1] — solving [PROBLEM] — expected to [BUSINESS IMPACT]
2. [INITIATIVE 2] — solving [PROBLEM] — expected to [BUSINESS IMPACT]
3. [INITIATIVE 3] — solving [PROBLEM] — expected to [BUSINESS IMPACT]

Write a "next quarter roadmap" narrative (250 words) that:
- Opens with the strategic theme tying these together
- Explains the sequencing logic (why in this order?)
- Addresses the resource trade-offs we're making
- Ends with what success looks like at the end of the quarter
```

---

**Step 4 — Generate the slide structure (5 minutes)**

```
Convert everything we've built into a slide deck outline. Format as:

Slide 1: Title
Slide 2: Quarter theme / strategic context (1 headline + 3 bullets)
Slide 3: Last quarter — what we shipped (visual timeline or table)
Slide 4: Last quarter — OKR results (metrics table: committed vs. actual)
Slide 5: What we learned (top 3 insights from research and data)
Slide 6–8: Next quarter priorities (one slide per initiative — problem, solution, expected impact)
Slide 9: What we're NOT doing and why (the deprioritization slide)
Slide 10: How to win next quarter — success criteria and risks

For each slide, give me: headline, 3–5 bullet points of content, and a note on what visual/chart would make it stronger.
```

---

**Step 5 — Prepare for hard questions (5 minutes)**

Use **Prompt 7: Anticipate Objections** from `03-stakeholder-communication-prompts.md`:

```
I'm presenting our Q[NUMBER] roadmap to [AUDIENCE: board / exec team / engineering leaders]. The most controversial decision in the deck is [YOUR MOST CONTROVERSIAL CHOICE]. What are the 5 hardest questions I'm likely to get, and what are strong, honest answers to each?
```

---

**Step 6 — Build the actual deck (15–20 minutes)**

Take your AI-generated outline and content into your slide tool (Google Slides, Keynote, Pitch). The AI has done the thinking. Your job now is:
- One idea per slide
- Lead with the headline (don't make people read to find the point)
- Use visuals for roadmap timelines and metrics tables
- Keep transitions to a minimum

**Output example:**
A 10-slide deck with: last quarter retrospective, OKR scorecard, top 3 insights, 3 justified next-quarter priorities, a "not doing" slide, and 5 pre-answered hard questions. **Prep time: 1 hour instead of a full day.**

---
---

## SOP E: New Feature Launch Communication Sequence

**What this produces:** A full internal and external communication package for a feature launch
**When to run it:** 2 weeks before a feature goes live
**Time commitment:** 30–45 minutes
**Prompt files:** `03-stakeholder-communication-prompts.md`, `02-strategy-roadmap-prompts.md`

---

### The Feature Launch Communication System

**The problem this solves:** Feature launches that nobody finds out about, or that create confusion because different teams are saying different things. This system produces one coordinated communication package that everyone can pull from.

---

**Step 1 — Define the launch (5 minutes)**

Before running any prompts, nail down:

- **Feature name:** What are we calling it externally? (This may differ from the internal code name)
- **One-sentence description:** What does it do, in plain English?
- **Who it's for:** Which users or customer segments benefit?
- **What problem it solves:** Stated as user outcome, not feature capability
- **Launch type:** GA (general availability) / Beta / Limited rollout / Internal only
- **Key date:** When does it go live?

---

**Step 2 — Generate the internal launch brief (8 minutes)**

Use **Prompt 12: Feature Launch Brief** from `03-stakeholder-communication-prompts.md`.

**Example input:**
```
Feature: Smart Digest
One-liner: A daily or weekly email summary of the notifications that actually matter to you
Who it's for: All users; most valuable for power users with 50+ notifications/week
Problem solved: Users miss critical updates because they're buried in real-time notification noise
Launch type: GA — rolling out to 100% of users over 3 days
Date: March 18
Key metrics we expect to move: Notification engagement rate (target: +20%), weekly active users (target: +5%)
Key team leads: Eng lead = Jamie, Design = Priya, CS = the enterprise team
```

**What you'll get:** An internal brief covering what's launching, why, who's affected, how it works, rollout plan, and escalation path.

---

**Step 3 — Generate the sales enablement one-pager (5 minutes)**

```
Now write a 1-page sales enablement doc for this feature. Target reader: Account Executive. Include:
1. The 30-second pitch for this feature on a customer call
2. Which customer pain points this directly addresses
3. Which customer segments benefit most
4. Top 3 objections and responses
5. Key differentiator vs. [COMPETITOR NAME] (who does / doesn't have this)
6. Discovery question to identify prospects who need this
7. Where to find more information (docs, demo video, etc.)

Format: scannable bullets, not paragraphs. AEs will reference this during calls.
```

---

**Step 4 — Generate customer-facing release notes (5 minutes)**

Use **Prompt 15: Release Notes** from `03-stakeholder-communication-prompts.md`:

```
Write user-facing release notes for Smart Digest. 
Audience: End users in our product changelog / in-app announcement.
Tone: Friendly, clear, benefit-first. Not technical.
Format: 
- Headline (benefit-focused, <10 words)
- 2-sentence description
- "What's new" bullet list (3–5 items, feature capabilities)
- "How to get started" (2–3 steps)
- Link placeholder for help doc
```

**Example output:**
```
📬 Never miss what matters — introducing Smart Digest

Smart Digest delivers a personalized summary of your most important notifications, so you stay informed without the noise.

What's new:
• Daily or weekly digest emails, delivered on your schedule
• AI-powered filtering surfaces updates that need your attention
• One-click settings to customize by project, team, or notification type
• Pause notifications during focus time — digest catches you up later

How to get started:
1. Go to Settings → Notifications
2. Choose "Daily Digest" or "Weekly Digest"
3. Select which projects to include — you're set

📖 Learn more in our Help Center →
```

---

**Step 5 — Generate the CS/support FAQ (5 minutes)**

```
Write an internal FAQ for our Customer Success and Support teams for the Smart Digest launch. 
They'll use this to handle inbound questions from customers.
Include 8–10 Q&As covering:
- What it is and who it's for
- How to turn it on or off
- How the AI decides what's "important"
- What happens to notifications users don't get in the digest
- How to troubleshoot if a customer isn't receiving digests
- Pricing / plan availability questions
- Known limitations at launch

Format: clean Q&A. Each answer should be 2–4 sentences. Written for a CS rep to read aloud or paste into a support ticket.
```

---

**Step 6 — Sequence the communications (2 minutes)**

Use this template to build your launch comms calendar:

| Day | Channel | Audience | Content | Owner |
|-----|---------|----------|---------|-------|
| T-14 | Slack #product | Internal all-hands | Launch brief | PM |
| T-7 | Sales Enablement Hub | AEs / SEs | Sales one-pager | PM + PMM |
| T-3 | Slack #customer-success | CS team | CS FAQ + talking points | PM |
| T-1 | Staging + QA | Engineering | Final go/no-go check | Eng Lead |
| T-0 | In-app / Email | Users (staged rollout) | Release notes + announcement | Marketing |
| T+3 | Slack #launches | Internal | 72-hour metrics update | PM |
| T+14 | Exec update | Leadership | 2-week impact summary | PM |

*Paste this table and your feature details into AI and ask it to fill in specific content for each row.*

---

**Output example:**
A complete launch package including: internal brief (1 page), sales one-pager (1 page), customer-facing release notes (150 words), CS FAQ (8–10 Q&As), and a comms calendar with owners and dates. **Produced in under an hour instead of a full day.**

---

*End of File 06 — Workflow SOPs*
*→ Next: 07-cheat-sheet.md — The 15 most powerful prompts, ready to copy and paste*
