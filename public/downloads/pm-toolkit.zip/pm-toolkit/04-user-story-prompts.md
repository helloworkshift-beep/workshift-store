# 04 — User Story Prompts

*20 prompts for user stories, acceptance criteria, epics, job stories, and story mapping*

---

## USER STORY CREATION

---

**Prompt 1: User Story Generator from Feature Description**

*When to use: You have a feature concept and need to break it down into well-formed user stories before sprint planning*

```
Convert the following feature description into a set of well-formed user stories.

Feature: [FEATURE NAME AND DESCRIPTION]
Product: [PRODUCT NAME]
Target user personas:
- Primary: [PERSONA NAME — role and key characteristic, e.g., "Alex, a mid-market Account Executive who manages 50+ active deals"]
- Secondary (if applicable): [PERSONA NAME AND DESCRIPTION]

Business goal: [WHAT THE BUSINESS NEEDS THIS FEATURE TO ACHIEVE]

Please produce:
1. **Epic story** (the parent story that frames the full feature)
2. **10-15 child user stories** broken into logical groups:
   - Core happy path (the primary flow)
   - Edge cases and alternate paths
   - Error and empty states
   - Admin / settings stories
   - Notification / email stories

Each user story must follow this format:
**Story ID: [FEATURE-XXX]**
As a [specific user type], I want to [specific action] so that [specific outcome/value].

**Acceptance Criteria:**
- Given [context], when [action], then [outcome]
- [Additional Given/When/Then criteria]

**Definition of Done:**
- [ ] Core functionality implemented
- [ ] Edge cases handled per AC
- [ ] Error states designed and implemented
- [ ] Analytics event fires
- [ ] Unit tests written
- [ ] QA sign-off

**Story Points:** [T-SHIRT SIZE: XS/S/M/L/XL]
**Priority:** [MUST HAVE / SHOULD HAVE / COULD HAVE / WON'T HAVE (MoSCoW)]
```

---

**Prompt 2: User Story Refinement and Splitting**

*When to use: You have a story that's too large to fit in a sprint and needs to be split into smaller, deliverable chunks*

```
Help me split the following large user story (too big for a single sprint) into smaller, independently deliverable stories.

Original story:
[PASTE THE FULL STORY INCLUDING ANY ACCEPTANCE CRITERIA]

Sprint capacity context:
- Sprint length: [1 WEEK / 2 WEEKS]
- Engineering capacity for this story: [STORY POINTS OR DAYS AVAILABLE]
- Team: [FRONTEND / BACKEND / FULLSTACK — RELEVANT TO HOW TO SPLIT]

Splitting constraints:
- Each sub-story must be independently deliverable (shippable on its own)
- Each sub-story must deliver some user value (not just "set up the database")
- We can feature-flag if needed
- Target size per story: [MAX STORY POINTS OR "COMPLETABLE IN 2-3 DAYS"]

Please:
1. **Suggest 3-5 ways to split this story** (different splitting strategies: by user type, by workflow step, by functional layer, by happy path vs edge cases)
2. **Recommend the best splitting strategy** with rationale
3. **Write the split stories** in full (story statement + acceptance criteria + DoD)
4. **Sequence them** — which order should they be built in, and why?
5. **Flag any dependencies** between the sub-stories

Key principle: A good split doesn't just make stories smaller — it makes each one valuable on its own. Avoid "foundation" stories that users can't actually use.
```

---

**Prompt 3: Acceptance Criteria Writer**

*When to use: You have a user story but need rigorous, testable acceptance criteria that eliminate ambiguity for QA and engineering*

```
Write comprehensive acceptance criteria for the following user story.

User Story:
As a [USER TYPE], I want to [ACTION] so that [OUTCOME].

Feature context:
- Product: [PRODUCT NAME]
- Related system/component: [RELEVANT PART OF THE PRODUCT]
- Business rules that apply: [ANY KNOWN CONSTRAINTS — e.g., "Free users can only create 3 items", "Timestamps must be in user's local timezone"]
- Edge cases I know about: [LIST ANY YOU'VE THOUGHT OF]

Please write acceptance criteria in the following structure:

**Happy Path:**
- Given [user state/context], when [they do X], then [Y happens]
[4-6 criteria covering the core successful flow]

**Edge Cases:**
- Given [edge condition], when [action], then [expected behavior]
[3-5 criteria covering boundary conditions, unusual inputs, concurrent actions]

**Error States:**
- Given [error condition], when [action], then [user sees/system does X]
[2-4 criteria covering failure scenarios]

**Validation Rules:**
- [Specific validation rules for any inputs — length limits, format requirements, required fields]

**Performance Criteria:**
- [Any relevant performance requirements — load time, response time, throughput]

**Accessibility:**
- [WCAG 2.1 AA requirements for this feature, if applicable]

**Analytics:**
- [Events that must fire and properties to include]

Mark each criterion as: MUST (blocking for release) / SHOULD (important but not blocking) / COULD (nice to have)
```

---

**Prompt 4: Epic Definition**

*When to use: Defining an Epic to group a set of related user stories for a major feature area — important for sprint planning and roadmap tracking*

```
Write an Epic definition for [EPIC NAME].

Context:
- Product: [PRODUCT NAME]
- Team: [TEAM NAME]
- Quarter: [Q + YEAR]
- Strategic theme: [WHICH ROADMAP THEME THIS EPIC BELONGS TO]

Background:
[DESCRIBE THE INITIATIVE — WHAT ARE WE BUILDING AND WHY]

Please write a complete Epic definition including:

**Epic Title:** [CONCISE NAME]

**Epic Goal Statement:** 
One sentence: "Enable [user type] to [do X] so that [business/user outcome]."

**Background & Context:**
(2-3 paragraphs: why we're doing this, what problem it solves, what signal or data drove it)

**User Personas Affected:**
(List with brief description of how each is impacted)

**Business Outcomes:**
(3-5 measurable outcomes we expect this Epic to drive)

**Scope: In / Out:**
| In Scope | Out of Scope |
|----------|-------------|
| [Item] | [Item] |

**Proposed Child Stories:**
(List 10-15 story titles — don't need full stories yet)

**Dependencies:**
(Other teams, systems, Epics that this depends on)

**Epic Success Criteria:**
(How will we know this Epic is "done" and successful? Specific metrics + user behavior signals)

**Estimated Size:** [T-SHIRT: S / M / L / XL]
**Target Sprint Range:** [e.g., "Sprints 14-18"]
```

---

**Prompt 5: Job Story Generator (JTBD Format)**

*When to use: Using the Jobs-to-be-Done framework — writing job stories that focus on motivation and context rather than user type*

```
Convert the following feature or user need into Job Stories using the Jobs-to-be-Done framework.

Feature or need: [DESCRIBE WHAT YOU'RE BUILDING OR THE USER NEED YOU'VE IDENTIFIED]

Customer/user context:
[DESCRIBE WHO USES THIS — THEIR SITUATION, GOALS, AND MOTIVATIONS. INCLUDE ANY RESEARCH OR INTERVIEW INSIGHTS YOU HAVE]

Job Stories use this format:
"When [situation/context], I want to [motivation/action], so I can [expected outcome]."

Unlike user stories, job stories focus on:
- The SITUATION that triggers the need (not the user type)
- The MOTIVATION behind the action (not just the feature request)
- The OUTCOME the user is trying to achieve (the real job, not the interface interaction)

Please write:
1. **5-8 Job Stories** for the core use cases
2. For each story:
   - The Job Story itself
   - **The real "job" being hired for** (2-sentence explanation of the deeper motivation)
   - **What "good" looks like** — how the user knows the job was done well
   - **What "failure" looks like** — how they'd know the product failed them
3. **Recommended story to start with** — which job story represents the highest-value MVP anchor?
4. **Design principles implied** by these stories — 3-4 principles to guide design decisions

Note: Job Stories should feel like real moments from real users' lives — not abstract feature descriptions.
```

---

## ACCEPTANCE CRITERIA & DEFINITION OF DONE

---

**Prompt 6: Definition of Done Template for Feature Type**

*When to use: Creating or updating your team's Definition of Done checklist for different types of work (new feature, bug fix, API change, etc.)*

```
Create a comprehensive Definition of Done (DoD) checklist for [FEATURE TYPE: NEW USER-FACING FEATURE / API CHANGE / PERFORMANCE IMPROVEMENT / BUG FIX / SECURITY PATCH].

Team context:
- Engineering team size: [NUMBER]
- Stack: [FRONTEND TECH / BACKEND TECH / INFRA]
- Deployment model: [CONTINUOUS DEPLOYMENT / SCHEDULED RELEASES]
- QA process: [AUTOMATED ONLY / MANUAL QA / BOTH]
- Analytics platform: [TOOL NAME]
- Key quality standards: [E.g., 99.9% uptime SLA, WCAG AA compliance, SOC 2 Type II requirements]

Please create a DoD checklist with items grouped by:

**1. Functionality**
- [ ] [Item]

**2. Code Quality**
- [ ] [Item]

**3. Testing**
- [ ] [Item]

**4. Security**
- [ ] [Item]

**5. Performance**
- [ ] [Item]

**6. Observability (Monitoring & Alerting)**
- [ ] [Item]

**7. Analytics & Instrumentation**
- [ ] [Item]

**8. Documentation**
- [ ] [Item]

**9. Accessibility**
- [ ] [Item]

**10. Deployment Readiness**
- [ ] [Item]

Also include:
- **Must-have items** (blocking release) vs **Should-have items** (important but can follow)
- **A "fast-track" DoD** for hotfixes and urgent releases (minimum viable checklist)
- **Review cadence recommendation** — how often should this DoD be reviewed and updated?
```

---

**Prompt 7: Gherkin Test Scenario Generator**

*When to use: Writing BDD-style Gherkin scenarios for QA automation or for communicating expected behavior to engineers*

```
Write Gherkin-style test scenarios for the following user story.

User Story:
As a [USER TYPE], I want to [ACTION] so that [OUTCOME].

Acceptance Criteria:
[PASTE YOUR ACCEPTANCE CRITERIA]

Feature context:
- Product: [PRODUCT NAME]
- User types who interact with this feature: [LIST]
- Key states the system can be in: [e.g., "empty state, partial data, full data, error state"]
- Key user permission levels: [e.g., "admin, editor, viewer, free plan, paid plan"]

Please write Gherkin scenarios covering:

**Happy Path Scenarios** (3-5)
```
Feature: [Feature Name]

  Scenario: [Scenario Name]
    Given [initial state]
    And [additional context]
    When [user action]
    Then [expected outcome]
    And [additional expected outcome]
```

**Negative / Edge Case Scenarios** (3-5)
**Permission-Based Scenarios** (2-3 — different access levels)
**Error State Scenarios** (2-3)
**Performance/Load Scenario** (1 — if applicable)

For each scenario, add a brief comment explaining:
- Why this scenario matters
- What we're protecting against (regression risk)

Group scenarios by priority: Smoke Test (must run before every release) / Regression Suite / Full Suite
```

---

**Prompt 8: Sprint Backlog Grooming**

*When to use: Preparing for a backlog grooming session and need to assess and refine stories in your backlog*

```
Help me groom the following backlog items for sprint planning.

Sprint goal (if defined): [SPRINT GOAL]
Available capacity: [STORY POINTS OR PERSON-DAYS]
Team composition: [NUMBER OF FRONTEND / BACKEND / FULLSTACK ENGINEERS + DESIGNER]

Backlog items:
[LIST EACH ITEM WITH: TITLE, CURRENT DESCRIPTION, CURRENT STORY POINT ESTIMATE IF ANY]

For each backlog item, please:
1. **Assess readiness** — is this story ready to sprint on? (Ready / Needs refinement / Blocked)
2. **Flag missing information** — what questions need answers before an engineer can start this?
3. **Identify hidden complexity** — what's likely harder than it looks?
4. **Suggest story point range** — based on description and complexity (use Fibonacci: 1, 2, 3, 5, 8, 13)
5. **Recommend acceptance criteria additions** — what's currently missing that could cause scope creep?
6. **Sequence recommendation** — in what order should these be worked on within the sprint?

After reviewing all items:
- **Recommended sprint backlog** — which items fit the capacity and goal?
- **What to defer** — what's not ready or doesn't fit?
- **Sprint risks** — what's most likely to blow up and why?
```

---

## STORY MAPPING

---

**Prompt 9: User Story Map Builder**

*When to use: Building a story map to visualize the full user journey before sprint planning — helps identify MVP scope and sequencing*

```
Help me build a User Story Map for [PRODUCT NAME / FEATURE AREA].

The user journey we're mapping:
[DESCRIBE THE END-TO-END USER WORKFLOW — FROM ENTRY POINT TO DESIRED OUTCOME]

Primary user: [PERSONA NAME AND DESCRIPTION]
Context: [WHEN AND WHY THIS USER ENGAGES WITH THIS WORKFLOW]

Please structure the story map as:

**Level 1: Activities** (the high-level phases of the journey)
[e.g., Discover → Sign Up → Onboard → Create → Collaborate → Review → Export]

**Level 2: User Tasks** (the specific tasks within each Activity)
[5-8 tasks per activity]

**Level 3: User Stories** (the detailed stories under each task)
[3-5 stories per task, in priority order top-to-bottom]

Then define release slices:
**MVP (Release 1):** [Which stories from each activity are needed for the minimum valuable experience]
**Release 2:** [What gets added in the next iteration]
**Release 3:** [Future enhancements]

For the MVP slice:
- List the stories included
- Identify the "walking skeleton" — the thinnest possible end-to-end slice that delivers value
- Flag any technical prerequisites not visible in the story map

Also note: What user outcomes are possible at each release level? (Not just features, but what the user can DO)
```

---

**Prompt 10: Journey-Based Story Writing**

*When to use: Writing stories for a specific stage of the user journey — onboarding, activation, core use, expansion, retention*

```
Write user stories for the [STAGE] stage of the user journey for [PRODUCT NAME].

Journey stage: [ONBOARDING / ACTIVATION / CORE USE / EXPANSION / AT-RISK RETENTION]
Definition of this stage for our product:
- User enters this stage when: [TRIGGER — e.g., "Signs up and verifies email"]
- User exits this stage when: [EXIT CONDITION — e.g., "Completes first export" / "Reaches $X spend" / "Becomes inactive for 14 days"]
- Current performance at this stage: [CONVERSION RATE, TIME IN STAGE, DROP-OFF POINT IF KNOWN]
- Biggest user complaint at this stage: [FROM RESEARCH, SUPPORT TICKETS, OR CHURN SURVEYS]

Goal: Improve [METRIC — e.g., "7-day activation rate from 28% to 40%"]

Please write:
1. **Journey narrative** — 2-3 sentences describing what an ideal user experience at this stage looks like
2. **10-15 user stories** for this stage — covering:
   - What the user needs to understand (orientation, context)
   - What the user needs to DO (key actions to reach the exit condition)
   - What the system needs to do to support them (prompts, progress indicators, guidance)
   - What happens when they get stuck (empty states, help, re-engagement)
3. **Anti-stories** — 3-5 things users SHOULDN'T experience at this stage (negative requirements)
4. **Measurement stories** — which analytics events need to exist to measure success at this stage?
5. **Recommended MVP scope** — if we're only doing 5 stories this sprint, which ones have the highest activation impact?
```

---

**Prompt 11: API / Developer Experience User Stories**

*When to use: Writing user stories for a developer-facing product, API, or internal developer tooling*

```
Write user stories for the developer experience for [API / DEVELOPER TOOL / PLATFORM NAME].

Developer persona:
- Role: [e.g., "Backend engineer at a B2B SaaS startup, integrating our API to automate customer data sync"]
- Technical level: [JUNIOR / MID / SENIOR]
- Primary language/stack: [LANGUAGE AND FRAMEWORK]
- Integration context: [WHAT THEY'RE BUILDING WITH YOUR API]

Job to be done: [WHAT THE DEVELOPER NEEDS TO ACCOMPLISH]

Please write user stories covering:

**Discovery & Authentication**
(Finding the API, getting credentials, first auth)

**First Integration (Getting to Hello World)**
(Making the first successful API call — the AHA moment)

**Core API Operations**
(CRUD operations, key endpoints, pagination, filtering)

**Error Handling & Debugging**
(Error messages, logging, debugging tools, status codes)

**Webhooks & Events** (if applicable)

**Rate Limits & Scaling**

**Documentation & Support**

For each story, include:
- Story statement
- Acceptance criteria
- Developer experience quality bar: "A senior engineer should be able to [milestone] in under [time]"
- A note on what "delightful" looks like beyond the minimum bar
```

---

**Prompt 12: Mobile-Specific User Stories**

*When to use: Writing user stories for a mobile app that need to account for mobile-specific constraints and patterns*

```
Write mobile-specific user stories for [FEATURE NAME] on [iOS / ANDROID / BOTH].

Feature description: [DESCRIBE THE FEATURE]
Target users: [USER PERSONA]
Mobile context: [HOW USERS TYPICALLY USE THIS FEATURE ON MOBILE — e.g., "Commuting, one-handed use, quick reference" vs "Deep work sessions with full attention"]

Mobile-specific considerations to address:
- Offline functionality: [REQUIRED / PREFERRED / NOT NEEDED]
- Push notifications: [INVOLVED? YES/NO — DESCRIBE IF YES]
- Device permissions needed: [CAMERA / LOCATION / CONTACTS / NOTIFICATIONS / ETC.]
- Deep links: [RELEVANT? YES/NO]
- Biometric auth: [REQUIRED? YES/NO]
- Tablet support: [REQUIRED? YES/NO]

Please write:
1. **Mobile user stories** (15-20) with mobile-specific acceptance criteria
2. **Platform-specific variations** — where iOS and Android behavior needs to differ
3. **Offline/sync stories** — how the feature behaves without connectivity and how it syncs when reconnected
4. **Performance criteria** — specific to mobile (battery impact, data usage, render performance)
5. **Accessibility stories** — VoiceOver/TalkBack, Dynamic Type, Reduce Motion
6. **Edge case stories** — interrupted flows (phone call, notification tap, background/foreground), low storage, slow network

Mark each story with: [iOS] [Android] [Both] and priority level.
```

---

**Prompt 13: Accessibility User Stories**

*When to use: Writing dedicated accessibility stories to ensure features meet WCAG standards and work for users with disabilities*

```
Write accessibility user stories for [FEATURE NAME].

Feature description: [DESCRIBE THE FEATURE — WHAT IT DOES AND HOW IT WORKS]
Target accessibility standard: [WCAG 2.1 AA / AAA / Section 508]
Platform: [WEB / iOS / ANDROID / DESKTOP]

User personas with accessibility needs:
- Visual: [SCREEN READER USER — JAWS, NVDA ON WEB; VOICEOVER ON IOS/MAC]
- Motor: [KEYBOARD-ONLY USER, SWITCH ACCESS USER]
- Cognitive: [USER WITH ATTENTION OR READING CHALLENGES]
- Auditory: [DEAF OR HARD OF HEARING USER — relevant for video/audio content]
- Low vision: [USER USING BROWSER ZOOM OR LARGE TEXT]

Please write:
1. **Accessibility user stories** — one per assistive technology / user type for the main feature flows
2. **Specific acceptance criteria** for each story — testable, with specific WCAG success criterion referenced (e.g., WCAG 2.1 1.4.3 Contrast)
3. **Screen reader behavior spec** — what should be announced at each interactive element?
4. **Keyboard navigation map** — tab order, focus states, keyboard shortcuts
5. **Color and contrast requirements** — specific contrast ratios for text and UI elements
6. **Error handling accessibility** — how are errors communicated accessibly?
7. **Testing approach** — what tools and manual checks should QA use?

Also flag: Any part of the current feature design that will require a design change to meet AA standards.
```

---

**Prompt 14: Notification & Communication Stories**

*When to use: Defining when, why, and how the product communicates with users — email, push, in-app, SMS*

```
Write user stories for the notification and communication system for [FEATURE NAME or PRODUCT AREA].

Product: [PRODUCT NAME]
Notification channels available: [EMAIL / PUSH / IN-APP / SMS / SLACK / WEBHOOK]

User context:
- When are users in the product? [DAILY ACTIVE / WEEKLY / OCCASIONAL]
- What do users need to know about? [LIST KEY EVENTS OR STATE CHANGES]
- Notification sensitivity: [ARE USERS LIKELY TO BE ANNOYED BY TOO MANY NOTIFICATIONS?]

Notification triggers to cover:
[LIST THE EVENTS THAT MIGHT TRIGGER A NOTIFICATION — e.g., "someone comments on your post", "your export is ready", "your trial expires in 3 days", "payment failed"]

Please write:
1. **Notification user stories** — one story per notification type
2. For each notification:
   - Trigger condition (exactly when does this fire?)
   - Recipient (who gets it — and who shouldn't get it)
   - Channel(s) — which notification channel(s) to use and why
   - Content spec — subject line, body, CTA (for email); title, body (for push)
   - Frequency / deduplication rules — how often can this fire?
   - Preference control — can users opt out? How?
3. **Notification preference center stories** — what controls should users have?
4. **Anti-notification stories** — "I should NOT receive a notification when..."
5. **Notification analytics stories** — what do we track to measure notification effectiveness?

Format: Standard user story with full acceptance criteria for each notification.
```

---

**Prompt 15: Admin / Back-Office User Stories**

*When to use: Writing stories for internal admin tools, customer success dashboards, or back-office functionality that supports the product but isn't customer-facing*

```
Write user stories for the admin / back-office tooling for [FEATURE NAME or PRODUCT AREA].

Primary admin users:
- [ADMIN ROLE 1 — e.g., "Customer Success Manager who needs to troubleshoot customer issues"]
- [ADMIN ROLE 2 — e.g., "Operations team who manages customer account configuration"]
- [ADMIN ROLE 3 — e.g., "Engineering on-call who needs to investigate production issues"]

What admin users need to be able to do:
[LIST THE OPERATIONS, INVESTIGATIONS, OR CONFIGURATIONS THAT ADMIN USERS PERFORM]

Customer-facing feature context:
[BRIEF DESCRIPTION OF THE CUSTOMER-FACING FEATURE THAT THIS ADMIN TOOLING SUPPORTS]

Please write:
1. **Admin user stories** (10-15) covering:
   - Viewing / searching / filtering customer data
   - Performing operations on behalf of customers
   - Configuration and settings management
   - Debugging and investigation tools
   - Audit logs and history
   - Bulk operations
   - Permission management (who can do what in admin)
2. **Audit trail requirements** — what actions need to be logged and why?
3. **Security and access control stories** — who can access admin, what approvals are needed for risky operations?
4. **Performance requirements** — admin tools often query large datasets; what's the performance bar?
5. **Prioritization** — rank stories by frequency of need and severity of consequence if missing

Note: Admin tools are often underfunded and overloaded. Flag which stories, if missing, create manual bottlenecks at scale.
```

---

**Prompt 16: User Story Review Checklist**

*When to use: Before bringing stories to sprint planning, want to run them through a quality check to ensure they're well-formed*

```
Review the following user stories and provide a quality assessment before they go into sprint planning.

Stories to review:
[PASTE YOUR USER STORIES HERE — INCLUDE TITLE, STORY STATEMENT, AND ACCEPTANCE CRITERIA FOR EACH]

Team context:
- Sprint length: [1 WEEK / 2 WEEKS]
- Max story size for sprint: [STORY POINT LIMIT]
- Team composition: [ENGINEERS, DESIGNER, QA]

For each story, assess:
1. **Story statement quality**:
   - Is the "As a [user]" specific (not "user" or "admin" without context)?
   - Is the "I want to" action clear and implementation-agnostic?
   - Is the "so that" a real user/business outcome (not just a feature)?

2. **Acceptance criteria quality**:
   - Are all AC testable? (Can QA write a test for each one?)
   - Are there obvious missing scenarios? (Error states, empty states, permissions)
   - Are there ambiguous phrases that will cause disagreement?

3. **Readiness assessment**:
   - Is this story "ready" to pick up? What's blocking it if not?
   - Are dependencies identified?
   - Is the design clear enough for development to start?

4. **Size sanity check**:
   - Is this story appropriately sized for a sprint?
   - If it seems too large, suggest how to split it

5. **Definition of Done**:
   - Is there a clear DoD for this story?
   - Is it appropriate for the story type?

Output: A table with each story and green/yellow/red status for each dimension, plus specific comments on what to fix.
```

---

**Prompt 17: Edge Case Discovery for Complex Features**

*When to use: You have a complex feature and want to systematically uncover edge cases before development begins — prevents scope creep during build*

```
Help me discover edge cases for the following feature before we start development.

Feature: [FEATURE NAME AND DESCRIPTION]
Core happy path: [DESCRIBE THE MAIN FLOW — STEP BY STEP]
Target users: [USER PERSONA AND CONTEXT]

System context:
- Related systems and integrations: [OTHER PARTS OF THE PRODUCT OR EXTERNAL SYSTEMS INVOLVED]
- Data types involved: [WHAT DATA IS BEING CREATED, READ, UPDATED, OR DELETED]
- User permissions model: [DIFFERENT ROLES / ACCESS LEVELS]
- Scale considerations: [EXPECTED VOLUME — USERS, DATA, CONCURRENT OPERATIONS]

Please systematically explore edge cases across these categories:

**Input Validation Edge Cases**
- Boundary values (empty, null, max length, special characters, unicode, injections)
- Invalid format inputs
- Conflicting or contradictory inputs

**State & Concurrency Edge Cases**
- What if two users do this simultaneously?
- What if the user does this with an account in an unusual state?
- What if this action is triggered while a previous one is still in progress?

**Permission & Access Edge Cases**
- What if permissions change mid-flow?
- What can different roles do / not do at each step?

**Integration & Dependency Edge Cases**
- What if an external system is slow / down?
- What if data from another part of the product is missing or malformed?

**Network & Performance Edge Cases**
- What happens if the connection drops mid-action?
- What if the operation times out?

**Data Integrity Edge Cases**
- What if the user tries to delete something with active dependencies?
- What if related data changes while this operation is in progress?

For each edge case, write:
- The scenario
- The recommended behavior
- Whether this needs a user-visible message or is silent handling
- Priority (must handle before launch / should handle before launch / future)
```

---

**Prompt 18: Persona-Driven Story Set**

*When to use: You serve multiple distinct user personas and need to ensure your feature addresses each persona's specific needs*

```
Write a complete set of user stories for [FEATURE NAME] covering all user personas we serve.

Product: [PRODUCT NAME]
Feature: [BRIEF DESCRIPTION]

Personas to cover:
1. **[PERSONA 1 NAME]**: [ROLE, COMPANY SIZE, KEY GOAL, TECH SAVVINESS LEVEL]
2. **[PERSONA 2 NAME]**: [ROLE, COMPANY SIZE, KEY GOAL, TECH SAVVINESS LEVEL]
3. **[PERSONA 3 NAME]**: [ROLE, COMPANY SIZE, KEY GOAL, TECH SAVVINESS LEVEL]
[ADD MORE IF NEEDED]

For each persona, please write:
1. **Persona context** — a 2-sentence description of how this persona will interact with the feature and what success looks like for them specifically
2. **5-7 user stories** specific to this persona's workflow and goals
3. **Persona-specific acceptance criteria** — any criteria that differ from the default because of this persona's needs
4. **Persona-specific risks** — what's most likely to go wrong or frustrate this specific user type?
5. **Onboarding / discovery story** — how does this persona learn the feature exists and how to use it?

After all personas:
- **Shared stories** — stories that apply equally to all personas (can be written once)
- **Persona conflicts** — where two personas need opposite behavior, and how to resolve
- **Priority by persona** — if we can only fully serve one persona in MVP, which one and why?
```

---

**Prompt 19: Micro-Interaction and UX Detail Stories**

*When to use: The happy path is defined but you need to specify the micro-interactions, transitions, loading states, and UX details that make a feature feel polished*

```
Write micro-interaction and UX detail user stories for [FEATURE NAME].

Feature context: [BRIEF DESCRIPTION OF THE FEATURE AND ITS MAIN FLOWS]
Design link: [URL OR "IN PROGRESS"]
Target quality bar: [e.g., "Comparable to Notion / Linear / Figma — high polish, fast, responsive"]

Platform: [WEB APP / MOBILE IOS / MOBILE ANDROID / DESKTOP]

Please write stories for:

**Loading & Progress States**
- Initial page/component load
- Action-triggered loading (button press → loading → result)
- Background loading and data refresh
- Skeleton screens vs spinners vs progress bars — when to use each

**Feedback & Confirmation**
- Success confirmation (toast, animation, state change)
- Error messages — inline, modal, or toast? Specific copy for each error type
- Destructive action confirmation dialogs
- Undo functionality

**Empty States**
- First-time user empty state (onboarding CTA)
- Returning user with no data (different from first-time)
- Search / filter with no results
- Error / failed load state

**Transitions & Animation**
- Page / panel transitions
- Element entrance/exit animations
- State change animations (toggle, expand/collapse)
- Drag and drop feedback

**Hover, Focus, and Active States**
- Interactive element hover states
- Focus rings (keyboard navigation)
- Active/selected states
- Disabled states with clear visual reasoning

For each story, specify:
- Exact animation/transition description (duration, easing, what changes)
- The emotional response it should create (confidence? speed? clarity?)
- Performance budget (max animation duration, frame rate target)
```

---

**Prompt 20: Story Estimation Workshop Facilitator**

*When to use: Facilitating a planning poker or story estimation session and need to prepare discussion questions and clarifying information for each story*

```
Prepare me to facilitate a story estimation session for the following stories.

Sprint context:
- Sprint goal: [SPRINT GOAL]
- Team size: [NUMBER OF ENGINEERS + ROLES]
- Sprint length: [1 OR 2 WEEKS]
- Estimation method: [FIBONACCI / T-SHIRT / HOURS / STORY POINTS]

Stories to estimate:
[LIST EACH STORY WITH TITLE AND BRIEF DESCRIPTION]

For each story, please prepare:
1. **2-minute read-out** — what I'll say to introduce the story to the team
2. **Key clarifying questions** — 3-5 questions that typically drive variance in estimates (things people will disagree about)
3. **Complexity dimensions to call out** — frontend work, backend work, data migration, third-party integration, unknown territory
4. **Historical reference** — suggest a previously completed story of similar complexity for calibration (I'll substitute with an actual example)
5. **Potential split** — if this story estimates large, how could we split it?

Facilitation guide:
- What to do when estimates vary widely (>2 points apart)
- How to handle "this needs more research before estimating"
- When to time-box the discussion and move on
- Signs that a story is not ready to estimate

Output the prep as a runsheet I can use during the actual session.
```
