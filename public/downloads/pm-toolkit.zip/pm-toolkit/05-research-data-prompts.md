# 05 — Research & Data Prompts

*15 prompts for turning raw research, metrics, and competitive intelligence into clear, actionable narratives*

---

## COMPETITIVE INTELLIGENCE

---

**Prompt 1: Competitive Analysis Report**

*When to use: Before a strategy review, roadmap planning, or when leadership asks "what are competitors doing?"*

```
Write a structured competitive analysis report for [YOUR PRODUCT NAME] against the following competitors: [COMPETITOR 1], [COMPETITOR 2], [COMPETITOR 3].

Context:
- Our product: [ONE-SENTENCE DESCRIPTION OF YOUR PRODUCT AND CORE VALUE PROP]
- Our primary user: [TARGET USER PERSONA]
- Market segment: [B2B/B2C, INDUSTRY, COMPANY SIZE WE SERVE]
- Key battleground features: [2-4 CAPABILITIES WHERE WE COMPETE MOST DIRECTLY]

For each competitor, analyze:
1. Positioning & messaging (how they describe themselves)
2. Key features and differentiators
3. Pricing model (if known)
4. Customer segments they target
5. Perceived strengths vs. our product
6. Perceived weaknesses vs. our product

Then produce:
- A comparison matrix (feature-by-feature table)
- A 3-sentence "state of competition" summary
- Top 3 strategic implications for our roadmap
- Top 2 risks if we do nothing

Format as a professional internal report a VP of Product could share with the exec team. Be direct and opinionated — this is strategy, not journalism.
```

---

**Prompt 2: Competitor Feature Deep-Dive**

*When to use: A competitor just shipped something significant and you need to understand the implications fast*

```
A competitor ([COMPETITOR NAME]) just launched [FEATURE OR PRODUCT NAME]. Here's what I know about it: [PASTE DESCRIPTION, ANNOUNCEMENT, OR NOTES FROM YOUR RESEARCH].

Help me analyze this launch with the following framework:

1. **What problem does it solve?** (from the user's perspective)
2. **Who is the target user?** (and does it overlap with our ICP?)
3. **How does it compare to our current capability?** (We currently [DESCRIBE YOUR CURRENT CAPABILITY OR GAP])
4. **Threat level:** Rate this 1–5 (1 = negligible, 5 = existential) and explain why
5. **Strategic response options:** List 3 possible responses with trade-offs for each
   - Option A: Match the feature
   - Option B: Differentiate/counter-position
   - Option C: Ignore and double down on our strengths
6. **Recommended action:** Your recommendation with one-paragraph rationale
7. **Talking points for sales:** 3 bullets our AEs can use when prospects bring this up

Our product's key differentiators are: [LIST 2-3 KEY DIFFERENTIATORS]
Our biggest current weakness relative to this competitor is: [HONEST ASSESSMENT]
```

---

## WIN/LOSS ANALYSIS

---

**Prompt 3: Win/Loss Interview Question Generator**

*When to use: Before scheduling calls with recently won or churned customers to understand why deals went the way they did*

```
Generate a complete win/loss interview guide for [WON / LOST] deals at [COMPANY NAME].

Context:
- Deal type: [NEW LOGO / EXPANSION / RENEWAL]
- Competitor we won against / lost to: [COMPETITOR NAME, OR "NO DECISION" / "BUILD IN-HOUSE"]
- Deal size: [ARR RANGE]
- Customer profile: [INDUSTRY, COMPANY SIZE, BUYER ROLE]
- Primary use case the customer was evaluating for: [USE CASE]

Create:
1. **Opening questions** (3–4 rapport-building questions to start the conversation)
2. **Discovery questions** (5–6 questions about their evaluation process, criteria, and who was involved)
3. **Decision questions** (4–5 questions probing the specific moment they made their choice)
4. **Product/feature questions** (4–5 questions about what mattered most technically)
5. **Competitive questions** (3–4 questions about how they evaluated us vs. alternatives)
6. **Closing questions** (2–3 future-looking questions)

For each question, add a "(probe:)" line with 1–2 follow-up probes.
Format for easy reading during a live call. Keep questions open-ended, neutral in tone, and free of leading language.
```

---

**Prompt 4: Win/Loss Findings Synthesis**

*When to use: After running 5–10 win/loss interviews and needing to synthesize findings into an actionable report*

```
I've completed [NUMBER] win/loss interviews. Here are my raw notes:

[PASTE INTERVIEW NOTES OR BULLET SUMMARIES]

Synthesize these findings into a structured Win/Loss Analysis report with the following sections:

1. **Executive Summary** (4–6 sentences: overall win rate context, top 2 themes for wins, top 2 themes for losses)
2. **Why We Win** (top 3–5 reasons, with representative quotes from interviews)
3. **Why We Lose** (top 3–5 reasons, with representative quotes)
4. **Key Evaluation Criteria** (ranked by how frequently customers mentioned them)
5. **Competitive Positioning Gaps** (where prospects perceived us as weaker and why)
6. **Product Gaps Mentioned** (specific features or capabilities that came up 2+ times)
7. **Sales Process Observations** (patterns in how deals were run that affected outcomes)
8. **Recommendations** (top 5 actions across Product, Marketing, and Sales)

Be direct. Use quantified language where possible (e.g., "7 of 10 lost deals mentioned..."). Flag your highest-confidence insights vs. ones that need more data.
```

---

## SURVEY & FEEDBACK DESIGN

---

**Prompt 5: Product Feedback Survey Designer**

*When to use: Designing a survey after a feature launch, product update, or to gather baseline satisfaction data*

```
Design a product feedback survey for [PRODUCT NAME / FEATURE NAME].

Survey context:
- What we're trying to learn: [PRIMARY RESEARCH QUESTION — e.g., "Is the new onboarding flow reducing time to first value?"]
- Target respondent: [USER SEGMENT — e.g., "new users who signed up in the last 30 days"]
- Survey channel: [IN-APP / EMAIL / INTERCOM / OTHER]
- Target completion time: [2 MINUTES / 5 MINUTES / OTHER]
- Sample size expected: [ROUGH NUMBER]

Create:
1. **Survey title and intro copy** (2–3 sentences, tells users why we're asking and how long it takes)
2. **Questions** (design 8–12 questions total, mixing):
   - Likert scale questions (1–5 or 1–7)
   - Multiple choice questions
   - At least 2 open-text questions
   - 1 NPS question if relevant
3. **Question logic notes** (flag where skip logic should apply)
4. **Closing copy** (thank-you message, what happens with their feedback)

For each question, note:
- Question type (Likert / MCQ / open text / NPS)
- What insight it's designed to capture
- Any known bias risks to watch for

Avoid leading questions, double-barreled questions, and jargon. Optimize for completion rate.
```

---

**Prompt 6: NPS Analysis Narrative**

*When to use: After collecting NPS scores and needing to turn the data into a story for leadership*

```
Help me write an NPS analysis narrative for [PRODUCT NAME / TEAM NAME].

Here is the data:
- Survey period: [DATE RANGE]
- Total responses: [NUMBER]
- Promoters (9–10): [NUMBER or %]
- Passives (7–8): [NUMBER or %]
- Detractors (0–6): [NUMBER or %]
- Calculated NPS: [SCORE]
- Previous NPS (last period): [SCORE]
- Industry benchmark: [SCORE, OR "UNKNOWN"]

Top themes from open-text responses:
Promoter comments: [PASTE OR SUMMARIZE TOP THEMES]
Detractor comments: [PASTE OR SUMMARIZE TOP THEMES]
Passive comments: [PASTE OR SUMMARIZE TOP THEMES]

Write a 400–600 word NPS narrative that:
1. Opens with context (what we measured, when, and who responded)
2. States the headline number and trend vs. prior period
3. Explains *why* the score moved (or didn't), grounded in the qualitative themes
4. Highlights the top 2–3 risks from detractor feedback
5. Highlights the top 2–3 strengths from promoter feedback
6. Ends with 3–5 recommended actions with owners (Product / CS / Marketing)

Tone: data-driven but human. Avoid over-celebrating or over-alarming. This will be shared in a leadership QBR.
```

---

## MARKET SIZING & OPPORTUNITY

---

**Prompt 7: Market Sizing Analysis**

*When to use: Building a business case, pitching a new initiative, or validating whether an opportunity is worth pursuing*

```
Help me build a market sizing analysis for [OPPORTUNITY/PRODUCT/FEATURE].

Approach: Use a [TOP-DOWN / BOTTOM-UP / BOTH] methodology.

Inputs I have:
- Total addressable market reference (if known): [ANY DATA POINTS OR SOURCES]
- Our current customer count: [NUMBER]
- Our current ACV/ARR per customer: [NUMBER]
- Target segment for this opportunity: [DESCRIBE THE SEGMENT — industry, size, role]
- Estimated segment size (if known): [NUMBER OF COMPANIES OR USERS]
- Expected conversion/penetration rate: [YOUR ESTIMATE OR ASK AI TO ESTIMATE]
- Assumptions to validate: [LIST KEY ASSUMPTIONS]

Produce:
1. **TAM** (Total Addressable Market) — with methodology explained
2. **SAM** (Serviceable Addressable Market) — filtered to our realistic reach
3. **SOM** (Serviceable Obtainable Market) — what we could realistically capture in 3 years
4. **Revenue model** — a simple table showing units × price = revenue at 3 penetration scenarios (conservative / base / optimistic)
5. **Key assumptions** — list every assumption made and its confidence level
6. **Data gaps** — what we'd need to know to sharpen these numbers

Format as a slide-ready analysis. Flag where numbers are estimated vs. sourced.
```

---

## CHURN & RETENTION

---

**Prompt 8: Churn Analysis Report**

*When to use: After a spike in churn, during a quarterly business review, or when building a retention initiative*

```
Help me write a churn analysis report for [PRODUCT NAME].

Data inputs:
- Time period: [MONTH / QUARTER / YEAR]
- Starting customer count: [NUMBER]
- Churned customers: [NUMBER]
- Churn rate: [%]
- Revenue churned: [$ AMOUNT OR ARR]
- Prior period churn rate: [%]
- Churn reasons collected (from exit surveys / CS notes): [PASTE DATA OR TOP CATEGORIES WITH COUNTS]
- Segments with highest churn: [INDUSTRY, COMPANY SIZE, COHORT, PLAN TYPE, ETC.]
- Segments with lowest churn: [SAME BREAKDOWN]

Write a structured churn analysis report with:
1. **Headline metrics** (churn rate, revenue impact, trend vs. prior period)
2. **Churn segmentation** (which segments are churning most and why)
3. **Root cause analysis** (the real reasons beneath the stated reasons — what do the patterns suggest?)
4. **Leading indicators** (what signals, if caught earlier, might have predicted these churns?)
5. **Retention opportunities** (3–5 specific interventions — product, CS, onboarding, pricing — with estimated impact)
6. **Recommended quick wins** (what can we do in the next 30 days?)
7. **Recommended strategic bets** (what requires 60–90 days+ to implement?)

Be analytical and direct. This is an internal document for leadership + the product team.
```

---

## USAGE DATA & ANALYTICS

---

**Prompt 9: Usage Data Storytelling**

*When to use: You have product analytics data and need to turn it into a narrative that drives decisions*

```
Help me turn the following product usage data into a compelling narrative for [AUDIENCE: engineering team / exec team / board / all-hands].

Data I have:
- Feature/product being analyzed: [NAME]
- Time period: [DATE RANGE]
- Key metrics:
  [METRIC 1]: [VALUE] (vs. [PRIOR PERIOD VALUE])
  [METRIC 2]: [VALUE] (vs. [PRIOR PERIOD VALUE])
  [METRIC 3]: [VALUE] (vs. [PRIOR PERIOD VALUE])
- Interesting patterns or anomalies: [DESCRIBE ANYTHING THAT STANDS OUT]
- Context/hypothesis: [WHAT DO YOU THINK IS DRIVING THE TRENDS?]
- Decision this data should inform: [WHAT ARE WE TRYING TO DECIDE?]

Write a data narrative that:
1. Opens with the "so what" — the one insight that matters most
2. Walks through the data logically, building the story
3. Distinguishes correlation from causation clearly
4. Addresses the "why" behind the numbers (with appropriate confidence levels)
5. Ends with a clear recommendation or call to action
6. Is written for [AUDIENCE] — calibrate technical depth accordingly

Target length: [300 WORDS / 500 WORDS / SLIDE DECK BULLETS]. Avoid data dumps. Every number should earn its place in the narrative.
```

---

**Prompt 10: A/B Test Results Summary**

*When to use: An experiment has concluded and you need to communicate results to stakeholders and make a ship/no-ship recommendation*

```
Help me write an A/B test results summary for [TEST NAME].

Test details:
- What we tested: [DESCRIBE THE VARIANT — what changed and why]
- Hypothesis: [IF WE DO X, WE EXPECT Y BECAUSE Z]
- Primary metric: [METRIC NAME] — Target: [GOAL] | Result: [ACTUAL RESULT]
- Secondary metrics:
  - [METRIC 2]: [RESULT]
  - [METRIC 3]: [RESULT]
- Guardrail metrics (did anything break?): [RESULTS]
- Statistical significance: [% CONFIDENCE, P-VALUE IF KNOWN]
- Sample size: [CONTROL: N=X | VARIANT: N=X]
- Test duration: [START DATE] to [END DATE]
- Segments tested: [ALL USERS / SPECIFIC SEGMENT]
- Unexpected findings: [ANYTHING SURPRISING?]

Write a results summary that includes:
1. **One-line result** ("The variant [won / lost / was inconclusive] on [PRIMARY METRIC] by [DELTA]")
2. **What we tested and why** (brief context)
3. **Results breakdown** (primary + secondary metrics, with % changes and confidence levels)
4. **Interpretation** (what the data actually means — include caveats)
5. **Recommendation: Ship / Iterate / Kill** — with rationale
6. **Next steps** (if shipping: rollout plan; if iterating: what to change; if killing: what we learned)
7. **Open questions** (what this test didn't answer)

Format for a Slack post or Confluence page. Clear, concise, no jargon.
```

---

## USER RESEARCH

---

**Prompt 11: User Interview Synthesis**

*When to use: After conducting a batch of user interviews and needing to extract patterns and insights*

```
I've conducted [NUMBER] user interviews with [USER SEGMENT — e.g., "mid-market operations managers who use our workflow automation product"]. Here are my interview notes:

[PASTE NOTES, TRANSCRIPTS, OR BULLET SUMMARIES — can be messy]

Synthesize these into a structured research readout with:

1. **Participant overview** (quick table: role, company size, tenure with product, key characteristic)
2. **Key themes** (top 4–6 patterns that appeared across multiple interviews — with frequency noted)
3. **Jobs to Be Done** (what are users actually trying to accomplish? Format as: "When [situation], I want to [motivation], so I can [outcome]")
4. **Pain points** (ranked by frequency and severity — include representative quotes)
5. **Moments of delight** (what do users love? What's working?)
6. **Mental models** (how do users think about the problem space? Any surprising assumptions?)
7. **Feature requests** (what users asked for — but also what underlying need each request reveals)
8. **Quotes wall** (10–15 of the most compelling, specific quotes — the kind you'd put in a deck)
9. **Implications for product** (3–5 "therefore we should..." statements)
10. **Open questions** (what we still don't know and how to find out)

Prioritize insight over summary. I want to understand *why* users behave the way they do, not just *what* they said.
```

---

**Prompt 12: Persona Development from Research**

*When to use: After gathering qualitative and quantitative data and needing to create or update a user persona*

```
Help me build a user persona based on the following research data:

Qualitative sources:
[PASTE INTERVIEW QUOTES, THEMES, OR SYNTHESIS]

Quantitative sources:
[PASTE SURVEY DATA, USAGE ANALYTICS, DEMOGRAPHIC DATA IF AVAILABLE]

Persona context:
- Product: [PRODUCT NAME]
- This persona represents: [% OF USER BASE OR SEGMENT DESCRIPTION]
- Primary use case: [WHAT THEY USE THE PRODUCT FOR]

Create a rich, research-grounded persona with:
1. **Name and title** (fictional but representative — e.g., "Marcus, Senior Operations Manager")
2. **Demographic snapshot** (role, company size, industry, experience level)
3. **A day in their life** (3–4 sentence narrative of their typical workday — make it vivid)
4. **Goals** (what they're trying to achieve — professional and personal)
5. **Frustrations** (top 3–5 pain points, in their own language)
6. **How they use our product** (workflow, frequency, key features)
7. **What success looks like to them** (how they measure their own win)
8. **Decision-making style** (how they buy, who they influence, what they care about)
9. **Quote** (one authentic-sounding quote that captures their mindset)
10. **Design/product implications** (3–4 "this means we should..." statements)

Ground every element in the research. Flag where you're inferring vs. where the data is direct.
```

---

## DATA-DRIVEN ROADMAP

---

**Prompt 13: Data-Driven Roadmap Justification**

*When to use: Defending prioritization decisions to engineering, leadership, or skeptical stakeholders who want to know "why this, why now?"*

```
Help me write a data-driven justification for prioritizing [FEATURE/INITIATIVE NAME] on our roadmap for [QUARTER/TIMEFRAME].

Here's my supporting data:
- User research signals: [SUMMARIZE RELEVANT FINDINGS — interview themes, survey results, support tickets]
- Usage data: [RELEVANT METRICS — adoption rates, drop-off points, feature requests]
- Business impact: [REVENUE AT RISK / OPPORTUNITY — churn data, sales blockers, expansion revenue tied to this]
- Competitive pressure: [IS A COMPETITOR DOING THIS? DOES IT AFFECT WIN/LOSS?]
- Strategic alignment: [HOW DOES THIS MAP TO OUR CURRENT OKRs OR COMPANY GOALS?]
- Effort estimate: [ROUGH T-SHIRT SIZE OR ENGINEERING ESTIMATE]
- What we're de-prioritizing to make room: [LIST WHAT WE'RE SAYING "NOT NOW" TO]

Write a 400–600 word justification document that:
1. Opens with the user/business problem (not the feature)
2. Presents the evidence stack — research, data, competitive context
3. Quantifies the opportunity (revenue impact, retention impact, or strategic value)
4. Addresses the strongest counterargument ("why not [ALTERNATIVE]?")
5. Confirms strategic alignment
6. States the recommendation clearly

Tone: confident, evidence-based, not defensive. This should stand up in a roadmap review.
```

---

**Prompt 14: OKR-to-Roadmap Traceability Report**

*When to use: Quarterly planning or when leadership asks "how does our roadmap connect to our goals?"*

```
Help me create an OKR-to-Roadmap traceability report for [TEAM NAME] for [QUARTER].

Our OKRs this quarter:
- Objective 1: [OBJECTIVE]
  - KR 1.1: [KEY RESULT WITH TARGET METRIC]
  - KR 1.2: [KEY RESULT WITH TARGET METRIC]
- Objective 2: [OBJECTIVE]
  - KR 2.1: [KEY RESULT WITH TARGET METRIC]
- [ADD MORE AS NEEDED]

Our planned roadmap items:
1. [INITIATIVE/FEATURE 1] — [BRIEF DESCRIPTION] — [ESTIMATED SHIP DATE]
2. [INITIATIVE/FEATURE 2] — [BRIEF DESCRIPTION] — [ESTIMATED SHIP DATE]
3. [INITIATIVE/FEATURE 3] — [BRIEF DESCRIPTION] — [ESTIMATED SHIP DATE]
[ADD MORE]

Create a report that:
1. Maps each roadmap item to the OKR(s) it supports (use a table)
2. Rates the strength of each connection (Direct / Indirect / Stretch)
3. Identifies any OKRs with weak or no roadmap coverage — these are gaps
4. Identifies any roadmap items with no OKR connection — these are "nice to haves" or misaligned work
5. Provides a 3–5 sentence executive summary of how well our roadmap serves our goals
6. Suggests one roadmap swap or addition to improve coverage of underserved KRs

Flag any conflicts where two roadmap items might compete for the same KR contribution.
```

---

**Prompt 15: Insight-to-Action Report**

*When to use: Monthly or quarterly, when you want to close the loop between research, data, and what actually gets built*

```
Help me write an Insight-to-Action report for [PRODUCT AREA / TEAM] covering [TIME PERIOD].

This report connects what we learned to what we decided. Here's my raw input:

Research and data insights gathered this period:
[LIST 5–10 KEY INSIGHTS FROM INTERVIEWS, ANALYTICS, SUPPORT TICKETS, SALES CALLS, OR NPS]

Decisions made / roadmap items added or removed as a result:
[LIST WHAT WAS CHANGED, ADDED, DEPRIORITIZED, OR KILLED — AND WHY]

Insights that are still waiting for action:
[LIST VALIDATED INSIGHTS THAT HAVEN'T YET INFLUENCED THE ROADMAP]

Write a report with:
1. **Period summary** (1 paragraph: what research modes did we use? What was the volume?)
2. **Top insights** (formatted as: Insight → Evidence → Decision Made → Expected Impact)
3. **Insights awaiting action** (formatted as: Insight → Why it hasn't been acted on → Recommended next step)
4. **Research debt** (what questions are we carrying forward that need answers?)
5. **Research plan for next period** (top 3 questions to answer and recommended method for each)

This report will be shared with Product, Design, Engineering leads, and the VP of Product. Make it concise, scannable, and decision-focused.
```

---

*End of File 05 — Research & Data Prompts*
*→ Next: 06-workflow-sops.md — Step-by-step systems for your most common PM workflows*
