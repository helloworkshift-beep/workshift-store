# PRODUCT INFO — The Product Manager's AI Prompt Toolkit

*Internal reference for sales, marketing, and distribution*

---

## Product Details

| Field | Value |
|-------|-------|
| **Product Name** | The Product Manager's AI Prompt Toolkit |
| **Price** | $67 |
| **Stripe Checkout Link** | https://buy.stripe.com/3cI5kFfHXatzfIdd2MgEg01 |
| **Format** | 7 Markdown files (digital download) |
| **Total Prompts** | 95+ ready-to-use AI prompts |

---

## Sales Description (200 words)

Product Managers are expected to produce more, move faster, and communicate more clearly than ever — with the same 40 hours a week they've always had.

**The Product Manager's AI Prompt Toolkit** gives you 95+ professionally crafted AI prompts engineered specifically for how PMs actually work. Not generic "write me a document" prompts — precise, context-rich templates that produce PRDs, stakeholder updates, user stories, research readouts, and competitive analyses you can actually use.

Every prompt includes bracketed variables you fill in with your real context. Paste in your inputs, get professional output in seconds. Then spend your time on the decisions that require a human — not the documents that don't.

This toolkit covers the full PM workflow: strategy and roadmaps, stakeholder communication, user stories and acceptance criteria, research and data analysis, and five complete step-by-step SOPs for your most time-intensive recurring tasks.

Whether you're a solo PM at a startup trying to punch above your weight, or a senior PM drowning in documentation at a scale-up — this toolkit cuts your writing time by 70% while raising the quality of everything you produce.

**Stop starting from a blank page. Start shipping.**

---

## 5 Headline Options

1. **"95 AI Prompts That Write Like a Senior PM — Because Your Time Is Worth More Than Documents"**

2. **"The Product Manager's AI Prompt Toolkit: From PRD to Launch Brief in Half the Time"**

3. **"Stop Staring at a Blank Page. 95 AI Prompts for Every PM Workflow — Ready to Paste and Use."**

4. **"Ship Faster. Write Smarter. The AI Prompt Library Built for Product Managers Who Have Too Much to Do."**

5. **"95 Battle-Tested AI Prompts for PMs: PRDs, Roadmaps, Stakeholder Updates, Research Reports, and More — Done in Minutes."**

---

## Target Audience

**Primary:** Product Managers at B2B SaaS companies, Series A through Series C. Typically 2–8 years of PM experience. Manages 1–3 engineers or a full squad. Responsible for roadmap, PRDs, stakeholder communication, and research synthesis.

**Secondary:**
- Associate PMs and APMs who want to produce senior-level output faster
- Senior PMs and Heads of Product who are writing-heavy and want to reclaim time
- Founders doing their own product management at early-stage startups
- Product Operations professionals supporting PM teams

**Pain points this product solves:**
- "I spend hours every week writing PRDs, updates, and meeting notes that should take 30 minutes"
- "I know what I want to say, but getting it onto paper in the right format takes forever"
- "My stakeholder updates aren't landing the way I want — they either get ignored or generate too many questions"
- "I want to use AI more in my work, but generic prompts don't produce PM-quality output"
- "I don't have a research team — I need to do competitive analysis, user synthesis, and data storytelling myself"

**Psychographic profile:** Analytical, results-oriented, perpetually time-constrained. Keeps up with the industry. Has already experimented with ChatGPT or Claude but finds the outputs too generic. Will pay for something that saves them real time on real tasks they do every week.

---

## All Included Files

| File | Description | Prompt Count |
|------|-------------|--------------|
| `01-quick-start-guide.md` | Setup guide, system prompt, how to use bracket variables, and tips for getting the best output | — |
| `02-strategy-roadmap-prompts.md` | PRDs, executive summaries, roadmap narratives, OKR frameworks, prioritization, feature specs | 25 prompts |
| `03-stakeholder-communication-prompts.md` | Weekly updates, exec presentations, pushback responses, launch announcements, board updates | 20 prompts |
| `04-user-story-prompts.md` | User story generation, splitting, acceptance criteria, epics, job stories, story mapping | 20 prompts |
| `05-research-data-prompts.md` | Competitive analysis, win/loss interviews, survey design, NPS narratives, churn analysis, A/B test summaries, user research synthesis | 15 prompts |
| `06-workflow-sops.md` | 5 complete step-by-step SOPs: PRD in 30 minutes, weekly stakeholder update system, sprint kickoff prep, quarterly roadmap review deck, feature launch communication sequence | 5 SOPs |
| `07-cheat-sheet.md` | Top 15 most powerful prompts copied in full + 10 Golden Rules of Prompting for PMs | 15 prompts + 10 rules |

**Total: 95+ prompts, 5 workflow SOPs, and 10 prompting frameworks**

---

## Frequently Asked Questions (for Sales Page)

**What AI tools do these prompts work with?**
All of them. These prompts are designed to work with ChatGPT (GPT-4o), Claude (Sonnet or Opus), Gemini Advanced, and any other instruction-following LLM. No API required — just paste into your existing AI tool.

**Do I need to be technical to use this?**
No. If you can copy, paste, and fill in the blanks, you can use every prompt in this toolkit.

**What format does the toolkit come in?**
7 Markdown (.md) files, readable in any text editor, Notion, Obsidian, or GitHub. Clean, portable, yours forever.

**Is this updated when new prompts are added?**
Customers who purchase receive the current version. Significant updates may be offered to previous buyers at a discount.

**What if the prompts don't work for me?**
If you fill in the brackets with real context and don't get usable output, reach out within 14 days for a full refund. No questions asked.

---

## Marketing Copy Snippets

### Short Ad Copy (50 words)
> "95 AI prompts designed for how PMs actually work. PRDs, roadmaps, stakeholder updates, user stories, research reports — done in minutes instead of hours. Fill in the brackets, get professional output. The toolkit that works as hard as you do. $67. Yours forever."

### Tweet/X Copy
> "Spent 3 hours on a PRD that AI could have drafted in 10 minutes. 
> 
> Built 95 PM-specific AI prompts so it never happens again. PRDs, roadmaps, user stories, stakeholder updates, research reports — all of it.
> 
> The Product Manager's AI Prompt Toolkit → [LINK]
> 
> $67. One time."

### LinkedIn Post Hook Options
- "I used to spend Sunday nights writing PRDs. Now I spend 30 minutes. Here's the exact system →"
- "The #1 thing separating good PMs from great ones right now: knowing how to prompt AI for PM work. I built the toolkit."
- "Every PM I know is drowning in documentation. I spent 3 months solving that problem. Here's what I built →"

---

*Last updated: March 2026*
*For questions: see Stripe dashboard for order management*
