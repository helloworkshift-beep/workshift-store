# 07 — The PM's AI Cheat Sheet

*The 15 most powerful prompts in this toolkit — ready to copy, paste, and use right now*

---

> **How to use this file:** This is your quick-access layer. Every prompt here is copied in full from the main prompt files. No need to dig. When you're in a meeting, on a call, or under pressure — start here.
>
> Fill in every `[BRACKET]` with your real context before pasting. The quality of your output is directly proportional to the specificity of your inputs.

---

## THE 15 MOST POWERFUL PROMPTS

---

### 🏆 Prompt 1: The Full PRD Generator
*Source: 02-strategy-roadmap-prompts.md*
*Why it's here: This is the single highest-leverage prompt in the toolkit. A 10-minute input produces a complete, stakeholder-ready PRD in seconds.*

```
Write a full Product Requirements Document (PRD) for [FEATURE NAME].

Context:
- Product: [PRODUCT NAME AND ONE-SENTENCE DESCRIPTION]
- Target user: [USER PERSONA — role, company size, key pain point]
- Problem being solved: [DESCRIBE THE PROBLEM IN 2-3 SENTENCES]
- Business context: [WHY ARE WE BUILDING THIS NOW — strategic driver, competitive pressure, revenue opportunity]
- Scope: [WHAT IS IN SCOPE AND WHAT IS EXPLICITLY OUT OF SCOPE]
- Timeline: [TARGET LAUNCH QUARTER OR DATE]
- Engineering resources: [NUMBER OF ENGINEERS AND ROUGH CAPACITY]

The PRD should include:
1. Problem Statement (user-centric, data-backed where possible)
2. Goals & Success Metrics (KPIs with target numbers)
3. User Stories (top 5-8, in standard format)
4. Functional Requirements (numbered, grouped by area)
5. Non-Functional Requirements (performance, security, accessibility)
6. Out of Scope (explicit list)
7. Open Questions (unresolved decisions that need input)
8. Dependencies (teams, systems, third parties)
9. Risks & Mitigations
10. Launch Considerations (rollout strategy, comms, support readiness)

Write it in professional PM voice. Be specific. No vague requirements like "should be fast" — say "p99 latency under 300ms." Flag any assumptions you're making.
```

---

### 🏆 Prompt 2: The PRD Executive Summary
*Source: 02-strategy-roadmap-prompts.md*
*Why it's here: Your detailed PRD won't get read by leadership. This turns it into a 1-pager that gets decisions made.*

```
Write a 1-page Executive Summary for the following PRD. This summary will be read by [C-SUITE TITLE, e.g., CEO, CPO] who has 3 minutes and will decide whether to greenlight this initiative.

PRD Content:
[PASTE YOUR FULL PRD HERE]

The Executive Summary should include:
- Problem: What customer pain are we solving? (2-3 sentences, user and business framing)
- Solution: What are we building? (3-4 sentences max)
- Why now: What's the strategic or market reason to prioritize this? (2-3 sentences)
- Success metrics: What does winning look like? (3-5 measurable KPIs)
- Investment required: Engineering effort, timeline, dependencies
- Risk: Top 1-2 risks and mitigations
- Ask: What decision or approval do you need?

No jargon. No feature lists. Translate everything to business impact. Bullet points are fine. Max 400 words.
```

---

### 🏆 Prompt 3: Competitive Analysis Report
*Source: 05-research-data-prompts.md*
*Why it's here: Converts a list of competitors into a strategic document with product implications — in minutes.*

```
Write a structured competitive analysis report for [YOUR PRODUCT NAME] against the following competitors: [COMPETITOR 1], [COMPETITOR 2], [COMPETITOR 3].

Context:
- Our product: [ONE-SENTENCE DESCRIPTION OF YOUR PRODUCT AND CORE VALUE PROP]
- Our primary user: [TARGET USER PERSONA]
- Market segment: [B2B/B2C, INDUSTRY, COMPANY SIZE WE SERVE]
- Key battleground features: [2-4 CAPABILITIES WHERE WE COMPETE MOST DIRECTLY]

For each competitor, analyze:
1. Positioning & messaging (how they describe themselves)
2. Key features and differentiators
3. Pricing model (if known)
4. Customer segments they target
5. Perceived strengths vs. our product
6. Perceived weaknesses vs. our product

Then produce:
- A comparison matrix (feature-by-feature table)
- A 3-sentence "state of competition" summary
- Top 3 strategic implications for our roadmap
- Top 2 risks if we do nothing

Format as a professional internal report a VP of Product could share with the exec team. Be direct and opinionated — this is strategy, not journalism.
```

---

### 🏆 Prompt 4: User Story Generator
*Source: 04-user-story-prompts.md*
*Why it's here: Transforms a feature concept into a full sprint-ready story set — the most common daily task for PMs and the most time-consuming without AI.*

```
Convert the following feature description into a set of well-formed user stories.

Feature: [FEATURE NAME AND DESCRIPTION]
Product: [PRODUCT NAME]
Target user personas:
- Primary: [PERSONA NAME — role and key characteristic, e.g., "Alex, a mid-market Account Executive who manages 50+ active deals"]
- Secondary (if applicable): [PERSONA NAME AND DESCRIPTION]

Business goal: [WHAT THE BUSINESS NEEDS THIS FEATURE TO ACHIEVE]

Please produce:
1. **Epic story** (the parent story that frames the full feature)
2. **10-15 child user stories** broken into logical groups:
   - Core happy path (the primary flow)
   - Edge cases and alternate paths
   - Error and empty states
   - Admin / settings stories
   - Notification / email stories

Each user story must follow this format:
**Story ID: [FEATURE-XXX]**
As a [specific user type], I want to [specific action] so that [specific outcome/value].

**Acceptance Criteria:**
- Given [context], when [action], then [outcome]
- [Additional Given/When/Then criteria]

**Definition of Done:**
- [ ] Core functionality implemented
- [ ] Edge cases handled per AC
- [ ] Error states designed and implemented
- [ ] Analytics event fires
- [ ] Unit tests written
- [ ] QA sign-off

**Story Points:** [T-SHIRT SIZE: XS/S/M/L/XL]
**Priority:** [MUST HAVE / SHOULD HAVE / COULD HAVE / WON'T HAVE (MoSCoW)]
```

---

### 🏆 Prompt 5: Stakeholder Pushback Response
*Source: 03-stakeholder-communication-prompts.md*
*Why it's here: Every PM faces pushback. This prompt helps you respond with facts and confidence instead of defensiveness.*

```
Help me write a response to the following pushback on my product decision.

The decision I made: [DESCRIBE YOUR DECISION — e.g., "I decided to deprioritize Feature X in Q3 in favor of improving our onboarding flow"]

The pushback I received: [DESCRIBE THE OBJECTION — e.g., "Our Head of Sales sent an email saying Feature X is a blocker for 3 enterprise deals and should be the #1 priority"]

My reasoning for the original decision:
- [REASON 1]
- [REASON 2]
- [DATA OR CONTEXT THAT SUPPORTS MY DECISION]

What I'm willing to reconsider: [BE HONEST — e.g., "I'm open to expediting a lightweight version of Feature X if it unblocks those specific deals"]
What I'm not willing to change: [e.g., "I won't delay the onboarding work — it's tied to our Q3 activation OKR"]

Audience: [NAME/TITLE OF THE PERSON PUSHING BACK]
Communication channel: [EMAIL / SLACK / IN A MEETING]

Write a response that:
1. Acknowledges their concern genuinely (not dismissively)
2. Explains the reasoning behind the decision with data and strategic context
3. Addresses the specific concern they raised
4. Offers a constructive path forward where possible
5. Closes aligned — leaves the relationship intact

Tone: Confident, collaborative, never defensive. This person is an ally, not an adversary.
```

---

### 🏆 Prompt 6: User Interview Synthesis
*Source: 05-research-data-prompts.md*
*Why it's here: Raw interview notes → structured insights and product implications. Turns hours of synthesis into minutes.*

```
I've conducted [NUMBER] user interviews with [USER SEGMENT — e.g., "mid-market operations managers who use our workflow automation product"]. Here are my interview notes:

[PASTE NOTES, TRANSCRIPTS, OR BULLET SUMMARIES — can be messy]

Synthesize these into a structured research readout with:

1. **Participant overview** (quick table: role, company size, tenure with product, key characteristic)
2. **Key themes** (top 4–6 patterns that appeared across multiple interviews — with frequency noted)
3. **Jobs to Be Done** (what are users actually trying to accomplish? Format as: "When [situation], I want to [motivation], so I can [outcome]")
4. **Pain points** (ranked by frequency and severity — include representative quotes)
5. **Moments of delight** (what do users love? What's working?)
6. **Mental models** (how do users think about the problem space? Any surprising assumptions?)
7. **Feature requests** (what users asked for — but also what underlying need each request reveals)
8. **Quotes wall** (10–15 of the most compelling, specific quotes — the kind you'd put in a deck)
9. **Implications for product** (3–5 "therefore we should..." statements)
10. **Open questions** (what we still don't know and how to find out)

Prioritize insight over summary. I want to understand *why* users behave the way they do, not just *what* they said.
```

---

### 🏆 Prompt 7: Data-Driven Roadmap Justification
*Source: 05-research-data-prompts.md*
*Why it's here: Turns your prioritization instinct into an evidence-backed argument that survives executive scrutiny.*

```
Help me write a data-driven justification for prioritizing [FEATURE/INITIATIVE NAME] on our roadmap for [QUARTER/TIMEFRAME].

Here's my supporting data:
- User research signals: [SUMMARIZE RELEVANT FINDINGS — interview themes, survey results, support tickets]
- Usage data: [RELEVANT METRICS — adoption rates, drop-off points, feature requests]
- Business impact: [REVENUE AT RISK / OPPORTUNITY — churn data, sales blockers, expansion revenue tied to this]
- Competitive pressure: [IS A COMPETITOR DOING THIS? DOES IT AFFECT WIN/LOSS?]
- Strategic alignment: [HOW DOES THIS MAP TO OUR CURRENT OKRs OR COMPANY GOALS?]
- Effort estimate: [ROUGH T-SHIRT SIZE OR ENGINEERING ESTIMATE]
- What we're de-prioritizing to make room: [LIST WHAT WE'RE SAYING "NOT NOW" TO]

Write a 400–600 word justification document that:
1. Opens with the user/business problem (not the feature)
2. Presents the evidence stack — research, data, competitive context
3. Quantifies the opportunity (revenue impact, retention impact, or strategic value)
4. Addresses the strongest counterargument ("why not [ALTERNATIVE]?")
5. Confirms strategic alignment
6. States the recommendation clearly

Tone: confident, evidence-based, not defensive. This should stand up in a roadmap review.
```

---

### 🏆 Prompt 8: A/B Test Results Summary
*Source: 05-research-data-prompts.md*
*Why it's here: Converts messy experiment data into a clear ship/no-ship recommendation that non-technical stakeholders can act on.*

```
Help me write an A/B test results summary for [TEST NAME].

Test details:
- What we tested: [DESCRIBE THE VARIANT — what changed and why]
- Hypothesis: [IF WE DO X, WE EXPECT Y BECAUSE Z]
- Primary metric: [METRIC NAME] — Target: [GOAL] | Result: [ACTUAL RESULT]
- Secondary metrics:
  - [METRIC 2]: [RESULT]
  - [METRIC 3]: [RESULT]
- Guardrail metrics (did anything break?): [RESULTS]
- Statistical significance: [% CONFIDENCE, P-VALUE IF KNOWN]
- Sample size: [CONTROL: N=X | VARIANT: N=X]
- Test duration: [START DATE] to [END DATE]
- Segments tested: [ALL USERS / SPECIFIC SEGMENT]
- Unexpected findings: [ANYTHING SURPRISING?]

Write a results summary that includes:
1. **One-line result** ("The variant [won / lost / was inconclusive] on [PRIMARY METRIC] by [DELTA]")
2. **What we tested and why** (brief context)
3. **Results breakdown** (primary + secondary metrics, with % changes and confidence levels)
4. **Interpretation** (what the data actually means — include caveats)
5. **Recommendation: Ship / Iterate / Kill** — with rationale
6. **Next steps** (if shipping: rollout plan; if iterating: what to change; if killing: what we learned)
7. **Open questions** (what this test didn't answer)

Format for a Slack post or Confluence page. Clear, concise, no jargon.
```

---

### 🏆 Prompt 9: Monthly Exec Product Update
*Source: 03-stakeholder-communication-prompts.md*
*Why it's here: Your monthly update to the exec team is high-stakes and high-visibility. This prompt gets it right.*

```
Write a monthly product update for [MONTH YEAR] for the executive team at [COMPANY NAME].

Context:
- Products/areas covered: [LIST PRODUCT AREAS]
- Company OKRs being tracked: [LIST RELEVANT OKRs]

This month's highlights:
- What shipped: [LIST MAJOR LAUNCHES OR MILESTONES]
- What we learned: [KEY INSIGHTS FROM RESEARCH, DATA, OR CUSTOMER FEEDBACK]
- Metrics: [KEY METRICS WITH MoM AND YoY COMPARISONS WHERE AVAILABLE]
- What we're planning: [HEADLINE PRIORITIES FOR NEXT 30-60 DAYS]
- Key decisions needed: [ANY DECISIONS THAT REQUIRE EXEC INPUT]

Please write:
1. **Executive Summary** (5-bullet max — what every exec needs to know)
2. **Progress vs OKRs** — concise status for each OKR (On track / At risk / Off track + 1-sentence rationale)
3. **Product highlights** — 3-4 major accomplishments with brief context on why they matter
4. **Key metrics dashboard** — narrative explaining the numbers, not just listing them
5. **Customer pulse** — 2-3 notable customer signals (quotes, feedback themes, churn context)
6. **Upcoming** — next 30 days key milestones
7. **Risks & flags** — anything the exec team should be aware of or weigh in on

Format: Clean, scannable. Executive-ready. No product jargon without explanation.
```

---

### 🏆 Prompt 10: Churn Analysis Report
*Source: 05-research-data-prompts.md*
*Why it's here: Churn conversations happen in every QBR. This transforms your raw retention data into an analytical narrative with actual recommendations.*

```
Help me write a churn analysis report for [PRODUCT NAME].

Data inputs:
- Time period: [MONTH / QUARTER / YEAR]
- Starting customer count: [NUMBER]
- Churned customers: [NUMBER]
- Churn rate: [%]
- Revenue churned: [$ AMOUNT OR ARR]
- Prior period churn rate: [%]
- Churn reasons collected (from exit surveys / CS notes): [PASTE DATA OR TOP CATEGORIES WITH COUNTS]
- Segments with highest churn: [INDUSTRY, COMPANY SIZE, COHORT, PLAN TYPE, ETC.]
- Segments with lowest churn: [SAME BREAKDOWN]

Write a structured churn analysis report with:
1. **Headline metrics** (churn rate, revenue impact, trend vs. prior period)
2. **Churn segmentation** (which segments are churning most and why)
3. **Root cause analysis** (the real reasons beneath the stated reasons — what do the patterns suggest?)
4. **Leading indicators** (what signals, if caught earlier, might have predicted these churns?)
5. **Retention opportunities** (3–5 specific interventions — product, CS, onboarding, pricing — with estimated impact)
6. **Recommended quick wins** (what can we do in the next 30 days?)
7. **Recommended strategic bets** (what requires 60–90 days+ to implement?)

Be analytical and direct. This is an internal document for leadership + the product team.
```

---

### 🏆 Prompt 11: Story Splitting for Sprint Fit
*Source: 04-user-story-prompts.md*
*Why it's here: Oversized stories are the #1 source of sprint failure. This prompt systematically splits them.*

```
Help me split the following large user story (too big for a single sprint) into smaller, independently deliverable stories.

Original story:
[PASTE THE FULL STORY INCLUDING ANY ACCEPTANCE CRITERIA]

Sprint capacity context:
- Sprint length: [1 WEEK / 2 WEEKS]
- Engineering capacity for this story: [STORY POINTS OR DAYS AVAILABLE]
- Team: [FRONTEND / BACKEND / FULLSTACK — RELEVANT TO HOW TO SPLIT]

Splitting constraints:
- Each sub-story must be independently deliverable (shippable on its own)
- Each sub-story must deliver some user value (not just "set up the database")
- We can feature-flag if needed
- Target size per story: [MAX STORY POINTS OR "COMPLETABLE IN 2-3 DAYS"]

Please:
1. **Suggest 3 ways to split this story** (different splitting strategies: by user type, by workflow step, by happy path vs edge cases)
2. **Recommend the best splitting strategy** with rationale
3. **Write the split stories** in full (using the same Given/When/Then format as the original)
4. **Flag dependencies** between the split stories (which must ship first?)
```

---

### 🏆 Prompt 12: NPS Analysis Narrative
*Source: 05-research-data-prompts.md*
*Why it's here: Turning NPS numbers into a story that drives product decisions is a skill most PMs underuse. This prompt does the heavy lifting.*

```
Help me write an NPS analysis narrative for [PRODUCT NAME / TEAM NAME].

Here is the data:
- Survey period: [DATE RANGE]
- Total responses: [NUMBER]
- Promoters (9–10): [NUMBER or %]
- Passives (7–8): [NUMBER or %]
- Detractors (0–6): [NUMBER or %]
- Calculated NPS: [SCORE]
- Previous NPS (last period): [SCORE]
- Industry benchmark: [SCORE, OR "UNKNOWN"]

Top themes from open-text responses:
Promoter comments: [PASTE OR SUMMARIZE TOP THEMES]
Detractor comments: [PASTE OR SUMMARIZE TOP THEMES]
Passive comments: [PASTE OR SUMMARIZE TOP THEMES]

Write a 400–600 word NPS narrative that:
1. Opens with context (what we measured, when, and who responded)
2. States the headline number and trend vs. prior period
3. Explains *why* the score moved (or didn't), grounded in the qualitative themes
4. Highlights the top 2–3 risks from detractor feedback
5. Highlights the top 2–3 strengths from promoter feedback
6. Ends with 3–5 recommended actions with owners (Product / CS / Marketing)

Tone: data-driven but human. Avoid over-celebrating or over-alarming. This will be shared in a leadership QBR.
```

---

### 🏆 Prompt 13: Win/Loss Interview Guide
*Source: 05-research-data-prompts.md*
*Why it's here: Win/loss interviews are the highest-signal competitive research you can do. This guide makes them consistent and thorough.*

```
Generate a complete win/loss interview guide for [WON / LOST] deals at [COMPANY NAME].

Context:
- Deal type: [NEW LOGO / EXPANSION / RENEWAL]
- Competitor we won against / lost to: [COMPETITOR NAME, OR "NO DECISION" / "BUILD IN-HOUSE"]
- Deal size: [ARR RANGE]
- Customer profile: [INDUSTRY, COMPANY SIZE, BUYER ROLE]
- Primary use case the customer was evaluating for: [USE CASE]

Create:
1. **Opening questions** (3–4 rapport-building questions to start the conversation)
2. **Discovery questions** (5–6 questions about their evaluation process, criteria, and who was involved)
3. **Decision questions** (4–5 questions probing the specific moment they made their choice)
4. **Product/feature questions** (4–5 questions about what mattered most technically)
5. **Competitive questions** (3–4 questions about how they evaluated us vs. alternatives)
6. **Closing questions** (2–3 future-looking questions)

For each question, add a "(probe:)" line with 1–2 follow-up probes.
Format for easy reading during a live call. Keep questions open-ended, neutral in tone, and free of leading language.
```

---

### 🏆 Prompt 14: Feature Launch Communication Brief
*Source: 03-stakeholder-communication-prompts.md*
*Why it's here: The fastest way to get every team aligned before a launch. One prompt, one brief, everyone knows what to do.*

```
Write an internal launch brief for [FEATURE NAME].

Feature context:
- What it does: [ONE-SENTENCE DESCRIPTION — what the user can now do that they couldn't before]
- Who it's for: [USER SEGMENT — e.g., all users / power users / enterprise accounts / admins]
- Problem it solves: [THE USER PAIN THIS ADDRESSES — in user language, not product language]
- Launch type: [GENERAL AVAILABILITY / BETA / LIMITED ROLLOUT / SOFT LAUNCH]
- Launch date: [DATE]
- Rollout plan: [PHASED % ROLLOUT / FEATURE FLAG / FULL IMMEDIATE RELEASE]

Metrics we expect to move:
- Primary: [METRIC] — current baseline [X], target [Y]
- Secondary: [METRIC] — current baseline [X], target [Y]

Teams involved and their roles:
- Engineering lead: [NAME]
- Design lead: [NAME]
- Customer Success: [NAME — responsible for customer comms]
- Marketing: [NAME — responsible for external announcement]

Write the internal launch brief with:
1. **What's launching** (clear, jargon-free description)
2. **Who it affects** (users, internal teams)
3. **Why it matters** (user value + business impact)
4. **Rollout plan** (when, who gets it, how)
5. **How it works** (enough detail for CS and Sales to explain it)
6. **Known limitations** (what it doesn't do yet — important for support)
7. **Success metrics** (what we're measuring and by when)
8. **Escalation path** (who to contact if something breaks)
9. **Customer comms plan** (what's going out, when, owned by whom)

Format as a Confluence page or Notion doc. Clear headers, bullet points. No fluff.
```

---

### 🏆 Prompt 15: The Horizon Roadmap Narrative
*Source: 02-strategy-roadmap-prompts.md*
*Why it's here: Strategy decks live or die on the narrative. This prompt takes your roadmap items and turns them into a vision story.*

```
Help me write a compelling roadmap narrative for [PRODUCT NAME / AREA] covering [TIME HORIZON — e.g., "the next 12 months" or "H2 2025"].

Context:
- Company stage: [SEED / SERIES A / SERIES B / GROWTH / ENTERPRISE]
- Target customer: [ICP DESCRIPTION]
- Current biggest product gaps: [TOP 2-3 PROBLEMS YOUR PRODUCT HAS TODAY]
- Strategic theme for this period: [THE "ONE BIG THING" — e.g., "becoming the system of record for ops teams"]

Roadmap initiatives (in rough priority order):
1. [INITIATIVE 1] — [BRIEF DESCRIPTION] — [QUARTER]
2. [INITIATIVE 2] — [BRIEF DESCRIPTION] — [QUARTER]
3. [INITIATIVE 3] — [BRIEF DESCRIPTION] — [QUARTER]
4. [INITIATIVE 4] — [BRIEF DESCRIPTION] — [QUARTER]

Write a roadmap narrative (400–600 words) that:
1. Opens with the strategic context — where are we, and what challenge are we solving?
2. Articulates the unifying theme across these initiatives
3. Explains the sequencing logic — why this order?
4. Connects each initiative to a user outcome and a business outcome
5. Paints a picture of what the product looks like at the end of this horizon
6. Closes with the "why this team, why now" confidence statement

This will be presented to: [AUDIENCE — e.g., "company all-hands / board / new team members"].
Tone: visionary but grounded. Ambitious but credible. Not a feature list — a direction.
```

---

## 10 GOLDEN RULES OF PROMPTING FOR PMs

*Follow these rules and you'll get better AI output than 95% of the people using these same tools.*

---

**Rule 1: Context first, always.**

The #1 mistake PMs make with AI is under-explaining context. AI doesn't know your product, your users, your team dynamics, or your company stage. Before you write a single prompt, give it a paragraph of context. The system prompt in `01-quick-start-guide.md` is your starting point — but always add specifics for your situation.

> **Bad:** "Write user stories for a notification feature."
> **Good:** "You're working on Workstream, a B2B project management tool for ops teams. Our users are operations managers at 50–500 person companies who are overwhelmed by notification noise. Write user stories for a smart notification digest that helps them stay informed without being interrupted."

---

**Rule 2: Specify your audience.**

"Write an update" produces different output than "Write a 5-bullet update for a CPO who reads 10 of these a week and will skim it in 90 seconds." Tell AI exactly who will read the output and what they care about. It will calibrate tone, depth, and format accordingly.

---

**Rule 3: Give it the messy version first.**

You don't need to have your ideas organized before using AI. Paste your messy notes, rough bullets, or brain dump and ask it to structure it. The organization step is where AI saves the most time. Get your thinking out — then let AI impose structure.

---

**Rule 4: Tell it what you don't want.**

Specify what to exclude as clearly as what to include. "No jargon. No feature lists. No bullet points longer than one line. Don't repeat what I told you in the intro." Constraints produce better output than open-ended prompts.

---

**Rule 5: Stay in the same conversation.**

When you're doing multi-step work (like writing a PRD, then user stories, then acceptance criteria), stay in the same chat window. AI has memory of everything you've shared in the conversation — the output becomes dramatically better because it has full context. Starting a new chat for each step is like explaining your project to a new person each time.

---

**Rule 6: Ask for multiple options.**

When you're not sure what you want, ask for 3 versions. "Give me 3 different ways to frame this problem statement." Then mix and match the best elements. This is faster than iterating on a single output.

---

**Rule 7: Tell it what you're trying to accomplish, not just what to write.**

AI produces better output when it understands the *goal* of the document, not just the *format*. "The goal of this message is to get the Sales VP to stop escalating this issue and trust that it's on our roadmap" produces a better response than "write an email to my Sales VP about the roadmap."

---

**Rule 8: Push back and iterate.**

The first output is rarely the final output. If something's off, say so specifically: "The tone is too formal — make it more direct." "The success metrics are too vague — give me specific numbers." "The third paragraph is weak — rewrite it with a stronger opening." AI responds well to specific feedback. Vague feedback ("make it better") produces vague improvement.

---

**Rule 9: Verify everything factual.**

AI will confidently state things that are wrong. Any time a prompt produces statistics, market data, competitor capabilities, or technical claims — verify them before sharing externally. Use AI for structure, writing, and thinking — not as a source of truth for facts you'll stake your reputation on.

---

**Rule 10: Build your own prompt library.**

Every prompt in this toolkit is a starting point. When you find a variation that works especially well for your product, team, or voice — save it. Build your own prompt library over time. The PMs who get the most from AI are the ones who treat their prompts as assets, not one-off experiments.

---

*End of File 07 — The PM's AI Cheat Sheet*
*You now have everything you need. Go ship something great.*
