# 03 — Stakeholder Communication Prompts

*20 prompts for exec updates, alignment emails, pushback handling, launch announcements, and board updates*

---

## EXECUTIVE UPDATES

---

**Prompt 1: Weekly PM Update to CPO/VP of Product**

*When to use: Writing your weekly product update to your direct manager — needs to be tight, strategic, and flag anything that needs their attention*

```
Write a weekly product update for [DATE] from [YOUR NAME], PM for [PRODUCT AREA].

Context for this week:
- Shipped: [LIST WHAT WENT LIVE THIS WEEK]
- In progress: [CURRENT SPRINT STATUS — % COMPLETE, ANY BLOCKERS]
- Metrics update: [KEY METRIC CHANGES — e.g., "DAU up 3% WoW, activation rate down 1.2%"]
- Decisions made: [ANY SIGNIFICANT DECISIONS MADE THIS WEEK AND BY WHOM]
- Coming next week: [TOP 3 PRIORITIES FOR NEXT 7 DAYS]
- Risks / flags: [ANYTHING THAT NEEDS YOUR MANAGER'S ATTENTION OR INPUT]
- Help needed: [SPECIFIC ASKS — DECISIONS, INTRODUCTIONS, UNBLOCKING]

Please format this as a concise, professional update following this structure:
- **TL;DR** (3 bullets max — the most important things)
- **Shipped this week** (bullet list with brief impact notes)
- **In flight** (sprint status, blockers)
- **Metrics** (notable changes with context)
- **Next week** (top priorities)
- **Flags & asks** (anything needing response)

Tone: Direct, confident, no filler. This person reads 5 of these a week. Make it easy to scan.
Max length: 400 words.
```

---

**Prompt 2: Monthly Product Update to Executive Team**

*When to use: Monthly product update for the exec team — broader than a weekly update, focused on progress against strategy and metrics*

```
Write a monthly product update for [MONTH YEAR] for the executive team at [COMPANY NAME].

Context:
- Products/areas covered: [LIST PRODUCT AREAS]
- Company OKRs being tracked: [LIST RELEVANT OKRs]

This month's highlights:
- What shipped: [LIST MAJOR LAUNCHES OR MILESTONES]
- What we learned: [KEY INSIGHTS FROM RESEARCH, DATA, OR CUSTOMER FEEDBACK]
- Metrics: [KEY METRICS WITH MoM AND YoY COMPARISONS WHERE AVAILABLE]
- What we're planning: [HEADLINE PRIORITIES FOR NEXT 30-60 DAYS]
- Key decisions needed: [ANY DECISIONS THAT REQUIRE EXEC INPUT]

Please write:
1. **Executive Summary** (5-bullet max — what every exec needs to know)
2. **Progress vs OKRs** — concise status for each OKR (On track / At risk / Off track + 1-sentence rationale)
3. **Product highlights** — 3-4 major accomplishments with brief context on why they matter
4. **Key metrics dashboard** — narrative explaining the numbers, not just listing them
5. **Customer pulse** — 2-3 notable customer signals (quotes, feedback themes, churn context)
6. **Upcoming** — next 30 days key milestones
7. **Risks & flags** — anything the exec team should be aware of or weigh in on

Format: Clean, scannable. Executive-ready. No product jargon without explanation.
```

---

**Prompt 3: Product Area Update for All-Hands**

*When to use: Presenting a product area update at a company all-hands — needs to be accessible to non-product people and energizing*

```
Write a product area update for [PRODUCT AREA / TEAM NAME] for the company all-hands on [DATE].

Audience: All employees — engineering, sales, marketing, operations, finance. Many have no deep context on this product area.

This quarter's story:
- Major things we shipped: [LIST 3-5 ITEMS WITH 1-SENTENCE DESCRIPTIONS]
- Metrics movement: [KEY METRICS — frame for business impact, not just numbers]
- Customer impact: [SPECIFIC EXAMPLES OR STORIES OF CUSTOMER VALUE]
- What we're working on next: [TOP 2-3 THEMES FOR NEXT QUARTER]
- Team shoutouts: [SPECIFIC PEOPLE TO RECOGNIZE AND WHY]

Please write:
1. **Opening hook** — 1-2 sentences that grab attention and frame the story
2. **The past quarter** — narrative of what we built and why it mattered (business + user framing)
3. **By the numbers** — 3-5 metrics with plain-English explanation of what they mean
4. **Customer moment** — 1 specific customer story or quote that makes the impact real
5. **What's next** — exciting things on the horizon (create energy without over-promising)
6. **Team recognition** — warm, specific shoutouts
7. **Closing** — 1-2 sentence connection to company mission

Tone: Energizing, proud, human. This is a team moment, not a status report. Keep it to 5 minutes spoken (roughly 700-900 words).
```

---

## ALIGNMENT EMAILS

---

**Prompt 4: Cross-Functional Alignment Email**

*When to use: Kicking off a new initiative and need to align multiple teams (engineering, design, marketing, sales, customer success) before work begins*

```
Write a cross-functional alignment email for [INITIATIVE NAME].

Sending to: [LIST TEAMS OR INDIVIDUALS — e.g., Engineering Lead, Design Lead, Marketing Lead, Sales Enablement, Customer Success]
From: [YOUR NAME], PM

Initiative overview:
- What we're building: [BRIEF DESCRIPTION]
- Why now: [BUSINESS DRIVER]
- Target launch: [DATE OR QUARTER]
- Success looks like: [KEY METRIC OR OUTCOME]

What each team needs to know / do:
- Engineering: [THEIR ROLE — e.g., "Building X, estimating Y, starting Z date"]
- Design: [THEIR ROLE]
- Marketing: [THEIR ROLE — e.g., "Positioning, go-to-market plan, launch comms"]
- Sales: [THEIR ROLE — e.g., "Beta customer outreach, demo prep, training by X date"]
- Customer Success: [THEIR ROLE — e.g., "Support documentation, customer notification"]
- Data/Analytics: [THEIR ROLE — e.g., "Instrumentation spec, dashboard setup"]

Please write an email that:
1. Opens with clear context (why this email, why now)
2. Describes the initiative in 2-3 sentences (accessible to all teams)
3. States each team's asks clearly with owners and deadlines
4. Sets expectations for how we'll coordinate (Slack channel, weekly sync, shared doc)
5. Lists open questions that need cross-functional input
6. Ends with a clear call to action

Tone: Collaborative, clear, respectful of people's time. This is a kickoff, not a directive.
```

---

**Prompt 5: Decision Alignment Email**

*When to use: A major product decision has been made and you need to communicate it, get buy-in, and pre-empt objections from stakeholders*

```
Write a stakeholder alignment email communicating the following product decision.

The decision: [STATE THE DECISION CLEARLY — e.g., "We've decided to deprioritize Feature X in Q3 in favor of Feature Y"]
Made by: [WHO MADE THE DECISION — PM + CPO / CEO / Product Council]
Decision date: [DATE]

Context for the decision:
- Options that were considered: [LIST OPTIONS]
- Key factors in the decision: [TOP 3-4 REASONS]
- Data or evidence used: [ANY DATA POINTS]
- Trade-offs acknowledged: [WHAT WE'RE GIVING UP OR ACCEPTING AS A RESULT]

Anticipated reactions:
- [TEAM OR PERSON A] may push back because: [REASON]
- [TEAM OR PERSON B] may push back because: [REASON]

Please write an email that:
1. States the decision clearly in the first sentence (no burying the lede)
2. Explains the context and rationale honestly (including trade-offs)
3. Addresses anticipated objections proactively (don't pretend they don't exist)
4. Clarifies what this means for each affected team (practical implications)
5. States what's still open for input and what isn't
6. Provides a clear path for anyone with concerns

Tone: Confident but not dismissive. Transparent about trade-offs. This is not a persuasion campaign — it's honest communication of a real decision.
```

---

**Prompt 6: Feature Request Response to Sales**

*When to use: Responding to a sales rep who has submitted a feature request from a prospect and wants to know if/when it'll be built*

```
Write a professional response to a sales team feature request.

The request: [DESCRIBE THE FEATURE REQUESTED]
Requested by: [SALES REP NAME] for prospect/customer: [COMPANY NAME]
Deal size / context: [ARR VALUE OR DEAL STAGE]
Sales rep's claim: [WHAT THEY SAID THIS WOULD UNLOCK — e.g., "They won't sign without this"]

Our actual situation:
- Is this on the roadmap? [YES — Q[X] / UNDER CONSIDERATION / NOT PLANNED / ALREADY EXISTS]
- If yes, when: [ESTIMATED DATE]
- If no, why: [BRIEF RATIONALE — NOT FOR THE EMAIL, JUST FOR CONTEXT]
- Alternative: [ANY EXISTING WORKAROUND OR PARTIAL SOLUTION]

Please write a response to the sales rep that:
1. Thanks them for the context and acknowledges the deal importance
2. Gives a clear, honest answer about roadmap status (no false promises)
3. Provides relevant context (if it's on the roadmap, what it will look like; if not, why)
4. Offers any available alternatives or workarounds
5. Explains what information would help us evaluate this further (if not yet on roadmap)
6. Sets expectations clearly — what can they tell the prospect?

Also write a separate 2-sentence version they can share directly with the prospect.

Tone: Helpful, honest, respectful. Sales and Product are partners. Don't be dismissive of the deal — don't make promises you can't keep either.
```

---

**Prompt 7: Dependency Request to Engineering / Platform Team**

*When to use: You need something from another engineering team (API access, infrastructure change, shared component) and need to formally request it without burning the relationship*

```
Write a formal dependency request to [TEAM NAME] at [COMPANY NAME].

Requestor: [YOUR NAME], PM for [PRODUCT AREA]
Request: [DESCRIBE WHAT YOU NEED FROM THIS TEAM — e.g., "A new API endpoint to retrieve user preference data", "Capacity in Q3 to support our data migration"]

Context:
- Why we need this: [BUSINESS DRIVER — USER STORY OR PRODUCT GOAL]
- When we need it by: [DATE AND WHY THAT DATE MATTERS]
- Impact if we don't get it: [WHAT GETS BLOCKED OR DELAYED]
- What we've already done: [ANY WORK DONE TO MINIMIZE THE ASK]

What we're asking for:
- [SPECIFIC DELIVERABLE 1]
- [SPECIFIC DELIVERABLE 2]
- [ESTIMATED EFFORT IN THEIR TERMS, IF YOU KNOW IT]

What we'll do in return / how we'll minimize burden:
- [e.g., "We'll provide a full spec", "We'll do the testing", "We can provide a junior dev to help"]

Please write a message/email that:
1. Opens with clear context (who we are, what we're building, why it matters)
2. States the specific ask with enough detail to estimate effort
3. Explains the business urgency without being demanding
4. Acknowledges their competing priorities
5. Proposes next steps (30-min sync? async review? doc review?)
6. Makes it easy for them to say yes

Tone: Collaborative, respectful of their constraints, clear about what we need. This is a request, not a demand.
```

---

## PUSHBACK HANDLING

---

**Prompt 8: Response to "Why Isn't This Built Yet?" from CEO**

*When to use: CEO or founder has flagged a missing feature or capability and you need to respond thoughtfully without being defensive*

```
Help me craft a response to my CEO who asked why [FEATURE/CAPABILITY] hasn't been built yet.

Their message (paraphrase): [DESCRIBE WHAT THEY SAID — e.g., "A customer just asked why we don't have SSO. Why don't we have this? Every enterprise product has SSO."]

The real situation:
- Is it on the roadmap? [YES / NO / DEPRIORITIZED]
- When was it deprioritized (if applicable)? [DATE AND REASON]
- What's ahead of it and why? [WHAT'S CURRENTLY PRIORITIZED INSTEAD]
- What would it take to build? [ROUGH EFFORT ESTIMATE]
- What's the actual business impact of not having it? [DATA IF AVAILABLE — DEALS LOST, CUSTOMERS CHURNED]

Please help me write:
1. **A direct message response** (Slack / text style) — immediate, confident, non-defensive (3-5 sentences)
2. **A follow-up email** with full context — includes the reasoning, what we can do, and a proposed path forward
3. **A recommended course of action** — based on the context, what should I actually do? (Don't just help me write the email — help me think through whether the CEO is right)

Tone for communication: Direct, accountable, data-informed. Don't grovel. Don't be defensive. Treat this as an opportunity to align.
```

---

**Prompt 9: Handling Pushback from Engineering on Scope**

*When to use: Engineering team is pushing back on scope, timeline, or requirements and you need to navigate the conversation*

```
Help me navigate pushback from engineering on [SPECIFIC SCOPE / TIMELINE / REQUIREMENT].

The situation:
- What I asked for: [YOUR REQUEST]
- What engineering is saying: [THEIR PUSHBACK — e.g., "This will take 3 months, not 3 weeks", "This approach will create technical debt we can't absorb", "The API you're describing doesn't exist in our system"]
- My response so far: [WHAT YOU'VE SAID OR DONE]
- The business context they may not fully know: [CUSTOMER COMMITMENT / COMPETITIVE PRESSURE / CEO PROMISE]

Please help me with:
1. **A structured 1:1 agenda** for the conversation with the engineering lead (30 minutes) — questions to ask, not arguments to make
2. **A reframe of the problem** — is there a way to state the user/business need that opens up engineering to propose a different solution?
3. **Tradeoff options to propose** — 3 ways to honor both the business constraint and the engineering concern (e.g., reduced scope, phased approach, technical spike first)
4. **Escalation assessment** — is this worth escalating? If so, how and to whom? If not, why?
5. **A collaborative Slack message** to send to engineering lead proposing a sync (tone: partner, not adversary)

Key principle: The goal is a good product decision, not "winning" the argument. Help me think through whether engineering is right.
```

---

**Prompt 10: Saying No to a Feature Request (Customer or Internal)**

*When to use: You need to decline a feature request from a customer, internal stakeholder, or executive while keeping the relationship intact*

```
Help me write a thoughtful "no" response to a feature request.

The request: [DESCRIBE THE FEATURE REQUESTED]
Who is requesting it: [CUSTOMER / INTERNAL STAKEHOLDER / EXEC — NAME AND RELATIONSHIP]
Why they want it: [THEIR STATED REASON OR BUSINESS CASE]

Why we're not building it:
[PICK WHICH APPLY AND ADD CONTEXT]
- Not in our target user's workflow
- Conflicts with product direction (explain)
- Low ROI given engineering cost
- We've tried this before and it didn't work (explain)
- We're solving this differently (explain)
- Not enough signal (only X users have asked)
- Technical complexity is too high for the value delivered

Please write:
1. **A customer-facing response** (email or in-app message) that declines without damage. Should: acknowledge their pain, explain our thinking honestly, offer any alternatives, leave the door open.
2. **An internal Slack message** to the stakeholder who surfaced this request, explaining the decision and providing talking points for the customer conversation
3. **A one-liner** for the roadmap backlog or customer success notes: "Not building because [HONEST REASON]"

Tone: Empathetic, honest, respectful. A good "no" is more valuable than a vague "maybe later." Don't promise what you can't deliver.
```

---

**Prompt 11: Managing Up — Pushing Back on an Exec Directive**

*When to use: Your CEO, CPO, or VP has asked you to build something you believe is the wrong call, and you need to make the case for a different approach*

```
Help me construct a thoughtful, evidence-based argument against building [FEATURE/INITIATIVE] as directed by [EXEC TITLE].

Their directive: [DESCRIBE WHAT THEY ASKED FOR AND WHY THEY WANT IT]
My concern: [DESCRIBE YOUR CONCERN — WHY YOU THINK THIS IS THE WRONG CALL]

Evidence I have:
- Customer data: [RELEVANT USER RESEARCH OR USAGE DATA]
- Market data: [COMPETITIVE OR MARKET CONTEXT]
- Eng complexity: [EFFORT OR TECHNICAL RISK]
- Opportunity cost: [WHAT WE WOULDN'T DO IF WE BUILD THIS]

What I'm proposing instead (or as a test): [ALTERNATIVE APPROACH]

Please help me:
1. **Steel-man the exec's position** — what are the strongest reasons they might be right that I should honestly consider before pushing back?
2. **Structure my argument** — a logical, evidence-based case for my position (not just "I disagree")
3. **Propose a compromise** — a way to honor their intent while addressing my concern (e.g., smaller scope, experiment first, time-bound pilot)
4. **Write a 5-minute meeting agenda** for a conversation where I present my case
5. **Draft a pre-read** (1-page) I can send before the meeting so we can have a productive conversation

Tone: Respectful, data-driven, confident. My job is to make the best decision for the company, not to win. Help me argue well, not just argue.
```

---

## LAUNCH ANNOUNCEMENTS

---

**Prompt 12: Internal Launch Announcement**

*When to use: A new feature or product is launching and you need to announce it to the company before the external launch*

```
Write an internal launch announcement for [FEATURE/PRODUCT NAME].

Launch date: [DATE]
What's launching: [DESCRIPTION OF THE FEATURE IN PLAIN ENGLISH]
Who it's for: [TARGET USER OR CUSTOMER SEGMENT]
Why we built it: [BRIEF BACKSTORY — CUSTOMER PAIN, STRATEGIC DRIVER]

Impact:
- Expected user impact: [WHAT CHANGES FOR USERS]
- Expected business impact: [REVENUE, RETENTION, ACQUISITION IMPACT]

Go-live details:
- Rollout: [ALL USERS / % ROLLOUT / SPECIFIC SEGMENT]
- Access: [HOW USERS GET IT — AUTOMATICALLY / OPT-IN / NEW PLAN]

Team acknowledgments: [LIST KEY CONTRIBUTORS — NAME AND WHAT THEY DID]

What different teams need to know:
- Sales: [KEY INFO FOR SALES — PRICING, POSITIONING, CUSTOMER ELIGIBILITY]
- Support: [KNOWN ISSUES, FAQ, ESCALATION PATH]
- Customer Success: [WHICH CUSTOMERS TO PROACTIVELY REACH OUT TO]

Please write:
1. **Subject line** (energizing, specific, not clickbait-y)
2. **Email body** (accessible to the whole company, 300-400 words)
3. **Slack announcement version** (shorter, emoji-friendly, with key links)
4. **A one-sentence "tweet" version** for quick reference

Tone: Proud, celebratory, clear. This is a team moment. Acknowledge the humans behind the work.
```

---

**Prompt 13: Customer-Facing Launch Email**

*When to use: Announcing a new feature or capability to your existing customer base*

```
Write a customer-facing feature launch email for [FEATURE NAME].

Product: [PRODUCT NAME]
Feature: [WHAT IT DOES — IN PLAIN, NON-TECHNICAL LANGUAGE]
Target recipients: [CUSTOMER SEGMENT — e.g., "all Business plan customers", "customers who have requested this"]
Sender: [FROM NAME — PM / HEAD OF PRODUCT / CEO]

Customer context:
- What pain does this solve for them? [SPECIFIC PROBLEM]
- How do they get access? [AUTOMATIC / SELF-SERVE IN SETTINGS / CONTACT CS]
- Any required action from the customer? [UPGRADE / MIGRATION / SETUP STEP]

Social proof / data point (if available): [E.g., "Beta users saved an average of 4 hours per week"]

Call to action: [WHAT DO YOU WANT THEM TO DO — TRY IT NOW / BOOK A DEMO / READ THE DOCS]

Please write:
1. **Subject line** (3 options — test-worthy)
2. **Email body** (250-350 words) — value-first, not feature-first. Lead with the outcome, not the functionality.
3. **Preview text** (90 characters max)
4. **CTA button text** (3 options)

Tone: Warm, direct, focused on value. This is not a features announcement — it's a "here's what you can now do" announcement.
```

---

**Prompt 14: Press Release / External Launch Announcement**

*When to use: Major product launch with external PR — for media, investors, or public announcement*

```
Write a press release for the launch of [PRODUCT/FEATURE NAME].

Company: [COMPANY NAME]
Product context: [BRIEF DESCRIPTION OF THE COMPANY AND PRODUCT]
What's launching: [DETAILED DESCRIPTION OF WHAT'S NEW]
Why it matters: [THE BIGGER STORY — MARKET TREND, INDUSTRY PROBLEM BEING SOLVED]
Key differentiator: [WHAT MAKES THIS DIFFERENT FROM EXISTING SOLUTIONS]

Supporting elements:
- Customer quote: [CUSTOMER NAME, TITLE, COMPANY, AND THEIR QUOTE]
- Founder/exec quote: [EXEC NAME AND TITLE — generate a compelling quote if not provided]
- Statistics or data points: [ANY RELEVANT METRICS — BETA USERS, TIME SAVINGS, ROI DATA]
- Availability: [WHEN AND HOW CUSTOMERS CAN GET ACCESS — PRICING, PLAN, AVAILABILITY DATE]

Company boilerplate: [COMPANY NAME] is [ONE-SENTENCE DESCRIPTION]. Founded in [YEAR], the company serves [CUSTOMER TYPE] and is [STAGE/BACKED BY/HEADQUARTERED IN].

Please write a press release following the standard inverted pyramid format:
1. Headline (under 15 words, active voice, lead with the benefit)
2. Subheadline (adds context, 20-25 words)
3. Dateline and lead paragraph (who, what, when, where, why — 75 words max)
4. Second paragraph (context and market problem — 100 words)
5. Customer quote
6. Product detail paragraph (specifics of what's being launched — 100 words)
7. Exec quote
8. Availability and pricing
9. Company boilerplate
10. Media contact block

Write this for a B2B tech trade publication audience, not a general consumer audience.
```

---

## BOARD UPDATES

---

**Prompt 15: Board Meeting Product Slide Narrative**

*When to use: Preparing the product section of a board meeting presentation — need clear, investor-ready framing*

```
Write the narrative and key points for the product section of a board meeting presentation.

Board context:
- Board composition: [INVESTOR BACKGROUND — e.g., "2 VC board members (enterprise SaaS focused), 2 independent directors (one technical, one ops background), 2 founders"]
- Company stage: [STAGE AND LAST FUNDING ROUND]
- Meeting date: [DATE]
- Quarter being reviewed: [Q + YEAR]

Product section should cover:
1. Product progress this quarter
2. Key metrics and what they mean
3. Strategic product bets and rationale
4. Risks and mitigation
5. Roadmap for next quarter

Raw content:
- Shipped this quarter: [LIST MAJOR LAUNCHES]
- Key metrics: [METRICS WITH TARGETS AND ACTUALS]
- Strategic context: [ANY PIVOTS, MAJOR DECISIONS, MARKET CHANGES]
- Roadmap next quarter: [TOP PRIORITIES]
- Open risks: [ANYTHING THE BOARD SHOULD KNOW ABOUT]

Please write:
1. **Slide-by-slide narrative** (what to say for each slide — 3-4 slides max for product section)
2. **Speaker notes** for each slide (conversational, anticipates board questions)
3. **Pre-read summary** (1-page written version board gets in advance)
4. **Top 5 questions the board will likely ask** — with suggested answers

Tone: Board-ready. Confident. Honest about risks. No fluff. Financial framing wherever possible (impact on ARR, CAC, LTV, retention).
```

---

**Prompt 16: Board Q&A Preparation**

*When to use: Prepping for the product Q&A portion of a board meeting — want to anticipate tough questions and have crisp answers*

```
Help me prepare for the product Q&A section of a board meeting.

Context:
- Product stage: [DESCRIBE WHERE THE PRODUCT IS TODAY]
- Quarter summary: [BRIEF DESCRIPTION OF THE QUARTER — WINS AND MISSES]
- Metrics: [KEY METRICS AND WHETHER THEY'RE ON / OFF TARGET]
- Known sensitive topics: [ANYTHING THE BOARD HAS FLAGGED IN PREVIOUS MEETINGS OR THAT MIGHT BE TOUCHY]

Board members attending: [LIST NAMES AND BACKGROUNDS IF KNOWN — e.g., "Sarah Lee, partner at Sequoia, deep consumer SaaS background"]

Please generate:
1. **20 hard questions the board might ask** — spanning strategy, execution, metrics, competitive, team, and risk topics
2. **Recommended answer framework for each** — not scripts, but key points and data to hit
3. **"I don't know" situations** — which questions should I defer vs. answer now? How do I defer without losing credibility?
4. **Questions I should proactively answer** — topics where I can get ahead of their concern instead of waiting to be asked
5. **The 3 things I want the board to walk away believing** — and how to ensure the Q&A reinforces those

Tone guide: Board Q&A is a conversation, not a performance. Help me sound prepared, honest, and strategically clear — not rehearsed.
```

---

**Prompt 17: Investor Update — Product Section**

*When to use: Writing the product section of a monthly or quarterly investor update email*

```
Write the product section of a monthly investor update for [MONTH YEAR].

Company: [COMPANY NAME]
Stage: [STAGE AND ROUND]

Product highlights this month:
- Shipped: [LIST KEY RELEASES OR MILESTONES]
- Metrics: [PRODUCT METRICS WITH CONTEXT — GROWTH, RETENTION, ACTIVATION, ETC.]
- Customer wins related to product: [SPECIFIC EXAMPLES IF AVAILABLE]
- What we learned: [KEY INSIGHT FROM USER RESEARCH OR DATA]

Challenges / risks:
- [DESCRIBE ANY PRODUCT CHALLENGES OR RISKS HONESTLY]

Next month focus:
- [TOP 2-3 PRODUCT PRIORITIES]

Please write a product section (200-300 words) that:
1. Leads with the most impactful headline (not a feature list — a business outcome)
2. Provides honest metrics with context (don't spin, but do explain)
3. Demonstrates product velocity and learning
4. Acknowledges challenges with a clear mitigation path
5. Creates confidence without over-promising on next month

Investors reading this want to know: "Is the product getting better? Is the team learning? Are they building the right things?" Answer those questions.
```

---

**Prompt 18: Escalation Email — Critical Issue to Leadership**

*When to use: A significant product issue (outage, data problem, customer impact, missed milestone) needs to be escalated to leadership clearly and promptly*

```
Write an escalation email for the following critical product situation.

Situation: [DESCRIBE THE ISSUE — e.g., "A bug in our billing calculation has been overcharging enterprise customers for 2 billing cycles", "Our mobile app has been crashing for 15% of iOS users for the past 48 hours"]

Current status:
- When it was discovered: [DATE AND HOW]
- Who is aware: [TEAMS / INDIVIDUALS ALREADY LOOPED IN]
- Current impact: [NUMBER OF USERS, REVENUE, CONTRACTS AFFECTED]
- Root cause: [KNOWN OR BEING INVESTIGATED]
- Mitigation taken so far: [WHAT'S ALREADY BEEN DONE]
- ETA to resolution: [IF KNOWN]

Escalating to: [EXEC TITLE(S)]
Reason for escalation: [WHY THEY NEED TO KNOW NOW — CUSTOMER RELATIONSHIP RISK / REVENUE IMPACT / PR RISK / NEED A DECISION]

Please write:
1. **Subject line** — clear, not panic-inducing, accurate
2. **Email body** — follows the "SBAR" format: Situation, Background, Assessment, Recommendation
3. **Specific ask** — what do you need from leadership? (Decision, resources, customer outreach authorization, etc.)
4. **Update cadence** — commit to how you'll keep them informed until resolved

Tone: Calm, clear, accountable. Escalation is not failure — it's professional judgment. Don't bury the lede. Don't catastrophize.
```

---

**Prompt 19: Quarterly Business Review (QBR) Product Section**

*When to use: Preparing the product contribution section of a customer QBR — showing a key account the value of the product over the past quarter*

```
Write the product section of a Quarterly Business Review for [CUSTOMER NAME].

Customer context:
- Company: [CUSTOMER COMPANY NAME]
- Industry: [INDUSTRY]
- Use case: [HOW THEY USE YOUR PRODUCT — KEY WORKFLOWS]
- Contract: [PLAN AND ARR — OPTIONAL]
- Key stakeholders: [WHO WILL BE IN THE QBR — TITLES]

Product highlights relevant to this customer:
- Features launched this quarter that affect them: [LIST]
- Features they specifically requested that shipped: [LIST — MAJOR WIN TO HIGHLIGHT]
- Features coming next quarter they'll care about: [LIST]
- Any known issues that affected them this quarter: [BE HONEST — THEY'LL KNOW]

Usage data for this customer (if available):
- [KEY USAGE METRICS — ACTIVE USERS, FEATURE ADOPTION, WORKFLOW COMPLETIONS]

Please write:
1. **Product Update slide narrative** (what to say for the product section — 3-5 minutes)
2. **"You asked, we built" moment** — if they had feature requests that shipped, make this moment count
3. **Upcoming roadmap highlights** — 3-4 items with brief context on how each benefits them specifically
4. **Product ROI framing** — 2-3 sentences connecting product usage to their business outcomes
5. **Questions to ask them** — 3-4 questions to gather feedback and uncover expansion opportunities

Tone: Partnership-oriented, specific to their context. This should feel like a custom conversation, not a standard product update.
```

---

**Prompt 20: Reorg / Strategy Pivot Communication**

*When to use: Major product strategy shift, team restructuring, or pivot that needs to be communicated clearly to internal stakeholders*

```
Help me craft communication for a significant product strategy change.

The change: [DESCRIBE THE STRATEGIC SHIFT — e.g., "We're deprioritizing our mobile app to focus entirely on enterprise web", "We're consolidating two product teams into one", "We're pivoting our core value prop from X to Y"]

Why this change is happening:
- Business reason: [DATA, MARKET SHIFT, OR STRATEGIC DECISION DRIVING THIS]
- What we learned: [INSIGHT THAT CHANGED OUR THINKING]
- What was considered: [OTHER OPTIONS THAT WERE EVALUATED]

Impact:
- Teams affected: [WHICH TEAMS, HOW]
- Features or projects being deprioritized: [WHAT'S STOPPING]
- New priorities: [WHAT'S STARTING OR ACCELERATING]
- Customer impact: [ANY CUSTOMERS WHO'LL BE AFFECTED]

Anticipated concerns:
- Team concerns: [E.G., "Engineers who worked on the deprioritized area may feel their work was wasted"]
- Customer concerns: [IF APPLICABLE]

Please write:
1. **All-hands talking points** (bullet format — what to say live, including how to handle hard questions)
2. **Written follow-up email** to the team (400-500 words) — honest, empathetic, clear
3. **Customer-facing FAQ** (if customers are impacted) — 5-7 Q&As
4. **Individual manager talking points** — what should team managers say when their reports come to them with questions?
5. **What NOT to say** — 3-4 phrases or framings to avoid (overpromising, minimizing, spinning)

Tone: Honest and direct. People can handle hard truths — they can't handle vague spin. Acknowledge real concerns without feeding anxiety.
```
