# 01 — Quick Start Guide

*How to get maximum value from this toolkit in the first 10 minutes*

---

## The 3-Minute Setup

### Step 1: Pick Your AI Tool
These prompts work with any modern LLM. Recommended:
- **ChatGPT (GPT-4o)** — Best for iterative back-and-forth
- **Claude (Sonnet or Opus)** — Best for long-form documents and nuanced writing
- **Gemini Advanced** — Good for data-heavy analysis prompts

### Step 2: Set a System Prompt (Optional but Powerful)
Paste this at the start of any new conversation to establish context:

```
You are an experienced senior Product Manager at a B2B SaaS startup. You write with clarity, precision, and a bias toward user outcomes over feature lists. You understand engineering constraints, business priorities, and user psychology. When I give you a prompt, produce clean, professional output I can use immediately — no unnecessary preamble or filler.
```

### Step 3: Fill In the Brackets
Every prompt uses `[BRACKET VARIABLES]` in ALL CAPS. Before you paste, find-and-replace every bracket with your real context. The more specific you are, the better the output.

---

## How to Fill In Variables Like a Pro

**Bad:**
```
[PRODUCT] = our app
[USER SEGMENT] = users
```

**Good:**
```
[PRODUCT] = Kona, a B2B HR analytics platform for People teams at 200-2000 person companies
[USER SEGMENT] = HR Directors who manage headcount planning and report to the CFO
```

The difference in output quality is enormous. Don't shortchange yourself.

---

## Power Techniques

### Technique 1: Stacking Prompts
Many workflows involve multiple prompts in sequence. Example:
1. Use **Strategy Prompt #3** to generate your OKR framework
2. Feed the OKRs into **Strategy Prompt #8** to build a roadmap that maps to them
3. Feed the roadmap into **Stakeholder Prompt #2** to write your exec update

### Technique 2: Regenerate with Constraints
If the first output isn't quite right, add a constraint:
- *"Regenerate this, but make it 30% shorter and more direct"*
- *"Redo this assuming engineering capacity is only 40% of what was assumed"*
- *"Write a version of this for an audience that is skeptical of the initiative"*

### Technique 3: Ask for Alternatives
- *"Give me 3 alternative versions of the executive summary — conservative, moderate, and ambitious"*
- *"What are 5 different ways to frame this prioritization decision?"*

### Technique 4: The Pressure Test
After generating a document or strategy, run it through this check:
```
You just wrote the above [PRD / roadmap / stakeholder email]. Now play the role of a skeptical VP of Engineering or CFO. What are the 5 strongest objections they would raise? What's missing? What's weakly argued?
```

### Technique 5: Calibrate for Your Audience
Add audience-specific instructions to any prompt:
- *"My CEO communicates in bullet points and hates fluff. Optimize for that."*
- *"Our board is primarily financial investors, not product people. Translate all product language accordingly."*

---

## Common Mistakes to Avoid

❌ **Pasting generic context** — "We make software for businesses" is useless. Be specific.

❌ **Accepting first output as final** — Always read critically, edit, and iterate.

❌ **Using for decisions, not just documents** — AI is a writing accelerant, not a decision-maker. You still have to think.

❌ **Skipping the system prompt** — It dramatically improves output quality.

❌ **Copy-pasting without reading** — Your name is on the document. Own it.

---

## Recommended Daily Workflow

| Situation | Go-To Prompts |
|-----------|--------------|
| Writing a PRD from scratch | Strategy #1, #2, #4 |
| Prepping for a stakeholder meeting | Stakeholder #1, #5 |
| Sprint planning kickoff | User Story #1, #3, #8 |
| Quarterly planning | Strategy #6, #7, #8 |
| Customer interview prep | Research #1, #2 |
| Handling pushback | Stakeholder #9, #10 |
| Launch week | Stakeholder #13, #14 |
| Board prep | Stakeholder #19, #20 |

---

## File Navigation

- **Strategy & Roadmap** → [02-strategy-roadmap-prompts.md](02-strategy-roadmap-prompts.md)
- **Stakeholder Communication** → [03-stakeholder-communication-prompts.md](03-stakeholder-communication-prompts.md)
- **User Stories** → [04-user-story-prompts.md](04-user-story-prompts.md)
- **Research & Data** → [05-research-data-prompts.md](05-research-data-prompts.md)
- **Full Workflow Playbooks** → [06-workflow-sops.md](06-workflow-sops.md)
- **Quick Reference** → [07-cheat-sheet.md](07-cheat-sheet.md)

---

*Ready? Start with the cheat sheet if you're in a hurry. Start with Strategy prompts if you're doing quarterly planning. Start with Stakeholder prompts if you have a tough meeting tomorrow.*
