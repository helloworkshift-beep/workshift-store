# 🚀 The Product Manager's AI Prompt Toolkit

**80+ battle-tested AI prompts for PMs at tech startups and scale-ups**

---

## What's Inside

This toolkit gives you instant access to high-quality, copy-paste-ready prompts for every part of the PM workflow — from writing PRDs to handling difficult stakeholder conversations, from crafting user stories to synthesizing research data.

Every prompt is:
- **Specific** — Built for real PM work, not generic business writing
- **Structured** — Uses `[BRACKET]` variables so you can customize in seconds
- **Actionable** — Designed to produce output you can actually use

---

## File Guide

| File | Contents | Prompts |
|------|----------|---------|
| [01-quick-start-guide.md](01-quick-start-guide.md) | How to use this toolkit effectively | — |
| [02-strategy-roadmap-prompts.md](02-strategy-roadmap-prompts.md) | PRDs, roadmaps, OKRs, prioritization, feature specs | 25 |
| [03-stakeholder-communication-prompts.md](03-stakeholder-communication-prompts.md) | Exec updates, alignment emails, pushback, launches, board | 20 |
| [04-user-story-prompts.md](04-user-story-prompts.md) | User stories, acceptance criteria, epics, job stories | 20 |
| [05-research-data-prompts.md](05-research-data-prompts.md) | Interview guides, surveys, data analysis, competitive intel | 15 |
| [06-workflow-sops.md](06-workflow-sops.md) | 5 end-to-end PM workflow playbooks | — |
| [07-cheat-sheet.md](07-cheat-sheet.md) | Top 15 power prompts, quick reference | 15 |

**Total: 80+ prompts**

---

## Who This Is For

- **Product Managers** at Series A–D startups and scale-ups
- **Associate PMs** looking to accelerate their output
- **Senior PMs / Group PMs** who need to 10x their documentation speed
- **Founders acting as PM** who need to punch above their weight

---

## How to Use

1. Start with **[01-quick-start-guide.md](01-quick-start-guide.md)** — it'll show you how to get 10x value from these prompts
2. Bookmark **[07-cheat-sheet.md](07-cheat-sheet.md)** — it's your daily driver
3. Deep-dive into specific sections as you need them

---

## The Philosophy

These prompts aren't magic. They're leverage. A great PM still needs sharp thinking, product sense, and customer empathy. What these prompts do is eliminate the blank-page problem and compress the time from "thinking" to "done."

Use them as a starting point. Edit ruthlessly. Make the output yours.

---

*Built for PMs who ship.*
