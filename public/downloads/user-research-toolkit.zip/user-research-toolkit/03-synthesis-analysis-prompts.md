# 03 · Synthesis & Analysis Prompts

**20 prompts for affinity mapping, insight extraction, pattern identification, research reports, executive summaries, and journey maps.**

---

## Affinity Mapping & Pattern Finding

---

### Prompt 1: Raw Notes to Affinity Clusters

**Transform messy research notes into organized affinity clusters**

*When to use: You have a mountain of raw notes from interviews or usability sessions and need to start making sense of them. Feed in your raw observations one batch at a time.*

```
You are a senior UX researcher performing affinity mapping on raw research observations.

Research Context:
Study Topic: [WHAT YOU WERE RESEARCHING]
Number of Sessions: [N]
Research Method: [INTERVIEWS / USABILITY TESTS / DIARY STUDY]

Below are raw observations from [NUMBER] research sessions. Each observation is a single note on a separate line.

Your task:
1. Group the observations into thematic clusters (affinity groups)
2. Name each cluster with a short, descriptive label (phrase, not a single word)
3. Identify the 2–3 most significant observations within each cluster
4. Flag any observations that appear in multiple clusters (cross-cutting themes)
5. Identify any outlier observations that don't fit cleanly but are worth noting
6. After clustering, propose a hierarchy: which clusters seem to be sub-themes of a larger theme?

Format your output as:
**CLUSTER NAME**
- Supporting observation 1
- Supporting observation 2
- [Key observation ⭐]
(And so on for each cluster)

Then: A brief summary paragraph of what patterns seem most significant across all clusters.

Raw observations:
[PASTE YOUR RAW NOTES HERE — one observation per line, as specific as possible]
```

---

### Prompt 2: Insight Ladder Builder

**Elevate observations into insights and then into design implications**

*When to use: After affinity mapping. You have clusters of observations but need to move from "what happened" to "what it means" to "what we should do about it."*

```
You are a UX researcher skilled in transforming observations into actionable insights.

For each of the following observations from user research, help me build an insight ladder:

Level 1: Observation (what we saw/heard — factual, evidence-based)
Level 2: Insight (what this tells us about the user's need, motivation, or mental model)
Level 3: Design Implication (what this means for the product — a starting point for ideation, not a solution)

Research Context:
Product: [PRODUCT NAME]
User Segment: [WHO THESE OBSERVATIONS ARE ABOUT]

Here are my observations:
[PASTE YOUR OBSERVATIONS — aim for 5–15 observations for a useful output]

For each observation:
1. Validate whether it's truly an observation (factual) or already an interpretation
2. Write the corresponding insight (start with: "This suggests users...")
3. Write 1–2 design implications (start with: "We should consider..." or "This challenges our assumption that...")

After all observations:
- Identify the 3 most significant insights across the full set
- Note any tensions or contradictions between insights that need further exploration
- Flag any insights that overturn a common assumption
```

---

### Prompt 3: Insight Extraction Engine

**Extract key insights from a large body of qualitative data**

*When to use: You have a transcript, set of notes, or synthesized data dump and need to surface the most meaningful insights quickly. Works with interview transcripts, survey open-ends, or session notes.*

```
You are an expert qualitative researcher. I'm going to give you a body of text from user research. Your job is to extract the most meaningful insights — not surface-level observations, but genuine revelations about user behavior, motivation, mental models, or unmet needs.

Research Context:
Product: [PRODUCT NAME AND BRIEF DESCRIPTION]
User Segment: [WHO THE RESEARCH IS WITH]
Research Goal: [THE CORE QUESTION THIS RESEARCH WAS TRYING TO ANSWER]

Rules for insights:
- An insight explains WHY, not just WHAT
- An insight should be non-obvious (not something you assumed going in)
- An insight should have strategic or design implications
- An insight must be evidence-based (tied to specific data)

From the text below, extract:
1. The top 5–8 insights, in order of significance
2. For each insight:
   - A one-sentence insight statement (bold)
   - Supporting evidence (2–3 specific quotes or observations)
   - The implication for product/design/strategy
   - Confidence level: [HIGH / MEDIUM / LOW] with brief justification

3. Identify any patterns that appeared consistently across participants
4. Flag any contradictions or anomalies in the data
5. Note what this data cannot tell us (limitations)

[PASTE RESEARCH TEXT HERE — transcripts, notes, or synthesized observations]
```

---

### Prompt 4: Quantitative Survey Open-End Coder

**Code and categorize open-ended survey responses at scale**

*When to use: You have 50–500+ open-ended survey responses and need to identify themes, frequencies, and representative quotes.*

```
You are a mixed-methods researcher performing qualitative coding on open-ended survey responses.

Survey Context:
Survey Question: "[EXACT SURVEY QUESTION TEXT]"
Sample Size: [NUMBER] responses
Product/Service: [CONTEXT]
Why This Question Was Asked: [RESEARCH GOAL]

I'll provide you with the responses in batches. For this batch:

Step 1: Read all responses and identify the main themes
Step 2: Create a coding scheme (theme names + descriptions)
Step 3: Assign each response to 1–2 themes (primary + secondary if applicable)
Step 4: Count frequency of each theme
Step 5: Select the 2–3 most representative quotes for each theme

Output format:

**THEME NAME** (n=[FREQUENCY], [%] of responses)
Description: [Brief definition of what belongs in this theme]
Representative quotes:
- "[Quote]" 
- "[Quote]"

After all themes:
- Overall summary paragraph (3–4 sentences)
- The single most important thing this data tells you
- Follow-up questions this data raises

Responses to code:
[PASTE RESPONSES — numbered, one per line]
```

---

### Prompt 5: Pattern Spotter Across Sessions

**Identify patterns across multiple research sessions**

*When to use: After completing a series of research sessions, you want to identify what themes, behaviors, and pain points appeared frequently, rarely, or surprisingly.*

```
You are a senior UX researcher conducting cross-session pattern analysis.

I have notes/summaries from [NUMBER] user research sessions. I need to identify:
1. Consistent patterns (appeared in [N]+ sessions)
2. Notable exceptions (appeared in only 1–2 sessions but are significant)
3. Contradictions (different participants showed opposing behaviors or needs)
4. Surprising patterns (things that challenge our assumptions)

For context:
Research Goal: [THE MAIN RESEARCH QUESTION]
Product: [PRODUCT NAME]
User Segments Represented: [LIST SEGMENTS]

For each pattern identified, tell me:
- Pattern name (short, descriptive)
- How many sessions it appeared in
- Representative example
- Why it matters (so what?)
- Confidence level (strong evidence / moderate evidence / weak signal worth watching)

Also:
- Identify any segment-specific patterns (things only certain user types do or say)
- Note patterns that seem related or reinforce each other
- Highlight the 3 most actionable patterns for the product team

Session notes:
[PASTE YOUR SESSION SUMMARIES OR NOTES — label each with a participant ID]
```

---

### Prompt 6: Competing Hypotheses Evaluator

**Test your research hypotheses against the evidence**

*When to use: After synthesis, when you want to rigorously evaluate which hypotheses your data supports, contradicts, or leaves undetermined.*

```
You are a rigorous UX researcher applying evidence-based reasoning to evaluate research hypotheses.

Before this research, we held the following hypotheses:
1. [HYPOTHESIS 1]
2. [HYPOTHESIS 2]
3. [HYPOTHESIS 3]
4. [HYPOTHESIS 4]

For each hypothesis, evaluate it against the research evidence using this framework:
- Supported: Strong, consistent evidence confirms this
- Partially Supported: Some evidence supports it, but with caveats
- Unsupported: Evidence contradicts this hypothesis
- Undetermined: The data doesn't address this one way or the other

For each hypothesis, provide:
1. Verdict (Supported / Partially Supported / Unsupported / Undetermined)
2. Evidence for (specific quotes, observations, or patterns)
3. Evidence against (contradicting data points)
4. Confidence level (1–10)
5. What additional research would be needed to resolve uncertainty

Also:
- Identify any findings that weren't captured in our hypotheses (unexpected discoveries)
- Rank the hypotheses by how much confidence our data gives us

Research evidence summary:
[PASTE YOUR RESEARCH FINDINGS / NOTES / SYNTHESIZED DATA]
```

---

## Research Reports & Summaries

---

### Prompt 7: Full Research Report Generator

**Draft a complete research report from synthesized findings**

*When to use: After synthesis is complete, you need to write the formal research report that will be shared with the broader product and design team.*

```
You are a senior UX researcher writing a comprehensive research report.

Study Information:
Study Name: [STUDY NAME]
Date: [DATE RANGE]
Researcher(s): [NAME(S)]
Study Type: [METHOD]
Participants: [N PARTICIPANTS — brief profile]
Research Goal: [CORE QUESTION]
Key Findings: [LIST 5–7 MAIN FINDINGS AS BULLET POINTS]

Write a full research report with the following sections:

1. **Executive Summary** (150–200 words)
   - Research goal, method, and participants
   - 3–4 key findings
   - Top recommendations
   
2. **Background & Research Goal** (100–150 words)
   - Business context — why this research was conducted
   - Research questions
   
3. **Methodology** (150–200 words)
   - Method rationale
   - Participant profile and sample size
   - How sessions were conducted
   - Limitations of the approach
   
4. **Findings** (main body — one section per major finding)
   For each finding:
   - Finding statement in bold (one sentence)
   - Supporting evidence (data, quotes, observations)
   - What this means for the product
   
5. **Recommendations** (prioritized)
   - Organize as: Must do / Should do / Consider doing
   - Each recommendation tied to a specific finding
   
6. **Next Steps**
   - Immediate actions
   - Research questions that remain open
   - Suggested follow-on studies

Tone: Clear and professional. Written for product designers, PMs, and engineers — not academic audience.
Use headers, bullet points. Avoid unnecessary jargon.
```

---

### Prompt 8: Executive Summary Generator

**Distill complex research findings into a crisp executive summary**

*When to use: Your full report is done but you need a standalone executive summary for leadership who won't read the full document.*

```
You are a UX researcher translating research findings for a C-suite or VP-level audience.

Research Summary to Work From:
[PASTE YOUR KEY FINDINGS, RECOMMENDATIONS, OR FULL REPORT]

Business Context:
Decision This Research Informs: [WHAT WILL BE DECIDED BASED ON THIS RESEARCH]
Primary Audience: [CEO / VPP / HEAD OF PRODUCT / BOARD / OTHER]
Their Key Concerns: [WHAT DO THEY CARE MOST ABOUT — e.g., growth, retention, NPS, cost, risk]

Write an executive summary (200–250 words) that:
1. Opens with the business implication — not the research process
2. States the most important finding in the first sentence
3. Uses a "What we learned → What it means for us" structure
4. Quantifies impact wherever possible (even estimates with caveats)
5. Ends with a clear, specific call to action (what decision should be made now)

Rules:
- No research methodology detail unless it affects how to trust the data
- No jargon (no "affordances," "mental models," "JTBD" without explanation)
- Every sentence earns its place
- An exec should be able to act on this without reading another word

Also write:
- A 3-bullet "TL;DR" version for Slack or email
- A one-paragraph version for a meeting agenda or Notion page header
```

---

### Prompt 9: Research Findings Prioritization Framework

**Rank and prioritize research findings for action**

*When to use: You have more findings than the team can act on. Need a framework to prioritize what gets addressed first.*

```
You are a UX researcher helping a product team triage and prioritize research findings.

We have [NUMBER] findings from a recent research study on [PRODUCT/FEATURE]. The team has limited capacity and needs to focus on the highest-impact items first.

Here are our findings:
[LIST YOUR FINDINGS — one per line, or paste summaries]

Evaluate each finding across these dimensions:
1. **User Impact**: How significantly does this affect the user experience? (1–5)
2. **Frequency**: How many users encounter this? (1–5)
3. **Business Impact**: Does this affect retention, conversion, support costs, or trust? (1–5)
4. **Addressability**: How feasible is it to fix with current resources? (1–5)
5. **Urgency**: Is there a time-sensitive reason to act? (1–5, with flag if urgent)

For each finding:
- Score it across all 5 dimensions
- Calculate a weighted priority score
- Assign a priority tier: P1 (act now) / P2 (next sprint) / P3 (backlog) / P4 (monitor)

Output as:
1. Prioritized findings table
2. Written rationale for the top 5 findings
3. A note on any P3/P4 findings that could become P1 if left unaddressed
4. 2–3 quick wins (high addressability + meaningful impact)
```

---

### Prompt 10: Research Repository Entry Template

**Standardized format for storing research insights in a repository**

*When to use: Adding research findings to a shared repository (Dovetail, Notion, Airtable, Confluence). Standardized format ensures findability and reuse.*

```
You are a research operations specialist creating standardized insight entries for a research repository.

Repository Platform: [DOVETAIL / NOTION / AIRTABLE / CONFLUENCE / OTHER]
Insight Type: [BEHAVIORAL / ATTITUDINAL / PAIN POINT / UNMET NEED / MENTAL MODEL / MOTIVATOR]
Research Context:
- Source study: [STUDY NAME]
- Date: [DATE]
- Method: [METHOD]
- Participants: [SEGMENT — n=X]

For each of the following raw observations, write a formatted repository entry:

Repository entry format:
- **Insight title**: (6–10 words, searchable)
- **Insight statement**: (1–2 sentences — what users do/think/feel and why it matters)
- **Evidence**: (2–3 supporting quotes or observations with participant IDs)
- **Tags**: (product area, user segment, research method, theme)
- **Related insights**: (IDs of related entries, if any)
- **Design implications**: (what this means for the product)
- **Confidence**: (Strong — 3+ participants / Moderate — 2 participants / Weak — 1 participant)
- **Status**: (New / Validated / Contradicted / Outdated)
- **Last reviewed**: [DATE]

Raw observations to format:
[PASTE OBSERVATIONS HERE]
```

---

## Journey Maps & Mental Models

---

### Prompt 11: Customer Journey Map Builder

**Create a detailed customer journey map from research data**

*When to use: After qualitative research (interviews, diary studies, or contextual inquiry), you have enough data to map a user's experience across a key scenario.*

```
You are a senior UX researcher constructing a customer journey map from research data.

Journey Context:
User Persona/Segment: [WHO THIS JOURNEY BELONGS TO]
Journey Scenario: [THE SPECIFIC EXPERIENCE BEING MAPPED — e.g., "First-time user onboarding" or "A parent planning a family vacation"]
Journey Scope: From [STARTING TRIGGER] to [END STATE/GOAL]
Product/Service: [WHAT PRODUCT IS INVOLVED, IF ANY]

Based on the following research data, construct a journey map with these layers:

**Stage names** (5–7 stages across the journey)

For each stage:
1. **What the user is doing** (actions and behaviors)
2. **What the user is thinking** (internal narrative, goals, questions)
3. **What the user is feeling** (emotional state — high/low points)
4. **Pain points** (specific friction or failure moments)
5. **Opportunities** (design or communication interventions that could help)
6. **Touchpoints** (channels, tools, people involved)

After the map:
- Identify the 3 highest emotional low points ("moment of most pain")
- Identify the 3 highest emotional high points ("moment of delight")
- Name the single biggest opportunity for intervention
- Flag assumptions in the map that need more research to validate

Research data:
[PASTE INTERVIEW EXCERPTS, NOTES, OR OBSERVATIONS]
```

---

### Prompt 12: Mental Model Map

**Document how users think about a domain, problem, or product**

*When to use: After discovery research when you want to understand how users mentally frame a domain — especially for complex products where mismatched mental models cause usability issues.*

```
You are a cognitive UX researcher constructing a mental model from qualitative interview data.

Domain: [THE SUBJECT AREA — e.g., "managing personal finances" or "understanding health insurance"]
Target User: [USER SEGMENT]
Key Interview Question Addressed: [THE CORE QUESTION THAT SURFACED THE MENTAL MODEL DATA]

From the research data below, construct a mental model analysis:

1. **Core concepts in the user's mental model** 
   - What categories or concepts do users naturally organize this domain into?
   - What labels/language do they use?

2. **Mental model map** (text-based representation)
   - How do users believe these concepts relate to each other?
   - What causal relationships do they assume?

3. **Gaps and misconceptions**
   - Where does the user's mental model diverge from reality or from how the product actually works?
   - What do users believe that isn't true?

4. **Shared vs. individual mental models**
   - Which elements were consistent across participants?
   - Where were there significant individual differences?

5. **Design implications**
   - How should the product's language, navigation, or IA match the user's mental model?
   - Where should we educate users vs. redesign to match their expectations?

Research data:
[PASTE RELEVANT INTERVIEW EXCERPTS]
```

---

### Prompt 13: Experience Principle Extractor

**Derive design-guiding principles from research**

*When to use: Synthesizing research into design principles that will guide a project or product vision. Turns insights into directional guidance for designers.*

```
You are a UX strategist extracting experience principles from user research data.

Product: [PRODUCT NAME]
User Segment: [WHO THE RESEARCH WAS WITH]
Research Methods Used: [METHODS]
Core Research Question Answered: [THE MAIN THING YOU LEARNED]

From the research findings below, extract 5–7 experience principles that should guide the design of [PRODUCT NAME].

For each experience principle:
1. **Principle title** (short, memorable phrase — max 5 words)
2. **Rationale** (which research findings drove this principle)
3. **What it means in practice** (3 concrete examples of how this principle shows up in design decisions)
4. **What it means we should stop doing** (the implicit anti-pattern this principle warns against)
5. **How we'll know we got it right** (what user behavior or feedback validates this principle)

Rules for good principles:
- Directional, not prescriptive (they guide decisions, don't make them)
- Based on evidence, not opinions
- Specific enough to be useful, general enough to apply across multiple design decisions
- Written to resonate with designers and PMs, not just researchers

Research findings:
[PASTE YOUR KEY FINDINGS]
```

---

### Prompt 14: Empathy Map Builder

**Create a structured empathy map from interview data**

*When to use: Building alignment across a team about who users are and what they experience. Especially useful before ideation sessions.*

```
You are a UX researcher creating an empathy map to align a product team around user understanding.

Persona/Segment: [USER SEGMENT OR PROTO-PERSONA NAME]
Scenario: [SPECIFIC CONTEXT — e.g., "when evaluating a new software tool for their team"]
Research Basis: [BRIEF DESCRIPTION OF THE RESEARCH USED]

Using the research excerpts below, fill in a detailed empathy map across these six dimensions:

**THINKS** (What's going through their mind? Internal dialogue, beliefs, concerns)
- Include: Conscious thoughts + background worries

**FEELS** (What are their emotional states? Visible and hidden)
- Include: Frustrations, fears, excitement, pride, anxiety

**SAYS** (What do they actually say out loud? Quotes and phrases they use)
- Direct quotes from research preferred

**DOES** (Observable behaviors and actions)
- Specific, observable — not interpretations

**PAINS** (Fears, frustrations, obstacles)
- What keeps them up at night related to this context?

**GAINS** (Goals, wishes, measures of success)
- What does "winning" look like for them?

After the empathy map:
- Write a 100-word persona summary that a designer could read in 60 seconds
- Identify the single most important tension between what this person "thinks" and what they "do"
- Name 3 design principles this empathy map suggests

Research data:
[PASTE INTERVIEW EXCERPTS OR OBSERVATION NOTES]
```

---

### Prompt 15: Job Story Generator from Research

**Convert research findings into job stories for design direction**

*When to use: Translating user needs discovered in research into job story format (When... I want to... So I can...) to brief designers.*

```
You are a UX researcher translating research findings into job stories for a design team.

Research Context:
Product: [PRODUCT NAME]
User Segment: [WHO THESE ARE FOR]
Research Findings to Work From: [PASTE OR DESCRIBE YOUR FINDINGS]

Convert each relevant finding into a job story using the format:
"When [SITUATION/TRIGGER], I want to [MOTIVATION/ACTION], so I can [EXPECTED OUTCOME]."

Rules for good job stories:
- "When" describes the specific context and trigger (not a persona trait)
- "I want to" describes a specific action or capability they need
- "So I can" describes the underlying goal or progress they're trying to make
- Stories should be at the right altitude — not too specific (a single UI action) or too broad (change my life)
- Avoid naming solutions in the "I want to" section

For each job story:
1. Write the job story
2. Name the research finding it came from
3. Rate the job story: Core (must solve) / Peripheral (nice to solve) / Aspirational (future vision)
4. Flag if multiple participants expressed this or if it's from a single source

Target: [NUMBER] job stories

After all stories:
- Identify job stories that cluster around the same underlying user goal
- Flag any tensions between job stories (where two needs pull in opposite directions)
```

---

### Prompt 16: Research Highlight Reel Script

**Plan and script a video highlight reel from research sessions**

*When to use: You have recorded research sessions and need to create a compelling video highlight reel to share insights with stakeholders who won't read a report.*

```
You are a UX researcher creating a script and plan for a research highlight reel video.

Video Context:
Audience: [WHO WILL WATCH THIS — e.g., leadership team, engineering team, full company]
Length Target: [3–5 MINUTES / 5–8 MINUTES]
Key Message: [THE SINGLE MOST IMPORTANT THING THIS VIDEO SHOULD COMMUNICATE]
Research Sessions Available: [NUMBER] recorded sessions
Platform to Share On: [SLACK / NOTION / EMAIL / PRESENTATION]

Create a highlight reel script that includes:

1. **Opening hook** (15–20 seconds)
   - A single striking quote or moment that immediately makes the audience lean in
   - Voiceover text to introduce the research context

2. **Theme sections** (3–4 themes, 45–90 seconds each)
   - Theme title and transition voiceover
   - 2–3 clip placeholders with descriptions of what type of clip to use (e.g., "Clip: Participant expressing frustration with checkout flow, ~15 sec")
   - Quote overlay text for key moments

3. **The pivot moment** (30 seconds)
   - The "so what" — what does this mean for our product?

4. **Closing call to action** (20–30 seconds)
   - What you want the audience to do after watching

Also provide:
- Clip selection criteria (what makes a good clip for each theme)
- B-roll suggestions (screen recordings, UI flows to show alongside user clips)
- Accessibility notes (captioning, audio description needs)
```

---

### Prompt 17: Quantitative + Qualitative Integration

**Blend qual and quant data into a coherent mixed-methods narrative**

*When to use: You have both survey/analytics data AND qualitative interview data and need to integrate them into a coherent story.*

```
You are a mixed-methods UX researcher integrating quantitative and qualitative data.

Quantitative Data Available:
[DESCRIBE OR PASTE KEY STATS — e.g., "28% task completion rate on step 3 of checkout," "NPS = 32," "average session length dropped 40% after last redesign"]

Qualitative Data Available:
[DESCRIBE OR PASTE KEY THEMES/QUOTES — from interviews, usability tests, open-ends]

Research Question: [WHAT YOU'RE TRYING TO UNDERSTAND]

Integrate the data using this framework:

1. **Quantitative findings** (the WHAT — what is happening at scale)
   - Present key metrics with brief context
   - Flag anomalies or surprising numbers

2. **Qualitative explanations** (the WHY — what the quant data means)
   - For each major metric, identify the qualitative evidence that explains it
   - Use format: "The data shows X. Our research suggests this is because Y [quote/evidence]."

3. **Where data sources converge** (high confidence findings)
   - Where qual and quant point to the same conclusion

4. **Where data sources diverge** (interesting tensions)
   - Where what people say differs from what the data shows
   - Why this matters and what it suggests

5. **Integrated narrative** (2–3 paragraphs)
   - Tell the complete story using both data sources
   - Suitable for a presentation slide or report introduction

6. **Recommendations** derived from the integrated view (what neither source could tell you alone)
```

---

### Prompt 18: Research-to-Roadmap Translation

**Map research findings to product roadmap decisions**

*When to use: Product planning season. You need to translate research insights into concrete roadmap inputs that a PM can act on.*

```
You are a UX researcher bridging research insights and product roadmap planning.

Product: [PRODUCT NAME]
Roadmap Planning Horizon: [NEXT QUARTER / NEXT 6 MONTHS / NEXT YEAR]
Key Research Findings (paste or list):
[YOUR FINDINGS]

Existing Roadmap Items (if any):
[LIST WHAT'S ALREADY PLANNED]

Translate the research findings into roadmap inputs using this structure:

For each key finding:
1. **Finding**: (one-sentence summary)
2. **User Need**: (what this tells us users need)
3. **Roadmap Implication**: (should we build/fix/remove/test something?)
4. **Priority Signal**: (is this blocking users? Causing churn? A delight opportunity?)
5. **Suggested Work Item**: (concrete description of what to add to the backlog)
6. **Success Metric**: (how will we know if we've addressed this finding?)

Then produce:
- A "Now / Next / Later" categorization of all suggested work items
- Any findings that contradict current roadmap plans (flag as risks)
- Research gaps that need to be filled before roadmap decisions can be made
- A one-paragraph research-to-roadmap recommendation memo suitable for a PM

Format clearly for a product planning meeting.
```

---

### Prompt 19: Cross-Study Synthesis

**Synthesize insights across multiple research studies**

*When to use: You have multiple research studies over time on related topics and need to synthesize across them to identify durable insights vs. temporary signals.*

```
You are a research strategist synthesizing insights across multiple research studies.

Studies to Synthesize:
Study 1: [NAME, DATE, METHOD, PARTICIPANTS, MAIN FINDINGS — 2–3 bullets]
Study 2: [NAME, DATE, METHOD, PARTICIPANTS, MAIN FINDINGS — 2–3 bullets]
Study 3: [NAME, DATE, METHOD, PARTICIPANTS, MAIN FINDINGS — 2–3 bullets]
[Add more as needed]

Synthesize across these studies to identify:

1. **Durable insights** (appeared in 2+ studies, likely stable truths about this user)
2. **Evolving insights** (finding changed between studies — what does the change signal?)
3. **Contradictions across studies** (different studies found opposing things — analyze why)
4. **White space** (important questions that no study has adequately addressed)
5. **Outdated findings** (older insights that newer research has superseded)

Output structure:
- Cross-study insight map (organized by theme, not by study)
- A confidence rating for each consolidated insight (evidence across how many studies?)
- A recommended "research canon" — the 5–7 most reliable, well-supported insights about this user/domain
- A research agenda: the 3 most important gaps to fill next

Format for a research repository or a research team review meeting.
```

---

### Prompt 20: Research Insight to Hypothesis Pipeline

**Convert research insights into testable product hypotheses**

*When to use: After synthesis, when you want to move insights into the product design cycle by framing them as testable hypotheses for further validation.*

```
You are a UX researcher creating a pipeline from research insights to testable product hypotheses.

Insights from Recent Research:
[LIST YOUR INSIGHTS — ideally 5–10]

For each insight, generate:

**Insight → Belief → Hypothesis → Test**

- **Insight**: (What the research revealed)
- **Belief it challenges or confirms**: (What the team currently believes about this)
- **Product hypothesis**: "We believe that [BUILDING/CHANGING X] for [USER] will result in [OUTCOME], because [RESEARCH-BACKED REASON]."
- **How to test**: (Quickest, most resource-efficient way to validate — A/B test, prototype test, analytics pull, follow-up interviews, etc.)
- **What we'll measure**: (The specific metric or observable behavior that confirms/refutes the hypothesis)
- **Time to test**: (Estimate: days / weeks / months)
- **Risk if untested**: (What's the cost of acting on this insight without validating?)

After all hypotheses:
- Rank by: highest impact × easiest to test
- Flag any hypotheses that can be tested without building anything
- Identify hypotheses that should be validated before significant engineering investment
```

---

*20 prompts complete. Continue to `04-survey-usability-prompts.md` →*
