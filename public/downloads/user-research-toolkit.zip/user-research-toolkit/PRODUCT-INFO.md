# PRODUCT-INFO.md — The UX Researcher's AI Prompt Toolkit

---

## Product Details

**Product Name:** The UX Researcher's AI Prompt Toolkit
**Price:** $57
**Purchase Link:** [https://buy.stripe.com/3cI14pgM10SZ2Vr8MwgEg04](https://buy.stripe.com/3cI14pgM10SZ2Vr8MwgEg04)

---

## Sales Description (200 words)

You already know how to do great research. Now imagine having an expert collaborator available at every stage — one that helps you write a tighter discussion guide in 20 minutes instead of two hours, turns a messy transcript into crisp insight statements before your next meeting, and helps you write the kind of executive summary that actually gets people to act.

That's what this toolkit does.

**The UX Researcher's AI Prompt Toolkit** is a library of 80+ battle-tested AI prompts covering the entire research lifecycle — from writing screeners and discussion guides, to synthesising qualitative data, running usability tests, building recommendation decks, and presenting findings to leadership.

Each prompt is ready to use: copy, fill in the brackets, and get a professional-quality first draft in seconds. No prompt engineering required. No starting from blank pages. No more staring at a cursor wondering how to turn 12 transcripts into three clear insights.

Whether you're a solo researcher wearing six hats, a research lead managing a team, or a designer running scrappy guerrilla tests — this toolkit compresses hours of writing and synthesis work into minutes, so you can spend your time on what only you can do: thinking, questioning, and understanding people.

**80+ prompts. 5 workflow SOPs. One cheat sheet. Built for researchers, by a researcher.**

---

## 5 Headlines

1. **Stop Staring at Blank Pages. Run Better Research, Faster.**
   80+ AI prompts that handle the writing and synthesis so you can focus on the thinking.

2. **The AI Toolkit Built for UX Researchers Who Have No Time.**
   From discussion guide to executive summary — every stage of your research workflow, covered.

3. **Turn 12 Transcripts Into Sharp Insights Before Your Next Stand-Up.**
   Proven prompts that do the heavy lifting on analysis, synthesis, and stakeholder communication.

4. **Write Research Deliverables That People Actually Read.**
   AI-powered one-pagers, executive summaries, recommendation decks, and persona write-ups — in minutes, not days.

5. **The Research Toolkit That Makes You Sound Like a Senior Researcher on Every Project.**
   80+ expert-level prompts, 5 complete workflow SOPs, and a cheat sheet for your most common research challenges.

---

## Target Audience

**Primary:**
- Mid-level UX researchers (2–5 years experience) looking to work more efficiently and produce more polished deliverables
- Solo researchers or small research teams who need to move fast without sacrificing quality
- UX designers, product managers, and customer success professionals who run research as part of a broader role

**Secondary:**
- Senior researchers and research leads who want to speed up team onboarding and standardise output quality
- Research operations professionals building team resources and templates
- Freelance UX researchers who bill by the project and need to maximise time efficiency

**The person this was built for:**
A UX researcher who is skilled at research but spends too much time writing — discussion guides, screeners, synthesis documents, reports, presentations. They're confident in their methods but frustrated by how long the surrounding admin and communication work takes. They're curious about AI but haven't found a resource that's genuinely useful for their specific discipline — until now.

---

## What's Included — Full File List

| File | Contents | Prompt Count |
|---|---|---|
| `01-planning-prompts.md` | Research question sharpening, study design, scoping, stakeholder alignment | ~10 prompts |
| `02-interview-prompts.md` | Discussion guides, screeners, participant comms, warm-up questions | ~15 prompts |
| `03-analysis-prompts.md` | Transcript analysis, affinity clustering, insight statements, recommendations | ~15 prompts |
| `04-survey-usability-prompts.md` | Survey design, usability test scripts, SUS analysis, first-click, card sorting, tree testing, accessibility | 20 prompts |
| `05-stakeholder-communication-prompts.md` | Presentation narratives, one-pagers, personas, recommendation decks, ROI arguments, executive updates | 15 prompts |
| `06-workflow-sops.md` | 5 complete end-to-end workflow SOPs with step-by-step instructions and prompt references | 5 SOPs |
| `07-cheat-sheet.md` | Top 15 prompts in full + 10 Golden Rules of Prompting for UX Researchers + quick reference table | — |
| `README.md` | How to use the toolkit, file map, getting started guide | — |

**Total:** 80+ prompts across 7 content files

---

## Key Features & Benefits

- **Ready-to-use prompts** — fill in the [BRACKETS], copy, and paste. No prompt engineering knowledge required.
- **Full research lifecycle coverage** — planning through to stakeholder communication
- **Method-specific** — separate prompts for interviews, surveys, usability tests, card sorts, tree tests, and accessibility research
- **Stakeholder communication focus** — dedicated file on presenting and communicating research findings
- **Workflow SOPs** — step-by-step playbooks that tell you exactly which prompt to use at each stage
- **Cheat sheet** — the 15 most-used prompts in one place for quick daily access
- **Bias-aware** — prompts are designed to preserve research rigour and flag AI limitations
- **Evergreen** — works with any AI assistant (ChatGPT, Claude, Gemini, Copilot)

---

## Pricing Rationale

At $57, this toolkit costs less than one hour of a mid-level researcher's time. If it saves you even three hours of writing and synthesis work — a conservative estimate for a single study — the ROI is immediate. For researchers running multiple studies per quarter, the time savings compound significantly.

No subscription. No renewal. Buy once, use forever.

---

## Frequently Asked Questions (for sales page)

**Which AI tools does this work with?**
All of them. The prompts are tool-agnostic and work with ChatGPT, Claude, Google Gemini, Microsoft Copilot, and any other AI assistant. If it accepts text input, these prompts work.

**Do I need to be technical or know prompt engineering?**
No. Every prompt is written in plain English. You fill in the [BRACKETED] fields with your specific context and paste. That's it.

**Is this for researchers only?**
The prompts are written for UX researchers, but they're equally useful for product designers, product managers, and anyone else who conducts user research as part of their role.

**Will this replace my research skills?**
No, and it's not designed to. AI is a drafting and synthesis accelerator — not a replacement for research judgment. The best outputs come from researchers who know their data and use AI to help communicate and structure it.

**Does it include templates for slides or reports?**
The toolkit provides the narrative content, structure, and language for your deliverables. You apply it to your preferred slide tool (Figma, Keynote, Google Slides, PowerPoint) or document tool (Notion, Confluence, Google Docs).

**What if I'm unhappy with it?**
If the toolkit doesn't deliver value within 30 days, reach out for a full refund. No questions asked.

---

*Last updated: 2026*
