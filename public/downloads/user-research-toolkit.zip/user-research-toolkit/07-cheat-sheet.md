# 07 — The UX Researcher's AI Cheat Sheet

> Your quick-access reference. The 15 most powerful prompts in the toolkit + 10 golden rules for prompting like a pro.

---

## Top 15 Most Powerful Prompts

These are the prompts researchers reach for most. They're reproduced here in full so you can copy-paste immediately without hunting through the other files.

---

### #1 — The Discussion Guide Builder
*The prompt you'll use before almost every qual study.*

```
You are an expert UX researcher. I need a complete discussion guide for a [NUMBER]-minute semi-structured user interview.

Research topic: [WHAT YOU'RE EXPLORING]
Target participant: [DESCRIBE WHO YOU'RE TALKING TO]
Primary research questions I need to answer:
1. [RESEARCH QUESTION 1]
2. [RESEARCH QUESTION 2]
3. [RESEARCH QUESTION 3]

Please create a complete discussion guide with:
1. Introduction script (welcome, consent reminder, recording notice, think-aloud explanation) — 3 minutes
2. Warm-up questions (3–4 questions about context and habits, not the topic yet) — 5 minutes
3. Core exploration questions organised by theme — allocate [X] minutes per theme:
   - Theme 1: [THEME NAME]
   - Theme 2: [THEME NAME]
   - Theme 3: [THEME NAME]
4. For each core question: the main question + 2–3 follow-up probes
5. Closing questions (reflections, anything I missed, recommendations) — 5 minutes
6. Closing script (thank you, next steps, incentive reminder) — 2 minutes

Write in a natural, conversational tone the interviewer can read verbatim or use as a guide. Flag any questions that might be leading or closed.
```

---

### #2 — The Transcript Insight Extractor
*Paste a raw transcript. Get structured insights in minutes.*

```
You are an expert qualitative UX researcher. Analyse the following interview transcript and extract structured insights.

Context: This was a [NUMBER]-minute interview with [BRIEF PARTICIPANT DESCRIPTION] about [TOPIC].
Research questions we were exploring: [LIST YOUR RESEARCH QUESTIONS]

Transcript:
[PASTE FULL TRANSCRIPT HERE]

Please provide:
1. **Key themes** — list all themes you identify (3–7), with a descriptive label per theme
2. **Supporting evidence** — for each theme, 2–3 direct quotes (with rough timestamp or paragraph reference)
3. **Participant's mental model** — how does this person conceptualise [TOPIC]? Describe it in 2–4 sentences
4. **Pain points** — specific frustrations mentioned, direct or implied
5. **Unmet needs** — what is this person trying to do that isn't being served?
6. **Moments of delight or positive surprise** — anything they reacted positively to
7. **Contradictions or tensions** — places where what they said and what they did (or said earlier) don't match
8. **Standout quote** — the single quote that best represents this participant's experience

Format each section clearly. Preserve exact quote wording — do not paraphrase.
```

---

### #3 — The Affinity Clustering Engine
*Turn raw sticky notes into clear research themes.*

```
You are a UX researcher facilitating an affinity clustering exercise. I have raw observations from [NUMBER] user research sessions. Help me cluster them into meaningful themes.

Research topic: [TOPIC]
Number of sessions: [N]

Raw observations (one per line or bullet):
[PASTE ALL YOUR RAW OBSERVATIONS — quotes, paraphrased notes, behaviours — as a single list]

Please:
1. **Group these observations** into 4–8 thematic clusters
2. **Name each cluster** with a descriptive, insight-oriented label (not just a topic — e.g. "Trust breaks down at the payment step" not just "Payment")
3. **List the observations** that belong to each cluster
4. **Count frequency** — how many participants/observations support each cluster
5. **Write a 2–3 sentence insight statement** for each cluster that goes beyond describing what happened to explaining why it matters
6. **Identify outliers** — observations that don't fit any cluster but might be important signals

Note any observations that could reasonably belong to more than one cluster and explain the ambiguity.
```

---

### #4 — The Insight Statement Generator
*From messy observations to crisp, evidence-backed insight statements.*

```
Transform the following raw research observations into polished insight statements suitable for a stakeholder presentation.

Research context: [BRIEF DESCRIPTION OF STUDY]
Target audience for these insights: [PRODUCT TEAM / EXECUTIVES / DESIGN TEAM]

Raw observations (paste your notes, themes, or clusters):
[YOUR RAW OBSERVATIONS HERE]

For each insight, write:
1. **Insight headline** (one bold sentence — present tense, user-focused, specific)
   Format: "[User type] [does/feels/needs/struggles with] [specific behaviour or need] because [root cause or context]"

2. **Supporting evidence** — 2–3 data points or quotes that substantiate the insight

3. **"So what"** — 1–2 sentences on why this insight matters to the product or business

4. **Confidence level:** High (5+ participants) / Medium (3–4) / Low (1–2) — based on the evidence provided

5. **Design/product implication** — one specific thing this insight suggests the team should consider

Avoid vague insights like "users want it to be easier." Be specific about what, why, and for whom.
```

---

### #5 — The Recommendations Builder
*Research-backed recommendations that get acted on.*

```
Generate actionable product and design recommendations based on the following research insights.

Product: [PRODUCT NAME]
Research type: [METHOD — e.g. "5 moderated usability tests + 12 interviews"]
Audience for recommendations: [PM / DESIGN LEAD / EXECUTIVE / ALL]

Key research insights:
[PASTE YOUR INSIGHT STATEMENTS OR ROUGH NOTES]

For each recommendation:
1. **Recommendation** — one clear, active-verb sentence (e.g. "Add a progress indicator to the checkout flow" — not "improve checkout")
2. **Research evidence** — which insight(s) support this recommendation
3. **User impact** — what the user will experience differently if this is implemented
4. **Business impact** — connect to a metric, retention, conversion, NPS, or risk
5. **Effort estimate:** Low (days) / Medium (weeks) / High (months) — rough signal only
6. **Priority:** Must do / Should do / Could do / Won't do now — with one-line rationale
7. **Success metric** — how will we know this worked?

Organise recommendations by priority. Flag any that are mutually dependent.
```

---

### #6 — The Usability Test Script Builder
*A complete moderated test script, ready to run.*

```
Create a complete moderated usability test script for the following study:

Product/feature being tested: [PRODUCT OR FEATURE NAME]
Platform: [web / mobile / desktop / physical]
Session length: [X] minutes
Number of tasks: [X]
Participant profile: [BRIEF DESCRIPTION]
Primary research questions:
- [QUESTION 1]
- [QUESTION 2]

The script must include:
1. **Introduction & consent** (verbal consent script, recording notice, "think aloud" instructions)
2. **Warm-up questions** (3–5 questions to understand context and habits)
3. **[X] task scenarios** — each with:
   - A realistic scenario framing (story-based, not instruction-based)
   - The task prompt (what you read aloud)
   - Success criteria (what counts as task completion)
   - 3 follow-up probe questions
   - Observer notes section
4. **Post-task rating prompt** (e.g. Single Ease Question)
5. **Debrief questions** (5 open-ended questions)
6. **Closing script** (thank you, next steps, incentive reminder)

Write in a natural, conversational tone the moderator can read verbatim.
```

---

### #7 — The Executive Summary Generator
*Turn messy findings into a crisp, decision-enabling summary.*

```
Write an executive summary of a usability test for a senior stakeholder audience.

Study details:
- Product/feature tested: [NAME]
- Date(s) of testing: [DATE RANGE]
- Number of participants: [N]
- Method: [MODERATED / UNMODERATED, REMOTE / IN-PERSON]
- SUS score (if available): [SCORE]
- Task completion rate (overall): [%]

Key findings (paste your top 5–7 findings in rough note form):
[YOUR NOTES HERE]

Please write:
1. **One-paragraph executive summary** (max 100 words) — what we tested, what we found, what it means for the business
2. **3 "must fix before launch" issues** — each in one sentence: what the issue is, who it affects, what to do
3. **2 "should fix soon" issues** — same format
4. **1 "monitor" item** — something to watch but not urgent
5. **Recommended decision** — in one clear sentence, what should the team do next?
6. **Success metric** — how will we know the fixes worked?

Tone: confident, direct, business-oriented. No jargon. No hedging.
```

---

### #8 — The Findings One-Pager
*A shareable one-page document that travels far.*

```
Create a professional one-page research findings summary for the following study.

Study: [STUDY NAME]
Audience for this document: [ROLE/S]
Date: [DATE]
Key findings (rough notes): [YOUR FINDINGS]
Top recommendations (rough notes): [YOUR RECOMMENDATIONS]

Format the one-pager with these sections:
1. **Header** — Study name, date, researcher name, participant count
2. **Research question** — One sentence: "We set out to understand..."
3. **Method snapshot** — 2–3 lines: what we did, who we spoke to, when
4. **Top 3 findings** — Each as: bold insight headline + 2-sentence explanation + one supporting data point or quote
5. **What this means** — 2–3 sentences connecting findings to business or product impact
6. **Recommendations** — 3–5 bullet points, each actionable and specific
7. **Priority matrix** — simple list: Quick wins | Strategic investments | Monitor | Deprioritise
8. **Next steps** — who does what, by when
9. **Contact / full report link**

Write in plain language. No academic tone. Skimmable in 90 seconds.
```

---

### #9 — The Persona Writer
*Evidence-grounded personas that teams actually use.*

```
Write a research-based persona document for the following user segment.

Research basis: [INTERVIEWS / SURVEY / ANALYTICS / MIXED — specify n]
Product context: [PRODUCT NAME AND TYPE]
Segment description (your notes):
[PASTE YOUR SEGMENT CHARACTERISTICS, BEHAVIOURS, NEEDS, FRUSTRATIONS]

For each persona, produce:
1. **Name and defining tagline** (e.g. "Maya — the reluctant adopter")
2. **Snapshot box:** role, age range, tech comfort level, primary device, frequency of product use
3. **Narrative bio** (2 short paragraphs — third person, present tense, grounded in real research patterns)
4. **Goals** (3–4 — what they're ultimately trying to achieve)
5. **Pain points** (3–4 — specific frustrations, not generic "wants it to be easier")
6. **Behaviours** (3–4 observable patterns relevant to the product)
7. **Representative quote** (synthesised from research — clearly labelled as composite)
8. **"Succeed/fail" with our product:** one sentence on when the product works for them and when it breaks down
9. **Research evidence note** — which findings support this persona

Flag any attributes that are inferred vs. directly evidenced by research.
```

---

### #10 — The Stakeholder Objection Handler
*Never be caught flat-footed in a research presentation again.*

```
Help me prepare responses to stakeholder objections about user research findings.

Research being challenged: [BRIEF DESCRIPTION OF FINDINGS]
Stakeholder role: [PM / EXEC / ENGINEER / MARKETING / OTHER]
Objections I anticipate (or have already heard):
1. [OBJECTION 1 — e.g. "These are just 8 people, this isn't statistically significant"]
2. [OBJECTION 2 — e.g. "Our users aren't like that"]
3. [OBJECTION 3 — e.g. "We already know this from support tickets"]
4. [OBJECTION 4 — add any others]

For each objection, write:
1. **Why the objection makes sense** (steelman it — acknowledge the legitimate concern)
2. **The response** — factual, confident, not defensive (2–4 sentences)
3. **The evidence** — specific data point or analogy that supports the response
4. **When to agree** — if the objection has merit, what to concede
5. **The follow-up offer** — what additional research or data you could provide

Also provide:
- **General objection-handling principles** for research presentations (5 bullet points)
- **The one thing NOT to say** when challenged on sample size (and what to say instead)
```

---

### #11 — The ROI of Research Argument
*The case for research investment, ready when you need it.*

```
Write a persuasive ROI argument for investing in user research at [COMPANY TYPE / STAGE].

Context:
- Current research investment: [BUDGET / HEADCOUNT / NONE]
- Sceptic's main objection: [e.g. "it takes too long", "we can just A/B test", "we talk to customers anyway"]
- One recent example where research saved or created value: [BRIEF DESCRIPTION — or "none available, use hypothetical"]
- Product type: [PRODUCT DESCRIPTION]
- Company size/stage: [STARTUP / SCALE-UP / ENTERPRISE]

Please write:
1. **The cost of guessing** — a concrete framing of what shipping without research costs
2. **Research ROI case** — 3 specific, referenced examples of value from similar companies
3. **The "speed" reframe** — why research done well speeds up delivery
4. **The minimum viable research argument** — what even 2–3 sessions can reveal
5. **Proposed investment** — frame your ask as a resource for a specific deliverable
6. **The risk register framing** — position skipping research as a risk that needs to be owned

Tone: businesslike, confident, not defensive or preachy.
```

---

### #12 — The Research Repository Entry
*Every study documented in a searchable, shareable format.*

```
Write a research repository entry for the following study.

Study name: [NAME]
Date conducted: [DATE]
Researcher(s): [NAMES]
Method: [METHOD]
Participants: [N, BRIEF PROFILE]
Product area: [PRODUCT/FEATURE]
Research questions: [LIST]
Key findings (rough notes): [YOUR NOTES]
Recommendations made: [ROUGH LIST]
Actions taken as a result (if known): [NOTES]

Please produce a repository entry with:
1. **Study ID** (format: YYYY-MM-[METHOD ABBREVIATION]-[NUMBER])
2. **One-line study description** (for search results preview)
3. **Research questions** (bulleted)
4. **Method & participants** (structured paragraph)
5. **Key findings** (5–7 numbered, each in one clear sentence)
6. **Recommendations** (numbered, each actionable)
7. **What was done with this research**
8. **Tags** — suggest 8–12 tags for searchability
9. **Confidence level:** High / Medium / Low — with rationale
```

---

### #13 — The Survey Bias Auditor
*Catch leading questions before they corrupt your data.*

```
Act as a survey methodology expert. Review the following survey questions for cognitive bias, clarity issues, and measurement validity problems.

Survey context: [BRIEF DESCRIPTION OF SURVEY PURPOSE AND AUDIENCE]

Questions to review:
[PASTE YOUR SURVEY QUESTIONS HERE]

For each question, provide:
1. **Bias/issue identified** (leading language, double-barrelled, loaded terms, ambiguity, recall bias, etc.) — or "No issues found"
2. **Severity:** High / Medium / Low
3. **Revised question** that preserves the research intent but removes the issue
4. **One-line rationale** for the change

At the end, give an overall quality score (1–10) with a 2-sentence summary of the survey's strengths and weaknesses.
```

---

### #14 — The Cross-Team Research Digest
*Share insights in a format teams will actually read.*

```
Write a cross-team research digest to share insights from a recent study.

Study: [STUDY NAME AND TYPE]
Primary audience for the digest: [ENGINEERING / MARKETING / SALES / CUSTOMER SUCCESS / LEADERSHIP / ALL]
Distribution channel: [SLACK / EMAIL / CONFLUENCE / ALL-HANDS]
Key insights (rough notes): [YOUR INSIGHTS]

Please produce:
1. **Subject line / Post title** (attention-grabbing, not academic)
2. **TL;DR** (3 bullet points — the most important things to know)
3. **Why this matters to [AUDIENCE]** — 1 paragraph tailored to the audience
4. **Top 3 insights** — each with: insight headline + 2-sentence explanation + one supporting data point or quote + "What this means for [TEAM]"
5. **One surprising thing** — the finding that challenged assumptions
6. **What's happening next** — what the team is doing with this research
7. **Feedback prompt** — one question asking what they'd like to know next
```

---

### #15 — The Research Presentation Narrative Builder
*Turn findings into a story executives remember.*

```
You are a UX researcher and strategic storyteller. Help me build a compelling narrative for a research findings presentation.

Audience: [ROLE — e.g. product leadership, engineering team, board, cross-functional pod]
Audience's likely mindset: [SCEPTICAL / CURIOUS / ALREADY ALIGNED / UNDER TIME PRESSURE]
Presentation length: [X] minutes / [X] slides
Core research findings (paste rough notes): [YOUR FINDINGS HERE]

Please produce:
1. **Narrative arc** — a 5-act structure:
   - Act 1: The question we set out to answer
   - Act 2: What we did (brief and credible)
   - Act 3: What we found (3–5 key insights, most important first)
   - Act 4: What it means (implications, so-whats)
   - Act 5: What we recommend (clear, actionable asks)

2. **Opening hook** — one powerful sentence or statistic
3. **Slide-by-slide outline:** slide title | key message | suggested visual | speaker note
4. **The single "headline finding"** — if stakeholders remember one thing, it should be this
5. **Anticipated objections** and prepared responses (top 3)
6. **Closing call to action** — one clear ask from the audience

Tone: authoritative, clear, no UX jargon. Built for decision-making.
```

---

## 10 Golden Rules of Prompting for UX Researchers

These rules apply to every prompt in this toolkit — and every AI interaction in your research practice.

---

### Rule 1: Context is Everything

AI has no idea what you're working on until you tell it. The more specific context you provide — product type, audience, research questions, business goals — the better the output. Vague in, vague out.

> **Do:** "I'm a UX researcher at a B2B SaaS company. We're testing an onboarding flow for finance managers, age 35–55, who are reluctant technology adopters."
>
> **Don't:** "Help me with research."

---

### Rule 2: Specify Your Audience

Who will read or hear the output? A junior researcher writing up notes needs different language than an executive one-pager. Always include the intended audience and their role in your prompt.

> **Always add:** "The audience for this output is [ROLE]. They are [context about their knowledge/priorities]."

---

### Rule 3: AI Drafts, You Decide

AI outputs are a first draft, not a finished product. Your job is to review, verify against real data, cut what's wrong, and add what's missing. Never share AI-generated research insights without checking them against your actual transcripts and notes.

> **Mantra:** "AI writes the structure. I write the truth."

---

### Rule 4: Give Examples to Get Examples

If you want AI to match a specific tone, format, or style, show it an example. Paste in a previous one-pager you liked, a quote you want to emulate, or the format of an existing deliverable. AI learns from examples far better than abstract instructions.

> **Add to any prompt:** "Here is an example of the format/tone I'm going for: [PASTE EXAMPLE]"

---

### Rule 5: Ask for Critique, Not Just Creation

One of the most underused AI superpowers: asking it to punch holes in your own work. Use AI to audit your discussion guides for bias, challenge your insight statements, or steelman stakeholder objections. The best researchers are rigorous self-critics.

> **Power move:** "Review the following [discussion guide / survey / insight statement] and tell me what's wrong with it, what I'm missing, and what assumptions I'm making that I shouldn't be."

---

### Rule 6: Chunk Large Inputs

If you're pasting interview transcripts, raw notes, or long documents, break them into manageable chunks (500–1,500 words per prompt). AI quality degrades on very long inputs. Process in batches, then synthesise across batches.

> **Workflow:** Process transcripts one at a time → collect outputs → synthesise across all outputs in a final prompt.

---

### Rule 7: Be Specific About Format

Tell AI exactly how you want the output structured. Do you want headers? Bullet points? A table? A numbered list? A narrative paragraph? If you don't specify, you'll get whatever the AI defaults to — and you'll spend time reformatting.

> **Add to any prompt:** "Format the output as [numbered list / table with columns X, Y, Z / a paragraph per insight / a structured report with H2 headers]."

---

### Rule 8: Separate Generation from Evaluation

Don't ask AI to generate AND evaluate in the same prompt — you'll get mediocre results at both. First, generate (e.g. "write me 10 discussion guide questions"). Then, in a separate prompt, evaluate (e.g. "review these 10 questions for leading language and bias").

> **Two-step rule:** Create first. Critique second. Never conflate them.

---

### Rule 9: Ground Insights in Quotes

When using AI for synthesis, always ask it to cite the specific quotes or observations that support each insight. This forces AI to stay close to your data rather than hallucinating themes. It also makes your insights defensible to stakeholders.

> **Always add:** "For each insight, provide 2–3 direct quotes from the data that support it. Do not include insights without evidence."

---

### Rule 10: Iterate, Don't Restart

If the first output isn't right, don't start a new prompt — continue the conversation. Tell the AI what to change: "Make insight #3 more specific to the checkout flow," or "Rewrite the executive summary in a less academic tone." Iterating builds on context; restarting loses it.

> **Power phrase:** "Keep everything else the same, but [specific change]."

---

## Quick Reference: Which Prompt for What?

| Task | File | Prompt # |
|---|---|---|
| Sharpen research questions | 01 | 01 |
| Write a discussion guide | 02 | 01 |
| Write a screener | 02 | 02 |
| Extract insights from a transcript | 03 | 01 |
| Cluster observations into themes | 03 | 03 |
| Write insight statements | 03 | 05 |
| Build recommendations | 03 | 07 |
| Design a survey | 04 | 01 |
| Audit survey for bias | 04 | 02 |
| Write a usability test script | 04 | 04 |
| Write task scenarios | 04 | 05 |
| Analyse SUS scores | 04 | 06 |
| Analyse task success data | 04 | 07 |
| Write a test executive summary | 04 | 20 |
| Build a findings presentation | 05 | 01 |
| Write a one-pager | 05 | 02 |
| Write personas | 05 | 04 |
| Build a recommendation deck | 05 | 06 |
| Pitch a research roadmap | 05 | 07 |
| Make the ROI case for research | 05 | 08 |
| Share insights cross-team | 05 | 09 |
| Log a study to repository | 05 | 10 |
| Brief senior leadership | 05 | 11 |
| Handle stakeholder objections | 05 | 15 |

---

*This cheat sheet is your everyday companion. The full context and variations for each prompt live in the numbered prompt files.*
