# 04 — Survey & Usability Testing Prompts

> **20 prompts** covering the full quantitative and evaluative research cycle — from survey design through usability testing, task analysis, and accessibility review.

---

## Survey Design

**1. Survey Draft Generator**

*When to use:* Starting a new survey from scratch and need a structured, unbiased questionnaire aligned to your research questions.

```
You are an expert UX researcher and survey methodologist. I need to design a survey to understand [RESEARCH TOPIC] among [TARGET AUDIENCE].

My core research questions are:
1. [RESEARCH QUESTION 1]
2. [RESEARCH QUESTION 2]
3. [RESEARCH QUESTION 3]

Constraints:
- Maximum completion time: [X] minutes
- Distribution channel: [email / in-app / intercept / panel]
- Prior knowledge of audience: [low / medium / high]

Please produce:
1. A screening question (if needed) to qualify respondents
2. An opening context statement (2–3 sentences, no leading language)
3. [X] survey questions organised by theme, with:
   - The question text (neutral, plain language)
   - Question type (Likert / multiple choice / ranking / open-text / NPS)
   - Why this question answers a research question
4. A closing open-text question for unprompted feedback
5. A thank-you/redirect message

Flag any questions that risk acquiescence bias, social desirability bias, or double-barrelled phrasing, and suggest alternatives.
```

---

**2. Survey Question Bias Auditor**

*When to use:* You've drafted survey questions and want an expert review before launch to catch leading, loaded, or ambiguous language.

```
Act as a survey methodology expert. Review the following survey questions for cognitive bias, clarity issues, and measurement validity problems.

Survey context: [BRIEF DESCRIPTION OF SURVEY PURPOSE AND AUDIENCE]

Questions to review:
[PASTE YOUR SURVEY QUESTIONS HERE]

For each question, provide:
1. **Bias/issue identified** (leading language, double-barrelled, loaded terms, ambiguity, recall bias, etc.) — or "No issues found"
2. **Severity:** High / Medium / Low
3. **Revised question** that preserves the research intent but removes the issue
4. **One-line rationale** for the change

At the end, give an overall quality score (1–10) with a 2-sentence summary of the survey's strengths and weaknesses.
```

---

**3. Likert Scale Response Narrative**

*When to use:* You have closed-ended Likert or rating data and need to write readable, insight-led summaries rather than just reporting percentages.

```
You are a UX researcher writing a findings narrative for a non-technical audience. Below are Likert-scale results from a survey of [NUMBER] participants about [SURVEY TOPIC].

Data:
[PASTE QUESTION + RESPONSE DISTRIBUTION, e.g.:
Q4. "The checkout process was easy to complete."
Strongly agree: 22% | Agree: 38% | Neutral: 18% | Disagree: 14% | Strongly disagree: 8%]

For each question:
1. Write a 2–3 sentence narrative summary that highlights the key finding (not just the numbers)
2. Note any surprising, polarising, or noteworthy distributions
3. Flag questions where the neutral category is unusually high (possible fence-sitting or ambiguous wording)
4. Suggest one follow-up question that would deepen understanding of this result

Keep language confident and specific. Avoid hedging phrases like "it seems" or "it appears".
```

---

## Usability Test Scripts

**4. Moderated Usability Test Script Builder**

*When to use:* Planning a moderated usability study and need a professional, complete test script with warm-up, tasks, and probes.

```
Create a complete moderated usability test script for the following study:

Product/feature being tested: [PRODUCT OR FEATURE NAME]
Platform: [web / mobile / desktop / physical]
Session length: [X] minutes
Number of tasks: [X]
Participant profile: [BRIEF DESCRIPTION]
Primary research questions:
- [QUESTION 1]
- [QUESTION 2]

The script must include:
1. **Introduction & consent** (verbal consent script, recording notice, "think aloud" instructions)
2. **Warm-up questions** (3–5 questions to understand context and habits)
3. **[X] task scenarios** — each with:
   - A realistic scenario framing (story-based, not instruction-based)
   - The task prompt (what you read aloud)
   - Success criteria (what counts as task completion)
   - 3 follow-up probe questions
   - Observer notes section
4. **Post-task rating prompt** (e.g. Single Ease Question)
5. **Debrief questions** (5 open-ended questions)
6. **Closing script** (thank you, next steps, incentive reminder)

Write in a natural, conversational tone the moderator can read verbatim.
```

---

**5. Task Scenario Writer**

*When to use:* You need realistic, non-leading task scenarios that put participants in context without telegraphing the correct path.

```
Write [NUMBER] usability test task scenarios for the following product and context.

Product: [PRODUCT NAME AND TYPE]
User goal being tested: [WHAT THE USER IS TRYING TO ACCOMPLISH]
Current experience level of participant: [NOVICE / INTERMEDIATE / EXPERT]
Platform: [web / iOS / Android / desktop]

For each scenario:
1. **Scenario title** (internal label only)
2. **Context-setting narrative** (2–4 sentences placing the participant in a realistic situation — use a fictional name like "Alex" if helpful)
3. **Task prompt** (one clear sentence stating the goal without revealing the path or UI labels)
4. **What NOT to say** (list any words or phrases the moderator should avoid that might lead the participant)
5. **Expected completion path** (for moderator reference only)
6. **Difficulty rating:** Easy / Medium / Hard — with rationale

Ensure tasks flow naturally from simple to complex across the session.
```

---

## SUS & Quantitative Analysis

**6. SUS Score Analysis Narrative**

*When to use:* You've collected System Usability Scale scores and need to translate raw numbers into a clear, stakeholder-ready narrative.

```
You are a UX researcher analysing System Usability Scale (SUS) results. Here is the data from my study:

Product: [PRODUCT NAME]
Study context: [BRIEF DESCRIPTION — e.g. "unmoderated test of new onboarding flow, n=32"]
Raw SUS scores: [LIST ALL INDIVIDUAL SCORES, e.g. 72.5, 85, 67.5, 90, 55...]

Please provide:
1. **Calculated mean SUS score** and confirmation of the calculation
2. **Percentile ranking** and adjective rating (Awful / Poor / OK / Good / Excellent / Best Imaginable) per the standard SUS benchmarking scale
3. **Grade letter** (A–F scale)
4. **Distribution analysis** — spread, outliers, standard deviation (if calculable)
5. **2-paragraph stakeholder narrative** explaining what the score means in plain language, what's good, and what needs improvement
6. **Benchmark comparison** — how does this score compare to industry SUS averages (if available for [PRODUCT CATEGORY])?
7. **3 recommended next steps** based on the score

If scores look inconsistent or suggest response bias (e.g. all extreme scores), flag this.
```

---

**7. Task Success & Error Rate Summary**

*When to use:* After a usability study, you have raw task completion data and need a structured analysis with error patterns.

```
Analyse the following usability test task data and produce a structured findings summary.

Study: [STUDY NAME]
Participants: [N]
Tasks: [NUMBER]

Data (paste in any format — table, CSV, or notes):
[PASTE YOUR TASK COMPLETION DATA HERE]

Please produce:
1. **Task success rate table** — task name, completion rate (%), mean time-on-task (if provided), mean Single Ease Question score (if provided)
2. **Critical failures** — tasks below 70% success rate, flagged as high priority
3. **Error pattern analysis** — common mistakes, wrong paths, or points of confusion across participants
4. **Severity classification** for each issue found (Critical / Serious / Moderate / Minor) using Nielsen's heuristics as a framework
5. **Top 5 usability issues** written as: [Issue] → [Impact on user] → [Recommended fix]
6. **Executive one-liner** summarising the overall usability health of the product
```

---

## First-Click & Navigation Testing

**8. First-Click Test Analysis Report**

*When to use:* You have first-click test results (from Optimal Workshop, Maze, or similar) and need a clear analysis of navigation and labelling issues.

```
Analyse the following first-click test results and produce a UX findings report.

Feature/page being tested: [PAGE OR FEATURE NAME]
Task prompt shown to participants: "[EXACT TASK WORDING]"
Number of participants: [N]
Tool used: [OPTIMAL WORKSHOP / MAZE / USERZOOM / OTHER]

Results data:
[PASTE CLICK HEATMAP DESCRIPTION OR CLICK LOCATION DATA — e.g.
"Header nav 'Products': 45 clicks (42%)
Hero CTA 'Get started': 28 clicks (26%)
Footer link: 10 clicks (9%)
Other/off-target: 23 clicks (21%)
Median time to first click: 8.3 seconds"]

Please provide:
1. **First-click accuracy rate** (% who clicked the target element first)
2. **Time-to-click analysis** — what the median time suggests about discoverability
3. **Top 3 incorrect click targets** and what they reveal about user mental models or labelling issues
4. **Heuristic diagnosis** — which usability/IA principles are being violated
5. **Specific label or design recommendations** to improve accuracy
6. **Confidence rating for the current design:** Low / Medium / High — with rationale
7. **Suggested follow-up study** (e.g. tree test, A/B test, card sort)
```

---

## Card Sorting

**9. Card Sort Synthesis Report**

*When to use:* You've run an open or closed card sort and need help making sense of the clustering data and naming patterns.

```
You are a UX researcher synthesising card sorting data to inform information architecture decisions.

Sort type: [OPEN / CLOSED / HYBRID]
Number of cards: [N]
Number of participants: [N]
Tool used: [OPTIMAL WORKSHOP / MAZE / MIRO / OTHER]
Product/site section: [CONTEXT]

Data provided:
[PASTE SIMILARITY MATRIX, TOP GROUPINGS, OR RAW NOTES — e.g. dendrogram clusters, most common category names, outlier cards]

Please produce:
1. **Top grouping patterns** — which cards were most consistently grouped together (>60% agreement)
2. **Problem cards** — cards frequently sorted alone, split across groups, or causing participant confusion
3. **Emergent category names** from participants (open sort) — themes and frequency
4. **Recommended IA structure** — proposed categories with card membership, based on the data
5. **Confidence level per category:** High (>70% agreement) / Medium (50–70%) / Low (<50%)
6. **Mental model insights** — what the sort reveals about how users conceptualise the content
7. **3 design recommendations** for navigation labels or content groupings
8. **Gaps** — anything the card sort data cannot answer that needs further research
```

---

## Tree Testing

**10. Tree Test Results Report**

*When to use:* You've run a tree test to evaluate your navigation structure and need a clear diagnostic report of where users get lost.

```
Analyse the following tree test results and produce a navigation diagnostic report.

Navigation structure tested: [BRIEF DESCRIPTION OR PASTE TOP-LEVEL CATEGORIES]
Number of tasks: [N]
Number of participants: [N]
Tool: [OPTIMAL WORKSHOP / TREEJACK / OTHER]

Results:
[PASTE TASK RESULTS — e.g.:
Task 1: "Find information about returns policy"
- Directness: 58% direct, 42% indirect
- Success: 71%
- Top failure path: Products > Delivery (22%)
...]

Please produce:
1. **Overall navigation health score** — based on directness and success rates
2. **Task-by-task findings table:** Task | Success % | Directness % | Top Failure Path | Issue Diagnosis
3. **Critical navigation failures** (tasks below 60% success) with root cause analysis
4. **Backtracking analysis** — which nodes cause the most u-turns (indicating dead ends or misleading labels)
5. **Category label recommendations** — specific wording changes based on failure paths
6. **Structural recommendations** — any categories that should be merged, split, or repositioned
7. **Priority fix list** ranked by impact (number of users affected × severity of confusion)
```

---

## Prototype Feedback

**11. Prototype Feedback Synthesis**

*When to use:* You've collected qualitative feedback on a prototype (from testing sessions or design reviews) and need to structure it into actionable findings.

```
Synthesise the following prototype feedback into a structured UX findings document.

Prototype type: [LO-FI WIREFRAMES / HI-FI PROTOTYPE / CLICKABLE PROTOTYPE / CODED PROTOTYPE]
Screen/flow being reviewed: [NAME OF FLOW OR FEATURE]
Feedback sources: [USABILITY SESSIONS / DESIGN CRITIQUE / STAKEHOLDER REVIEW / ALL]
Number of feedback providers: [N]

Raw feedback notes:
[PASTE ALL RAW FEEDBACK — quotes, observer notes, timestamps, etc.]

Please produce:
1. **Affinity clusters** — group feedback into 4–7 themes with a descriptive label per theme
2. **Frequency count** — how many unique participants/sources mentioned each theme
3. **Sentiment split per theme:** Positive / Negative / Mixed
4. **Top 5 issues** ranked by frequency and severity, written as:
   - Issue: [description]
   - Evidence: [supporting quotes, max 2]
   - Recommendation: [specific design change]
   - Priority: Critical / High / Medium / Low
5. **What's working well** — positive patterns worth preserving
6. **Open questions** the feedback raises but doesn't answer
7. **Recommended next iteration focus** — top 3 things to change before next test round
```

---

**12. Prototype Feedback Guide for Facilitators**

*When to use:* You're running a prototype review session and need a structured guide to gather consistent, high-quality feedback from participants or stakeholders.

```
Create a structured feedback guide for a prototype review session.

Prototype: [WHAT IS BEING REVIEWED]
Session format: [MODERATED 1:1 / GROUP CRITIQUE / ASYNC REVIEW]
Participants: [WHO IS GIVING FEEDBACK — users / designers / PMs / executives]
Session length: [X] minutes
Key design decisions being tested: [LIST 2–4 DECISIONS YOU NEED FEEDBACK ON]

The guide should include:
1. **Session framing script** (how to introduce the prototype and set expectations — "we're testing the design, not you")
2. **Warm-up question** to understand the participant's context and familiarity
3. **Observation phase prompts** — what to ask while participant explores (think-aloud cues, reaction prompts)
4. **Targeted feedback questions** for each key design decision (2 questions per decision)
5. **Comparative question** (if testing multiple versions): how to frame preference without leading
6. **Priority ranking exercise** — a structured way to help participants identify what matters most
7. **Closing question** — "If you could change one thing..."
8. **Note-taking template** for observers (columns: screen, observation, quote, severity)
```

---

## Unmoderated Testing

**13. Unmoderated Test Screener**

*When to use:* Recruiting participants for an unmoderated usability study and need a screener that qualifies the right people without tipping off what you're testing.

```
Write a participant screener for an unmoderated usability study.

Product being tested: [PRODUCT TYPE — do not name specific product in screener]
Target participant profile:
- Demographics: [AGE RANGE, LOCATION, etc.]
- Behaviour/experience: [WHAT THEY NEED TO DO OR HAVE DONE — e.g. "purchased online in last 30 days"]
- Exclusions: [WHO TO SCREEN OUT — e.g. competitors, non-target users]
Recruitment platform: [USERLYTICS / MAZE / USERTESTING / PROLIFIC / OTHER]
Estimated study length: [X] minutes

Please write:
1. **Introduction text** (2–3 sentences, no product spoilers, sets expectations)
2. **[5–8] screener questions** with:
   - Question text (neutral)
   - Response options
   - Qualify/disqualify logic (e.g. "Must select X to qualify")
3. **Device/tech check question** (if relevant)
4. **Availability/scheduling question** (if synchronous)
5. **Disqualification message** (polite, no reason given)
6. **Qualification confirmation message** (next steps)

Flag any questions that might telegraph the product or desired behaviour.
```

---

**14. Unmoderated Test Task & Instructions Builder**

*When to use:* Setting up an unmoderated study and need clear, self-contained task instructions that participants can follow without a moderator.

```
Write unmoderated usability test instructions and tasks for the following study.

Product: [PRODUCT NAME]
Platform: [WEB / MOBILE — specify iOS or Android]
Study goal: [WHAT YOU ARE TRYING TO LEARN]
Number of tasks: [X]
Estimated duration: [X] minutes

For each task, provide:
1. **Task title** (internal)
2. **Scenario text** (participant-facing — realistic, jargon-free, no leading language)
3. **Task prompt** (exactly what appears on screen)
4. **Success screen/state** (what the participant should see when done — for auto-scoring)
5. **"I give up" path instructions** (what to click if stuck — to avoid abandoned sessions)
6. **Post-task question** (Single Ease Question + one open-text "why?")

Also write:
- **Study introduction text** (what participants see first — purpose, recording notice, think-aloud prompt)
- **Study closing text** (thank you, what happens next)
- **Technical troubleshooting note** (what to do if the prototype doesn't load)

Keep all participant-facing language at a [8th / 10th / 12th] grade reading level.
```

---

## Accessibility Research

**15. Accessibility Audit Research Notes**

*When to use:* You've observed an accessibility audit session or AT (assistive technology) user test and need to structure the findings.

```
Structure the following accessibility research observations into a prioritised findings report.

Context:
- Product: [PRODUCT NAME]
- Assistive technology used: [SCREEN READER (NVDA/JAWS/VoiceOver) / SWITCH ACCESS / MAGNIFICATION / VOICE CONTROL / OTHER]
- Participant profile: [DISABILITY TYPE, EXPERIENCE LEVEL WITH AT]
- Session length: [X] minutes
- Tasks attempted: [LIST TASKS]

Raw observations and notes:
[PASTE YOUR SESSION NOTES, TIMESTAMPS, AND QUOTES HERE]

Please produce:
1. **WCAG violation log** — for each observed issue:
   - Issue description
   - WCAG criterion violated (e.g. 1.4.3 Contrast, 4.1.2 Name/Role/Value)
   - Conformance level: A / AA / AAA
   - Participant impact (what they could/couldn't do)
   - Quote or observation evidence
2. **Severity classification:** Blocker / Critical / Serious / Moderate / Minor
3. **Priority fix list** (top 5, ordered by user impact)
4. **Positive findings** — what worked well for AT users
5. **Developer handoff notes** — specific technical guidance for each fix
6. **Executive summary** (3 sentences — suitable for a leadership update)
```

---

**16. Accessibility Research Recruitment Brief**

*When to use:* Planning a study that includes participants with disabilities and need a respectful, inclusive screener and recruitment brief.

```
Write a recruitment brief and screener for a usability study that includes participants with disabilities.

Study type: [MODERATED / UNMODERATED]
Product: [PRODUCT TYPE]
Assistive technologies to cover: [LIST — e.g. screen reader, magnification, voice control]
Number of participants needed per AT type: [N]
Session format: [IN-PERSON / REMOTE — specify platform]
Incentive: [AMOUNT AND FORMAT]

Please provide:
1. **Recruitment brief** for a disability inclusion specialist or recruitment agency (what we need, why, how sessions will be run)
2. **Participant screener questions** (disability-inclusive language, no ableist framing) covering:
   - AT usage type and experience level
   - Device and browser preferences
   - Availability and session format preferences
   - Any specific accommodation needs
3. **Session accommodation checklist** — what to prepare for each AT type (captions, extended time, document formats, etc.)
4. **Participant communication template** — confirmation email with what to expect
5. **Incentive equity note** — ensuring payment method is accessible to all participants

Use plain, respectful, identity-first or person-first language as appropriate (offer both options).
```

---

**17. Think-Aloud Protocol Prompt Cheat Sheet**

*When to use:* Preparing moderators (especially junior researchers) to keep participants talking during sessions without leading them.

```
Create a moderation cheat sheet for think-aloud usability sessions focused on [PRODUCT TYPE / FEATURE AREA].

The cheat sheet should be printable on one page and include:

**SILENCE BREAKERS** (prompts for when participant goes quiet)
- List 8 neutral prompts to encourage verbalisation (e.g. "What are you thinking right now?")

**CONFUSION PROBES** (prompts for when participant looks stuck or frustrated)
- List 6 empathetic probes that don't reveal answers

**POSITIVE REACTION PROBES** (prompts for when participant seems pleased)
- List 4 prompts to unpack what's working and why

**TASK COMPLETION PROBES** (after each task)
- List 5 post-task questions to surface retrospective insight

**THINGS NEVER TO SAY** (leading or biasing phrases)
- List 8 phrases moderators must avoid, with "instead say..." alternatives

**BODY LANGUAGE REMINDERS**
- List 5 non-verbal moderation tips

**EMERGENCY PHRASES** (for when things go wrong — prototype breaks, participant distressed, etc.)
- List 4 recovery phrases

Format as a clean, scannable reference card.
```

---

**18. Remote vs. In-Person Study Design Comparison**

*When to use:* Deciding between remote and in-person research methods and need a structured recommendation for your specific study goals.

```
Help me decide between remote and in-person research methods for the following study.

Research goals:
1. [GOAL 1]
2. [GOAL 2]
3. [GOAL 3]

Constraints:
- Budget: [RANGE]
- Timeline: [WEEKS AVAILABLE]
- Participant location: [LOCAL / NATIONAL / INTERNATIONAL]
- Product type: [WEB / MOBILE / PHYSICAL / SERVICE]
- Team research experience: [JUNIOR / MID / SENIOR]

Please provide:
1. **Method recommendation** (Remote moderated / Remote unmoderated / In-person moderated / Hybrid) with rationale
2. **Trade-off table** comparing remote vs. in-person across: data richness, ecological validity, cost, speed, participant access, observer logistics
3. **Risk assessment** for the recommended method (top 3 risks + mitigation)
4. **Setup checklist** for the recommended method
5. **Tech stack recommendation** (tools for recruiting, session running, note-taking, analysis)
6. **If budget/time were no constraint** — what would the ideal method be and why?
```

---

**19. Post-Study Debrief Facilitator Guide**

*When to use:* Running a team debrief after a usability study and need a structured agenda to surface insights collaboratively before one researcher goes away to analyse alone.

```
Create a facilitator guide for a team debrief session following a usability study.

Study just completed: [STUDY NAME AND TYPE]
Number of sessions observed: [N]
Debrief attendees: [ROLES — e.g. lead researcher, 2 observers, product manager, designer]
Time available for debrief: [X] minutes
Goal: [ALIGN ON FINDINGS / PRIORITISE ISSUES / GENERATE HYPOTHESES / ALL]

The guide should include:
1. **Opening frame** (2-minute facilitator script — set the purpose, rules of the session)
2. **Brain dump exercise** (how to run a sticky-note dump of raw observations — what each person writes, how long, format)
3. **Affinity clustering activity** (step-by-step instructions for grouping observations into themes)
4. **Severity voting method** (how the team dot-votes on issue priority)
5. **"So what?" round** — structured prompts for each theme to move from observation to insight
6. **Open questions parking lot** — how to capture things needing more data
7. **Action items template** — who owns what next
8. **Closing check-out question** (one per person — to surface anything missed)

Include time allocations for each activity based on [X] total minutes.
```

---

**20. Usability Test Report Executive Summary Generator**

*When to use:* You've completed analysis and need to write a crisp executive summary of usability test findings that busy stakeholders will actually read.

```
Write an executive summary of a usability test for a senior stakeholder audience.

Study details:
- Product/feature tested: [NAME]
- Date(s) of testing: [DATE RANGE]
- Number of participants: [N]
- Method: [MODERATED / UNMODERATED, REMOTE / IN-PERSON]
- SUS score (if available): [SCORE]
- Task completion rate (overall): [%]

Key findings (paste your top 5–7 findings in rough note form):
[YOUR NOTES HERE]

Please write:
1. **One-paragraph executive summary** (max 100 words) — what we tested, what we found, what it means for the business
2. **3 "must fix before launch" issues** — each in one sentence: what the issue is, who it affects, what to do
3. **2 "should fix soon" issues** — same format
4. **1 "monitor" item** — something to watch but not urgent
5. **Recommended decision** — in one clear sentence, what should the team do next? (e.g. "Ship with fixes to issues 1–3 and retest onboarding in 6 weeks")
6. **Success metric** — how will we know the fixes worked?

Tone: confident, direct, business-oriented. No jargon. No hedging.
```

---

*These 20 prompts pair with the interview and analysis prompts in files 02 and 03. For workflow guidance on how to sequence them, see `06-workflow-sops.md`.*
