# 🔬 The UX Researcher's AI Prompt Toolkit

**Version 1.0 | 80+ Professional Prompts for UX Researchers & Product Designers**

---

## Welcome

You didn't get into UX research to spend hours staring at a blank document trying to write a screener survey or figure out how to frame findings for a skeptical VP of Engineering. You got into it to understand people — to find the signal in the noise and build things that actually work.

This toolkit puts AI to work on the parts that slow you down, so you can spend more time on the parts only you can do.

Every prompt in here was built for the real workflows of UX researchers and product designers: from recruiting participants to presenting findings to executives who have 12 minutes and a full inbox.

---

## What's Inside

| File | Contents |
|------|----------|
| `01-quick-start-guide.md` | How to use this toolkit, prompt anatomy, and tips for best results |
| `02-interview-research-prompts.md` | **25 prompts** — interview guides, recruiting, screeners, moderation |
| `03-synthesis-analysis-prompts.md` | **20 prompts** — affinity mapping, insight extraction, journey maps |
| `04-survey-usability-prompts.md` | **20 prompts** — survey design, usability scripts, SUS analysis |
| `05-stakeholder-communication-prompts.md` | **15 prompts** — presentations, personas, recommendation decks |
| `06-workflow-sops.md` | **5 complete SOPs** — end-to-end research workflows |
| `07-cheat-sheet.md` | **Top 15 power prompts** — your daily driver reference |
| `PRODUCT-INFO.md` | Product description and marketing copy |

**Total: 80+ prompts + 5 full workflows**

---

## How to Use This Toolkit

### 1. Find Your Situation
Browse by phase or jump to the cheat sheet (`07-cheat-sheet.md`) for the most versatile prompts.

### 2. Copy the Prompt
Each prompt is in a code block — copy it cleanly.

### 3. Fill in the Brackets
Every `[BRACKET]` is a variable. Replace them with your specific context. The more detail you add, the better your output.

### 4. Paste into Your AI Tool
Works with Claude, ChatGPT, Gemini, or any capable LLM.

### 5. Iterate
First output rarely needs zero edits. Treat it as a strong first draft and refine from there.

---

## Prompt Quality Principles

Every prompt in this toolkit follows these rules:

- **Context-first**: AI needs to understand your situation before it can help
- **Role-priming**: Prompts establish the AI as a UX/research-fluent collaborator
- **Specificity**: Vague prompts get vague outputs — these are specific
- **Output format**: Prompts tell the AI exactly what structure you need
- **Professional tone**: Outputs are boardroom-ready, not generic blog posts

---

## Who This Is For

- **UX Researchers** (junior to senior, in-house and freelance)
- **Product Designers** who do their own research
- **Design Ops** professionals building research operations
- **Product Managers** running lightweight discovery
- **Design Leads** who need to synthesize research fast

---

## Quick Wins (Start Here)

If you're new to AI-assisted research, start with these three prompts:

1. **Interview Guide Builder** → `02-interview-research-prompts.md`, Prompt #1
2. **Insight Extraction Engine** → `03-synthesis-analysis-prompts.md`, Prompt #3
3. **Executive Summary Generator** → `03-synthesis-analysis-prompts.md`, Prompt #10

These three alone will save you 3–5 hours per research cycle.

---

## A Note on AI in Research

AI is a powerful accelerator, not a replacement for researcher judgment. These prompts help you move faster on structural and communicative tasks — drafting, organizing, formatting, synthesizing. The interpretation, the empathy, the "so what" — that's still yours.

Use AI to do the scaffolding. You do the thinking.

---

*Built for researchers who take their craft seriously.*
