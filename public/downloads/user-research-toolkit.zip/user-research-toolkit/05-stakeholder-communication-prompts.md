# 05 — Stakeholder Communication Prompts

> **15 prompts** to help you translate research into influence — from one-pagers and persona narratives to executive briefings and ROI arguments.

---

## Research Presentations

**1. Research Presentation Narrative Builder**

*When to use:* You have your findings and need to turn them into a compelling story arc for a slide deck presentation — something people will remember, not just read.

```
You are a UX researcher and strategic storyteller. Help me build a compelling narrative for a research findings presentation.

Audience: [ROLE — e.g. product leadership, engineering team, board, cross-functional pod]
Audience's likely mindset: [SCEPTICAL / CURIOUS / ALREADY ALIGNED / UNDER TIME PRESSURE]
Presentation length: [X] minutes / [X] slides
Core research findings (paste rough notes):
[YOUR FINDINGS HERE]

Please produce:
1. **Narrative arc** — a 5-act structure for the presentation:
   - Act 1: The question we set out to answer (why this research mattered)
   - Act 2: What we did (method, participants — brief and credible)
   - Act 3: What we found (3–5 key insights, most important first)
   - Act 4: What it means (implications, so-whats)
   - Act 5: What we recommend (clear, actionable asks)

2. **Opening hook** — one powerful sentence or statistic to open the deck
3. **Slide-by-slide outline** with: slide title | key message | suggested visual | speaker note
4. **The single "headline finding"** — if stakeholders remember one thing, it should be this
5. **Anticipated objections** and prepared responses (top 3)
6. **Closing call to action** — one clear ask from the audience

Tone: authoritative, clear, no UX jargon. Built for decision-making, not information dumping.
```

---

**2. Findings One-Pager**

*When to use:* You need a single-page leave-behind document that captures the essence of your research for people who won't read a full report.

```
Create a professional one-page research findings summary for the following study.

Study: [STUDY NAME]
Audience for this document: [ROLE/S]
Date: [DATE]
Key findings (rough notes):
[YOUR FINDINGS]
Top recommendations (rough notes):
[YOUR RECOMMENDATIONS]

Format the one-pager with these sections:
1. **Header** — Study name, date, researcher name, participant count
2. **Research question** — One sentence: "We set out to understand..."
3. **Method snapshot** — 2–3 lines: what we did, who we spoke to, when
4. **Top 3 findings** — Each as: bold insight headline + 2-sentence explanation + one supporting data point or quote
5. **What this means** — 2–3 sentences connecting findings to business or product impact
6. **Recommendations** — 3–5 bullet points, each actionable and specific (not "improve the UX")
7. **Priority matrix** — simple 2x2 or numbered list: Quick wins | Strategic investments | Monitor | Deprioritise
8. **Next steps** — who does what, by when
9. **Contact / full report link**

Write in plain language. No academic tone. Skimmable in 90 seconds.
```

---

**3. Research Highlight Reel Script**

*When to use:* You're creating a short video or audio highlight reel from session recordings to bring research to life for stakeholders who weren't in the room.

```
Write a script and curation guide for a [X]-minute research highlight reel video.

Study: [STUDY NAME]
Intended audience: [AUDIENCE]
Platform where it will be shared: [SLACK / CONFLUENCE / PRESENTATION / ALL-HANDS]
Top themes to convey: [LIST 3–5 THEMES]

Raw clip notes (describe the moments you're considering):
[LIST YOUR CANDIDATE CLIPS WITH BRIEF DESCRIPTIONS AND TIMESTAMPS]

Please produce:
1. **Clip selection rationale** — recommended [X] clips (30–60 sec each) that best represent each theme, with reason for inclusion
2. **Narration script** — voiceover or title card text to introduce each clip (keep it short — 1–2 sentences per transition)
3. **Opening frame** (15-second context-setter: what is this, why should I watch?)
4. **Closing frame** (15-second summary: what we learned, what we're doing about it)
5. **Content warnings / sensitivity notes** — anything to flag before sharing
6. **Title card suggestions** for each participant quote used (anonymised)

Tone: human, empathetic, not voyeuristic. The goal is empathy, not entertainment.
```

---

## Personas & User Profiles

**4. Persona Write-Up Generator**

*When to use:* You have synthesised user segments from research and need to write compelling, evidence-based persona narratives that feel real — not fictional marketing fluff.

```
Write a research-based persona document for the following user segment.

Research basis: [INTERVIEWS / SURVEY / ANALYTICS / MIXED — specify n]
Product context: [PRODUCT NAME AND TYPE]
Segment description (your notes):
[PASTE YOUR SEGMENT CHARACTERISTICS, BEHAVIOURS, NEEDS, FRUSTRATIONS]

For each persona, produce:
1. **Name and defining tagline** (e.g. "Maya — the reluctant adopter")
2. **Snapshot box:** role, age range, tech comfort level, primary device, frequency of product use
3. **Narrative bio** (2 short paragraphs — third person, present tense, grounded in real research patterns — no fabricated details)
4. **Goals** (3–4 — what they're ultimately trying to achieve, not just product goals)
5. **Pain points** (3–4 — specific frustrations, not generic "wants it to be easier")
6. **Behaviours** (3–4 observable patterns relevant to the product)
7. **Representative quote** (synthesised from research — clearly labelled as composite, not verbatim)
8. **"Succeed/fail" with our product:** one sentence on when the product works for them and when it breaks down
9. **Research evidence note** — which findings support this persona (reference specific data points)

Important: flag any attributes that are inferred vs. directly evidenced by research.
```

---

**5. Persona Update Brief**

*When to use:* Existing personas are outdated and you need to brief the team on what's changed and why the personas need refreshing — without starting from scratch.

```
Write a persona update brief explaining how recent research has changed or challenged existing user personas.

Existing persona(s): [DESCRIBE OR PASTE EXISTING PERSONA SUMMARIES]
New research conducted: [STUDY TYPE, N, DATE]
What changed (your notes): [KEY SHIFTS IN BEHAVIOUR, NEEDS, OR CONTEXT YOU OBSERVED]

Please produce:
1. **Update summary** — 1 paragraph explaining why the personas need updating (what changed in the world, user behaviour, or product context)
2. **Change log per persona:**
   - What stays the same (with rationale)
   - What needs to change (specific attributes — behaviours, pain points, goals)
   - What's newly discovered (attributes not in the original persona)
   - What can be retired (attributes no longer supported by evidence)
3. **Evidence citations** — which research data supports each change
4. **Recommendation:** full redraft / targeted updates / merge/split personas
5. **Process note** — how to socialise the updated personas with the team (workshop suggestion, communication plan)
```

---

## Recommendation Decks

**6. Recommendation Deck Narrative**

*When to use:* You've analysed your research and need to build the case for specific design or product recommendations in a way that connects evidence to action.

```
Write the narrative content for a UX research recommendation deck.

Research basis: [STUDY TYPE AND BRIEF DESCRIPTION]
Audience: [PRODUCT MANAGER / DESIGN LEAD / EXECUTIVE / ENGINEERING / CROSS-FUNCTIONAL]
Number of recommendations: [X]
Desired outcome of this deck: [GET APPROVAL / PRIORITISE BACKLOG / INFLUENCE ROADMAP / INFORM DESIGN SPRINT]

Recommendations (rough notes):
[YOUR RECOMMENDATIONS AND SUPPORTING DATA]

For each recommendation, write:
1. **Recommendation headline** (bold, active verb, specific — not "improve navigation")
2. **The evidence** — 2–3 sentences summarising the research that supports this recommendation
3. **User impact statement** — "Without this change, users will continue to [PROBLEM], leading to [CONSEQUENCE]"
4. **Business impact statement** — connect to a metric, revenue, retention, NPS, support cost, or risk
5. **Effort/impact label:** Quick win / Strategic / Investment / Avoid — with 1-line rationale
6. **Success metric** — how we'll know it worked
7. **"Do nothing" risk** — what happens if this isn't addressed

Also write:
- **Deck title and subtitle**
- **3-sentence deck introduction** (context, method, what you'll see)
- **Closing slide copy** — next steps, owners, timeline proposal
```

---

## Research Strategy

**7. Research Roadmap Pitch**

*When to use:* You're proposing a quarterly or annual research roadmap and need to make the case for why specific studies should be prioritised and funded.

```
Help me write a research roadmap pitch for [QUARTER / YEAR].

Context:
- Team size: [NUMBER OF RESEARCHERS]
- Product area: [PRODUCT OR PORTFOLIO]
- Business priorities this period: [LIST 2–4 COMPANY/PRODUCT PRIORITIES]
- Current research gaps: [WHAT WE DON'T KNOW THAT WE SHOULD]

Proposed studies (rough list):
[YOUR PROPOSED STUDIES]

Please produce:
1. **Opening framing** — why research investment matters right now (2–3 sentences tied to business priorities)
2. **Research question → Business question mapping** — for each proposed study, show how it answers a strategic business question
3. **Proposed roadmap** — presented as a simple table:
   | Study | Quarter | Method | Effort (days) | Answers | Priority |
4. **Rationale for prioritisation** — why this order, what's been deprioritised and why
5. **What we'll be able to decide** at the end of each study
6. **Resource ask** — what you need (researcher time, tools, participant budget) presented clearly
7. **Risk of not doing this research** — 1 paragraph on the cost of flying blind
8. **Success metrics for the research program** — how leadership will know the research team is delivering value

Tone: strategic, confident, business-literate. Not defensive.
```

---

**8. ROI of Research Argument**

*When to use:* You're making the case for research investment to a budget holder or sceptical stakeholder who thinks research slows teams down.

```
Write a persuasive ROI argument for investing in user research at [COMPANY TYPE / STAGE].

Context:
- Current research investment: [BUDGET / HEADCOUNT / NONE]
- Sceptic's main objection: [e.g. "it takes too long", "we can just A/B test", "we talk to customers anyway"]
- One recent example where research saved or created value: [BRIEF DESCRIPTION — or "none available, make it hypothetical"]
- Product type: [PRODUCT DESCRIPTION]
- Company size/stage: [STARTUP / SCALE-UP / ENTERPRISE]

Please write:
1. **The cost of guessing** — a concrete framing of what shipping without research costs (failed features, redesigns, churn, support tickets — use industry-cited examples where relevant)
2. **Research ROI case** — 3 specific, referenced examples of how research has delivered measurable value at similar companies
3. **The "speed" reframe** — a 2-paragraph argument for why research done well speeds up delivery (fewer wrong bets, faster alignment, better briefs)
4. **The minimum viable research argument** — what even 2–3 participant sessions can reveal, for sceptics who think research has to be a 6-week project
5. **Proposed investment** — frame your ask as a specific resource in return for a specific deliverable
6. **The risk register framing** — position skipping research as a risk that needs to be owned, not a default

Tone: businesslike, confident, not defensive or preachy. Assume a smart audience.
```

---

## Cross-Team Insight Sharing

**9. Cross-Team Research Insight Digest**

*When to use:* You want to proactively share research learnings with teams that weren't involved in the study, in a format they'll actually engage with.

```
Write a cross-team research digest to share insights from a recent study.

Study: [STUDY NAME AND TYPE]
Primary audience for the digest: [ENGINEERING / MARKETING / SALES / CUSTOMER SUCCESS / LEADERSHIP / ALL]
Distribution channel: [SLACK / EMAIL / CONFLUENCE / NEWSLETTER / ALL-HANDS]
Key insights (rough notes): [YOUR INSIGHTS]

Please produce:
1. **Subject line / Post title** (attention-grabbing, not academic)
2. **TL;DR** (3 bullet points — the most important things to know if you read nothing else)
3. **Why this matters to [AUDIENCE]** — a 1-paragraph "what this means for your team" tailored to the audience
4. **Top 3 insights** — each with:
   - Insight headline (plain language)
   - 2-sentence explanation
   - One supporting data point or quote
   - "What this means for [TEAM]" — 1 sentence tailored to recipient
5. **One surprising thing** — the finding that challenged our assumptions
6. **What's happening next** — what the team is doing with this research
7. **"Want to know more?"** — link to full report + offer for a 15-min walkthrough
8. **Feedback prompt** — one question asking the receiving team what they'd like to know next

Format for [SLACK / EMAIL / CONFLUENCE — choose appropriate length and formatting style].
```

---

**10. Research Repository Summary**

*When to use:* You're adding a study to your research repository (Dovetail, Notion, Confluence, etc.) and need a structured, searchable summary entry.

```
Write a research repository entry for the following study.

Study name: [NAME]
Date conducted: [DATE]
Researcher(s): [NAMES]
Method: [METHOD]
Participants: [N, BRIEF PROFILE]
Product area: [PRODUCT/FEATURE]
Research questions: [LIST]
Key findings (rough notes): [YOUR NOTES]
Recommendations made: [ROUGH LIST]
Actions taken as a result (if known): [NOTES]

Please produce a repository entry with:
1. **Study ID** (format: YYYY-MM-[METHOD ABBREVIATION]-[NUMBER] — e.g. 2024-06-INT-03)
2. **One-line study description** (for search results preview)
3. **Research questions** (bulleted, as asked)
4. **Method & participants** (structured paragraph: method, recruitment source, n, demographics, dates)
5. **Key findings** (5–7 numbered, each in one clear sentence — optimised for future searchability)
6. **Recommendations** (numbered, each actionable)
7. **What was done with this research** (decisions made, designs influenced, debates resolved)
8. **Tags** — suggest 8–12 tags for searchability (product area, method, audience type, themes)
9. **Related studies** — placeholder noting which past/future studies connect
10. **Confidence level:** High / Medium / Low — with rationale (sample size, method rigour, recency)
```

---

## Leadership Communication

**11. Leadership Research Update**

*When to use:* You're providing a regular research update to senior leadership and need it to be concise, strategic, and decision-oriented — not a project status report.

```
Write a monthly/quarterly research update for senior leadership.

Period covered: [DATE RANGE]
Leadership audience: [C-SUITE / VP LEVEL / BOARD — specify]
Studies completed this period: [LIST]
Studies in progress: [LIST]
Key insights that should influence leadership decisions: [YOUR NOTES]
Research team wins / impact this period: [NOTES]

Please produce a leadership update with:
1. **Opening headline** — the single most important thing leadership needs to know from research this period (1 sentence)
2. **Strategic insights summary** (3–5 insights that connect to business priorities — not a study-by-study recap)
3. **"This changed our thinking"** — one insight that challenged a previous assumption or reversed a decision
4. **Decisions this research enabled** — specific examples of where research directly influenced product, design, or strategy
5. **In-flight studies** — what's running and when to expect results (table format: Study | Status | Expected output | Date)
6. **Watch-outs** — 1–2 emerging user needs or risks the business should be aware of
7. **Research asks** — any decisions, resources, or access you need from leadership
8. **Metrics snapshot** (if applicable): NPS trend, CSAT, SUS benchmarks, task completion trends

Length: maximum 1 page or 5-minute read. No methodology details. No jargon.
```

---

**12. Research Impact Case Study**

*When to use:* You want to document a specific instance where research drove a meaningful outcome — for internal advocacy, performance reviews, or building the research function's credibility.

```
Write a research impact case study documenting how user research drove a specific outcome.

Situation (before research): [DESCRIBE THE PROBLEM, DECISION, OR UNCERTAINTY THE TEAM FACED]
Research conducted: [WHAT YOU DID, METHOD, N, TIMELINE]
Key finding(s): [WHAT YOU DISCOVERED]
Decision or action taken: [WHAT CHANGED AS A RESULT]
Outcome (if measurable): [METRICS, FEEDBACK, OR QUALITATIVE EVIDENCE OF IMPACT]

Please write:
1. **Case study title** (impact-focused, e.g. "How 6 user interviews prevented a £200k rebuild")
2. **The challenge** (2–3 sentences — what was at stake, what assumptions the team held)
3. **The research** (2–3 sentences — what was done, who was involved, how quickly)
4. **What we found** (3 bullet points — the key insights)
5. **What changed** (specific decision, design change, or strategic pivot)
6. **The impact** (quantified where possible — time saved, cost avoided, metric improvement, risk reduced)
7. **The quote** (a stakeholder reaction or team member reflection on the research value)
8. **Lesson learned** (one transferable insight about the value of this type of research)

Format: suitable for an internal Notion page, slide, or portfolio piece.
```

---

## Design Critique & Facilitation

**13. Design Critique Facilitation Guide**

*When to use:* You're facilitating or contributing to a design critique and want to ensure feedback is evidence-based, structured, and actionable — not just opinions.

```
Create a facilitation guide for a design critique session grounded in research evidence.

Design being reviewed: [WHAT IS BEING CRITIQUED — feature, flow, full product]
Session participants: [ROLES]
Session length: [X] minutes
Research available to inform the critique: [STUDIES, PERSONAS, USABILITY DATA — brief list]
Known design goals: [WHAT THE DESIGN IS TRYING TO ACHIEVE]

Please produce:
1. **Pre-read document** (sent to participants before the session):
   - Design context and goals
   - Relevant research summary (3–5 bullet points)
   - 3 specific questions the team wants feedback on
   - "What good looks like" criteria

2. **Session agenda** with time allocations

3. **Facilitation prompts** for each phase:
   - Observation phase: "What do you notice?" (no judgement yet)
   - Research connection: "Where does this align with or contradict what we know about users?"
   - Critique phase: structured feedback format (What works / What could be stronger / Questions it raises)
   - Prioritisation: how to stack-rank feedback

4. **"Research check" prompts** — questions to redirect opinion-based feedback toward evidence:
   - List 5 redirects (e.g. "Do we have data on how users approach this?")

5. **Capture template** — note-taking format for the session

6. **Closing prompt** — what does the designer need to leave with clarity on?
```

---

**14. Research Findings to Design Brief**

*When to use:* You're handing off research insights to a design team and want to write a brief that translates findings into clear design direction — not just a PDF they'll ignore.

```
Write a research-informed design brief based on the following findings.

Research conducted: [STUDY TYPE, N, DATE]
Design team receiving the brief: [TEAM NAME / ROLE]
Design challenge: [WHAT NEEDS TO BE DESIGNED OR REDESIGNED]
Research findings (rough notes): [YOUR FINDINGS]
Business constraints: [TIMELINE, PLATFORM, TECHNICAL LIMITS]

Please produce a design brief with:
1. **Brief title and date**
2. **Context** — why this design challenge exists and what the current experience is
3. **Users** — who we're designing for (reference personas or segments by name)
4. **Insights that must drive the design** (3–5 research-backed imperatives, each framed as: "Because [finding], the design must [design principle]")
5. **The core problem to solve** — one "How Might We" question synthesised from the research
6. **Success criteria** — how the design team will know they've solved the problem (measurable where possible)
7. **Constraints** — what the design cannot do (technical, business, accessibility requirements)
8. **Open questions** — what research hasn't answered yet that the design process might surface
9. **Suggested early exploration directions** — 2–3 springboard ideas (not prescriptive solutions)
10. **Research support available** — what the researcher can do to support the design process (reviews, guerrilla tests, etc.)
```

---

**15. Stakeholder Objection Handler**

*When to use:* You're about to present findings and anticipate pushback — or you've already faced objections and need sharp, evidence-based responses.

```
Help me prepare responses to stakeholder objections about user research findings.

Research being challenged: [BRIEF DESCRIPTION OF FINDINGS]
Stakeholder role: [PM / EXEC / ENGINEER / MARKETING / OTHER]
Objections I anticipate (or have already heard):
1. [OBJECTION 1 — e.g. "These are just 8 people, this isn't statistically significant"]
2. [OBJECTION 2 — e.g. "Our users aren't like that"]
3. [OBJECTION 3 — e.g. "We already know this from support tickets"]
4. [OBJECTION 4 — add any others]

For each objection, write:
1. **Why the objection makes sense** (steelman it — acknowledge the legitimate concern underneath)
2. **The response** — factual, confident, not defensive (2–4 sentences)
3. **The evidence** — specific data point or analogy that supports the response
4. **When to agree** — if the objection has merit, what to concede and what to offer instead
5. **The follow-up offer** — what additional research or data you could provide to address the concern

Also provide:
- **General objection-handling principles** for research presentations (5 bullet points)
- **The one thing NOT to say** when challenged on sample size (and what to say instead)
```

---

*These 15 prompts are most powerful when paired with the analysis prompts in file 03 and the workflow SOPs in file 06.*
