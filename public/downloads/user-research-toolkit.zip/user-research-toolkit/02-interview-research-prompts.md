# 02 · Interview & Research Prompts

**25 prompts for user interview guides, recruiting emails, screener surveys, moderation scripts, follow-up questions, and remote interview setup.**

---

## Interview Guide Creation

---

### Prompt 1: Full Interview Guide Builder

**Complete discovery or evaluative interview guide with probes and structure**

*When to use: Starting a new research study and need a complete, professional interview guide from scratch. Works for discovery, generative, and evaluative research.*

```
You are an expert UX researcher with deep experience in conducting qualitative user interviews. 

Create a complete user interview guide for the following study:

Product/Feature: [PRODUCT OR FEATURE NAME]
Research Goal: [WHAT QUESTION ARE YOU TRYING TO ANSWER — e.g., "Understand how small business owners currently manage invoicing and where they experience the most friction"]
Target Participant: [SPECIFIC USER SEGMENT — e.g., "Freelance designers, 5+ years experience, $50k+ annual revenue, uses at least one invoicing tool"]
Session Length: [E.G., 45 MINUTES / 60 MINUTES]
Research Phase: [DISCOVERY / GENERATIVE / EVALUATIVE]
Moderator Experience Level: [JUNIOR / SENIOR — affects how many explicit probes to include]

Structure the guide as follows:
1. Introduction script (2–3 minutes) — warm welcome, explain purpose without revealing hypotheses, consent/recording reminder
2. Warm-up questions (3–5 minutes) — rapport-building, not product-specific
3. Context-setting questions (5–10 minutes) — current behavior, habits, workarounds
4. Core research questions (20–30 minutes) — [NUMBER] questions, each with 2–3 follow-up probes
5. Concept/feature exploration (if evaluative — 10–15 minutes)
6. Closing questions (5 minutes) — catch-all, what would surprise them, anything they want to add
7. Outro script — appreciation, next steps, how data will be used

For each core question:
- Write the primary question (open-ended, non-leading)
- Include 2–3 follow-up probes labeled as (Probe:)
- Add a brief moderator note in italics when a question needs special handling

Tone: [WARM AND CONVERSATIONAL / PROFESSIONAL / CLINICAL]
Avoid: Jargon, leading questions, double-barreled questions, yes/no questions
```

---

### Prompt 2: Topic-First Interview Question Generator

**Generate targeted questions around a specific theme or hypothesis**

*When to use: You already have a rough guide but need stronger questions around a specific topic, behavior, or hypothesis you want to explore.*

```
You are a senior UX researcher known for asking questions that reveal unexpected insights.

I'm conducting user interviews about [TOPIC/THEME — e.g., "how people make decisions when choosing a streaming service"]. 

My hypotheses to explore (without telegraphing them to participants):
1. [HYPOTHESIS 1]
2. [HYPOTHESIS 2]
3. [HYPOTHESIS 3]

Generate 10 open-ended interview questions that:
- Explore these themes without stating the hypotheses explicitly
- Use "show me," "tell me about a time," and "walk me through" framing where appropriate
- Progress from broad/contextual to specific/detailed
- Include at least 3 questions that explore emotional or identity dimensions of the behavior
- Include at least 2 "extreme user" probes (asking about best/worst/most memorable experiences)

For each question, add a one-line note explaining which hypothesis or insight it targets.

Format: Numbered list, question in bold, hypothesis note in italics below.
```

---

### Prompt 3: Jobs-to-Be-Done Interview Script

**Interview guide specifically built around the JTBD framework**

*When to use: You're researching why users "hire" a product, what progress they're trying to make, and what competing solutions they consider. Ideal for positioning and product strategy research.*

```
You are a UX researcher skilled in the Jobs-to-Be-Done research methodology.

Create a Jobs-to-Be-Done interview guide for:
Product Category: [E.G., PROJECT MANAGEMENT TOOLS / MEAL KIT SERVICES / TAX SOFTWARE]
Target User: [USER SEGMENT — be specific about context of use]

The guide should follow the JTBD interview arc:
1. Anchor moment — explore the first time they used this type of solution
2. Timeline reconstruction — walk back through the decision to start looking
3. Passive looking — what triggered awareness of a problem
4. Active looking — how they evaluated options
5. The switch moment — what made them finally act
6. Consumption — how use has evolved over time
7. Satisfaction gaps — what "good enough" actually means

For each stage, write:
- 2 primary interview questions
- Specific follow-up probes that pull on timeline, emotion, and alternatives considered

Also include:
- An intro script that frames this as a conversation about their experience (not a product interview)
- A moderator cheat sheet with 5 universal JTBD probes they can use anywhere in the conversation
- 3 questions that specifically uncover the "struggling moment" that made change feel necessary
```

---

### Prompt 4: Diary Study Prompt Set

**Diary study entry prompts and reflection questions**

*When to use: Running a longitudinal diary study and need structured prompts participants will respond to over days or weeks.*

```
You are a UX researcher designing a diary study to capture in-context behavior over time.

Study Context:
Topic: [WHAT BEHAVIOR OR EXPERIENCE YOU'RE TRACKING]
Duration: [NUMBER] days/weeks
Participant Profile: [USER SEGMENT]
Submission Frequency: [DAILY / AFTER EACH RELEVANT EVENT / WEEKLY]
Submission Method: [APP / EMAIL / FORM / VIDEO]

Create:
1. A set of [NUMBER] daily/event-triggered diary prompts that:
   - Are short enough to answer in 3–5 minutes
   - Mix structured (scale, yes/no) with open-ended responses
   - Capture: what happened, emotional state, what they tried, what worked/didn't, context details
   - Avoid priming participants toward your hypotheses

2. A weekly reflection prompt (5–7 questions) for deeper retrospective insight

3. An onboarding message explaining how to submit entries (tone: friendly and encouraging, not clinical)

4. A reminder message template for participants who haven't submitted in [NUMBER] days

Each prompt should feel like a natural check-in, not a research interrogation. 
Format as clearly numbered, copy-paste ready sections.
```

---

## Recruiting & Screener Surveys

---

### Prompt 5: Participant Recruiting Email — Cold Outreach

**Professional recruiting email for reaching out to potential participants**

*When to use: Recruiting participants via email from a customer list, LinkedIn, panel, or community. Needs to be compelling enough to get replies without revealing too much about what you're testing.*

```
You are a UX researcher writing a recruiting email to find participants for a user study.

Study Details:
Product/Company: [COMPANY OR PRODUCT NAME]
What You're Studying: [BRIEF, NON-REVEALING DESCRIPTION — e.g., "how people manage their work schedules"]
Participant Profile: [WHO YOU'RE LOOKING FOR, SPECIFICALLY]
Session Format: [REMOTE VIDEO CALL / IN-PERSON / SURVEY]
Session Length: [E.G., 45 MINUTES]
Incentive: [DOLLAR AMOUNT / GIFT CARD TYPE / "NO COMPENSATION — CONTRIBUTION TO RESEARCH"]
Study Dates: [DATE RANGE]
Scheduling Link or Contact: [URL OR EMAIL]

Write 2 versions of a recruiting email:

Version A: Short and punchy (under 100 words)
- Lead with the incentive and time commitment
- One-line description of what the study is about
- Clear CTA

Version B: Relationship-driven (150–200 words)
- Open by acknowledging the recipient's expertise or experience
- Explain the broader value of their participation
- Build trust with transparency about how data will be used
- Clear CTA

Both should:
- Have a subject line option (write 3 subject line variants for each)
- Avoid sounding like spam or a mass email
- Not reveal what specific product, feature, or hypothesis is being tested
- Include an easy opt-out line
```

---

### Prompt 6: Screening Survey Builder

**Participant screener that qualifies the right people without tipping them off**

*When to use: You need a screener survey to identify qualified participants before scheduling — especially when you need specific behaviors, tools used, or experience levels.*

```
You are a UX research recruiter building a screener survey to find ideal study participants.

Study Requirements:
Product/Topic: [WHAT YOU'RE RESEARCHING]
Ideal Participant: [DETAILED DESCRIPTION — demographics, behaviors, tools, frequency of use, job role, etc.]
Disqualifying Criteria: [WHO SHOULD NOT PARTICIPATE — competitors, researchers, people who've done research studies in past X months, etc.]
Number of Participants Needed: [TARGET N]
Survey Platform: [TYPEFORM / GOOGLE FORMS / QUALTRICS / OTHER]

Create a screener survey with:
1. Intro message (2–3 sentences, friendly, explains participation without revealing research topic)
2. [NUMBER] screening questions that:
   - Start with soft demographic/behavioral questions to warm up
   - Include questions that disqualify without telegraphing why
   - Use a mix of multiple choice, ranking, and 1–2 open-ended questions
   - Identify must-have vs. nice-to-have participant qualities
3. Qualifying logic notes (e.g., "If answer to Q4 is X or Y → qualified; Z → disqualify")
4. A thank-you/next-steps message for qualified participants
5. A polite decline message for non-qualified participants

Avoid: Mentioning specific product features, competitor names in ways that tip off the study focus, or any question that allows participants to fake qualification.
```

---

### Prompt 7: Recruiting Criteria Document

**Internal document defining participant criteria for a research study**

*When to use: Writing up participant criteria for a recruiting agency, research ops team, or when handing off recruiting to someone else on the team.*

```
Act as a senior UX researcher writing a participant recruiting brief for a research recruiting agency or internal research ops team.

Study:
Research Topic: [TOPIC]
Research Goals: [2–3 BULLET GOALS]
Study Type: [INTERVIEWS / USABILITY TEST / SURVEY / DIARY STUDY]
Number of Sessions: [N] sessions across [N] participant segments (if segmented)
Session Length: [DURATION]
Study Dates: [DATE RANGE]
Format: [REMOTE / IN-PERSON / HYBRID]
Incentive: [AMOUNT AND TYPE]

Write a complete recruiting criteria document including:
1. Primary participant profile (must-haves)
2. Secondary participant profile (nice-to-haves for diversity of perspective)
3. Explicit disqualification criteria with reasons
4. Demographic diversity targets (age range, gender balance, geography if relevant)
5. Behavioral requirements (specific actions, tools, or experiences participants must have)
6. Recruitment source recommendations (where to find these participants)
7. A note on any sensitive topics to handle with care during recruitment

Format: Professional brief suitable to send to an external recruiting agency.
Length: 400–600 words.
```

---

### Prompt 8: Panel Recruitment Post — Community/Social

**Social post or community post to recruit research participants**

*When to use: Recruiting participants organically through LinkedIn, Reddit, Slack communities, or niche online groups.*

```
Write a participant recruitment post for [PLATFORM — e.g., LinkedIn / Reddit / Slack community / Twitter/X].

Study Details:
Topic: [GENERAL DESCRIPTION — non-revealing]
Who You're Looking For: [SPECIFIC USER PROFILE]
Time Commitment: [SESSION LENGTH]
Format: [REMOTE / IN-PERSON]
Incentive: [COMPENSATION OR "YOUR FEEDBACK HELPS SHAPE THE FUTURE OF..."]
Sign-up Link: [URL PLACEHOLDER]

Requirements for the post:
- Match the tone and norms of [PLATFORM] (LinkedIn = professional; Reddit = conversational; Slack = direct)
- Lead with what participants get (incentive, impact, or both)
- Be specific about who qualifies without making it sound restrictive
- Include 3 hashtag options (for LinkedIn/Twitter)
- Under [150 / 200 / 250] words
- Sound like a real person wrote it, not a marketing department

Write 2 versions: one that leads with the incentive, one that leads with the impact/mission angle.
```

---

## Moderation & Interview Facilitation

---

### Prompt 9: Moderation Script for Usability Studies

**Step-by-step facilitation guide for usability test sessions**

*When to use: Preparing to moderate a usability test, especially when you're newer to moderation or testing a complex flow. Ensures consistency across moderators.*

```
You are a senior UX researcher with 10+ years of usability testing experience.

Create a complete moderation script for a usability test with the following specs:

Product: [PRODUCT NAME AND BRIEF DESCRIPTION]
Features Being Tested: [LIST THE SPECIFIC FLOWS OR FEATURES]
Participant Profile: [USER SEGMENT]
Session Length: [DURATION]
Format: [MODERATED REMOTE / MODERATED IN-PERSON / UNMODERATED]
Number of Tasks: [N] tasks
Think-Aloud Protocol: [YES — prompted / YES — concurrent / NO]

The script should include:
1. Pre-session checklist (what moderator sets up before participant joins)
2. Welcome and orientation script (verbatim)
3. Think-aloud explanation and practice task
4. Consent/recording confirmation script
5. Introduction to each task (written as read-aloud prompts — neutral, non-leading)
6. Transition phrases between tasks
7. Stuck-participant intervention guide (what to say when someone is completely lost — and when to intervene vs. observe)
8. Post-task questions after each task (2–3 questions per task)
9. Post-test debrief questions (5–7 questions)
10. Closing script

Moderator notes throughout in [brackets] to flag timing, watch-fors, and common participant behaviors to observe.
```

---

### Prompt 10: Think-Aloud Priming Script

**Training participants on thinking aloud before the session starts**

*When to use: Before every moderated usability study to establish the think-aloud protocol and reduce the awkwardness that makes participants clam up.*

```
Write a think-aloud priming script for use at the start of a usability test session.

Participant Context: [GENERAL AUDIENCE TYPE — e.g., non-technical consumers / enterprise software users / older adults]
Session Tone: [CASUAL AND FRIENDLY / FORMAL / CLINICAL]

The script should:
1. Explain what "thinking aloud" means in plain language (no research jargon)
2. Emphasize that you're testing the product, not the participant — with genuine warmth
3. Include a practice task that gets participants comfortable before the real test begins
4. Address the three most common reasons participants go silent:
   - They think they're doing it wrong
   - They get stuck and feel embarrassed
   - They're too focused to narrate
5. Give the moderator 2–3 natural intervention phrases to use when the participant goes quiet

Write in a conversational, warm tone. The script should take approximately [3–5] minutes to deliver.
Avoid research jargon. Write as if speaking to someone who has never participated in research before.
```

---

### Prompt 11: Bias Audit for Interview Guides

**Check your interview guide for common qualitative research biases**

*When to use: After drafting an interview guide, before running the study. Catches leading questions, confirmation bias, and acquiescence bias.*

```
You are an expert in research methodology and cognitive bias. 

Please audit the following user interview guide for research quality issues. Check for:

1. Leading questions (that suggest a preferred answer)
2. Double-barreled questions (asking two things at once)
3. Yes/no questions (closed when they should be open)
4. Acquiescence bias triggers (questions that invite agreement)
5. Confirmation bias (questions that only explore one side of a hypothesis)
6. Loaded language (words with emotional valence that prime responses)
7. Sequence effects (earlier questions that may prime or bias later ones)
8. Social desirability bias risks (questions where participants may answer to look good)

For each issue found:
- Quote the problematic question
- Name the bias type
- Explain the risk
- Rewrite the question to fix the issue

After the audit, give an overall quality score (1–10) with a brief justification.

Here is the interview guide to audit:
[PASTE YOUR FULL INTERVIEW GUIDE HERE]
```

---

### Prompt 12: Follow-Up Question Bank

**Deep-dive probes for when participants give surface-level answers**

*When to use: During interview prep. Print this and keep it next to your screen. Pull from it when a participant's answer is thin and you need to go deeper without leading.*

```
You are a master interviewer who specializes in getting past surface-level answers to uncover genuine behavior and motivation.

Generate a comprehensive follow-up question bank organized by situation type, for use during user interviews about [RESEARCH TOPIC / PRODUCT CATEGORY].

Create 5–6 follow-up probes for each of these situations:

1. When a participant gives a vague answer ("It's fine," "I just do it," "It's complicated")
2. When a participant mentions a feeling or emotion but doesn't elaborate
3. When a participant describes a past behavior you want to understand more deeply
4. When a participant mentions a workaround or hack they've developed
5. When a participant mentions a frustration or pain point briefly
6. When a participant says something that contradicts what they said earlier
7. When a participant gives a suspiciously positive answer (possible social desirability bias)
8. When a participant goes off-topic but the tangent might be valuable
9. When a participant uses a specific word or phrase you want to understand better
10. When a participant describes a decision they made

Format: Grouped by situation, each probe on its own line. Mark the strongest probe in each group with ⭐.
These should feel natural to say out loud during a conversation — not academic or clinical.
```

---

### Prompt 13: Sensitive Topic Interview Protocol

**Interview guide for research involving sensitive subjects**

*When to use: Your research touches on health, finances, trauma, discrimination, relationship issues, or any topic where participants may feel vulnerable.*

```
You are a trauma-informed UX researcher with experience in sensitive topic research.

I need to conduct user interviews about [SENSITIVE TOPIC — e.g., financial hardship / health conditions / experiences of discrimination / grief / relationship challenges].

Create a modified interview protocol that:

1. Opening safeguards:
   - Consent language that clearly explains topic sensitivity and the right to skip questions
   - How to create a psychologically safe environment in the first 3 minutes
   - Trauma-informed framing language

2. Question adaptations:
   - Rewrite these [N] questions to use safer, more distanced framing:
     [PASTE YOUR ORIGINAL QUESTIONS]
   - Add "permission structure" language before sensitive sections
   - Include "escape hatch" options at each sensitive question

3. Moderator interventions:
   - What to say if a participant becomes distressed
   - How to redirect without minimizing their experience
   - When and how to offer to pause or end the session

4. Closing protocol:
   - Debrief language that doesn't re-traumatize
   - Resources to offer participants if relevant
   - Aftercare guidance for the moderator (secondary trauma is real)

5. Data handling notes:
   - Anonymization reminders for sensitive disclosures
   - What should NOT appear in research reports even if shared
```

---

## Remote Interview Setup

---

### Prompt 14: Remote Research Session Setup Checklist

**Complete technical and logistical setup guide for remote interviews**

*When to use: When onboarding a new team member to run remote sessions, or standardizing your remote research operations.*

```
You are a research operations specialist creating a standardized setup guide for remote user research sessions.

Our Setup:
Video Platform: [ZOOM / TEAMS / MEET / LOOKBACK / USERZOOM / OTHER]
Recording Tool: [BUILT-IN / OTTER.AI / DOVETAIL / OTHER]
Prototype/Product Being Tested: [TYPE — live product, Figma prototype, website, etc.]
Session Type: [INTERVIEW / USABILITY TEST / CO-CREATION]
Number of Sessions Per Week: [N]
Team Size: [HOW MANY RESEARCHERS RUNNING SESSIONS]

Create a comprehensive remote session setup guide including:

1. Pre-session checklist (day before)
2. Pre-session checklist (30 minutes before)
3. Participant confirmation email template (send 24 hours prior)
4. Tech check script (first 2 minutes of session)
5. Backup plan protocols for: 
   - Audio issues
   - Video issues
   - Participant can't share screen
   - Platform crashes mid-session
   - Participant joins late
6. Observer guidelines (for teammates watching live)
7. Note-taking template for observers
8. Post-session checklist (file naming, storage, follow-up tasks)

Format as a practical operations doc with checkboxes where appropriate.
```

---

### Prompt 15: Participant Preparation Email

**Email to send participants before a remote research session**

*When to use: 24–48 hours before any remote research session. Reduces no-shows, tech issues, and awkward session starts.*

```
Write a participant preparation email to send [24 HOURS / 48 HOURS] before a remote user research session.

Session Details:
Date/Time: [DATE AND TIME WITH TIMEZONE]
Platform: [VIDEO PLATFORM]
Session Link: [LINK PLACEHOLDER]
Session Type: [INTERVIEW / USABILITY TEST / CO-CREATION WORKSHOP]
Session Length: [DURATION]
Moderator Name: [YOUR NAME]
Company/Team: [COMPANY OR TEAM NAME]
Incentive Reminder: [IF APPLICABLE]
Tech Requirements: [E.G., "Please join from a computer, not mobile. You'll need to share your screen."]

The email should:
1. Confirm the appointment clearly (date, time, timezone, length)
2. Explain what to expect in the session (without revealing what you're testing)
3. Provide any tech setup instructions (screen sharing, audio check, etc.)
4. Set expectations about recording (if applicable)
5. Give a contact method if they have issues connecting
6. Include a calendar invite attachment note
7. Have a warm but professional tone

Keep it under 200 words. Participants shouldn't need to read it twice to understand what to do.
Also write a 1-line reminder message for the day of the session (suitable for SMS or calendar event).
```

---

### Prompt 16: Unmoderated Study Setup Guide

**Instructions and task prompts for unmoderated research**

*When to use: Running unmoderated usability tests or research through platforms like UserTesting, Maze, or Lookback async.*

```
You are a UX researcher creating an unmoderated study for [PLATFORM — e.g., Maze / UserTesting / Lookback Async].

Product Being Tested: [PRODUCT DESCRIPTION]
User Tasks to Complete: [LIST THE TASKS — e.g., "Find and book an appointment," "Complete the checkout flow"]
Participant Profile: [WHO SHOULD TAKE THIS STUDY]
Study Goal: [WHAT YOU'RE TRYING TO LEARN]

Create:
1. Study introduction (participant-facing) — 50–75 words
   - What they'll be doing (without revealing what's being evaluated)
   - Reminder to think aloud
   - Estimated time

2. For each task, write:
   - Task scenario (realistic framing that gives context without leading)
   - Task success criteria (internal note — not shown to participant)
   - 1 post-task question (single ease scale + open-ended follow-up)

3. Post-study survey (5–7 questions):
   - 2 rating scales (overall experience, confidence)
   - 2–3 open-ended questions about what was easy/hard/confusing
   - 1 likelihood to use/recommend question

4. Screener questions (3–5) to add as a pre-study gate

Write all participant-facing copy in plain, friendly language at a [8th GRADE / GENERAL ADULT] reading level.
```

---

### Prompt 17: Interview Debrief Template

**Post-interview reflection and note capture template**

*When to use: Immediately after each interview session to capture hot observations before they fade.*

```
Create a structured post-interview debrief template that a UX researcher fills out within 30 minutes of completing a session.

Research Context:
Study Topic: [TOPIC]
Key Research Questions: [LIST 3–5 QUESTIONS]

The template should include:
1. Session metadata (participant ID, date, duration, moderator name)
2. Top 3 most surprising or unexpected observations from this session
3. Evidence for each of our key research questions (one section per question)
4. Memorable quotes (3–5, verbatim with timestamp)
5. Observed behaviors that differed from self-reported behaviors
6. Emerging patterns (things you're starting to see across sessions)
7. Questions or hypotheses this session raised
8. Clips to pull for highlight reels (timestamp + description)
9. Recruiting/methodology notes (e.g., "this participant type doesn't work, need X instead")
10. Raw notes dump (free-form section)

Format as a fillable template with field headers and brief instructions for each section.
Keep it fast to fill in — total completion time should be under 15 minutes.
```

---

### Prompt 18: Research Consent Form Language

**Participant consent language for user research sessions**

*When to use: Creating or updating your consent form, particularly for recorded sessions, data storage, or sensitive research.*

```
You are a UX researcher with knowledge of research ethics and basic privacy law requirements.

Draft participant consent language for:
Study Type: [INTERVIEW / USABILITY TEST / DIARY STUDY / SURVEY]
Recording: [VIDEO + AUDIO / AUDIO ONLY / NO RECORDING]
Data Storage: [HOW LONG AND WHERE — e.g., "encrypted company servers for 2 years"]
Data Use: [HOW CLIPS/QUOTES MIGHT BE USED — e.g., "internal presentations only / external case studies / published research"]
Participant Anonymization: [FULL ANONYMITY / PSEUDONYM / IDENTIFIED]
Company Location/Jurisdiction: [COUNTRY/STATE — for GDPR, CCPA, or other compliance]

Write consent form language that:
1. Is written at an 8th-grade reading level (plain language)
2. Clearly states what participants are consenting to
3. States explicitly what they are NOT consenting to
4. Explains the right to withdraw at any time without consequence
5. States how to contact the team with concerns
6. Covers recording consent separately and clearly
7. Includes data storage and deletion language
8. Is suitable for oral confirmation (for sessions where written forms aren't practical)

Also write a verbal consent check script for moderators to use at the start of a recorded session.

Note: This is a template to be reviewed by your legal team before use.
```

---

### Prompt 19: Longitudinal Research Check-In Script

**Check-in scripts for multi-week or multi-session research studies**

*When to use: Running a longitudinal study (diary study, panel, or multi-session research) and need consistent check-in scripts across touchpoints.*

```
You are a UX researcher maintaining participant engagement in a longitudinal research study.

Study Details:
Study Type: [DIARY STUDY / LONGITUDINAL INTERVIEW SERIES / EXTENDED PANEL]
Duration: [NUMBER] weeks
Check-in Frequency: [DAILY / WEEKLY / BI-WEEKLY]
Research Topic: [WHAT YOU'RE TRACKING OVER TIME]
Participant Commitment Level: [HIGH-TOUCH / LIGHT — affects tone]

Create check-in communication templates for:
1. Week 1 / Session 1: Onboarding and expectations-setting
2. Mid-study: Re-engagement message (catches participants who've gone quiet)
3. Milestone check-in at the [MIDPOINT]: Brief reflection prompts (3–4 questions)
4. Final session: Retrospective wrap-up questions (5 questions covering the full arc)
5. Study completion: Thank-you and next steps message

For each template:
- Subject line (for email) or first line (for SMS/app)
- Body copy (voice: warm, personal — like a real human relationship, not a notification)
- 1–2 specific prompts or questions relevant to that touchpoint

Keep all participant-facing messages under 150 words.
Include a note on timing recommendations (what day/time of week to send each check-in).
```

---

### Prompt 20: Guerrilla Research Script

**Quick script for hallway testing or informal pop-up research**

*When to use: You have 10 minutes and a willing participant (colleague, conference attendee, café customer). You need to extract useful signal fast.*

```
Create a guerrilla research script for quick, informal user testing in [LOCATION — e.g., a conference, café, office hallway, store].

Product/Feature to Test: [WHAT YOU HAVE TO SHOW THEM]
Primary Question to Answer: [ONE SPECIFIC THING YOU WANT TO LEARN]
Time Available: [5 / 10 / 15 MINUTES]

Script requirements:
1. Cold approach line (how to ask a stranger to give you a few minutes)
2. 30-second explanation of what you're doing and why
3. 2–3 observation tasks or questions that fit the time constraint
4. One key thing to observe or one key question to ask
5. A natural close (thank them, ask if they have questions)

Also include:
- A list of 3 things to always observe/record even in informal sessions
- Note-capture shorthand guide (symbols or codes for fast documentation)
- How to document consent verbally for informal contexts

Tone: Conversational, low-pressure. This should feel like a friendly conversation, not a research session.
```

---

### Prompt 21: Multi-Site Research Coordination Guide

**Coordination protocols for research across multiple locations or teams**

*When to use: Running a distributed research study across multiple offices, countries, or with multiple research teams who need to stay aligned.*

```
You are a research operations lead coordinating a multi-site user research study.

Study Details:
Number of Sites/Teams: [N] — [LIST LOCATIONS OR TEAM NAMES]
Total Sessions: [N] sessions per site
Timeline: [START DATE] to [END DATE]
Research Method: [INTERVIEWS / USABILITY TESTS / SURVEYS / MIXED]
Coordination Challenge: [DESCRIBE SPECIFIC COMPLEXITY — e.g., "Two teams in different time zones using different tools" or "External research agency + internal team"]

Create a coordination guide including:
1. Standardization requirements (what MUST be consistent across sites)
2. Acceptable variation (what each team can adapt to their context)
3. Shared materials checklist
4. Communication cadence (how teams share progress and blockers)
5. Data collection standards (file naming, storage location, format)
6. Quality assurance check — how to audit that all sites are running sessions consistently
7. Synthesis coordination plan (how data from all sites gets combined)

Format as a brief but complete operations handbook.
```

---

### Prompt 22: Stakeholder Interview Guide

**Interview guide for interviewing internal stakeholders, not end users**

*When to use: Before starting a research project, you need to interview product managers, engineers, execs, or other internal stakeholders to understand their assumptions, priorities, and what they need to learn.*

```
You are a UX researcher conducting internal stakeholder interviews before a research project begins.

Context:
Product/Initiative: [PRODUCT OR FEATURE BEING RESEARCHED]
Stakeholder Role: [E.G., VP OF PRODUCT / ENGINEERING LEAD / CUSTOMER SUCCESS MANAGER]
Purpose: Understand their assumptions, goals, risks, and what they need from this research

Create a stakeholder interview guide that uncovers:
1. Their current mental model of the problem/user
2. Their hypotheses (stated and unstated)
3. What decisions this research needs to inform
4. What they already believe they know (to surface potential bias)
5. What would surprise them
6. What would be "bad news" and how would they react
7. Success criteria for the research from their perspective
8. Timeline and scope constraints they're working under

Include:
- 8–10 interview questions (30-minute session)
- Notes on how to probe for assumptions hidden behind confident statements
- A "translation guide" — how to take what a stakeholder says and identify the underlying research question
- How to close the interview with aligned expectations about what the research will and won't answer

Tone: Collegial and collaborative — this is a peer conversation, not an interrogation.
```

---

### Prompt 23: International/Cross-Cultural Research Adaptation

**Adapt research materials for different cultural contexts**

*When to use: Conducting research in markets or with participants whose cultural norms differ from the team's home culture — especially around directness, authority, disagreement, and privacy.*

```
You are a UX researcher with cross-cultural research experience adapting materials for international studies.

Original Research Materials: [PASTE YOUR GUIDE OR DESCRIBE IT]
Original Context: [COUNTRY/CULTURE THIS WAS DESIGNED FOR]
Target Context: [COUNTRY/CULTURE YOU'RE ADAPTING FOR]

Key cultural dimensions to address:
- Directness: [HOW DIRECT IS ACCEPTABLE IN THE TARGET CULTURE?]
- Authority/Hierarchy: [HOW DOES STATUS AFFECT THE INTERVIEW DYNAMIC?]
- Collectivism vs. Individualism: [HOW DOES THIS CHANGE WHAT GETS DISCUSSED OPENLY?]
- Uncertainty avoidance: [HOW COMFORTABLE ARE PARTICIPANTS WITH AMBIGUITY?]
- Time orientation: [DOES PUNCTUALITY, SESSION LENGTH, OR PACING NEED TO ADJUST?]

Adapt the materials by:
1. Rewriting questions that assume [ORIGINAL CULTURE] norms
2. Flagging language or concepts that don't translate well
3. Suggesting local analogies or reference points to replace generic examples
4. Modifying the moderator's role (more/less formal, different relationship norms)
5. Recommending local recruiter involvement and why
6. Noting any topics that are culturally sensitive in the target context

Output: Side-by-side comparison of original vs. adapted materials with annotations.
```

---

### Prompt 24: Research Study Overview Document

**Internal alignment document summarizing a research study plan**

*When to use: Before you start any research study, create this document to align stakeholders, get feedback on the plan, and document your research design decisions.*

```
You are a UX researcher writing a study overview document to align internal stakeholders before fieldwork begins.

Study Details:
Research Goal: [WHAT QUESTION DOES THIS ANSWER]
Business Context: [WHY THIS MATTERS NOW — what decision does it inform]
Research Method: [WHAT YOU'RE DOING AND WHY]
Participants: [WHO, HOW MANY, HOW RECRUITED]
Timeline: [KEY MILESTONES]
Deliverables: [WHAT STAKEHOLDERS WILL RECEIVE AT THE END]
Limitations: [KNOWN CONSTRAINTS]

Write a 1-page study overview document that includes:
1. Research question (the headline — what are we trying to answer)
2. Background and context (why now, why this method, why these users)
3. Study design (method, participants, timeline)
4. What we will and won't learn from this study
5. How to participate (for stakeholders who want to observe)
6. Deliverables and timeline
7. Contact for questions

Tone: Clear and concise. This document will be shared with non-research stakeholders who need the "so what" quickly.
Length: 400–500 words maximum.
Format: Use headers, short paragraphs. No research jargon without explanation.
```

---

### Prompt 25: Research Debrief Session Facilitator Guide

**Guide for facilitating team debriefs after research fieldwork**

*When to use: After completing field research (interviews, usability tests) with a team of observers. Structured debrief sessions prevent bias from groupthink and ensure all observations are captured.*

```
You are a UX researcher facilitating a team debrief session after completing [NUMBER] research sessions.

Debrief Context:
Research Method: [INTERVIEW / USABILITY TEST / ETHNOGRAPHIC STUDY]
Number of Sessions Completed: [N]
Team Attending Debrief: [ROLES PRESENT — e.g., researcher, designer, PM, engineer]
Time Available for Debrief: [DURATION — e.g., 90 minutes]
Goal: Capture observations before interpretation begins; prevent premature consensus

Create a complete debrief facilitation guide including:
1. Pre-debrief setup (room/virtual setup, materials needed, ground rules to establish)
2. Warm-up activity (5–10 min): Individual silent observation capture before group discussion
3. Round-robin observation sharing protocol (prevents loudest voice bias)
4. Structured discussion prompts:
   - What patterns did you notice?
   - What surprised you?
   - What challenged your assumptions?
   - What did you notice that others might have missed?
5. A method for organizing observations in real-time (e.g., affinity notes on digital whiteboard)
6. Conflict resolution protocol: What to do when team members disagree about what they observed
7. Closing: Document open questions for next steps

Facilitator notes throughout. Designed for a cross-functional team where some attendees may anchor hard on early interpretations.
```

---

*25 prompts complete. Continue to `03-synthesis-analysis-prompts.md` →*
