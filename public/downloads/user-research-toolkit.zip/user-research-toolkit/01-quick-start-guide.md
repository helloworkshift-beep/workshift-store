# 01 · Quick Start Guide

## Getting the Most Out of Every Prompt

This guide takes 10 minutes to read and will multiply the value of every prompt in this toolkit. Don't skip it.

---

## The Anatomy of a Great Prompt

Every prompt in this toolkit follows a structure. Understanding it helps you adapt prompts when your situation doesn't fit perfectly.

```
[ROLE] — Who the AI should act as
[CONTEXT] — Your specific situation, product, users
[TASK] — What you want it to produce
[FORMAT] — How the output should be structured
[CONSTRAINTS] — What to avoid, word count, tone, etc.
```

The more you fill in the `[BRACKETS]`, the better your output. Here's the difference:

**Under-specified:**
> "Write me an interview guide for a fintech app."

**Well-specified (using this toolkit's structure):**
> "Write me an interview guide for [COMPANY NAME]'s mobile budgeting app. The target user is [25–40-year-old freelancers who struggle with irregular income]. The research goal is [understanding how they mentally track cash flow week-to-week]. Include [8–10 questions with probes]. Tone should be [warm and conversational]."

Same prompt template. Wildly different output quality.

---

## The Golden Rules

### Rule 1: Context is Everything
AI has no idea what your product does, who your users are, or what your research goals are unless you tell it. Before running any prompt, gather:
- Product/feature description (2–3 sentences)
- Target user segment (be specific)
- Research objective (what decision does this research inform?)
- Any relevant constraints (timeline, budget, platform, accessibility needs)

### Rule 2: Treat Outputs as First Drafts
Even the best prompt produces a first draft, not a final deliverable. Plan for one round of edits. AI outputs are 70–80% of the way there — your expert judgment gets you to 100%.

### Rule 3: Iterate in the Same Conversation
Don't start fresh when output isn't right. Follow up with:
- "Make question 3 less leading"
- "Shorten this by 30%"
- "Add a section on [topic]"
- "Rewrite the intro to sound less formal"

AI tools remember the conversation context. Use it.

### Rule 4: Add Your Voice
AI-generated copy tends toward the generic. After you have a solid draft, read it aloud. Does it sound like your team? Your brand? Your participants' mental model? Edit accordingly.

### Rule 5: Don't Trust Research Outputs Without Verification
This toolkit is for creating research *instruments* and *communications*, not for AI to generate research *findings*. Never let AI invent user insights, behaviors, or quotes. That's fabrication, not research.

---

## Setting Up AI for Research Work

### Recommended System Prompt
Paste this at the start of a new conversation to set context for a full research project:

```
You are an expert UX researcher with 10+ years of experience in mixed-methods research, 
user interviews, usability testing, and research synthesis. You're working with a UX 
research team at [COMPANY TYPE]. You understand how to write for different audiences — 
from casual interview participants to C-suite executives. 

When I ask you to create research materials, default to:
- Clear, non-jargon language for participant-facing materials
- Professional but approachable tone for internal documents  
- Structured, scannable formats for stakeholder outputs
- Rigorous, evidence-based framing for findings

The product we're researching: [BRIEF PRODUCT DESCRIPTION]
Our target users: [USER SEGMENT]
Current research phase: [DISCOVERY / GENERATIVE / EVALUATIVE / STRATEGIC]
```

### Keeping a Prompt Journal
Create a simple doc where you paste prompts that worked really well (with your filled-in context). This becomes a personal research prompt library specific to your product and team.

---

## Choosing the Right Prompt for Your Phase

### Discovery / Generative Research
You're trying to understand the problem space. Use:
- `02-interview-research-prompts.md` — guides, screeners, recruiting
- `03-synthesis-analysis-prompts.md` — affinity mapping, pattern finding

### Evaluative Research
You have something to test. Use:
- `04-survey-usability-prompts.md` — usability scripts, task scenarios
- `02-interview-research-prompts.md` — moderation scripts

### Synthesis & Reporting
You have data. Now what? Use:
- `03-synthesis-analysis-prompts.md` — insight extraction, reports, journey maps
- `05-stakeholder-communication-prompts.md` — presentations, persona docs

### Stakeholder Communication
You need buy-in. Use:
- `05-stakeholder-communication-prompts.md` — recommendation decks, ROI framing
- `06-workflow-sops.md` — presenting to executives workflow

---

## Filling in the Brackets — Field Guide

| Bracket Type | What to Write |
|---|---|
| `[PRODUCT/FEATURE NAME]` | The specific thing being researched, not just "our app" |
| `[USER SEGMENT]` | Specific: "first-time homebuyers aged 28–40" not "users" |
| `[RESEARCH GOAL]` | One clear sentence: what question does this answer? |
| `[NUMBER]` | Be specific — "8 questions" beats "several questions" |
| `[TONE]` | Formal/casual, clinical/warm, technical/accessible |
| `[COMPANY/TEAM NAME]` | Real name for participant trust |
| `[PLATFORM]` | Mobile, web, desktop, physical, hybrid |
| `[TIMEFRAME]` | Session length, study duration, deadline |
| `[CONSTRAINTS]` | Budget, headcount, accessibility needs, legal limits |

---

## Troubleshooting Common Issues

**Output is too generic**
→ Add more specific context about your product, users, and research goal

**Output is too long**
→ Ask: "Trim this to [X] words/questions, keeping only the highest-value content"

**Tone is off**
→ Paste in a sample of your team's writing style and ask: "Rewrite to match this tone"

**Questions are leading**
→ Ask: "Audit these questions for leading language and rewrite any that push toward a specific answer"

**Output sounds like it was written by AI**
→ Ask: "Rewrite this to sound like a senior researcher wrote it, not a chatbot. Remove corporate clichés."

**Not enough depth**
→ Ask: "Add follow-up probes to each question that help a moderator go deeper if participants give surface answers"

---

## Before You Run Any Prompt — Checklist

- [ ] I know what decision this research informs
- [ ] I can describe my target user in 2 sentences
- [ ] I have a clear research goal/question
- [ ] I know what format/length I need
- [ ] I've gathered any relevant context (existing data, product info, constraints)

---

*Now pick your first prompt and get to work.*
