# 06 — Workflow SOPs for AI-Assisted UX Research

> **5 complete Standard Operating Procedures** for the most common UX research workflows. Each SOP tells you exactly what to do, when to do it, and which prompts from this toolkit to use at each stage.

---

## How to Use These SOPs

Each SOP is a **step-by-step playbook** for a complete research workflow. They are written assuming you are the lead researcher (or sole researcher) and are using AI to accelerate and elevate your work — not to replace your judgment.

**Before you start any SOP:**
- Read the SOP in full (5 minutes)
- Note which prompt files you'll need
- Adapt timings to your actual constraints
- Remember: AI outputs are starting points. Review, edit, and ground them in your real data before sharing.

---

## SOP A: End-to-End User Interview Study
**Recruit → Conduct → Synthesise → Present**

**Total timeline:** 3–5 weeks (depending on recruitment speed)
**Team:** 1–2 researchers
**Prompt files used:** 01, 02, 03, 05

---

### Phase 1: Study Design (Days 1–2)

**Step 1.1 — Define the research question**
Write your primary and secondary research questions before opening any AI tool. These should be your words, grounded in what the business actually needs to decide.

**Step 1.2 — Write the research brief** *(~30 min with AI)*
Use **Prompt 01-01 (Research Question Sharpener)** from `01-planning-prompts.md` to pressure-test your research questions and ensure they're answerable through interviews.

**Step 1.3 — Design the discussion guide** *(~45 min with AI)*
Use **Prompt 02-01 (Discussion Guide Builder)** from `02-interview-prompts.md`. Feed in your research questions, participant profile, and session length. Review the output carefully — check that questions are open-ended and sequenced logically.

**Step 1.4 — Write the screener** *(~20 min with AI)*
Use **Prompt 02-02 (Participant Screener Writer)** from `02-interview-prompts.md`. Specify your target profile, disqualifying criteria, and recruitment platform.

> **AI Time Saved:** ~3–4 hours of writing compressed to ~2 hours of review and editing.

---

### Phase 2: Recruitment (Days 3–10)

**Step 2.1 — Recruit participants**
Post your screener to your chosen channel (panel, CRM, social, referral). Aim for 8–12 participants for generative research; 5–6 for evaluative.

**Step 2.2 — Send confirmations and pre-session materials**
Use **Prompt 02-03 (Participant Communication Templates)** from `02-interview-prompts.md` to generate confirmation emails, reminder messages, and consent form language.

**Step 2.3 — Schedule sessions**
Block 60-minute interview slots + 15-minute buffer. Brief any observers using a one-paragraph observer guide (ask AI to draft this from your discussion guide).

> **Target:** Minimum 5 completed sessions. Aim for 8 if budget allows.

---

### Phase 3: Conducting Interviews (Days 8–15)

**Step 3.1 — Before each session**
Re-read your discussion guide. Do not rely on AI during live interviews — be present.

**Step 3.2 — During the session**
Record with consent. Take timestamped notes. Note non-verbal reactions if video.

**Step 3.3 — Immediately after each session** *(10 min)*
Write a "hot take" — 3–5 bullet points on what surprised you, what confirmed existing thinking, and one standout quote. Save these as `session-notes/P01.md`, `P02.md`, etc.

**Step 3.4 — Use AI for real-time transcript processing** *(after each session, ~20 min)*
Use **Prompt 03-01 (Transcript Highlighter)** from `03-analysis-prompts.md`. Paste the transcript and ask it to pull key quotes by theme. Spot-check against your raw notes.

---

### Phase 4: Synthesis (Days 15–19)

**Step 4.1 — Affinity clustering** *(2–3 hours)*
Gather all session notes and transcript highlights. Use **Prompt 03-03 (Affinity Clustering Assistant)** from `03-analysis-prompts.md`. Feed in your raw notes in batches.

> ⚠️ **Important:** Run clustering on your own in sticky-note format first (physical or digital) before using AI. AI clustering should validate and sharpen your thinking, not replace it. This protects against AI hallucinating themes that aren't in the data.

**Step 4.2 — Build the insight statements** *(1–2 hours)*
For each cluster, use **Prompt 03-05 (Insight Statement Generator)** from `03-analysis-prompts.md` to turn raw observations into sharp, evidence-backed insight statements.

**Step 4.3 — Generate recommendations** *(1 hour)*
Use **Prompt 03-07 (Recommendations Builder)** from `03-analysis-prompts.md`. Always review AI recommendations against your research data — reject any that aren't directly supported.

**Step 4.4 — Write the findings report** *(2–3 hours)*
Structure the report yourself. Use AI to write individual sections (executive summary, method, findings narrative) using prompts from `05-stakeholder-communication-prompts.md`.

> **Prompt to use:** Prompt 05-01 (Research Presentation Narrative Builder) for the story arc, Prompt 05-02 (Findings One-Pager) for a shareable summary.

---

### Phase 5: Presenting Findings (Days 20–22)

**Step 5.1 — Build the slide deck**
Use the narrative arc from Prompt 05-01. Keep slides to 12–15 maximum. Each slide = one idea.

**Step 5.2 — Prepare for objections**
Use **Prompt 05-15 (Stakeholder Objection Handler)** from `05-stakeholder-communication-prompts.md`. Brief all objections you anticipate from your specific audience.

**Step 5.3 — Present**
Lead with the headline finding. Have the one-pager ready to share. Offer a follow-up slot for deeper dives.

**Step 5.4 — Add to research repository** *(30 min post-presentation)*
Use **Prompt 05-10 (Research Repository Summary)** from `05-stakeholder-communication-prompts.md` to create a searchable repository entry.

---

**Total estimated researcher time:** 40–60 hours
**Total estimated AI-assisted time:** 25–40 hours (saving 30–40% on writing and synthesis tasks)

---

## SOP B: Usability Test Sprint in One Week

**Total timeline:** 5 working days
**Team:** 1–2 researchers + product/design observer
**Prompt files used:** 02, 04, 05

---

### Day 1: Plan & Recruit (Monday)

**Step 1.1 — Define test objectives** *(AM, 1 hour)*
Write 3–5 specific usability questions you need answered. Be concrete: not "is the checkout usable?" but "can users find the promo code field without help?"

**Step 1.2 — Write test script** *(AM, 1–2 hours with AI)*
Use **Prompt 04-04 (Moderated Usability Test Script Builder)** from `04-survey-usability-prompts.md`. Feed in your objectives, task count, and session length.

**Step 1.3 — Write task scenarios** *(AM, 30 min with AI)*
Use **Prompt 04-05 (Task Scenario Writer)** from `04-survey-usability-prompts.md`. Generate scenarios for each task, then edit to match your specific product language and user context.

**Step 1.4 — Recruit participants** *(PM)*
For a one-week sprint, use your fastest recruitment channel. Aim for 5–6 participants. Schedule sessions for Days 3 and 4.

If using unmoderated: Use **Prompt 04-13 (Unmoderated Test Screener)** and **Prompt 04-14 (Unmoderated Test Task Builder)** from `04-survey-usability-prompts.md` to set up on your platform today.

**Step 1.5 — Set up tech** *(PM, 30 min)*
Confirm recording software, prototype access, observer call-in details, and incentive delivery.

---

### Day 2: Pilot & Prep (Tuesday)

**Step 2.1 — Run pilot session** *(AM)*
Run the test script with a colleague or someone outside the team. Time the tasks. Fix anything confusing.

**Step 2.2 — Brief observers** *(PM, 30 min)*
Write a one-page observer brief. Assign one observer per session. Instruct them to note: task completion, hesitation moments, verbal frustration, and direct quotes.

**Step 2.3 — Set up analysis workspace**
Create a shared document or Dovetail project with columns for: participant, task, outcome, observations, quotes, severity.

---

### Day 3–4: Run Sessions (Wednesday–Thursday)

**Step 3.1 — Run sessions** *(2–3 per day)*
Stick to your script. Record with consent. Do not ad-lib task prompts.

**Step 3.2 — Post-session notes** *(15 min per session)*
Immediately after each session: write 3–5 bullet hot takes. Don't wait.

**Step 3.3 — AI-assisted transcript processing** *(evening)*
After each day's sessions, use **Prompt 03-01** from `03-analysis-prompts.md` to extract key observations from transcripts. Paste results into your analysis workspace.

---

### Day 5: Analyse & Report (Friday)

**Step 5.1 — Calculate task metrics** *(AM, 1 hour)*
Calculate: task completion rates, error rates, mean SUS scores (if collected). Use **Prompt 04-07 (Task Success & Error Rate Summary)** from `04-survey-usability-prompts.md`.

**Step 5.2 — Identify top issues** *(AM, 1–2 hours)*
Group observations by theme. Prioritise by: frequency × severity. Use **Prompt 03-05** from `03-analysis-prompts.md` for insight statements.

**Step 5.3 — Write executive summary** *(PM, 30 min with AI)*
Use **Prompt 04-20 (Usability Test Report Executive Summary)** from `04-survey-usability-prompts.md`. Feed in your top findings in rough note form.

**Step 5.4 — Deliver findings**
Send the one-pager (Prompt 05-02) by end of day Friday. Schedule a 30-minute readout for Monday.

---

**Total estimated time:** 5 days / ~30–40 researcher hours
**Key output:** Top 5 prioritised usability issues + executive summary + recommended fixes

---

## SOP C: Survey Campaign — Brief to Insights

**Total timeline:** 3–4 weeks
**Team:** 1 researcher + optional analyst
**Prompt files used:** 01, 04, 05

---

### Phase 1: Brief & Design (Days 1–3)

**Step 1.1 — Clarify the brief** *(Day 1, 1–2 hours)*
Meet with the stakeholder requesting the survey. Capture:
- The business decision this survey needs to inform
- What "good" looks like (what would make this a success)
- Who the target respondents are
- Any existing data that should inform the survey design

**Step 1.2 — Design the survey** *(Day 2, 2–3 hours with AI)*
Use **Prompt 04-01 (Survey Draft Generator)** from `04-survey-usability-prompts.md`. Feed in your research questions, audience, and constraints.

**Step 1.3 — Audit for bias** *(Day 3, 30–45 min with AI)*
Paste your draft questions into **Prompt 04-02 (Survey Question Bias Auditor)** from `04-survey-usability-prompts.md`. Review all flagged issues. Revise before moving to pilot.

**Step 1.4 — Stakeholder review**
Share the draft with one or two stakeholders for content review. Limit changes to factual corrections — resist scope creep.

---

### Phase 2: Pilot & Launch (Days 4–7)

**Step 2.1 — Cognitive pilot** *(Day 4)*
Run the survey with 3–5 people matching your target audience profile (internal proxy respondents are fine for this stage). Observe them completing it if possible. Note: confusing questions, unexpected interpretations, drop-off points, average completion time.

**Step 2.2 — Revise and finalise** *(Day 5)*
Make final edits based on pilot. Lock the survey. Any post-launch changes invalidate comparison of responses.

**Step 2.3 — Set up distribution** *(Day 6)*
Configure your survey platform (Qualtrics, Typeform, SurveyMonkey, etc.). Set: progress bar, estimated time, privacy notice, incentive details.

**Step 2.4 — Launch** *(Day 7)*
Send to your distribution channel. Set a response target (minimum 50 for basic segmentation; 150+ for reliable cross-tabs). Monitor completion rate and drop-off for the first 24 hours.

---

### Phase 3: Data Collection (Days 7–17)

**Step 3.1 — Monitor daily**
Check: response rate, completion rate, time-on-survey (flag if < half expected time — may indicate satisficing), open-text response quality.

**Step 3.2 — Mid-point check** *(Day 12)*
At 50% of target responses: check demographic distribution. If skewed, adjust distribution or boost under-represented segments before closing.

**Step 3.3 — Close survey** *(Day 17 or when target reached)*
Close the survey. Export the full dataset.

---

### Phase 4: Analysis (Days 18–21)

**Step 4.1 — Clean the data** *(Day 18, 2–3 hours)*
Remove: incomplete responses (< 50% complete), speeder responses (under-time), straight-liners (same answer for all Likert questions), duplicates.

**Step 4.2 — Analyse closed-ended responses** *(Day 19)*
Run frequencies and cross-tabulations on your key variables. Note patterns, surprises, and segments that differ significantly.

**Step 4.3 — Analyse open-text responses** *(Day 19–20, with AI)*
Use **Prompt 03-02 (Open-Text Response Coder)** from `03-analysis-prompts.md`. Paste responses in batches (50–100 at a time) and ask for thematic coding. Verify AI coding against a sample manually.

**Step 4.4 — Write findings narrative** *(Day 20–21)*
Use **Prompt 04-03 (Likert Scale Response Narrative)** from `04-survey-usability-prompts.md` for quantitative sections. Use **Prompt 05-02 (Findings One-Pager)** from `05-stakeholder-communication-prompts.md` for the executive summary.

---

### Phase 5: Share Insights (Days 22–24)

**Step 5.1 — Build the deliverable**
Match the format to the audience: dashboard for ongoing tracking, slide deck for one-time presentation, one-pager for broad distribution.

**Step 5.2 — Present or distribute**
Use **Prompt 05-01 (Research Presentation Narrative Builder)** if presenting live.

**Step 5.3 — Repository entry**
Use **Prompt 05-10 (Research Repository Summary)** to log the study.

---

**Total estimated time:** 3–4 weeks calendar / 20–30 researcher hours
**Key output:** Insight report, one-pager, and stakeholder presentation

---

## SOP D: Setting Up a Research Repository

**Total timeline:** 2–4 weeks initial setup; ongoing
**Team:** Lead researcher + optional ops support
**Prompt files used:** 03, 05

A research repository is your team's institutional memory. Done well, it reduces duplicated effort, accelerates onboarding, and makes the case for research's impact. Done badly, it becomes a graveyard of PDFs no one reads.

---

### Phase 1: Audit Existing Research (Days 1–3)

**Step 1.1 — Inventory all existing research** *(Day 1–2)*
Search: shared drives, email attachments, Notion/Confluence, Slack channels, analytics tools. List every study, presentation, or insight document that exists.

**Step 1.2 — Assess what's worth importing** *(Day 3)*
Apply a quick triage: Is it less than 3 years old? Is it still relevant to current products? Does it contain raw insights or just polished decks? Prioritise: recent + raw + strategic.

---

### Phase 2: Choose Your Platform (Day 4)

**Step 2.1 — Select a repository tool**
Options by context:
- **Small team / low budget:** Notion (simple, searchable, free tier)
- **Mid-size team:** Confluence with a research template, or Airtable
- **Research-forward team:** Dovetail (purpose-built, best for tagging and evidence linking)
- **Enterprise:** EnjoyHQ, UserZoom repository features, or Dovetail Enterprise

**Step 2.2 — Define your taxonomy**
Before adding a single entry, agree on: primary tags (product area, method, audience type, theme), confidence rating scale, and naming conventions for study IDs.

---

### Phase 3: Build the Entry Template (Day 5)

**Step 3.1 — Design a standard entry format**
Use **Prompt 05-10 (Research Repository Summary)** from `05-stakeholder-communication-prompts.md` as the template. Every entry should have:
- Study ID
- One-line description (for search previews)
- Research questions
- Method & participants
- Key findings (numbered, searchable)
- Recommendations
- What was done with this research
- Tags
- Confidence level

**Step 3.2 — Create a submission guide for contributors**
Write a one-page guide for how other researchers (or PMs, designers) should submit entries. Include: required fields, tag list, naming convention, turnaround expectation.

---

### Phase 4: Backfill High-Priority Studies (Days 6–14)

**Step 4.1 — Process studies in priority order** *(~30–45 min per study with AI)*
For each study: gather the original report or notes. Use **Prompt 05-10** to generate a repository entry draft. Review and edit for accuracy.

**Step 4.2 — Use AI for rapid synthesis of old reports** *(if reports are long)*
Paste the executive summary and top findings into **Prompt 03-05 (Insight Statement Generator)** from `03-analysis-prompts.md` to create crisp, searchable insight statements from verbose old reports.

**Target:** 10–15 high-priority studies loaded by end of Week 2.

---

### Phase 5: Launch & Embed (Days 15–20)

**Step 5.1 — Announce the repository**
Use **Prompt 05-09 (Cross-Team Research Insight Digest)** from `05-stakeholder-communication-prompts.md` to write a launch announcement for Slack or email. Include: what it is, why it exists, how to use it, how to contribute.

**Step 5.2 — Embed in team rituals**
Add "update the repository" to your research checklist. Add "check the repository" to design sprint kickoffs and product discovery kick-offs.

**Step 5.3 — Set a quarterly review cadence**
Every quarter: archive studies older than 3 years, update confidence ratings on studies that have been superseded, and add any new cross-study patterns as standalone "insight pages."

---

**Key success metric:** Can someone new to the team find a relevant past study in under 3 minutes?

---

## SOP E: Presenting Research Findings to Executives

**Total timeline:** 1–3 days preparation
**Team:** Lead researcher (+ optional design/PM co-presenter)
**Prompt files used:** 03, 05

Executive presentations are a different discipline from team readouts. The goal is not to educate — it's to enable a decision. Every minute you spend on methodology is a minute executives aren't making the decision you need them to make.

---

### Step 1: Know Your Audience Before You Prepare (Day 1, AM)

**Step 1.1 — Answer these questions before opening any tool:**
- What decision is this executive responsible for making?
- What do they currently believe about this topic?
- What would they need to see to change their mind?
- What's their biggest concern or objection likely to be?
- How do they prefer to receive information? (Data-first? Story-first? Headlines first?)

**Step 1.2 — Define the single "so what"**
One sentence: "After this presentation, I want [EXECUTIVE NAME] to [SPECIFIC ACTION OR DECISION]."

If you can't write that sentence, you're not ready to build slides.

---

### Step 2: Structure the Presentation (Day 1, PM — 1–2 hours with AI)

**Step 2.1 — Build the narrative arc**
Use **Prompt 05-01 (Research Presentation Narrative Builder)** from `05-stakeholder-communication-prompts.md`. Specify the audience as "senior executive" and the desired outcome from Step 1.2.

**Step 2.2 — Write the headline findings**
Use **Prompt 05-11 (Leadership Research Update)** from `05-stakeholder-communication-prompts.md` as a template for the findings section. Prioritise: strategic implications over methodological detail.

**Step 2.3 — Apply the "so what" test to every slide**
For each slide in your draft, ask: "What decision does this enable?" If you can't answer, cut the slide or move it to an appendix.

---

### Step 3: Prepare for Objections (Day 2, AM — 30–45 min with AI)

**Step 3.1 — Anticipate challenges**
Use **Prompt 05-15 (Stakeholder Objection Handler)** from `05-stakeholder-communication-prompts.md`. List the specific objections this executive is likely to raise.

**Step 3.2 — Build your appendix**
Prepare 3–5 "appendix slides" with: methodology detail, full data tables, sample sizes, and raw quotes. These are not for presenting — they're for answering questions.

**Step 3.3 — Rehearse the hard questions**
Say your answers out loud. Time your key points. The opening headline should take no more than 60 seconds.

---

### Step 4: Prepare Supplementary Materials (Day 2, PM — 1 hour with AI)

**Step 4.1 — Write the pre-read** *(if the exec prefers to read ahead)*
Use **Prompt 05-02 (Findings One-Pager)** from `05-stakeholder-communication-prompts.md`. Send this 24–48 hours before the meeting.

**Step 4.2 — Prepare the leave-behind**
The one-pager plus a clear "Next steps" page. This is what the executive shares with others.

---

### Step 5: The Presentation (Day 3)

**Step 5.1 — Opening (first 2 minutes)**
State the context (what we tested/explored), the headline finding (one sentence), and the decision you need (one sentence). Do not open with "today I'll be sharing research on..." — open with the insight.

**Step 5.2 — Findings section (5–10 minutes)**
Maximum 3–5 key insights. Each one: what we found → what it means → what we recommend. Use one data point or quote per insight to ground it.

**Step 5.3 — Recommendations (3–5 minutes)**
Clear, numbered, actionable. Connect each recommendation to a business outcome. Have an effort/impact view ready.

**Step 5.4 — Discussion (remaining time)**
Invite questions. Use your appendix slides when challenged on data. Your objection prep is your safety net.

**Step 5.5 — Close with the ask**
Restate what you need from the executive: a decision, a resource, a next step. Never leave without clarity on what happens next.

---

### Step 6: Post-Presentation (Same Day)

**Step 6.1 — Send follow-up within 2 hours**
Email: the one-pager, the decision/next step agreed, and any follow-up you committed to.

**Step 6.2 — Log the outcome**
Note in your repository: what decision was made, what's being deprioritised, and any new research questions that emerged from the discussion.

**Step 6.3 — Update the research impact tracker**
Add this to your research impact log (see Prompt 05-12). Over time, this becomes your most powerful evidence for the value of the research function.

---

**Key executive presentation rule:** If they only read the title of each slide, they should still understand the story.

---

*For the most commonly needed prompt from each of these SOPs, see the `07-cheat-sheet.md`.*
