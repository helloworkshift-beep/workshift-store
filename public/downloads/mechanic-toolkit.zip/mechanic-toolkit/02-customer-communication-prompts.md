# 02 — Customer Communication Prompts

*23 prompts for service write-ups, repair updates, customer follow-ups, and professional shop communication*

---

### Vehicle Drop-Off Confirmation Text
*Use when confirming receipt of a customer's vehicle and setting expectations for diagnosis.*

```
Write a professional drop-off confirmation text for a customer who just left their vehicle.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
What they described: [CUSTOMER_COMPLAINT]
Estimated diagnosis time: [DIAGNOSIS_TIMEFRAME]
How I'll contact them: [CONTACT_METHOD — text, call]
My shop name: [SHOP_NAME]

Write a text message that:
1. Confirms we have their vehicle
2. States what we're inspecting
3. Tells them when and how they'll hear from us
4. Is friendly and professional

Under 80 words. No jargon — plain language a non-car person understands.
```

---

### Vehicle Inspection Results Message
*Use when sharing the inspection findings with a customer before starting any work.*

```
Write a clear, professional inspection results message for a customer.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL] with [MILEAGE] miles
Reason they brought it in: [ORIGINAL_COMPLAINT]
What we found (be specific): [FINDINGS_LIST]
What we recommend fixing: [RECOMMENDED_REPAIRS]
What can wait: [DEFERRED_ITEMS]
Total estimate: [ESTIMATE_TOTAL]
Time needed to complete: [COMPLETION_TIME]
Contact method: [TEXT/CALL]

Write a message that:
1. Summarizes what we inspected
2. Explains findings in plain language (not mechanic jargon)
3. Clearly separates what's urgent from what can wait
4. States the total estimate
5. Asks for approval to proceed

Format: Clear, friendly, no more than 200 words.
```

---

### Repair Authorization Request
*Use when asking a customer to approve a specific repair before beginning work.*

```
Write a repair authorization message for a customer.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Repair needed: [REPAIR_DESCRIPTION]
Why it's needed: [PLAIN_LANGUAGE_EXPLANATION — what's causing the problem and what happens if not fixed]
Parts required: [PARTS_LIST]
Labor estimate: [LABOR_TIME] hours at [LABOR_RATE]
Parts cost: [PARTS_COST]
Total estimate: [TOTAL_ESTIMATE]
Time to complete: [COMPLETION_TIME]
Any warranty on this repair: [WARRANTY_TERMS]

Write a message that:
1. Explains the repair and why it's necessary (non-technical)
2. Breaks down the cost clearly
3. States the expected completion time
4. Asks for clear approval (yes or no)
5. Offers to call if they have questions

Under 200 words. Clear and trustworthy.
```

---

### Additional Repair Found During Service
*Use when you discover an additional problem during a repair the customer didn't originally authorize.*

```
Write a message informing a customer we found an additional issue while working on their vehicle.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Original repair approved: [ORIGINAL_REPAIR]
New issue discovered: [NEW_ISSUE]
Why we found it: [HOW_IT_WAS_DISCOVERED — e.g., "while replacing the brake pads we noticed..."]
Urgency level: [URGENT — safety issue / NOT URGENT — can wait]
Estimate for additional repair: [ADDITIONAL_ESTIMATE]
Impact on original completion time: [TIME_IMPACT]

Write a message that:
1. Updates them on the original repair (good news first if applicable)
2. Explains the new finding in plain language
3. States whether it's urgent or can wait
4. Provides a clear estimate
5. Asks for approval without pressuring them

Keep it transparent and factual. Customers who feel informed, not pressured, say yes more often.
```

---

### Vehicle Ready for Pickup Notification
*Use when a vehicle is complete and ready for the customer to pick up.*

```
Write a vehicle ready for pickup notification.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Work completed: [WORK_SUMMARY — brief, in plain language]
Total amount due: [TOTAL_DUE]
Payment accepted: [PAYMENT_METHODS]
Shop hours: [HOURS]
Shop address: [ADDRESS]
Any follow-up notes: [NOTES — e.g., "tire rotation due in 3,000 miles", "rear brakes should be checked next visit"]

Write a pickup notification that:
1. Tells them the vehicle is ready
2. Briefly summarizes what was done
3. States the amount due
4. Gives pickup logistics (hours, payment)
5. Adds one helpful maintenance reminder

Short and clear. They want to know it's ready and what they owe.
```

---

### Cost Overrun Explanation
*Use when the final cost exceeds the original estimate.*

```
Write an explanation for a repair that came in higher than the original estimate.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Original estimate: [ORIGINAL_ESTIMATE]
Actual cost: [ACTUAL_COST]
Reason for difference: [REASON — be specific: additional parts needed, more labor than expected, hidden damage found, etc.]
Can we offset any of the difference: [OFFSET — e.g., "we're waiving the diagnostic fee", "we applied a parts discount"]

Write a message that:
1. Addresses the cost difference directly (don't bury it)
2. Explains the reason factually and specifically
3. Shows what we're doing to minimize the impact
4. Remains professional and non-defensive

This is a trust-building moment, not a problem to minimize. Transparency wins.
```

---

### Declined Repair Follow-Up
*Use when a customer declined a recommended repair at pickup and you want to follow up for their safety.*

```
Write a follow-up message for a customer who declined a recommended repair.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Repair they declined: [DECLINED_REPAIR]
Safety concern (if any): [SAFETY_CONCERN — honest, not fear-based]
Timeframe before it becomes more serious: [TIMEFRAME — if applicable]
What to watch for: [SYMPTOMS_TO_MONITOR]
Invitation to rebook: [BOOKING_CTA]
Shop name: [SHOP_NAME]

Write a message that:
1. Reminds them of the declined repair without pressure
2. Gives a genuine safety context (if it applies)
3. Tells them what to watch for
4. Makes it easy to book when they're ready

Friendly and informative — not a guilt trip or a sales pitch.
```

---

### Service Reminder — Overdue Maintenance
*Use when a customer is due or overdue for routine maintenance.*

```
Write a service reminder message for a customer with overdue maintenance.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Last service date: [LAST_SERVICE_DATE]
Mileage at last service: [LAST_MILEAGE]
Service due: [SERVICE_TYPE — oil change, tire rotation, etc.]
How overdue: [MILEAGE_OR_TIME_OVERDUE]
Shop name: [SHOP_NAME]
Booking link or phone: [BOOKING_CONTACT]

Write a service reminder that:
1. Names the specific service due (not generic "it's time for a service")
2. Gives the context (when/mileage last done)
3. Explains briefly why staying on schedule matters
4. Makes booking easy

Under 100 words. Not pushy — just helpful.
```

---

### Welcome Back — Customer Who Hasn't Been In a While
*Use when reaching out to a customer who hasn't visited in 12+ months.*

```
Write a re-engagement message for a customer who hasn't been in for a while.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle (if known): [YEAR_MAKE_MODEL]
Last visit date: [LAST_VISIT_DATE — approximate is fine]
Shop name: [SHOP_NAME]
Offer or reason to come back: [INCENTIVE — e.g., "complimentary multi-point inspection", "10% off your next service"]
My name: [MY_NAME]

Write a message that:
1. Reconnects personally (not like a mass email)
2. References their vehicle if possible
3. Offers something of value
4. Makes it easy to book

Warm and personal. Under 100 words.
```

---

### Apology Message — Service Issue
*Use when something went wrong and you need to address it directly with the customer.*

```
Write an apology and resolution message for a customer who had a service problem.

Customer name: [CUSTOMER_FIRST_NAME]
What went wrong: [ISSUE — be specific: wrong part installed, took longer than quoted, damage occurred, etc.]
How serious was it: [SEVERITY — minor inconvenience / significant problem / safety concern]
What we're doing to fix it: [RESOLUTION — redo the work, refund, discount, etc.]
Timeline to resolve: [RESOLUTION_TIMELINE]
Who to contact: [CONTACT_NAME], [CONTACT_METHOD]
Shop name: [SHOP_NAME]

Write an apology that:
1. Owns the mistake completely — no excuses
2. States specifically what happened
3. Explains exactly what we're doing to make it right
4. Gives a timeline
5. Provides a direct contact

Professional and sincere. Customers forgive mistakes — they don't forgive being brushed off.
```

---

### Text Estimate Summary
*Use when sending a quick text-based estimate summary to a customer.*

```
Write a brief text message estimate summary.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Service(s) being estimated: [SERVICES]
Estimate total: [ESTIMATE]
What's included: [INCLUDED_ITEMS]
Time to complete: [COMPLETION_TIME]
Valid through: [ESTIMATE_EXPIRATION]

Write a text message that:
1. States the service and estimate amount clearly
2. Briefly describes what's included
3. States the timeline
4. Gives them an easy way to approve

Under 100 words. Clean and professional.
```

---

### Parts Delay Notification
*Use when a parts delay will push back a vehicle's completion time.*

```
Write a parts delay notification for a customer.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Repair being done: [REPAIR]
Original completion promised: [ORIGINAL_DATE]
New expected completion: [NEW_DATE]
Reason for delay: [REASON — part backordered, wrong part shipped, etc.]
What we're doing to expedite: [WHAT_WE'RE_DOING]
Loaner/rental available: [YES/NO]
Contact: [CONTACT_METHOD]

Write a notification that:
1. Gets to the point immediately (they need to know their car is delayed)
2. Gives the specific new timeline
3. Explains why honestly (customers understand — they just want honesty)
4. Tells them what you're doing about it
5. Offers the loaner/rental option if available
```

---

### Warranty Repair Communication
*Use when a customer brings in a vehicle for a warranty repair on previous work.*

```
Write a communication for a customer bringing in a vehicle for a warranty repair.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Original repair: [ORIGINAL_REPAIR] — done on [ORIGINAL_DATE]
Issue they're experiencing: [WARRANTY_COMPLAINT]
Our warranty policy: [WARRANTY_TERMS]
Whether this is covered: [COVERED/NOT_COVERED/PARTIALLY]
If not fully covered — why: [REASON_NOT_COVERED]
What we'll do: [RESOLUTION_PLAN]

Write a response that:
1. Acknowledges their concern professionally
2. States clearly whether it's covered under warranty
3. If covered: confirms the plan to fix it promptly
4. If not covered: explains why respectfully and offers options
5. Ends with next steps

Straightforward and respectful. Every customer wants to feel their concern is taken seriously.
```

---

### Post-Service Thank You
*Use when sending a thank-you message after a service appointment.*

```
Write a post-service thank you message for a customer.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Service performed: [SERVICE_SUMMARY]
Next service due: [NEXT_SERVICE]
Review request: [YES/NO — include a review request link or not]
Shop name: [SHOP_NAME]
My name: [MY_NAME]

Write a thank you that:
1. Thanks them by name for their business
2. Briefly reminds them what was done
3. Notes when to come back
4. Includes a review request if applicable (single line, not pushy)

Under 80 words. Warm and personal.
```

---

### Multi-Vehicle Fleet Customer Update
*Use when updating a fleet customer or business owner who has multiple vehicles in for service.*

```
Write a fleet service status update for a business customer with multiple vehicles.

Customer/business: [COMPANY_NAME], contact: [CONTACT_NAME]
Vehicles in service:
- Vehicle 1: [MAKE_MODEL_YEAR] — status: [STATUS] — estimated completion: [DATE]
- Vehicle 2: [MAKE_MODEL_YEAR] — status: [STATUS] — estimated completion: [DATE]
- Vehicle 3 (if applicable): [MAKE_MODEL_YEAR] — status: [STATUS]
Total estimated cost for all: [TOTAL_ESTIMATE]
Priority vehicle (needs to be done first): [PRIORITY_VEHICLE] — reason: [REASON]
My name: [MY_NAME], [SHOP_NAME]

Write a professional fleet update that:
1. Gives a clear status for each vehicle
2. Highlights the priority vehicle
3. States the total cost estimate
4. Ends with a clear next communication checkpoint

Businesslike and organized. Fleet customers care about scheduling and cost.
```

---

### Complaint Response — In Person or Written
*Use when a customer complains in person, by phone, or in writing about their service experience.*

```
Write a response to a customer complaint.

Customer name: [CUSTOMER_NAME]
Complaint: [COMPLAINT_DESCRIPTION — what they said happened]
Our review of what happened: [OUR_REVIEW]
Was the complaint valid? [YES / PARTIALLY / NO]
Resolution we're offering: [RESOLUTION]
Who they're dealing with: [MY_NAME], [MY_ROLE]
Shop name: [SHOP_NAME]

Write a response that:
1. Acknowledges their frustration specifically (not generically)
2. Presents our understanding of what happened
3. Offers the resolution directly and without conditions
4. Closes with a genuine invitation to continue the relationship

Under 200 words. Professional, calm, and genuine.
```

---

### New Customer Welcome Message
*Use when welcoming a first-time customer after their first visit.*

```
Write a new customer welcome message to send after their first visit.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Service performed: [SERVICE]
My name: [MY_NAME]
Shop name: [SHOP_NAME]
Special offer for second visit (if any): [SECOND_VISIT_OFFER]
Review request: [YES/NO]

Write a message that:
1. Thanks them for choosing us for the first time
2. Confirms what we did for their vehicle
3. Lets them know we're here for their future needs
4. Offers the second-visit incentive if applicable
5. Mentions a review if applicable

Under 100 words. Human and warm.
```

---

### Vehicle Inspection Declined — Safety Notice
*Use when a customer declines a safety-critical repair and you need to document and communicate the risk.*

```
Write a safety notice for a customer who declined a safety-critical repair.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Safety issue declined: [SAFETY_ISSUE]
Reason it's safety-critical: [SAFETY_EXPLANATION — plain language]
Risk of driving with this issue: [RISK_DESCRIPTION]
Advice given: [WHAT_YOU_TOLD_THEM_IN_PERSON]
Documentation note: Include a line that they were informed and made this decision.

Write a message that:
1. States the safety concern clearly (honest, not dramatic)
2. Explains the risk in plain language
3. Documents that they were informed
4. Keeps the door open for them to return when ready

This message protects both the customer and your shop. Keep it factual and professional.
```

---

### Customer Survey Request
*Use when asking a recent customer to complete a satisfaction survey.*

```
Write a customer satisfaction survey request.

Customer name: [CUSTOMER_FIRST_NAME]
Service date: [SERVICE_DATE]
Vehicle: [YEAR_MAKE_MODEL]
Survey link: [SURVEY_LINK]
Estimated time to complete: [TIME — e.g., "2 minutes"]
Incentive for completing (if any): [INCENTIVE]
Shop name: [SHOP_NAME]

Write a message that:
1. Thanks them for their recent visit
2. Explains why their feedback matters (genuine, not corporate)
3. Makes completing the survey feel easy and low-effort
4. Links directly to the survey

Under 80 words.
```

---

### Referral Request to a Happy Customer
*Use when following up with a satisfied customer to ask for referrals.*

```
Write a referral request for a very satisfied customer.

Customer name: [CUSTOMER_FIRST_NAME]
What their experience was: [RECENT_POSITIVE_EXPERIENCE]
Referral offer: [REFERRAL_INCENTIVE — e.g., "$25 off next service for every referral"]
Shop name: [SHOP_NAME]
How to refer: [HOW — "just give them our name and number", "use this link", etc.]

Write a message that:
1. Opens by acknowledging their positive experience
2. Makes the referral ask feel natural and friendly
3. Explains the incentive clearly
4. Keeps it short and easy

Under 100 words. Like a note from a neighbor, not a marketing email.
```

---

### Vehicle Storage Notification
*Use when a customer's vehicle has been at the shop longer than expected and storage fees may apply.*

```
Write a vehicle storage notification for a customer whose vehicle has been at the shop.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Days at shop: [DAYS_IN_SHOP]
Reason vehicle is still there: [REASON — waiting for parts authorization, repair paused, etc.]
Storage policy: [STORAGE_POLICY — e.g., "storage fees of $X per day apply after 5 business days"]
Storage fees accumulated (if any): [FEES_TO_DATE]
Action needed: [WHAT_CUSTOMER_NEEDS_TO_DO]
Deadline: [DEADLINE]

Write a message that:
1. States the situation clearly and early
2. References the storage policy
3. States any fees accumulated
4. Gives a clear deadline for action
5. Provides easy contact info

Direct but not threatening. Under 150 words.
```

---

### Holiday / Seasonal Shop Hours Notification
*Use when notifying customers of holiday hours, closures, or schedule changes.*

```
Write a holiday hours notification for shop customers.

Shop name: [SHOP_NAME]
Holiday/occasion: [HOLIDAY_OR_OCCASION]
Normal hours: [NORMAL_HOURS]
Modified hours or closure dates: [MODIFIED_SCHEDULE]
Last day for drop-offs before closure: [LAST_DROP_OFF_DATE]
Emergency contact (if applicable): [EMERGENCY_CONTACT]
Reopening date: [REOPEN_DATE]

Write a notification that:
1. States the modified schedule clearly (specific dates and times)
2. Notes the last drop-off deadline
3. Wishes them a genuine seasonal message
4. Reminds them of the reopening date

Short and informative. Under 100 words.
```

---

*Total prompts in this file: 23*
