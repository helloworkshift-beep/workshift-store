# 🔧 The Auto Mechanic's AI Prompt Toolkit

**90+ AI prompts for mechanics, shop owners, and service advisors**

---

## What's Inside

This toolkit gives auto mechanics and shop owners instant access to professional-grade prompts for every aspect of running a shop — from writing repair orders to responding to reviews to marketing your services on social media.

Every prompt is:
- **Shop-specific** — Built for real auto repair work, not generic business writing
- **Structured** — Uses `[BRACKET VARIABLES]` so you can customize in seconds
- **Ready to use** — Designed to produce output you can hand to a customer or post today

---

## File Guide

| File | Contents | Prompts |
|------|----------|---------|
| [01-quick-start-guide.md](01-quick-start-guide.md) | How to use this toolkit effectively | — |
| [02-customer-communication-prompts.md](02-customer-communication-prompts.md) | Service write-ups, repair updates, follow-up messages | 23 |
| [03-service-estimates-prompts.md](03-service-estimates-prompts.md) | Estimates, recommendations, parts explanations | 22 |
| [04-shop-marketing-prompts.md](04-shop-marketing-prompts.md) | Review requests, social posts, promotions | 18 |
| [05-operations-prompts.md](05-operations-prompts.md) | SOPs, staff communication, vendor management | 17 |
| [06-workflow-sops.md](06-workflow-sops.md) | 5 complete shop workflow playbooks | — |
| [07-cheat-sheet.md](07-cheat-sheet.md) | Top 15 power prompts + quick reference | 15 |

**Total: 90+ prompts**

---

## Who This Is For

- **Independent shop owners** running their own auto repair business
- **Service advisors** who write repair orders and communicate with customers
- **Shop managers** standardizing how their team communicates
- **Mobile mechanics** looking to professionalize their client communications

---

*Built for mechanics who run a tight shop.*
