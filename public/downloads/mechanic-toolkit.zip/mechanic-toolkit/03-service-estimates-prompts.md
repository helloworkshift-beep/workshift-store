# 03 — Service Estimates Prompts

*22 prompts for writing professional estimates, explaining repair recommendations, and communicating pricing*

---

### Full Service Estimate — Multi-Point Inspection Results
*Use when presenting complete inspection findings and a comprehensive repair estimate.*

```
Write a full service estimate based on a multi-point vehicle inspection.

Customer: [CUSTOMER_NAME]
Vehicle: [YEAR] [MAKE] [MODEL], [MILEAGE] miles
Reason for visit: [CUSTOMER_COMPLAINT]

Inspection findings:
URGENT (safety or drivability concern):
- [URGENT_ITEM_1]: [DESCRIPTION], estimated cost: [COST]
- [URGENT_ITEM_2]: [DESCRIPTION], estimated cost: [COST]

RECOMMENDED (should be done soon):
- [RECOMMENDED_ITEM_1]: [DESCRIPTION], estimated cost: [COST]
- [RECOMMENDED_ITEM_2]: [DESCRIPTION], estimated cost: [COST]

MONITOR (not urgent yet but worth watching):
- [MONITOR_ITEM]: [DESCRIPTION], frequency to recheck: [RECHECK_INTERVAL]

Total for urgent repairs: [URGENT_TOTAL]
Total for all recommended: [FULL_TOTAL]

Write an estimate document that:
1. Separates items by urgency category clearly
2. Explains each item in plain language (what it does, why it matters, what happens if neglected)
3. Breaks down labor and parts for each item
4. States the total clearly
5. Notes any parts or labor warranties
```

---

### Brake Service Estimate
*Use when presenting a brake repair or replacement estimate.*

```
Write a brake service estimate for a customer.

Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Brake condition found:
- Front brakes: [CONDITION — e.g., "pads at 2mm, rotors within spec", "pads worn, rotors need replacement"]
- Rear brakes: [CONDITION]
- Brake fluid: [FLUID_CONDITION]
- Calipers: [CALIPER_CONDITION]
Services recommended:
- [SERVICE_1] (front/rear): parts $[PARTS], labor $[LABOR]
- [SERVICE_2]: parts $[PARTS], labor $[LABOR]
Total estimate: [TOTAL]
Warranty: [WARRANTY]

Write an estimate that:
1. Explains what brake pads and rotors do (briefly, for a non-car person)
2. Describes the condition found in clear terms (e.g., "critically worn" vs. "worn normally for mileage")
3. Explains why each service is recommended now vs. later
4. Breaks down the cost clearly

Trust-building tone — not upselling, just informing.
```

---

### Engine Diagnostic and Repair Estimate
*Use when presenting findings from a diagnostic scan or engine complaint diagnosis.*

```
Write a diagnostic results and repair estimate for an engine issue.

Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Customer complaint: [COMPLAINT — e.g., "check engine light on, rough idle, loss of power"]
Diagnostic codes found: [DTC_CODES]
Root cause identified: [ROOT_CAUSE_IN_PLAIN_ENGLISH]
Recommended repair: [REPAIR_DESCRIPTION]
Parts needed: [PARTS_LIST] — cost: [PARTS_COST]
Labor: [LABOR_HOURS] hours at [LABOR_RATE] = [LABOR_COST]
Total estimate: [TOTAL]
Diagnostic fee: [DIAG_FEE — note if applied toward repair]
Time to complete: [COMPLETION_TIME]

Write an estimate that:
1. Explains what the diagnostic code means in plain language
2. Connects the code to the customer's symptom they experienced
3. Explains the recommended repair
4. Makes the diagnostic fee transparent
5. Notes what happens if the repair is not done
```

---

### Tire Replacement Estimate
*Use when presenting tire wear findings and a replacement estimate.*

```
Write a tire inspection and replacement estimate.

Vehicle: [YEAR_MAKE_MODEL]
Tire findings:
- Front left: [TREAD_DEPTH]mm, condition: [CONDITION]
- Front right: [TREAD_DEPTH]mm, condition: [CONDITION]
- Rear left: [TREAD_DEPTH]mm, condition: [CONDITION]
- Rear right: [TREAD_DEPTH]mm, condition: [CONDITION]
Recommendation: [RECOMMENDATION — replace 2, replace 4, monitor, etc.]
Tire options:
- Budget option: [BRAND_MODEL], [PRICE] each
- Mid-range option: [BRAND_MODEL], [PRICE] each
- Premium option: [BRAND_MODEL], [PRICE] each
Alignment and balancing: [ALIGNMENT_COST], [BALANCE_COST]
Total estimate (mid-range): [TOTAL]

Write an estimate that explains:
1. What tread depth numbers mean (in terms a non-mechanic understands)
2. The safety threshold for replacement
3. The tire options without being confusing
4. Why alignment and balancing matter with new tires
```

---

### Transmission Service Estimate
*Use when recommending transmission service or presenting a transmission-related repair estimate.*

```
Write a transmission service estimate.

Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Type of transmission: [AUTOMATIC/MANUAL/CVT]
Service needed: [SERVICE — fluid change, filter replacement, rebuild, replacement]
Reason for recommendation: [REASON — mileage interval, fluid condition, slip/shudder symptoms]
Fluid condition: [FLUID_CONDITION — color, smell, metal flakes — if relevant]
Service details: parts $[PARTS], labor $[LABOR]
Total: [TOTAL]
Alternative if not serviced: [CONSEQUENCE — what could happen if this is skipped]

Write an estimate that:
1. Explains what a transmission does (briefly)
2. Describes why the service is recommended at this mileage or with these symptoms
3. Explains what the service involves (what we do)
4. Notes the risk of skipping it (honest, not fear-based)
5. States the total and any warranty

Under 250 words.
```

---

### Oil Change Service Summary
*Use when presenting a standard oil change completion summary to a customer.*

```
Write an oil change service summary.

Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Oil type used: [OIL_TYPE — e.g., 5W-30 full synthetic]
Oil capacity: [QUARTS]
Filter brand: [FILTER_BRAND]
Next oil change due: [NEXT_MILEAGE] miles / [NEXT_DATE]
Additional items inspected: [INSPECTION_ITEMS — fluids, tire pressure, lights, etc.]
Any flags from inspection: [FLAGS — items to watch or recommend]
Total charge: [TOTAL]

Write a service summary that:
1. Confirms what was done
2. States the next service interval clearly
3. Notes any flags from the inspection without being overwhelming
4. Thanks them briefly for their business

Under 150 words. Clean and professional.
```

---

### Major Repair vs. Vehicle Value Discussion
*Use when the repair cost is close to or exceeds the vehicle's value and the customer needs context.*

```
Write a message to help a customer make an informed decision when a major repair cost is close to the vehicle's value.

Customer: [CUSTOMER_NAME]
Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Estimated vehicle value: [VEHICLE_VALUE — approximate KBB/private party]
Repair needed: [REPAIR_DESCRIPTION]
Repair estimate: [REPAIR_ESTIMATE]
Vehicle condition otherwise: [VEHICLE_CONDITION — good, fair, poor]
Your recommendation: [YOUR_RECOMMENDATION — repair, sell as-is, junk, evaluate further]

Write a message that:
1. Presents the situation clearly (repair cost vs. vehicle value)
2. Acknowledges this is a significant financial decision
3. Lays out the options without bias (repair, sell/trade, junk title, etc.)
4. Gives your honest professional recommendation
5. Offers to help either way

Objective and helpful. This is not a sales pitch — it's a trusted advisor conversation.
```

---

### Parts Markup Explanation
*Use when a customer questions why they're paying more for parts than they saw online.*

```
Write an explanation for a customer who is questioning the cost of parts compared to online retail prices.

Customer: [CUSTOMER_NAME]
Part in question: [PART_NAME]
Online price they found: [ONLINE_PRICE]
Our parts price: [OUR_PARTS_PRICE]
Difference: [PRICE_DIFFERENCE]
Why our parts cost more: [REASONS — OEM vs. aftermarket, warranty on parts, shop liability, sourcing, etc.]

Write a response that:
1. Acknowledges their question directly (don't deflect)
2. Explains the real reasons behind the price difference (quality, warranty, sourcing)
3. Notes the warranty/guarantee we provide on parts vs. customer-supplied parts
4. States whether we allow customer-supplied parts and any caveats if so
5. Ends respectfully — they asked a fair question

Honest and educational. Under 200 words.
```

---

### Pre-Purchase Inspection Report
*Use when a customer brings in a vehicle for a pre-purchase inspection.*

```
Write a pre-purchase inspection report for a customer evaluating a used vehicle.

Vehicle inspected: [YEAR_MAKE_MODEL], [MILEAGE] miles
Customer: [CUSTOMER_NAME]
Inspection date: [DATE]

Inspection categories:
ENGINE: [FINDINGS]
TRANSMISSION: [FINDINGS]
BRAKES: [FINDINGS]
SUSPENSION/STEERING: [FINDINGS]
TIRES: [FINDINGS]
BODY/FRAME: [FINDINGS]
FLUIDS: [FINDINGS]
ELECTRICAL: [FINDINGS]
HVAC: [FINDINGS]
UNDERCARRIAGE: [FINDINGS]

Immediate concerns: [URGENT_ISSUES]
Estimated repair cost for immediate concerns: [IMMEDIATE_REPAIR_ESTIMATE]
Anticipated repairs in next 12 months: [UPCOMING_NEEDS]
Estimated cost of upcoming needs: [UPCOMING_ESTIMATE]
Overall assessment: [SUMMARY — buy, negotiate, avoid]

Write the report in plain language. They're deciding whether to buy this vehicle — give them a clear picture. Include your professional recommendation.
```

---

### Estimate Comparison Explanation
*Use when helping a customer understand why your estimate may differ from another shop.*

```
Write a response to a customer who says another shop quoted them lower.

Customer: [CUSTOMER_NAME]
Service quoted: [SERVICE]
Our estimate: [OUR_ESTIMATE]
Competitor quote: [COMPETITOR_QUOTE]
Difference: [DIFFERENCE]
Why our estimate may be higher: [REASONS — better parts quality, more thorough diagnosis, warranty included, etc.]
What's included in our estimate that may not be in theirs: [OUR_INCLUSIONS]

Write a response that:
1. Thanks them for letting us know (not defensive)
2. Asks about what's included in the competitor quote (key question)
3. Explains what our estimate includes
4. Highlights our warranty or quality difference
5. Doesn't badmouth the competitor

Confident and professional. The goal is to earn trust, not win an argument.
```

---

### Estimate for Fleet or Commercial Customer
*Use when writing an estimate for a business or fleet account.*

```
Write a professional estimate for a commercial fleet account.

Company: [COMPANY_NAME]
Fleet contact: [CONTACT_NAME]
Vehicle(s): [VEHICLE_LIST]
Services needed: [SERVICES]
Breakdown by vehicle:
- Vehicle 1 [LICENSE/UNIT]: [SERVICE], estimate: [COST]
- Vehicle 2 [LICENSE/UNIT]: [SERVICE], estimate: [COST]
- Vehicle 3 (if applicable): [SERVICE], estimate: [COST]
Total for all vehicles: [TOTAL]
Fleet discount (if applicable): [DISCOUNT]
Net total: [NET_TOTAL]
Priority vehicle (needed first): [PRIORITY] — completion by [DATE]
All vehicles completion: [COMPLETION_DATE]
Payment terms: [TERMS — net 30, on completion, etc.]

Format as a professional fleet estimate with a clear breakdown by unit and a summary total.
```

---

### Extended Warranty / Service Contract Explanation
*Use when a customer has an extended warranty or service contract and you need to communicate coverage.*

```
Write a message explaining to a customer how their extended warranty applies to the repair.

Customer: [CUSTOMER_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Extended warranty provider: [WARRANTY_COMPANY]
Repair needed: [REPAIR_DESCRIPTION]
Is it covered? [FULLY / PARTIALLY / NOT COVERED]
What's covered: [COVERED_AMOUNT_OR_ITEMS]
Customer's deductible: [DEDUCTIBLE]
What's NOT covered and why: [EXCLUSIONS]
Estimated customer out-of-pocket: [CUSTOMER_COST]
Next step: [AUTHORIZATION_PROCESS]

Write a message that:
1. States clearly what is and isn't covered
2. Explains the customer's cost
3. Describes the authorization process (how we work with their warranty company)
4. Sets expectations for timing
5. Is transparent about any gaps in coverage

Clear and helpful. Extended warranty confusion is a major frustration — make it simple.
```

---

### Seasonal Maintenance Package Estimate
*Use when presenting a seasonal maintenance bundle (e.g., winter prep, summer tune-up).*

```
Write a seasonal maintenance package estimate.

Season: [WINTER/SPRING/SUMMER/FALL]
Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Package name: [PACKAGE_NAME — e.g., "Winter Ready Package"]
Services included:
- [SERVICE_1]: [BRIEF_DESCRIPTION], value: $[INDIVIDUAL_PRICE]
- [SERVICE_2]: [BRIEF_DESCRIPTION], value: $[INDIVIDUAL_PRICE]
- [SERVICE_3]: [BRIEF_DESCRIPTION], value: $[INDIVIDUAL_PRICE]
- [SERVICE_4]: [BRIEF_DESCRIPTION], value: $[INDIVIDUAL_PRICE]
Regular price if purchased separately: [TOTAL_INDIVIDUAL]
Package price: [PACKAGE_PRICE]
Savings: [SAVINGS]
Available through: [OFFER_EXPIRATION]

Write an estimate that:
1. Opens with why this season's maintenance matters for this vehicle type
2. Lists each service with a brief explanation of what it does
3. Highlights the value and savings clearly
4. Creates natural urgency (seasonal timing)
```

---

### Written Estimate for Insurance or Legal Purposes
*Use when a customer needs a formal written estimate for an insurance claim or legal matter.*

```
Write a formal written estimate for insurance/legal purposes.

Date: [DATE]
Shop name: [SHOP_NAME]
Shop address: [ADDRESS]
Shop license: [LICENSE_NUMBER — if applicable]
Customer: [CUSTOMER_NAME]
Vehicle: [YEAR] [MAKE] [MODEL], VIN: [VIN], Mileage: [MILEAGE]
Damage or issue: [DAMAGE_DESCRIPTION]
Cause of damage: [CAUSE — accident, flood, vandalism, etc.]
Repair estimate:
- Labor: [LABOR_HOURS] hrs × $[LABOR_RATE] = $[LABOR_TOTAL]
- Parts: [PARTS_LIST_WITH_COSTS]
- Materials/shop supplies: $[MATERIALS]
Subtotal: $[SUBTOTAL]
Tax: $[TAX]
TOTAL ESTIMATE: $[TOTAL]
Estimate valid through: [VALIDITY_DATE]
Technician signature: ________________

Format as an official document with all fields. This will be submitted to an insurance company.
```

---

### Multi-Repair Prioritization Guide
*Use when a customer has multiple needed repairs but has a limited budget and needs help prioritizing.*

```
Write a repair prioritization guide for a customer with multiple needed repairs and a limited budget.

Customer: [CUSTOMER_NAME]
Budget available: [BUDGET]
Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles

Repairs needed (from inspection):
1. [REPAIR_1] — cost: [COST], safety/urgency: [CRITICAL/RECOMMENDED/MAINTENANCE]
2. [REPAIR_2] — cost: [COST], urgency: [LEVEL]
3. [REPAIR_3] — cost: [COST], urgency: [LEVEL]
4. [REPAIR_4] — cost: [COST], urgency: [LEVEL]
5. [REPAIR_5] — cost: [COST], urgency: [LEVEL]

Write a prioritized guide that:
1. Sorts repairs by safety urgency first, then cost-effectiveness
2. Explains why each repair is ranked where it is
3. Recommends what to do within their budget today
4. Notes what to schedule next
5. Estimates consequences of deferring each item

Help them make a smart decision, not spend more than they need to right now.
```

---

### Estimate Decline and Alternative Options
*Use when a customer declines your estimate and you want to offer alternative options.*

```
Write a response to a customer who said your estimate is too high and they want to decline.

Customer: [CUSTOMER_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Estimate they declined: [ESTIMATE_AMOUNT] for [SERVICE]
Alternative options I can offer: [OPTIONS — e.g., "used parts instead of OEM", "do the most urgent item only", "payment plan"]
Anything I can do to keep the job: [FLEXIBILITY]
What happens if they delay this repair: [CONSEQUENCE]

Write a response that:
1. Accepts their decision without pressure
2. Offers 1-2 genuine alternatives (not a bait-and-switch)
3. Notes what to watch for if they delay
4. Leaves the door open to come back

Under 150 words. Respectful and genuine.
```

---

### Diagnostic Fee Explanation
*Use when a customer questions why they're being charged for a diagnosis.*

```
Write an explanation for a customer who is questioning the diagnostic fee.

Customer: [CUSTOMER_NAME]
Diagnostic fee charged: $[DIAG_FEE]
What the diagnostic involved: [DIAGNOSTIC_PROCESS — time, tools used, expertise required]
Whether the fee is applied to the repair if they proceed: [YES/NO]
Why we charge for diagnostics: [REASON — covers time, tooling, specialist knowledge]

Write a response that:
1. Explains what was done during the diagnostic (the work, not just "we plugged in a scanner")
2. Clarifies the fee policy (applied to repair or not)
3. Helps them understand the value of an accurate diagnosis
4. Is not defensive

Under 150 words. Educational and transparent.
```

---

*Total prompts in this file: 22*
