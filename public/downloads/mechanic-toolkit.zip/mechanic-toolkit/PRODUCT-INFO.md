# PRODUCT INFO — The Auto Mechanic's AI Prompt Toolkit

---

## Product Details

| Field | Value |
|-------|-------|
| **Product Name** | The Auto Mechanic's AI Prompt Toolkit |
| **Version** | 1.0 |
| **Format** | 7 Markdown files (digital download) |
| **Total Prompts** | 90+ ready-to-use AI prompts |
| **Support** | helloworkshift@gmail.com |

---

## Who It's For

Auto mechanics, shop owners, and service advisors who want to write better customer communications, build professional estimates, market their shop, and standardize their operations — without hiring staff for it.

---

## What's Included

| File | Description | Prompt Count |
|------|-------------|--------------|
| `01-quick-start-guide.md` | Setup, system prompt, best practices | — |
| `02-customer-communication-prompts.md` | Service write-ups, updates, follow-ups | 23 |
| `03-service-estimates-prompts.md` | Estimates, parts explanations, recommendations | 22 |
| `04-shop-marketing-prompts.md` | Review requests, social media, promotions | 18 |
| `05-operations-prompts.md` | SOPs, staff communication, vendor management | 17 |
| `06-workflow-sops.md` | 5 complete shop workflow playbooks | — |
| `07-cheat-sheet.md` | Top 15 prompts + variable quick reference | 15 |

---

*For support: helloworkshift@gmail.com*
*Last updated: 2026*
