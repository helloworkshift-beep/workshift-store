# 04 — Shop Marketing Prompts

*18 prompts for review requests, social media, promotions, and growing your auto shop's reputation*

---

### Google Review Request — Text
*Use when asking a satisfied customer to leave a Google review.*

```
Write a Google review request text message.

Customer name: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Service performed: [SERVICE_SUMMARY]
Google review link: [REVIEW_LINK]
Shop name: [SHOP_NAME]

Write a text message that:
1. Thanks them by name for their visit
2. Makes the ask feel natural and brief
3. Provides the link clearly
4. Doesn't feel like an automated mass message

Under 75 words. Genuine and personal.
```

---

### Google Review Request — Email
*Use when following up via email to ask for a Google review.*

```
Write a Google review request email.

Customer name: [CUSTOMER_FIRST_NAME]
Service date: [SERVICE_DATE]
Vehicle: [YEAR_MAKE_MODEL]
Service performed: [SERVICE]
Google review link: [REVIEW_LINK]
Shop name: [SHOP_NAME]
My name: [MY_NAME]

Write an email that:
1. Opens by referencing their specific service (not generic)
2. Makes the ask in a natural, low-pressure way
3. Explains why reviews matter to an independent shop (briefly — 1 sentence)
4. Makes clicking the link frictionless
5. Thanks them

Under 150 words.
```

---

### Response to 5-Star Google Review
*Use when responding to a positive Google or Yelp review.*

```
Write a response to a 5-star review.

Reviewer name: [REVIEWER_NAME — or "Customer" if anonymous]
What they said: "[REVIEW_TEXT]"
Specific thing to reference: [SPECIFIC_DETAIL_TO_ACKNOWLEDGE]
Shop name: [SHOP_NAME]
My name: [MY_NAME]

Write a response that:
1. Thanks them by name
2. Mentions something specific from their review (not generic)
3. Expresses genuine appreciation
4. Invites them back

Under 75 words. Warm and personal.
```

---

### Response to 1-2 Star Review
*Use when responding to a negative review to protect your shop's reputation.*

```
Write a professional response to a negative review.

Reviewer: [REVIEWER_NAME — or "Customer"]
Their review: "[NEGATIVE_REVIEW_TEXT]"
What actually happened (your perspective): [YOUR_ACCOUNT]
Was the concern valid? [YES / PARTIALLY / NO]
What we did or offered to resolve it: [RESOLUTION_OFFERED]
My name: [MY_NAME]
Shop name: [SHOP_NAME]

Write a response that:
1. Opens with acknowledgment (not denial)
2. Is factual and professional (no emotion)
3. Takes responsibility where appropriate
4. States what was done to resolve it
5. Invites them to contact you directly

Under 150 words. This response is marketing — future customers are reading it.
```

---

### Instagram Post — Shop Culture / Behind the Scenes
*Use when sharing a behind-the-scenes look at your shop to build brand personality.*

```
Write an Instagram caption for a behind-the-scenes shop post.

What the photo/video shows: [PHOTO_DESCRIPTION — e.g., "technician working under a lifted truck", "shop at opening time", "newly installed equipment"]
What makes this moment special: [WHAT_TO_HIGHLIGHT]
Values or culture to convey: [CULTURE_POINT — e.g., "we're detail-oriented", "our team loves what they do"]
CTA or engagement question: [CTA]
Shop name: [SHOP_NAME]
Hashtags: [YES — include relevant local and industry hashtags / NO]

Write a caption that:
1. Feels human and authentic (not a press release)
2. Connects the image to a value your customers care about
3. Ends with an engaging question or CTA
4. Uses appropriate hashtags if requested
```

---

### Facebook Post — New Service or Equipment Announcement
*Use when announcing a new service, piece of equipment, or shop capability.*

```
Write a Facebook post announcing a new service or capability at the shop.

New service/equipment: [ANNOUNCEMENT]
What it allows us to do: [CAPABILITY]
Who benefits: [CUSTOMER_TYPE — e.g., "diesel truck owners", "all customers"]
Any launch special: [INTRO_OFFER]
Shop name: [SHOP_NAME]
CTA: [CTA — "Call to book", "DM us", "mention this post for X% off"]

Write a post that:
1. Leads with the customer benefit (what can they get done now that they couldn't before?)
2. Explains the new capability simply
3. Mentions any intro offer
4. Ends with a clear CTA

150-200 words. Excited but not over the top.
```

---

### Seasonal Promotion — Text to Customer List
*Use when running a seasonal service promotion.*

```
Write a seasonal promotion text message for our customer list.

Season/occasion: [SEASON_OR_EVENT]
Promotion: [OFFER — e.g., "winter tire swap special: $X per vehicle", "free multi-point inspection with any service in October"]
Valid through: [EXPIRATION_DATE]
Any limitations: [LIMITATIONS — by appointment, while supplies last, etc.]
Booking contact: [PHONE_OR_BOOKING_LINK]
Shop name: [SHOP_NAME]

Write a text that:
1. States the offer clearly in the first sentence
2. Creates natural urgency (seasonal timing + deadline)
3. Makes booking easy
4. Feels like a heads-up from a local shop owner, not a mass text

Under 80 words.
```

---

### "Why Go to an Independent Shop" Social Post
*Use when posting content that differentiates your independent shop from dealerships.*

```
Write a social media post explaining the benefits of using an independent auto shop vs. a dealership.

My shop: [SHOP_NAME]
Location: [CITY, STATE]
Key differentiators: [DIFFERENTIATORS — e.g., "half the labor rate of dealerships", "same quality parts", "you talk to the person who actually worked on your car", "family-owned for X years"]
Services I do that people often assume only dealerships do: [SERVICES]
Platform: [FACEBOOK/INSTAGRAM/NEXTDOOR]

Write a post that:
1. Doesn't badmouth dealerships (keep it positive)
2. Makes the value case for independent shops clearly
3. Builds trust with first-time customers who are hesitant to leave their dealer
4. Ends with a CTA

200-300 words.
```

---

### Customer Testimonial Post
*Use when sharing a customer quote or testimonial on social media.*

```
Write a social media testimonial post based on a customer quote.

Customer name: [FIRST_NAME — or "a recent customer" if they prefer anonymity]
Vehicle: [MAKE_MODEL — optional]
Service received: [SERVICE]
What they said: "[CUSTOMER_QUOTE]"
Any result to highlight: [RESULT — e.g., "fixed what two other shops couldn't figure out"]
Shop name: [SHOP_NAME]
Platform: [PLATFORM]

Write a post that:
1. Leads with the customer's experience or result (not our shop name)
2. Uses the quote in a natural way
3. Adds brief context about the service
4. Ends with a CTA for similar customers

Authentic. Not a corporate case study — a real person's experience.
```

---

### Referral Program Announcement — Social
*Use when launching a customer referral program and promoting it on social media.*

```
Write a social media post announcing a customer referral program.

Shop name: [SHOP_NAME]
What the referrer gets: [REFERRER_REWARD — e.g., "$25 off next service"]
What the referred friend gets: [FRIEND_REWARD — e.g., "$25 off first service"]
How to refer: [HOW_TO_REFER — mention name when booking, use link, etc.]
Any expiration: [EXPIRATION — if applicable]
Platform: [PLATFORM]

Write a post that:
1. Leads with the benefit (not "we're launching a program")
2. Makes both the referral reward and the friend reward clear
3. Explains how to refer in 1-2 steps
4. Ends with a CTA

Under 150 words. Community-minded tone.
```

---

### Google Business Profile Update Post
*Use when updating your Google Business Profile with a timely post or offer.*

```
Write a Google Business Profile post.

Shop name: [SHOP_NAME]
Post type: [OFFER / WHAT'S NEW / EVENT / COVID_UPDATE — choose one]
Topic: [TOPIC — e.g., "fall brake inspection special", "new alignment equipment", "hiring a technician"]
Offer or call to action: [OFFER_OR_CTA]
Valid dates (if offer): [START_DATE] to [END_DATE]
Photo description (if including image): [PHOTO_DESCRIPTION]

Write a post that:
1. Gets to the point in the first sentence
2. Includes the offer or news clearly
3. Has a direct CTA
4. Is under the 1,500 character limit

Professional and specific.
```

---

### Neighborhood/Nextdoor Post
*Use when posting in local community groups or Nextdoor to attract neighborhood customers.*

```
Write a neighborhood community post for Nextdoor or a local Facebook group.

Shop name: [SHOP_NAME]
Location: [ADDRESS or INTERSECTION]
How long in business: [YEARS_IN_BUSINESS]
Services offered: [TOP_SERVICES]
What makes the shop different: [DIFFERENTIATOR]
Intro offer for first-time customers: [INTRO_OFFER]
Contact info: [PHONE_OR_WEBSITE]

Write a post that:
1. Introduces the shop as a neighbor, not an advertiser
2. Mentions the neighborhood/local connection
3. Offers genuine value to local residents
4. Keeps it friendly and non-salesy

100-150 words. Like an intro from a neighbor who happens to own a shop.
```

---

### Before/After Service Social Post
*Use when posting a vehicle transformation (clean engine bay, rust repair, etc.) on social media.*

```
Write a before/after post for social media showcasing a notable repair or restoration.

Platform: [INSTAGRAM / FACEBOOK]
What was done: [SERVICE_DESCRIPTION]
Vehicle: [YEAR_MAKE_MODEL — or just "a recent customer's vehicle"]
Before state: [BEFORE_DESCRIPTION]
After state: [AFTER_DESCRIPTION]
What makes this job special: [WHAT_YOU'RE_PROUD_OF]
Time it took: [TIMEFRAME]
Hashtags needed: [YES/NO]

Write a caption that:
1. Opens with the transformation (result-first)
2. Briefly explains the process
3. Connects to the customer's relief or satisfaction
4. Ends with a CTA or engagement question

Under 200 words.
```

---

### Email Newsletter — Monthly Shop Update
*Use when sending a monthly email to your customer email list.*

```
Write a monthly shop email newsletter.

Shop name: [SHOP_NAME]
Month: [MONTH]
Shop news: [SHOP_UPDATE — new tech, staff addition, hours change, etc.]
Maintenance tip of the month: [MAINTENANCE_TIP]
Monthly special or promotion: [PROMOTION]
Customer spotlight (optional): [CUSTOMER_STORY — brief]
CTA: [CTA — book an appointment, refer a friend, etc.]
My name: [MY_NAME]

Write a newsletter that:
1. Opens with something useful (not a promotion)
2. Shares a genuine maintenance tip in plain language
3. Mentions the promotion without leading with it
4. Feels like a note from a local shop you trust, not a corporate mail merge

Under 300 words.
```

---

### Technician Spotlight Post
*Use when featuring a team member to build trust and show the human side of your shop.*

```
Write a technician spotlight post for social media.

Platform: [PLATFORM]
Technician name: [TECH_NAME]
Role: [ROLE — e.g., "lead technician", "service advisor", "apprentice"]
Years of experience: [YEARS]
Specialty: [SPECIALTY — e.g., "European vehicles", "diesel engines", "electrical diagnosis"]
Something interesting about them: [PERSONAL_DETAIL — their passion for cars, how long they've been with the shop, etc.]
Shop name: [SHOP_NAME]

Write a post that:
1. Introduces the person (not just their credentials)
2. Highlights what they're known for at the shop
3. Adds a personal detail that makes them relatable
4. Ends with why customers trust their work

150-200 words. Human and genuine.
```

---

### Safety Tip Content Post
*Use when sharing a vehicle safety or maintenance tip to add value and build authority.*

```
Write a vehicle safety or maintenance tip post for social media or a newsletter.

Platform/format: [PLATFORM — Instagram, Facebook, email, etc.]
Topic: [TOPIC — e.g., "when to replace your cabin air filter", "how to check tire pressure", "signs your brakes need attention"]
Key information to convey: [KEY_POINTS]
How it connects to our services: [SERVICE_CONNECTION — natural, not pushy]
CTA (if any): [CTA]
Shop name: [SHOP_NAME]

Write a tip post that:
1. Teaches something genuinely useful
2. Is in plain language (no mechanic jargon without explanation)
3. Positions the shop as a trusted resource
4. Includes a natural (not forced) mention of services if relevant

150-200 words for social. 100 words for a text/email tip.
```

---

### Local Sponsorship / Community Involvement Post
*Use when announcing a local sponsorship, charity involvement, or community event.*

```
Write a social post announcing a community involvement or sponsorship.

Shop name: [SHOP_NAME]
What we're doing: [COMMUNITY_ACTIVITY — sponsoring a sports team, donating to a school, participating in a local event]
Event/org name: [ORG_OR_EVENT_NAME]
Why we're involved: [WHY — community connection, personal tie, belief in the cause]
Any discount or offer tied to it (if applicable): [OFFER]
Platform: [PLATFORM]

Write a post that:
1. Shares the community involvement with genuine enthusiasm
2. Tells a brief "why" story (the human connection)
3. Tags the org or event if possible
4. Keeps the focus on the community, not the shop

Under 150 words. Community-first, shop-second.
```

---

*Total prompts in this file: 18*
