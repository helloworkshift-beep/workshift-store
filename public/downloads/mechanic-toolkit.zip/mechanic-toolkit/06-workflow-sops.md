# 06 — Workflow SOPs

*5 complete systems for your most time-intensive shop tasks — powered by AI*

---

## SOP A: The Perfect Customer Drop-Off to Pickup System

**What this produces:** A professional, consistent customer experience from check-in to vehicle return  
**When to run it:** Every service appointment  
**Prompt file:** `02-customer-communication-prompts.md`

---

**Step 1 — Drop-off confirmation (within 30 minutes of vehicle receipt)**

Use **Vehicle Drop-Off Confirmation Text** to send an immediate acknowledgment.

Don't wait until after diagnosis. Customers start worrying the moment they leave their keys.

---

**Step 2 — Inspection results (within agreed timeframe)**

Use **Vehicle Inspection Results Message** to communicate findings.

Communication rule: Lead with what's working, then what needs attention. Prioritize by urgency. Give a total estimate. Ask for approval.

If you find additional issues while working: use **Additional Repair Found During Service** — never do unauthorized work.

---

**Step 3 — Repair authorization**

Use **Repair Authorization Request** for any work you haven't already gotten approval for.

Written authorization (text or email) is your protection against disputes. Always get it.

---

**Step 4 — Vehicle ready notification**

Use **Vehicle Ready for Pickup Notification** the moment the vehicle is done and QC'd.

Include one proactive maintenance note — something small and genuinely helpful. It shows you care about their vehicle beyond just the repair.

---

**Step 5 — Post-service follow-up (24-48 hours later)**

Use **Post-Service Thank You** with a review request included.

The 24-48 hour window is when customers are most likely to leave a positive review. Don't wait a week.

---

**Full system timing:**
| Step | Timing |
|------|--------|
| Drop-off confirmation | Within 30 min of drop-off |
| Inspection results | Within agreed timeframe (quote this at check-in) |
| Authorization for additional work | Before starting any additional repair |
| Ready notification | Same day vehicle is complete |
| Thank you + review request | 24-48 hours after pickup |

---

## SOP B: The Reputation Management System — Reviews on Autopilot

**What this produces:** A steady stream of Google reviews and a protected online reputation  
**When to run it:** Weekly  
**Time commitment:** 30 minutes per week  
**Prompt file:** `04-shop-marketing-prompts.md`

---

**Weekly review routine:**

**Monday (10 minutes):**
- Check Google, Yelp, and Facebook for new reviews
- Respond to all new positive reviews using **Response to 5-Star Google Review**
- Note any negative reviews for immediate response

**Tuesday (15 minutes):**
- Respond to any negative reviews using **Response to 1-2 Star Review**
- Rule: never let a negative review sit unanswered for more than 72 hours

**Friday (5 minutes):**
- Send Google review requests to satisfied customers from the week
- Use **Google Review Request — Text** for customers who prefer texting
- Use **Google Review Request — Email** for email customers

---

**Review request timing:**
The best time to ask for a review is within 24-48 hours of a positive experience. If a customer says "thank you" or "great job" — that's your cue.

**Review threshold goal:** Aim for at least 1 new review per week. 52 reviews/year compounded over 3 years = dominant local presence.

---

## SOP C: Monthly Marketing Content — 1 Hour a Month

**What this produces:** A full month of social media content and a monthly email  
**When to run it:** Last week of each month (prep for next month)  
**Time commitment:** 60 minutes  
**Prompt file:** `04-shop-marketing-prompts.md`

---

**30 minutes — Plan and draft social posts:**
- 1 behind-the-scenes post: **Instagram Post — Shop Culture / Behind the Scenes**
- 1 safety or maintenance tip: **Safety Tip Content Post**
- 1 customer testimonial or result: **Customer Testimonial Post** or **Before/After Service Post**
- 1 promotional post (if running a special): **Seasonal Promotion — Text to Customer List**

**15 minutes — Write the email newsletter:**
Use **Email Newsletter — Monthly Shop Update**

**15 minutes — Update Google Business Profile:**
Use **Google Business Profile Update Post** with any current offer or news

---

**Monthly content formula:**
| Week | Post Type |
|------|-----------|
| Week 1 | Behind the scenes / shop life |
| Week 2 | Maintenance tip (educational value) |
| Week 3 | Customer result or testimonial |
| Week 4 | Promotion or seasonal offer |

---

## SOP D: The New Customer Win — First Impression System

**What this produces:** A first-time customer who becomes a loyal, reviewing, referring regular  
**When to run it:** Every time a new customer visits  
**Prompt file:** `02-customer-communication-prompts.md`, `04-shop-marketing-prompts.md`

---

**At the visit:**
- Welcome them personally — ask how they heard about you
- Explain every step: what you'll inspect, when you'll call, how long it takes
- Use the full drop-off to pickup SOP (SOP A)

**After the visit (same day):**
- Send **Post-Service Thank You** with review request

**48 hours after:**
- If no review yet, send **Google Review Request — Text**

**After first review (if they leave one):**
- Use **Response to 5-Star Google Review** — respond personally

**30 days after:**
- Send **New Customer Welcome Message** offering a second-visit incentive (builds the habit of returning)

---

**First-visit checklist:**
- [ ] Customer was greeted by name
- [ ] Drop-off confirmation sent within 30 min
- [ ] Authorization received before additional work started
- [ ] Vehicle ready notification sent promptly
- [ ] Maintenance notes included with pickup
- [ ] Thank you sent within 48 hours
- [ ] Review request sent

---

## SOP E: The Shop Operations Review — Quarterly Check-In

**What this produces:** A clear picture of what's working, what needs attention, and what to focus on next quarter  
**When to run it:** Every 90 days  
**Time commitment:** 2 hours  
**Prompt file:** `05-operations-prompts.md`

---

**Step 1 — Review key metrics (30 minutes)**

Pull these numbers from your shop management system:
- [ ] Total repair orders this quarter
- [ ] Average repair order value
- [ ] Comeback rate (warranty returns)
- [ ] Technician efficiency (hours billed vs. hours available)
- [ ] Review count and average rating
- [ ] Customer retention rate (returning vs. first-time)

---

**Step 2 — Safety and compliance check (30 minutes)**

Use **Annual Insurance and Compliance Checklist** as a quarterly spot-check.

At minimum, verify:
- [ ] All licenses current
- [ ] Lift certifications up to date
- [ ] Environmental disposal scheduled
- [ ] Employee certifications current

---

**Step 3 — Team feedback (20 minutes)**

Run a brief 1-on-1 with each team member:
- "What's working well in the shop?"
- "What's your biggest frustration?"
- "What would make your job easier?"

Use **Performance Feedback for a Technician** for any formal feedback to deliver.

---

**Step 4 — Set next quarter priorities (20 minutes)**

Based on your metrics and team feedback, identify:
- 1 metric you're focused on improving
- 1 operational improvement to implement
- 1 marketing initiative to run
- Any equipment or staffing needs

Use **New Equipment Purchase Justification Memo** if a major purchase is on the table.

---

*5 complete shop workflow SOPs*
