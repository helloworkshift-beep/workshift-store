# 05 — Shop Operations Prompts

*17 prompts for shop SOPs, staff management, vendor communication, and business operations*

---

### Shop Opening Procedure SOP
*Use when documenting the standard opening procedure for your shop.*

```
Write an opening shift SOP for an auto repair shop.

Shop name: [SHOP_NAME]
Opening time: [OPEN_TIME]
Who opens: [OPENER_ROLE — service advisor, lead tech, owner]
Key tasks at opening: [OPENING_TASKS — e.g., unlock, open bays, check voicemail, review day's schedule, prepare work orders]
Systems to check: [SYSTEMS — shop management software, phone system, computer]
Safety check items: [SAFETY_CHECKS — fire extinguisher, hazmat disposal, lifts]
Time to complete all opening tasks: [ESTIMATED_TIME]

Write a numbered SOP with:
1. Step-by-step opening tasks in order
2. Who is responsible for each step
3. Time allotment per task
4. What "complete" looks like for each step
5. What to do if a critical opening task can't be completed (e.g., system down)

Format for posting at the front desk or in a shared binder.
```

---

### Closing Procedure SOP
*Use when documenting the standard closing procedure for your shop.*

```
Write a closing shift SOP for an auto repair shop.

Shop name: [SHOP_NAME]
Closing time: [CLOSE_TIME]
Who closes: [CLOSER_ROLE]
End-of-day tasks: [CLOSING_TASKS — e.g., secure vehicles, update work orders, close out register, lock bays]
Security checks: [SECURITY_STEPS — doors, lifts lowered, alarm set]
Cash/payment closeout: [PAYMENT_CLOSEOUT_PROCESS]
Next-day prep: [PREP_TASKS — e.g., "pull work orders for tomorrow's appointments"]

Write a numbered SOP with:
1. Tasks in the order they should be completed
2. Owner of each task
3. Any time-sensitive steps (e.g., "daily deposits must be made by X")
4. Sign-off checklist at the end

Format for posting in the shop office.
```

---

### New Technician Onboarding Checklist
*Use when hiring a new technician and planning their first week.*

```
Write a first-week onboarding plan for a new automotive technician.

Shop: [SHOP_NAME]
New hire: [TECH_NAME]
Start date: [START_DATE]
Their skill level: [SKILL_LEVEL — apprentice, journeyman, master]
Certifications: [CERTIFICATIONS — ASE, OEM, etc.]
Mentor assigned: [MENTOR_NAME — if applicable]
Tools they're bringing: [TECH_TOOLS_STATUS — using shop tools / bringing own]
Key systems to learn: [SHOP_MANAGEMENT_SOFTWARE]
Policies to cover: [KEY_POLICIES]

Create a day-by-day plan for Week 1:
- Day 1: Shop tour, introductions, paperwork, safety overview
- Day 2: Observe existing work orders, learn the shop management system
- Day 3: Supervised diagnostic and basic service
- Day 4: First assigned work order with oversight
- Day 5: Review, feedback, answer questions

Include a skill assessment checklist for the end of week 1.
```

---

### Service Advisor Job Description
*Use when hiring a service advisor or customer service representative for the front desk.*

```
Write a job description for a service advisor position.

Shop: [SHOP_NAME], located in [CITY, STATE]
Role: Service Advisor
Responsibilities: [RESPONSIBILITIES — e.g., greet customers, write work orders, call customers with updates, explain repairs, process payments]
Experience required: [REQUIREMENTS — e.g., "2+ years auto shop experience preferred", "customer service experience required"]
Pay range: [PAY_RANGE — hourly or salary + commission]
Benefits (if applicable): [BENEFITS]
Hours: [SHIFT_SCHEDULE]
Why work here: [SHOP_CULTURE_DESCRIPTION]
How to apply: [APPLICATION_PROCESS]

Write a job posting that:
1. Opens with why this shop is a great place to work
2. Describes the role in terms of what you'll do (not a task list)
3. Lists requirements clearly
4. Ends with an easy application CTA
```

---

### Warranty Claim Documentation Form
*Use when creating an internal form for documenting warranty claims on completed work.*

```
Write an internal warranty claim documentation form template.

Shop name: [SHOP_NAME]
Form purpose: Document warranty claims on repairs to protect the shop and ensure consistent resolution

Include fields for:
- Date of warranty claim
- Customer name and contact
- Vehicle info (year, make, model, VIN, mileage)
- Original repair (date, work order number, technician)
- Original complaint and repair performed
- Customer's warranty complaint
- Technician's inspection findings on warranty visit
- Determination: covered / not covered / partially covered
- Resolution performed
- Parts replaced (if any)
- Labor time spent
- Cost to shop
- Customer signature acknowledging resolution
- Technician signature

Format as a fillable form template. Professional and thorough.
```

---

### Vehicle Storage Policy — Customer Handout
*Use when writing a policy document to give customers whose vehicles may be stored at your shop.*

```
Write a vehicle storage policy for our shop.

Shop name: [SHOP_NAME]
Storage rate: $[RATE] per [DAY/WEEK] after [FREE_PERIOD] free days
When storage fees begin: [TRIGGER — e.g., "after repair is completed and customer is notified", "after 5 business days if not picked up"]
Maximum storage period before additional action: [MAX_PERIOD]
What happens at max period: [CONSEQUENCE — lien, abandoned vehicle process, etc.]
Exceptions: [EXCEPTIONS — if any]

Write a clear, professional policy document that:
1. States the storage fee clearly
2. Explains when it begins and how customers will be notified
3. Describes the process for extended storage situations
4. Notes any legal rights (abandoned vehicle statutes)

This document will be given to customers at drop-off or when a vehicle is at risk of storage fees.
```

---

### Vendor Communication — Parts Order Dispute
*Use when disputing an incorrect or damaged parts order with a supplier.*

```
Write a message to a parts vendor about an incorrect or damaged order.

Vendor: [VENDOR_NAME]
Parts ordered: [PARTS_LIST]
Purchase order or invoice number: [PO_NUMBER]
Issue: [ISSUE — wrong part, damaged packaging, incorrect quantity, quality defect]
How this affected our work: [IMPACT — e.g., "delayed customer vehicle by 2 days", "had to source replacement elsewhere at additional cost"]
What I'm requesting: [REQUEST — replacement, credit, refund]
My name: [MY_NAME], [SHOP_NAME]
Account number: [ACCOUNT_NUMBER]

Write a message that:
1. States the issue factually and specifically
2. References the order number
3. States the impact on our operations
4. Makes a clear request
5. Remains professional (you'll work with this vendor again)

Under 200 words.
```

---

### Vendor Negotiation — Volume Discount Request
*Use when negotiating better pricing or terms with a parts supplier.*

```
Write a vendor negotiation email requesting better pricing or terms.

Vendor: [VENDOR_NAME]
My shop: [SHOP_NAME]
Current spending with this vendor: [MONTHLY_SPEND] per month / [ANNUAL_SPEND] annually
What I'm requesting: [REQUEST — e.g., "better parts discount tier", "extended payment terms", "free shipping threshold"]
Why I deserve better terms: [RATIONALE — volume, tenure, growth, payment history]
Competitive context: [COMPETITOR_OFFER — if I have one, what is it?]
My timeline: [DECISION_TIMELINE]
My name: [MY_NAME]

Write a negotiation email that:
1. Leads with the relationship and volume
2. Makes the request clearly and specifically
3. References any competitive offers (if applicable) as leverage, not a threat
4. Ends with an invitation to discuss

Professional and direct. I want a better deal, not a fight.
```

---

### Staff Meeting Agenda — Weekly Shop Meeting
*Use when planning a weekly or regular team meeting for your shop staff.*

```
Write a weekly shop meeting agenda.

Shop: [SHOP_NAME]
Meeting date/time: [DATE_TIME]
Attendees: [ATTENDEES — technicians, service advisor, manager]
Duration: [MEETING_LENGTH]
Topics this week:
- Production update: [THIS_WEEK_WORKLOAD]
- Quality or comeback issue to review: [QUALITY_ITEM — if any]
- Safety topic: [SAFETY_TOPIC]
- Team update: [TEAM_NEWS — new hire, schedule change, etc.]
- Upcoming week: [NEXT_WEEK_PREVIEW]
- Recognition: [WHO_TO_RECOGNIZE — if any]

Create an agenda with:
1. Timestamps for each section
2. Who leads each item
3. 2-3 discussion questions for the meeting
4. Action items format (who does what by when)

Under 30 minutes total. Keep it tight.
```

---

### Performance Feedback for a Technician
*Use when providing feedback to a technician on their work quality, efficiency, or customer interaction.*

```
Write a performance feedback message for a technician.

Tech name: [TECH_NAME]
Feedback period: [PERIOD — this week, this month, last 3 months]
What they're doing well: [STRENGTHS — be specific: fast diagnostic, clean work orders, reliable]
Area for improvement: [IMPROVEMENT_AREA — be specific: comeback rate, estimated time accuracy, communication]
Specific example of the issue: [SPECIFIC_EXAMPLE]
What success looks like: [SUCCESS_DEFINITION — what you want to see instead]
Next check-in: [FOLLOW_UP_DATE]

Write feedback that:
1. Opens with genuine recognition
2. Addresses the improvement area directly with a specific example
3. Sets clear expectations for what to do differently
4. Sets a follow-up date

Delivered respectfully and clearly. Technicians respond to direct, specific feedback — not vague criticism.
```

---

### Lift Safety Inspection Checklist
*Use when creating a periodic lift safety inspection procedure.*

```
Write a lift safety inspection checklist for our shop.

Number of lifts: [NUMBER_OF_LIFTS]
Types of lifts: [LIFT_TYPES — two-post, four-post, scissor, etc.]
Inspection frequency: [FREQUENCY — daily, weekly, monthly]
Who performs the inspection: [INSPECTOR_ROLE]

Create a safety inspection checklist covering:
1. Structural components (columns, arms, runways)
2. Locking mechanisms and safety latches
3. Hydraulic systems (fluid level, leaks, cylinders)
4. Electrical components (switches, cables)
5. Lifting pads and adapters
6. Floor attachment condition
7. ANSI/ALI compliance items
8. Test lift procedure steps

Format with: item, inspection criteria, pass/fail checkboxes, and notes field. Include a sign-off line for technician and date.

This document may be reviewed by OSHA or insurance auditors — make it thorough.
```

---

### Shop Rules and Employee Handbook Section
*Use when writing a shop rules section for an employee handbook or orientation document.*

```
Write a shop rules and expectations document for new employees.

Shop name: [SHOP_NAME]
Topics to cover:
- Safety requirements (PPE, lift safety, chemical handling)
- Personal conduct (language, professional behavior, customer interaction)
- Tool policy (shop tools vs. personal tools, accountability)
- Vehicle handling (customer vehicles, speed limits, inspection before/after)
- Cleanliness standards (bay cleanliness, shop appearance, uniform)
- Phone and personal device policy
- Tardiness and attendance policy
- Disciplinary process

Write a clear, concise shop rules document that:
1. States each rule in plain language
2. Explains the "why" where it helps compliance
3. States the consequence for violations
4. Ends with an acknowledgment signature section

Tone: Professional and direct. Written to be read, not filed.
```

---

### Annual Insurance and Compliance Checklist
*Use when doing an annual review of shop insurance coverage and regulatory compliance.*

```
Write an annual compliance and insurance review checklist for an auto repair shop.

Shop name: [SHOP_NAME]
State: [STATE]
Shop type: [REPAIR_ONLY / ALSO_SELLS_PARTS / AUTO_BODY / SPECIALTY]

Create a checklist covering:
1. Insurance policies to review (general liability, garage keeper's, workers' comp, property)
2. License renewals (contractor license, state auto repair license, emissions certification)
3. OSHA compliance items (SDS sheets, PPE, fire safety, hazmat)
4. EPA compliance (waste oil, refrigerant, battery disposal)
5. Building and equipment inspections (lift certification, fire suppression)
6. Employee training renewals (safety training, certification updates)
7. Financial reviews (payroll tax deposits, business registration renewal)
8. Technology (shop management software licenses, security cameras, data backup)

Format as a checklist with: item, renewal frequency, deadline month, responsible party, done/not done checkbox.
```

---

### Customer Vehicle Damage Claim Process
*Use when a customer claims their vehicle was damaged while in your shop's care.*

```
Write an internal process document for handling customer vehicle damage claims.

Shop name: [SHOP_NAME]
Insurance carrier: [CARRIER_NAME — or "consult with carrier" if not known]

Write a step-by-step process covering:
1. Initial claim receipt (how to take the customer's report)
2. Immediate documentation steps (photos, written account, witnesses)
3. Who to notify internally (owner, manager)
4. How to communicate with the customer during the process
5. Insurance notification and claims process
6. Resolution options (repair, compensation, third-party estimate)
7. Documentation to retain in the customer file
8. How to prevent recurrence

Also write: a customer-facing acknowledgment form for when they pick up their vehicle after a damage incident.

Professional and thorough — this is a legal and financial protection document.
```

---

### Environmental Compliance Reminders — Monthly
*Use when documenting or posting monthly environmental compliance reminders.*

```
Write a monthly environmental compliance reminder document for the shop team.

Shop name: [SHOP_NAME]
Month: [MONTH]
State: [STATE]

Include reminders on:
1. Used oil disposal (licensed collector, no pouring down drains)
2. Antifreeze disposal (recycling, not dumping)
3. Battery disposal (core return, licensed recycler)
4. Refrigerant (EPA 609 certification, no venting)
5. Parts washer fluid (hazardous waste pickup schedule)
6. Rags and filters (proper disposal per state regs)
7. Any upcoming inspections or collection dates: [SCHEDULED_EVENTS]

Format as a brief monthly bulletin posted in the shop. Clear, brief, compliant.
Include: "If you're unsure about proper disposal of any material, ask [MANAGER_NAME] before disposing."
```

---

### New Equipment Purchase Justification Memo
*Use when making the business case for a major equipment purchase.*

```
Write a business justification memo for purchasing new shop equipment.

Equipment: [EQUIPMENT_NAME]
Cost: [PURCHASE_PRICE]
Alternative: [LEASE / USED — if considering alternatives]
What it replaces or adds: [WHAT_IT_DOES_FOR_THE_SHOP]
Vehicles/services we can't do or can't do well without it: [CURRENT_LIMITATIONS]
Revenue opportunity enabled: [NEW_REVENUE — e.g., "adds alignment services worth $X/month"]
Payback period: [MONTHS_TO_PAYBACK]
Financing options: [FINANCING_OPTIONS — if applicable]
Urgency: [URGENT / NOT URGENT — why]

Write a business justification that:
1. States the equipment and cost clearly
2. Explains the limitation it addresses
3. Calculates the revenue opportunity and payback period
4. Makes a clear recommendation

1 page. For the owner, partner, or lender.
```

---

*Total prompts in this file: 17*
