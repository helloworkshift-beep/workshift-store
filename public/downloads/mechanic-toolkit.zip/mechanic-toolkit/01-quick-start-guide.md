# 01 — Quick Start Guide

*How to get maximum value from this toolkit in the first 10 minutes*

---

## The 3-Minute Setup

### Step 1: Pick Your AI Tool
These prompts work with any modern LLM:
- **ChatGPT (GPT-4o)** — Great for quick customer messages
- **Claude (Sonnet or Opus)** — Best for longer documents like SOPs and estimates
- **Gemini Advanced** — Works well on mobile

### Step 2: Set a System Prompt
Paste this at the start of any new conversation:

```
You are an experienced auto shop owner and service advisor with 20+ years in the automotive industry. You understand how to communicate technical issues to non-technical customers in plain language — honest, straightforward, and never condescending. You write professional service documents, customer messages, and marketing copy for an independent auto repair shop. Produce clean, usable output immediately. Keep the tone friendly but professional.
```

### Step 3: Fill In the Brackets
Every prompt uses `[BRACKET_VARIABLES]` in ALL_CAPS. Replace every bracket with your real shop and customer information before pasting.

---

## How to Fill In Variables Like a Pro

**Bad:**
```
[VEHICLE] = their car
[ISSUE] = the problem
```

**Good:**
```
[VEHICLE] = 2018 Toyota Camry with 87,000 miles
[ISSUE] = intermittent rough idle at startup, likely caused by carbon buildup on intake valves (direct injection engine)
```

Real details = professional output your customer will trust.

---

## Power Techniques

### Use AI for Customer Communication Speed
Writing a repair authorization text used to take 5 minutes. With this toolkit, it takes 30 seconds. Use the time you save to take one more vehicle.

### Create Templates for Repeat Situations
Once you generate a great response for a common situation (like explaining why a recommended service is overdue), save it as a template in your phone or computer. Edit 10% for each customer.

### Regenerate for Tone
- *"Rewrite this for a customer who has been pushing back on cost — make it more empathetic"*
- *"Make this shorter — they prefer texts over long messages"*
- *"Rewrite for a long-time customer I have a friendly relationship with"*

---

## Common Mistakes to Avoid

❌ **Using technical jargon in customer communications** — These prompts translate tech to plain language, but only if you give them specific technical input.

❌ **Not editing before sending** — Add the customer's first name, a personal touch, your shop name.

❌ **Ignoring the marketing prompts** — Review responses and social posts drive new customers. Don't skip them.

---

## Recommended Use by Situation

| Situation | Go-To Prompts |
|-----------|--------------|
| Explaining repairs to a customer | Customer Comm #1, #3 |
| Writing a repair authorization | Customer Comm #4 |
| Building a detailed estimate | Estimates #1, #3 |
| Explaining why a part costs what it costs | Estimates #8 |
| Asking for a Google review | Marketing #1, #2 |
| Responding to a bad review | Marketing #6, #7 |
| Writing a social media post | Marketing #9, #10 |
| Running a seasonal promo | Marketing #12 |
| Writing an employee policy | Operations #1 |
| Texting a vendor about a delay | Operations #10 |

---

## File Navigation

- **Customer Communication** → [02-customer-communication-prompts.md](02-customer-communication-prompts.md)
- **Service Estimates** → [03-service-estimates-prompts.md](03-service-estimates-prompts.md)
- **Shop Marketing** → [04-shop-marketing-prompts.md](04-shop-marketing-prompts.md)
- **Shop Operations** → [05-operations-prompts.md](05-operations-prompts.md)
- **Full Workflow Playbooks** → [06-workflow-sops.md](06-workflow-sops.md)
- **Quick Reference** → [07-cheat-sheet.md](07-cheat-sheet.md)

---

*Start with the cheat sheet for the 15 most-used prompts, or jump to customer communications if you have a message to write right now.*
