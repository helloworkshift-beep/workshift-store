# 07 — The Mechanic's AI Cheat Sheet

*The 15 most powerful prompts in this toolkit — ready to copy, paste, and use right now*

---

> Fill in every `[BRACKET]` with real details before pasting. Specific input = professional output.

---

## THE 15 MOST POWERFUL PROMPTS

---

### 🏆 Prompt 1: Vehicle Inspection Results Message
*Use when presenting inspection findings to a customer before starting work.*

```
Write a clear customer inspection results message.

Customer: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Reason for visit: [ORIGINAL_COMPLAINT]
What we found:
- Urgent: [URGENT_ITEMS_WITH_ESTIMATES]
- Recommended: [RECOMMENDED_ITEMS]
- Monitor: [DEFERRED_ITEMS]
Total estimate: [TOTAL]
Time needed: [COMPLETION_TIME]

Write a message explaining findings in plain language, separating urgent from recommended, stating the estimate, and asking for approval to proceed. Under 200 words.
```

---

### 🏆 Prompt 2: Google Review Request — Text
*Use 24-48 hours after a satisfied customer's visit.*

```
Write a Google review request text.

Customer: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Service: [SERVICE]
Review link: [LINK]
Shop: [SHOP_NAME]

Write a personal, non-spammy text under 75 words that thanks them by name, makes the ask naturally, and provides the link.
```

---

### 🏆 Prompt 3: Negative Review Response
*Use within 72 hours of any negative review.*

```
Write a professional negative review response.

Their review: "[NEGATIVE_REVIEW]"
What happened: [YOUR_ACCOUNT]
Valid? [YES/PARTIALLY/NO]
Resolution offered: [RESOLUTION]
My name: [MY_NAME]

Write a response that acknowledges the concern, is factual not emotional, takes responsibility where appropriate, states the resolution, and invites direct contact. Under 150 words.
```

---

### 🏆 Prompt 4: Repair Authorization Request
*Use before starting any work not pre-authorized.*

```
Write a repair authorization message.

Customer: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Repair needed: [REPAIR]
Why it's needed: [PLAIN_LANGUAGE_EXPLANATION]
Parts: [PARTS] — cost: [PARTS_COST]
Labor: [LABOR_HOURS] hrs × [RATE] = [LABOR_COST]
Total: [TOTAL]
Time to complete: [TIME]
Warranty: [WARRANTY]

Write a message explaining the repair in plain language, breaking down the cost, and asking for clear yes/no approval.
```

---

### 🏆 Prompt 5: Vehicle Ready for Pickup
*Use the moment the vehicle is done and inspected.*

```
Write a vehicle ready notification.

Customer: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Work completed: [WORK_SUMMARY]
Amount due: [TOTAL_DUE]
Payment methods: [PAYMENT_METHODS]
Hours: [SHOP_HOURS]
Follow-up maintenance note: [NEXT_MAINTENANCE_DUE]

Short, clear notification: vehicle is ready, what was done, what they owe, how to pay, and one helpful maintenance reminder.
```

---

### 🏆 Prompt 6: Additional Repair Found Mid-Job
*Use when you discover something new while already working on a vehicle.*

```
Write a message about an additional issue found during service.

Customer: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Original repair: [ORIGINAL_REPAIR]
New issue: [NEW_ISSUE]
How discovered: [HOW_IT_WAS_FOUND]
Urgency: [URGENT/CAN_WAIT]
Additional estimate: [AMOUNT]
Time impact: [SCHEDULE_IMPACT]

Write a transparent message: update on original repair, explain new finding in plain language, state urgency, give estimate, ask for approval without pressure.
```

---

### 🏆 Prompt 7: Full Service Estimate — Multi-Point Inspection
*Use when presenting comprehensive inspection findings.*

```
Write a full service estimate from a multi-point inspection.

Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Customer: [CUSTOMER_NAME]

URGENT: [ITEMS_WITH_COSTS]
RECOMMENDED: [ITEMS_WITH_COSTS]
MONITOR: [ITEMS]

Total urgent: [URGENT_TOTAL]
Total all recommended: [FULL_TOTAL]

Write an estimate separating items by urgency, explaining each in plain language, breaking down parts and labor, and noting warranties.
```

---

### 🏆 Prompt 8: Declined Repair Follow-Up
*Use when a customer declined a recommended repair at pickup.*

```
Write a follow-up for a customer who declined a repair.

Customer: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Declined repair: [REPAIR]
Safety concern: [CONCERN — if applicable]
Symptoms to watch for: [SYMPTOMS]
Timeframe: [URGENCY_TIMEFRAME]
Booking: [CTA]

Remind them of the declined repair, give honest safety context (not fear-based), tell them what to watch for, and make rebooking easy. Friendly, not pushy.
```

---

### 🏆 Prompt 9: Parts Delay Notification
*Use when a parts delay will affect a vehicle's completion.*

```
Write a parts delay notification.

Customer: [CUSTOMER_FIRST_NAME]
Vehicle: [YEAR_MAKE_MODEL]
Repair: [REPAIR]
Original completion: [ORIGINAL_DATE]
New completion: [NEW_DATE]
Reason for delay: [REASON]
What we're doing about it: [ACTION]
Loaner available: [YES/NO]

Get to the point immediately, give the new timeline, explain why honestly, state what you're doing, offer loaner if available.
```

---

### 🏆 Prompt 10: Opening Shift SOP
*Use when documenting or refreshing your shop opening procedure.*

```
Write an opening shift SOP for an auto repair shop.

Opening time: [TIME]
Opener role: [ROLE]
Opening tasks: [TASKS]
Systems to check: [SYSTEMS]
Safety checks: [SAFETY_ITEMS]
Time to complete: [ESTIMATED_TIME]

Write a numbered SOP with step-by-step tasks in order, ownership, time allotment, and what "done" looks like for each step.
```

---

### 🏆 Prompt 11: Seasonal Promotion Text
*Use when running a time-limited service promotion.*

```
Write a seasonal promotion text for customers.

Season/occasion: [SEASON]
Promotion: [OFFER]
Valid through: [DATE]
Limitations: [LIMITATIONS]
Booking: [PHONE_OR_LINK]
Shop: [SHOP_NAME]

State the offer in the first sentence, create natural urgency, make booking easy. Under 80 words. Like a heads-up from a local owner.
```

---

### 🏆 Prompt 12: Apology for Service Issue
*Use when something went wrong and you need to address it directly.*

```
Write an apology and resolution message for a service problem.

Customer: [CUSTOMER_FIRST_NAME]
What went wrong: [ISSUE — specific]
How serious: [SEVERITY]
Resolution: [WHAT_WE'RE_DOING]
Timeline: [WHEN_RESOLVED]
Contact: [NAME], [METHOD]

Own the mistake completely, state what happened, explain the resolution with timeline, provide direct contact. Professional and sincere.
```

---

### 🏆 Prompt 13: Pre-Purchase Inspection Report
*Use when completing a pre-purchase inspection for a customer evaluating a used vehicle.*

```
Write a pre-purchase inspection report.

Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Customer: [CUSTOMER_NAME]
Date: [DATE]

Findings by category:
Engine: [FINDINGS]
Transmission: [FINDINGS]
Brakes: [FINDINGS]
Suspension: [FINDINGS]
Tires: [FINDINGS]
Body/Frame: [FINDINGS]
Fluids: [FINDINGS]
Electrical: [FINDINGS]

Immediate concerns: [URGENT_ISSUES]
Immediate repair estimate: [ESTIMATE]
Anticipated 12-month needs: [UPCOMING]
Estimated upcoming cost: [UPCOMING_ESTIMATE]
Overall recommendation: [BUY/NEGOTIATE/AVOID + reasoning]

Write a plain-language report that helps them decide whether to buy.
```

---

### 🏆 Prompt 14: Service Advisor Job Description
*Use when hiring a front desk service advisor.*

```
Write a service advisor job description.

Shop: [SHOP_NAME], [CITY, STATE]
Responsibilities: [RESPONSIBILITIES]
Requirements: [REQUIREMENTS]
Pay: [PAY_RANGE]
Benefits: [BENEFITS]
Hours: [SCHEDULE]
Why work here: [SHOP_CULTURE]
How to apply: [PROCESS]

Open with why this shop is a great place to work. Describe the role in terms of what you'll do. List requirements clearly. End with easy application CTA.
```

---

### 🏆 Prompt 15: Major Repair vs. Vehicle Value Discussion
*Use when a customer needs context on whether to repair or replace their vehicle.*

```
Write a message helping a customer decide on a major repair vs. replacing the vehicle.

Customer: [CUSTOMER_NAME]
Vehicle: [YEAR_MAKE_MODEL], [MILEAGE] miles
Vehicle value: [VALUE — approx KBB]
Repair needed: [REPAIR]
Repair estimate: [ESTIMATE]
Vehicle condition otherwise: [CONDITION]
My recommendation: [RECOMMENDATION]

Present the situation clearly (cost vs. value), acknowledge the significance of the decision, lay out options without bias (repair, sell, junk), give your honest professional recommendation.
```

---

## QUICK VARIABLE REFERENCE

| Variable | What to Put Here |
|----------|-----------------|
| `[CUSTOMER_FIRST_NAME]` | Customer's first name only |
| `[YEAR_MAKE_MODEL]` | e.g., "2019 Honda Accord" |
| `[MILEAGE]` | Current odometer reading |
| `[SHOP_NAME]` | Your shop's name |
| `[MY_NAME]` | Your name |
| `[ESTIMATE_TOTAL]` | Total repair estimate in dollars |
| `[SERVICE]` | The specific service performed |
| `[PARTS_COST]` | Cost of parts only |
| `[LABOR_COST]` | Labor charge (hours × rate) |
| `[COMPLETION_TIME]` | How long the repair takes |
| `[WARRANTY]` | Parts/labor warranty terms |
| `[REVIEW_LINK]` | Your Google review link |

---

*Built for mechanics who run a tight shop.*
