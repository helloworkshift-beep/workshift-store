# The AI Prompt Starter Kit
## 20 Essential Prompts for Professionals — by Workshift

---

These 20 prompts are the foundation. Each one follows the same principle: give the AI a role, a context, and a specific output format — and you'll get something usable on the first try.

Replace everything in [BRACKETS] with your details.

---

### 1. The Professional Email
> Write a professional email from [your name/role] to [recipient and their role] about [topic]. Context: [brief background]. Goal: [what you want to happen after they read it]. Tone: [direct/warm/formal]. Under [word count] words.

---

### 2. The Meeting Summary
> Summarize the following meeting notes into a structured summary. Include: key decisions made, action items with owners, open questions, and next steps. Audience: [team members who weren't there]. Notes: [paste your raw notes].

---

### 3. The Executive Brief
> Write a one-page executive brief on [topic] for [audience: e.g., C-suite, board, investors]. They care most about [what matters to them]. Key points to cover: [your bullet points]. Format: headline insight → context → implications → recommended action.

---

### 4. The Job Posting
> Write a job posting for [job title] at [company type/size]. The role involves: [core responsibilities]. We're looking for someone who: [key traits and skills]. Culture note: [what makes your team different]. Tone: [direct/welcoming/ambitious]. Avoid corporate jargon.

---

### 5. The Performance Review
> Write a [mid-year/annual] performance review for [employee name, role]. Strengths observed: [list]. Areas to develop: [list]. Key achievements this period: [list]. Tone: [constructive and specific]. Format: 3 sections — strengths, growth areas, goals for next period.

---

### 6. The Proposal / Pitch
> Write a [proposal/pitch] for [what you're proposing] to [audience]. The core problem you're solving: [problem]. Your solution: [solution]. Why now: [urgency/opportunity]. What you're asking for: [decision/budget/approval]. Keep it under [page/word limit].

---

### 7. The Social Post
> Write [3] [LinkedIn/Twitter/Instagram] posts about [topic]. Each should: [educate / inspire / start a conversation]. Audience: [your target audience]. Tone: [your brand voice]. Avoid: [things to not say]. Each post under [character/word limit].

---

### 8. The Status Update
> Write a project status update for [project name]. Audience: [stakeholders]. Current status: [on track/at risk/blocked]. Completed this week: [list]. Planned next week: [list]. Risks or blockers: [list]. Tone: [brief and factual — 1 minute to read].

---

### 9. The Client Follow-Up
> Write a follow-up email to [client name] after [meeting/proposal/call]. Context of the conversation: [what was discussed]. Next step agreed: [what happens next]. My goal for this email: [build trust/move to close/clarify a concern]. Tone: [warm and confident]. Under [word count].

---

### 10. The Difficult Conversation Script
> Help me prepare for a difficult conversation with [person's role]. The situation: [what happened]. What I need them to understand: [core message]. What I'd like the outcome to be: [ideal resolution]. Tone: [direct but not confrontational]. Give me an opening statement and 3 key points to make.

---

### 11. The Research Brief
> Summarize the key facts about [topic] as of [date/context]. I need to understand: [specific questions]. Format: bullet points under each question. Keep it factual — no filler. Flag anything that's uncertain or needs verification.

---

### 12. The Training / Onboarding Doc
> Write an onboarding guide for [new employee role] joining [team/department]. Cover: what they'll be working on in week 1, key people to meet, tools and systems to set up, important context about how we work, and one thing most new people get wrong. Tone: [welcoming and practical].

---

### 13. The Sales Script
> Write a [cold call / discovery call / demo] script for selling [product/service] to [target customer]. Opening hook: [what grabs their attention]. Key qualifying questions: [what you need to learn]. Main value proposition: [what problem you solve]. Objection to handle: [most common pushback]. Closing ask: [specific next step].

---

### 14. The Data Story
> I have the following data: [paste your numbers or findings]. Help me turn this into a clear narrative for [audience]. The "so what" I want them to take away: [key insight]. Format: headline insight → supporting data → business implication → recommended action. Under [word count].

---

### 15. The Blog Post / Article Outline
> Create a detailed outline for a [word count]-word article titled "[working title]." Target reader: [who they are and what they care about]. Goal of the article: [inform / persuade / convert]. Key points to hit: [your 3-5 main ideas]. Tone: [conversational / authoritative / practical]. Include: intro hook, main sections with subheadings, and a strong conclusion.

---

### 16. The FAQ / Help Doc
> Write an FAQ section for [product / service / policy]. Audience: [your customers/users]. Include the 8 most common questions people ask about [topic], with clear, jargon-free answers. Format: Q&A pairs. Each answer under 75 words.

---

### 17. The Negotiation Prep
> Help me prepare for a negotiation about [what you're negotiating: salary / contract / deal terms]. My position: [what I want]. Their likely position: [what they want]. My walk-away point: [your limit]. Key leverage I have: [your strengths]. Give me: an opening statement, 3 concession strategies, and how to respond if they say no.

---

### 18. The Feedback Response
> Help me respond to this feedback: [paste the feedback]. My initial reaction: [honest take]. What I think is valid: [what's fair]. What I disagree with: [what's not]. I want my response to: [acknowledge the valid parts / defend my position / seek clarification]. Tone: [professional and non-defensive].

---

### 19. The Brand Voice Guide
> Write a brand voice guide for [company/product name]. We are: [3 adjectives that describe the brand]. We are NOT: [3 adjectives that describe what we're NOT]. Our audience: [who they are]. Sample message in our voice: [example]. Sample message NOT in our voice: [example]. Format: 1-page reference doc.

---

### 20. The Retrospective / Lessons Learned
> Facilitate a retrospective on [project / quarter / initiative]. What went well: [list]. What didn't: [list]. What we'd do differently: [list]. Write a structured retrospective summary that: captures the key learnings, frames the problems as solvable, and ends with 3 concrete action items for next time. Audience: [the team + leadership].

---

## What's Next

These 20 prompts will handle most of what you write at work.

If you want a full library built specifically for your profession — with 100+ prompts, complete workflows, and templates — check out the Workshift AI Prompt Toolkits:

→ workshift.store/toolkits

Each toolkit is built for one profession. One-time purchase. Instant download. Yours forever.

---

*© Workshift — workshift.store*
