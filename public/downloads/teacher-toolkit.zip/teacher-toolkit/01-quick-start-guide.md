# 01 — Quick Start Guide

*How to get maximum value from this toolkit in the first 10 minutes*

---

## The 3-Minute Setup

### Step 1: Pick Your AI Tool
These prompts work with any LLM. Recommended:
- **ChatGPT (GPT-4o)** — Best for lesson plans, activities, and parent emails
- **Claude (Sonnet or Opus)** — Best for long-form documents, feedback, and nuanced communication
- **Gemini Advanced** — Good for research and standards-alignment tasks

### Step 2: Set a System Prompt
Paste this at the start of every conversation to establish context:

```
You are an experienced, creative educator with 15 years of classroom experience. You write lesson plans, assessments, and communications that are clear, age-appropriate, and genuinely useful — not generic. You understand that teachers are busy and output should be ready to use with minimal editing. You write student-facing materials in age-appropriate language and parent communications with warmth and professionalism. You know how to differentiate instruction, design meaningful assessments, and manage a classroom.
```

**Customize with your context:**
```
You are supporting a [GRADE LEVEL] [SUBJECT] teacher. The students are [DESCRIPTION — grade level, any relevant context about the class]. The teacher uses [STANDARDS — Common Core / State Standards / IB / other] and [CURRICULUM/TEXTBOOK if any]. Communication style is [WARM AND PERSONAL / PROFESSIONAL / DIRECT].
```

### Step 3: Fill In the Brackets
Every prompt uses `[BRACKET VARIABLES]` in ALL CAPS. Replace each one with real information. The more specific you are, the more useful the output.

**Bad:**
```
[GRADE] = my class
[TOPIC] = the unit we're doing
```

**Good:**
```
[GRADE] = 7th grade
[TOPIC] = The American Revolution — causes and key events
[STANDARD] = CCSS.ELA-LITERACY.RH.6-8.2 — Determine the central ideas of a primary source
[STUDENT CONTEXT] = Mixed ability class, 4 ELL students at intermediate level, 3 students with reading IEPs
```

---

## Power Techniques

### Technique 1: Build a Lesson Plan in 3 Prompts
1. Use **Lesson Planning Prompt #1** to generate the full lesson plan
2. Use **Prompt #3** to generate the activity or worksheet for students
3. Use **Prompt #7** to differentiate the activity for students with IEPs or ELL needs

### Technique 2: The Feedback Factory
For grading essays or written responses:
1. Paste one strong student sample and ask AI to describe what makes it strong
2. Use that description as a rubric or feedback template
3. Paste 2-3 sentences from each student's work and get individualized feedback suggestions

### Technique 3: Scaffold for All Levels
After generating any text or reading passage:
```
Take the above text and create 3 versions:
- Version A: For students reading 2 grade levels below (simplified vocabulary, shorter sentences)
- Version B: On-grade-level (current version)
- Version C: For advanced students (added complexity, higher-order vocabulary, extension questions)
```

### Technique 4: The Reluctant Parent Email
When you need to write a difficult parent email:
1. Draft it yourself in bullet points (your key points)
2. Paste into the prompt with: "Turn these bullet points into a professional, warm parent email that maintains the relationship while delivering hard news"
3. Edit to match your voice

### Technique 5: Backwards Design
Start with the standard, end with the lesson:
```
Step 1: "What would students need to know and do to demonstrate mastery of [STANDARD]?"
Step 2: "Design a 3-part assessment that measures those skills"
Step 3: "Now build the lesson that teaches what the assessment measures"
```

---

## Common Mistakes to Avoid

❌ **Using outputs without reading them** — AI can write generic or inaccurate content. You know your students; AI doesn't. Always review.

❌ **Forgetting grade-level context** — A prompt without grade level produces generic output. Always specify the grade.

❌ **Skipping the student context** — "My class" is meaningless. "My 8th grade class of 26, including 5 ELL students and 4 who struggle with reading fluency" is everything.

❌ **Using AI for sensitive parent communications without editing** — AI can be too formal or miss the relational context you have with a family. Always personalize hard conversations.

❌ **Over-generating, under-editing** — It's faster to generate 5 versions and pick the best one than to try to refine one version endlessly.

---

## Quick Reference: Situation → Prompt

| Situation | File | What to use |
|-----------|------|-------------|
| Building a lesson plan from scratch | Lesson Planning | Prompt #1 |
| Need activities for a concept | Lesson Planning | Prompt #5 |
| Differentiating a lesson | Classroom Management | Prompt #4 |
| Writing a rubric | Assessment | Prompt #1 |
| Quiz or test questions | Assessment | Prompt #8 |
| Writing report card comments | Assessment | Prompt #15 |
| Difficult parent email | Parent Communication | Prompt #5 |
| End-of-year parent letter | Parent Communication | Prompt #15 |
| Behavior plan | Classroom Management | Prompt #11 |
| Sub plans | Lesson Planning | Prompt #12 |

---

*Ready? Start with the cheat sheet if you need something now. Start with lesson planning prompts if you're prepping for the week.*
