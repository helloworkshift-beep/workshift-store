# 04 — Classroom Management Prompts

*22 prompts for behavior systems, classroom routines, SEL, and differentiated support*

---

**Prompt 1: Classroom Behavior System Design**

*When to use: Setting up or redesigning your classroom management system*

```
Design a comprehensive classroom management system for the following.

Grade level: [GRADE]
Subject: [SUBJECT]
Class size: [NUMBER]
School behavior philosophy: [PBIS / RESTORATIVE PRACTICES / TRADITIONAL / OTHER — or "none specified"]
My teaching philosophy: [BRIEF — e.g., "I believe in high expectations with strong relationships"]
Current challenges: [WHAT PROBLEMS AM I TRYING TO PREVENT OR ADDRESS?]

Design a system that includes:
1. Classroom expectations (3-5 positively stated, observable, memorable)
2. Routines for: entering class, transitions, turning in work, asking for help, leaving class
3. Proactive strategies (how to prevent problems before they occur)
4. Acknowledgment system (how you'll recognize positive behavior)
5. Response ladder (minor → moderate → major behaviors and specific teacher responses for each)
6. How to rebuild after a conflict (restorative approach vs. punitive)
7. Parent communication protocol for behavior concerns

Also: how do you teach the system in the first week of school? A management system students don't know isn't a system — it's a list of rules.
```

---

**Prompt 2: First Week of School Plan**

*When to use: Planning the first days of school to establish culture and routines*

```
Create a first-week-of-school plan for [GRADE LEVEL] [SUBJECT].

Class size: [NUMBER]
Duration of each class: [MINUTES]
Days in first week: [TYPICALLY 3-5 — describe the schedule]
School culture: [BRIEF DESCRIPTION]
My goals for the first week: [RELATIONSHIPS / ROUTINES / EXPECTATIONS / CONTENT PREVIEW / ALL]

Create a day-by-day plan for the first week that:
1. Prioritizes relationships before rules
2. Explicitly teaches routines (not just states them)
3. Previews what learning will look like this year (engages curiosity)
4. Establishes norms collaboratively (not just posted posters)
5. Gives students a chance to share who they are
6. Gives ME information about who my students are

For each day:
- Agenda overview
- Specific activities with timing
- Exact teacher language for key moments
- What I want students to feel at the end of each day

Day 1 should answer: "Will I be known here? Will this be worth my time?"
```

---

**Prompt 3: Restorative Conversation Script**

*When to use: Having a restorative conversation with a student after a behavior incident*

```
Write a restorative conversation script for a teacher to use with a student after a classroom behavior incident.

Situation: [DESCRIBE THE INCIDENT BRIEFLY — what happened, where, with whom]
Student profile: [GRADE LEVEL, any relevant context about this student]
What happened from the student's perspective (if known): [THEIR EXPLANATION]
The impact of the behavior: [ON TEACHER, CLASSMATES, LEARNING]
Goal of the conversation: [REPAIR THE RELATIONSHIP / UNDERSTAND WHAT HAPPENED / CREATE A PLAN / ALL THREE]

Write a conversation script using restorative questions:
1. What happened? (student's account, not teacher's interrogation)
2. What were you thinking at the time?
3. Who has been affected by this and how?
4. What do you think you need to do to make things right?
5. What support do you need to make better choices?

Also include:
- How to open the conversation without putting the student on defense
- How to respond if the student is defensive, silent, or blaming others
- How to close the conversation with a clear, actionable plan
- How to follow up

Restorative conversations are about accountability AND relationship — not punishment. The student should leave feeling both responsible and supported.
```

---

**Prompt 4: Differentiation Station / Learning Center Design**

*When to use: Creating differentiated learning stations for a class with mixed abilities*

```
Design differentiated learning stations for the following lesson or unit.

Subject: [SUBJECT]
Grade level: [GRADE]
Topic: [TOPIC]
Number of stations: [3-5]
Station duration: [MINUTES PER ROTATION]
Group composition: [HOW ARE STUDENTS GROUPED — mixed / ability-based / student choice]

For each station, create:
1. Station name and clear student directions
2. The learning task (what students DO at this station)
3. Materials needed
4. Differentiation (how this station serves different learners)
5. Student accountability (how they record/show their work)
6. Teacher role at this station (small group instruction / monitoring / independent)

Also: a rotation management plan (how students move, noise levels, transitions) and a "what to do when done early" plan for each station.

The goal: every student is meaningfully engaged at their appropriate challenge level simultaneously. Not just busy.
```

---

**Prompt 5: Behavior Intervention Plan (BIP) Language**

*When to use: Documenting or drafting language for a Behavior Intervention Plan*

```
Draft Behavior Intervention Plan language for a student with significant behavioral challenges.

Student profile: [DESCRIBE WITHOUT NAME — grade level, disability if any, behavioral pattern]
Target behavior: [SPECIFIC BEHAVIOR TO DECREASE — described in observable, measurable terms]
Replacement behavior: [WHAT WE WANT THE STUDENT TO DO INSTEAD]
Function of the behavior: [WHAT NEED THE BEHAVIOR SERVES — attention, escape, sensory, tangible]
Current antecedents: [WHAT TYPICALLY TRIGGERS THE BEHAVIOR]
Current consequences in place: [WHAT HAPPENS CURRENTLY WHEN BEHAVIOR OCCURS]

Write BIP language for:
1. Behavior definition (precise, observable — no interpretive language)
2. Antecedent interventions (changes to environment or task before behavior occurs)
3. Teaching the replacement behavior (how and when it's taught)
4. Reinforcement strategies (what motivates this student, how we'll use it)
5. Response to the target behavior (consistent plan when it occurs)
6. Data collection plan (how often, by whom, using what tool)
7. Fading plan (how supports decrease as the student demonstrates the replacement behavior)

Note: BIP documents should be reviewed and approved by special education team, behavior specialist, and administration before implementation.
```

---

**Prompt 6: SEL Morning Meeting Activities**

*When to use: Planning social-emotional learning activities for morning meetings or advisory*

```
Create a bank of morning meeting or SEL advisory activities for [GRADE LEVEL].

Time available: [15-30 MINUTES]
Focus area: [SELF-AWARENESS / SELF-MANAGEMENT / SOCIAL AWARENESS / RELATIONSHIP SKILLS / RESPONSIBLE DECISION-MAKING / ROTATION]
Current class dynamic: [BRIEF — do students know each other? Any tensions? Building community?]

Create 10 activities with:
- Activity name
- Time needed
- Materials (if any)
- Step-by-step instructions
- The SEL skill it builds
- A debrief question to close the activity

Vary formats: include discussion prompts, movement-based activities, reflection journals, partner activities, and whole-class games.

Each activity should feel worthwhile — not like "we have to do this." The best SEL activities make students feel seen and build genuine community, not just check a box.
```

---

**Prompt 7: Conflict Resolution Protocol for Students**

*When to use: Teaching students how to resolve peer conflicts independently*

```
Write a student-facing conflict resolution protocol for [GRADE LEVEL] students.

School setting: [CLASSROOM / ADVISORY / COUNSELING / WHOLE SCHOOL]
Common conflicts at this grade level: [E.G., friendship drama, group work disagreements, perceived unfairness]
Approach: [PEER MEDIATION / GUIDED SELF-RESOLUTION / TEACHER-FACILITATED]

Write materials including:
1. A student-facing "How to Solve a Conflict" guide (simple steps, grade-appropriate language)
2. A "cool-down" protocol for when emotions are high before the conversation
3. Sentence starters for difficult conversations ("I felt ___ when ___ because ___")
4. Common mistakes students make during conflict resolution (and what to do instead)
5. When to involve a teacher vs. when to handle it independently
6. A reflection form to complete after a conflict is resolved

Also: how to teach this to the class (a 20-30 minute lesson introducing the protocol before students need it).
```

---

**Prompt 8: Trauma-Informed Classroom Practices**

*When to use: Adapting your classroom environment and responses for students who've experienced trauma*

```
Write a trauma-informed classroom practices guide for a teacher.

Grade level: [GRADE]
Context: [GENERAL EDUCATION / TITLE I SCHOOL / HIGH ADVERSE EXPERIENCE POPULATION / OTHER]
Current challenges: [SPECIFIC BEHAVIORS OR PATTERNS YOU'RE SEEING]
Professional development context: [IS THIS A NEW CONCEPT OR BUILDING ON EXISTING KNOWLEDGE?]

Create a practical guide covering:
1. What trauma-informed teaching is (and isn't) — 1-page overview
2. Brain-based explanation: why trauma affects learning and behavior (briefly, accessibly)
3. 5 classroom environment changes that reduce stress responses
4. 5 instructional practice changes that support regulated learners
5. Language shifts: trauma-informed vs. traditional responses (side-by-side examples)
6. How to build predictability and safety without losing academic rigor
7. Self-care strategies for teachers working with high-need students (compassion fatigue is real)
8. When to refer: what a counselor or social worker handles vs. what a teacher handles

This is one of the highest-leverage areas of professional practice for teachers in high-need settings. Make it practical, not just philosophical.
```

---

**Prompt 9: Student Interest Survey**

*When to use: Learning about student interests and backgrounds at the start of the year*

```
Create a student interest and background survey for [GRADE LEVEL] students.

Purpose: [LEARN ABOUT INTERESTS FOR INSTRUCTION / BUILD RELATIONSHIPS / INFORM DIFFERENTIATION / ALL THREE]
Format: [WRITTEN / DIGITAL / INTERVIEW QUESTIONS — specify]
Time: [10-20 MINUTES]
Language: [ENGLISH ONLY / SUPPORT FOR ELL STUDENTS NEEDED]

Create a survey with 15-20 questions that:
1. Discover learning preferences and interests (topics, formats, solo vs. group)
2. Uncover home languages, background knowledge, and cultural assets
3. Identify students who might need academic or social-emotional support (without stigmatizing)
4. Reveal what students care about outside of school
5. Build student agency (let them tell you what they need)
6. Are age-appropriate and answerable honestly (not just what they think you want to hear)

Also include:
- A parent/family version of select questions (to gather family perspective)
- Teacher analysis guide (how to use the data from the survey in your planning)

Questions should feel like the start of a conversation, not a form to fill out.
```

---

**Prompt 10: English Language Learner Support Strategies**

*When to use: Supporting ELL students in a mainstream classroom*

```
Create a support strategy guide for English Language Learner students in a mainstream classroom.

Grade level: [GRADE]
Subject: [SUBJECT]
ELL students' proficiency levels: [ENTERING / EMERGING / DEVELOPING / EXPANDING / BRIDGING — list levels in your class]
Number of ELL students: [NUMBER]
Home languages represented: [LIST]
Available language support: [CO-TEACHER / BILINGUAL AIDE / TRANSLATION TOOLS / NONE]

Create a practical guide with strategies in each category:

1. **Classroom environment**: Physical setup and visual supports that help ELL students navigate
2. **Instruction**: Techniques during direct instruction (slow down, visual, gesture, check-in)
3. **Academic language**: How to teach content vocabulary to ELL students specifically
4. **Student tasks**: Modifications that maintain grade-level rigor while making content accessible
5. **Assessment**: How to assess ELL students' content knowledge fairly (not English proficiency)
6. **Family communication**: Strategies for communicating with families with limited English

For each strategy: be specific about WHAT to do, not just that you should "support ELL students." Vague strategies help no one.
```

---

**Prompt 11: Behavior Documentation Template**

*When to use: Creating a consistent system for documenting student behavior incidents*

```
Create a behavior documentation system for classroom teachers.

Grade level: [GRADE]
Purpose: [TRACK PATTERNS / COMMUNICATE WITH ADMINISTRATION / INFORM IEP / PARENT COMMUNICATION / ALL]
Format: [PAPER LOG / DIGITAL FORM / BOTH]
Privacy requirements: [SCHOOL POLICY — who has access]

Create:
1. An incident documentation form (what to record, in what format)
2. Required fields: date, time, location, behavior description (observable language), antecedents, student response, teacher response, outcome
3. Language guide: how to write observable, objective descriptions (not interpretations)
4. Pattern analysis template (monthly look at frequency, triggers, times of day)
5. Communication template when sharing with parents (same data, different tone)
6. Communication template when sharing with administration or specialists

Important: document behaviors in factual, observable language. "Student punched the wall" is documentation. "Student was angry and aggressive" is interpretation. One holds up; one doesn't.
```

---

**Prompt 12: Positive Behavior Support Plan**

*When to use: Creating a proactive, positive behavior support plan for a struggling student*

```
Create a Positive Behavior Support Plan for a student who is struggling behaviorally.

Student profile: [GRADE LEVEL, learning/behavioral profile — no name]
Target behaviors to INCREASE: [POSITIVE BEHAVIORS YOU WANT TO SEE MORE OF]
Target behaviors to DECREASE: [WHAT YOU WANT TO SEE LESS OF]
Student strengths and motivators: [WHAT THEY'RE GOOD AT, WHAT THEY CARE ABOUT]
Current triggers: [WHAT SETS THE BEHAVIOR OFF]
Current adult responses: [WHAT HAPPENS NOW]
People involved: [HOMEROOM TEACHER / MULTIPLE TEACHERS / COUNSELOR / PARENTS]

Create a plan that:
1. Is written from a strengths perspective (leads with what the student CAN do)
2. Identifies specific environmental and instructional supports
3. Creates a daily check-in system (morning and afternoon)
4. Uses a point/incentive system tied to the student's specific motivators
5. Includes a "cool down" protocol for moments of dysregulation
6. Has a consistent adult response plan (everyone responds the same way)
7. Sets a 2-week check-in to evaluate progress

Positive behavior support is proactive. Don't wait for the behavior to happen — build the conditions for success before the student arrives.
```

---

**Prompt 13: Culturally Responsive Teaching Audit**

*When to use: Evaluating and improving cultural responsiveness in your classroom*

```
Write a culturally responsive teaching self-audit and action plan for a classroom teacher.

Teacher context: [GRADE LEVEL, SUBJECT, SCHOOL DEMOGRAPHICS]
Student population: [BRIEF DESCRIPTION — cultural/linguistic backgrounds represented]
Current practices: [WHAT YOU'RE ALREADY DOING WELL, IF KNOWN]
Areas of uncertainty: [WHERE YOU'RE NOT SURE IF YOUR PRACTICE IS INCLUSIVE]

Create a self-audit covering:
1. **Curriculum and content**: Whose perspectives are represented in my materials? Whose are missing?
2. **Instruction**: Do my methods match the cultural learning preferences of my students?
3. **Language**: Am I validating home languages as assets rather than deficits?
4. **Relationships**: Do all students feel seen, valued, and known?
5. **Family engagement**: Am I reaching families in ways that work for them?
6. **Expectations**: Are my behavior and academic standards applied consistently and equitably?

For each area:
- Current evidence (what I do now)
- Gap identified
- One specific action to take this month
- One longer-term goal for this year

This is not a guilt exercise — it's a growth practice. Culturally responsive teaching is a skill, not a checklist.
```

---

**Prompt 14: Transition Procedures for Smooth Classroom Flow**

*When to use: Creating specific procedures for any transition point in the school day*

```
Create detailed classroom transition procedures for the following situations.

Grade level: [GRADE]
Transitions needed: [LIST — e.g., entering class, partner work → whole class, independent work → stations, bathroom procedures, packing up, dismissal]
Class culture: [WHAT CURRENTLY WORKS / WHAT DOESN'T]
Problem transitions: [WHICH ONES ARE MOST CHAOTIC]

For each transition:
1. The exact procedure (step-by-step)
2. Signal used to start the transition (verbal cue, timer, music, visual)
3. Expected time for the transition
4. Student accountability during the transition (what every student should be doing)
5. What happens if the transition falls apart (specific teacher response)
6. How to teach this procedure explicitly (practice script for first week)

Also: a "one-minute teacher" guide — what exactly do you do while students are transitioning? Use that time intentionally (check in with a student, take attendance, reset your own mental state).
```

---

**Prompt 15: Student Goal-Setting Workshop**

*When to use: Running a student goal-setting activity at the start of a semester or school year*

```
Design a student goal-setting workshop for [GRADE LEVEL] students.

Purpose: [ACADEMIC GOALS / PERSONAL GOALS / BOTH]
Duration: [ONE CLASS PERIOD]
Time of year: [START OF YEAR / START OF SEMESTER / AFTER REPORT CARDS]
Connection to curriculum: [STANDALONE / TIED TO SPECIFIC SUBJECT]

Create a workshop that includes:
1. Warm-up: a reflection on last semester / last year (what worked, what didn't, what they want more of)
2. Mini-lesson on what makes a good goal (specific, achievable, motivating — accessible version of SMART)
3. Structured goal-writing activity (template for students to fill out — academic + personal)
4. Peer sharing protocol (accountability partner goal share)
5. A "commitment artifact" students keep (wallet card, sticky note on desk, posted in the room)
6. A mid-point check-in plan (when and how goals are revisited)
7. Celebration plan (how you'll recognize students who meet their goals)

Goals work when students own them. This workshop should feel like a beginning, not an assignment.
```

---

**Prompt 16: Attention and Focus Strategies**

*When to use: Supporting students with attention challenges (ADHD or general focus issues)*

```
Create a practical guide for supporting students with attention and focus challenges.

Grade level: [GRADE]
Context: [ONE STUDENT WITH DIAGNOSED ADHD / SEVERAL STUDENTS / WHOLE CLASS WITH FOCUS CHALLENGES]
Common challenges: [STAYING ON TASK / TRANSITIONING / IMPULSE CONTROL / ORGANIZATION / STAYING IN SEAT / ALL]

Create a toolkit of strategies organized by category:

**Environmental**: Physical classroom setup that reduces distractions and supports focus
**Instructional**: Teaching techniques that maintain engagement (pacing, movement, brain breaks)
**Task design**: How to structure tasks for students who struggle with sustained attention
**Self-regulation tools**: What students can use independently to manage their own attention
**Executive function supports**: Organization, time management, and transition tools
**Teacher responses**: When attention breaks down, what to do (that doesn't create more disruption)

For each strategy: be specific (not "use visual supports" — "post a numbered agenda on the board at the start of every class so students can track where they are"). Generic strategies aren't strategies; they're suggestions.
```

---

**Prompt 17: Social Skills Small Group Curriculum**

*When to use: Running a social skills group for students who need explicit instruction*

```
Design a 6-week social skills small group curriculum for [GRADE LEVEL] students.

Group size: [3-6 STUDENTS]
Session length: [20-30 MINUTES]
Setting: [CLASSROOM PULL-OUT / COUNSELOR'S OFFICE / ADVISORY]
Target skills: [LIST — e.g., joining a group, reading social cues, managing frustration, handling conflict, making and keeping friends]
Facilitator: [TEACHER / COUNSELOR / SPECIALIST]

Design 6 weekly sessions, each covering one skill:

For each session:
1. Skill focus and why it matters
2. Check-in activity (2-3 minutes)
3. Mini-lesson introducing the skill (direct instruction — 5 minutes)
4. Modeling: show what the skill looks like (2 minutes)
5. Role play or practice activity (10 minutes)
6. Debrief and real-world application plan (5 minutes)
7. "Try it this week" assignment (one specific thing to practice)
8. Next session preview

This curriculum works because it's explicit. Social skills must be taught, practiced, and coached — not assumed.
```

---

**Prompt 18: Mindfulness and Regulation Activities**

*When to use: Building quick mindfulness or self-regulation activities into your classroom routine*

```
Create a bank of quick mindfulness and self-regulation activities for [GRADE LEVEL] students.

Time available: [2-5 MINUTES per activity]
Setting: [REGULAR CLASSROOM / SEL CLASS / ADVISORY]
Comfort level with mindfulness: [NEW TO THIS / SOME EXPERIENCE / ESTABLISHED PRACTICE]
Current class energy: [ACTIVITIES FOR WHEN CLASS IS TOO HIGH-ENERGY / TOO LOW / ANXIOUS / SPECIFIC EMOTION]

Create 12 activities organized by purpose:

**Calming/settling** (4 activities — for after recess, after a hard moment, before a test):
- [Brief name, 2-sentence description, exact student instructions]

**Energizing** (4 activities — for mid-afternoon slumps, before demanding tasks):
- [Brief name, 2-sentence description, exact student instructions]

**Focusing** (4 activities — before transitions into demanding work):
- [Brief name, 2-sentence description, exact student instructions]

For each: include the exact language to introduce it so it doesn't feel weird or forced ("Today before we dive into our work, we're going to take 2 minutes to...").
```

---

**Prompt 19: Parent-Teacher Communication Log**

*When to use: Setting up a consistent system for tracking parent communication*

```
Create a parent communication tracking system for a classroom teacher.

Grade level: [GRADE]
Number of students: [NUMBER]
Types of communication you do: [EMAIL / PHONE / IN-PERSON / CLASS DOJO / REMIND / SCHOOLOGY / OTHER]
Communication goals: [PROACTIVE POSITIVE OUTREACH / BEHAVIOR CONCERNS / ACADEMIC UPDATES / ALL]

Create a system that includes:
1. A communication log template (what to record for each contact)
2. A "positive contact" protocol (how often to make positive calls/emails, who to prioritize)
3. A priority list for the fall (which families do you need to reach first and why?)
4. Templates for the most common communication types:
   - Weekly class newsletter (brief, easy to sustain)
   - Positive phone call or email
   - Concern-based phone call (script)
   - Behavior incident notification
5. A documentation guide (what detail level you need if the situation escalates)

Research shows that families who receive at least one positive contact early in the year are more likely to stay engaged when challenges arise. Build the positive contact into the system, not as an afterthought.
```

---

**Prompt 20: Inclusive Classroom Design Checklist**

*When to use: Evaluating and improving your classroom environment for all learners*

```
Create an inclusive classroom design checklist and action plan.

Grade level: [GRADE]
Classroom type: [GENERAL ED / SPECIAL ED / CO-TAUGHT / INCLUSION — describe]
Student population: [DIVERSITY — ability levels, languages, IEPs, 504s, behavioral needs]
Current setup: [BRIEF DESCRIPTION of furniture, layout, walls, materials]

Create a comprehensive checklist covering:
1. **Physical environment**: Furniture arrangement, accessibility, sensory considerations
2. **Visual supports**: Anchor charts, schedules, word walls, exemplars — are they useful and current?
3. **Materials**: Are materials accessible to all students independently?
4. **Representation**: Do classroom materials reflect all students' backgrounds and identities?
5. **Technology**: Are tools available that support students with different needs?
6. **Seating**: Are there options? Can students make choices about where/how they work?
7. **Calm space / regulation zone**: Is there a place for students to reset?

For each checklist item:
- Current status (yes / not yet / partial)
- Specific action if "not yet"
- Priority level (do this week / this month / this year)

A physical environment either communicates "you belong here" or it doesn't. Audit yours honestly.
```

---

**Prompt 21: Handling Sensitive Topics in the Classroom**

*When to use: Preparing for or responding to a sensitive topic or current event that affects students*

```
Write a guide for handling a sensitive topic in the classroom.

Grade level: [GRADE]
Topic: [THE SENSITIVE SUBJECT — e.g., racial injustice, school violence, family hardship, political controversy, community tragedy, LGBTQ+ issues]
Context: [HOW THIS IS COMING UP — current event, curriculum content, student-raised issue, community event]
School policy on this topic: [WHAT GUIDANCE EXISTS — or "none / unclear"]
Your goals: [ACKNOWLEDGE AND VALIDATE / TEACH PERSPECTIVE-TAKING / INFORM / FACILITATE DIALOGUE / KEEP LEARNING ON TRACK]

Create:
1. Pre-discussion preparation (what to do before class — know the facts, know school policy, notify admin if needed)
2. How to open the conversation productively
3. Discussion guidelines to establish first (how to talk about hard things together)
4. Specific facilitation moves for common hard moments (when students say something offensive, when students are upset, when discussion gets heated)
5. How to close the discussion (land somewhere — not necessarily resolved, but grounded)
6. How to support affected students after class
7. What to communicate to parents if appropriate

Teachers don't have to have all the answers. They have to create a space where questions can be asked safely.
```

---

**Prompt 22: Substitute Teacher Management Plan**

*When to use: Preparing a behavioral management briefing for substitute teachers*

```
Write a substitute teacher behavioral management briefing for my class.

Grade level: [GRADE]
Subject: [SUBJECT]
Class period(s): [SCHEDULE]
Class description: [GENERAL CLASS DYNAMIC — is it well-behaved, energetic, challenging?]
Key students to know:
- Supportive students: [3-4 students the sub can rely on — first names only]
- Students who may test limits: [GENERAL NOTE — "one student may try to negotiate rules; hold firm"]
- Students with needs: [ANY HEALTH, BEHAVIORAL, OR LEARNING NEEDS the sub must know — general description]

Write a briefing that:
1. Describes the class honestly (without scaring the sub)
2. Lists the 3-4 non-negotiable class rules that always apply
3. Notes the classroom management system in use (what to do when something happens)
4. Gives the sub permission to enforce consequences (many subs feel they can't)
5. Describes what to do if a student needs to leave the room
6. Gives specific names for who to contact if something goes wrong
7. Closes with an encouraging note

Subs who feel set up for success actually have better class days. Make them feel prepared.
```

---

*Next: `05-parent-communication-prompts.md` → 20 prompts for parent emails, conferences, and newsletters*
