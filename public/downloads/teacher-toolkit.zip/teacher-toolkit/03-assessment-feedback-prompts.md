# 03 — Assessment & Feedback Prompts

*25 prompts for rubrics, quizzes, report card comments, meaningful feedback, and grading efficiency*

---

**Prompt 1: Rubric Generator**

*When to use: Creating a rubric for any assignment*

```
Create a rubric for the following assignment.

Subject: [SUBJECT]
Grade level: [GRADE]
Assignment: [ASSIGNMENT DESCRIPTION]
Learning objectives assessed: [LIST 3-5 OBJECTIVES]
Rubric format: [HOLISTIC / ANALYTIC — 4-6 rows preferred]
Scale: [4-3-2-1 / A-D / MASTERY LEVELS / POINTS — specify]
Audience: [STUDENT-FACING (readable) / TEACHER GRADING TOOL / BOTH]

Create an analytic rubric with:
- 4-5 criteria rows (one per major learning objective or component)
- 4 performance levels per row
- Specific, behavioral language at each level (not just "good," "adequate," "poor")
- Point values or grade equivalents if applicable

For each cell: describe exactly what student work looks like at that level — specific enough that two different teachers would grade the same paper the same way.

Also: write a student-friendly version of the rubric that students can use for self-assessment.
```

---

**Prompt 2: Essay Feedback Comments**

*When to use: Generating specific, useful feedback for student writing*

```
Write feedback comments for a student essay or written response.

Assignment: [ESSAY TYPE AND PROMPT]
Grade level: [GRADE]
Student's essay excerpt or summary: [PASTE EXCERPT — or describe the key strengths/weaknesses]
Student's current level: [APPROACHING / MEETING / EXCEEDING]
Key criteria being assessed: [LIST — e.g., thesis, evidence, analysis, mechanics]

For each criterion, write:
1. A specific strength comment (what they did well — with a quote or example if possible)
2. A specific growth comment (what to improve — concrete, actionable, not just "be more specific")
3. One specific revision suggestion (e.g., "Your thesis states X. Try adding a 'because' clause to show why: 'X because Y'")

Also write:
- An overall opening comment (2-3 sentences)
- One "most important next step" for revision

Feedback should be honest but encouraging. Avoid "great job!" without specific evidence. Avoid "needs work" without specific direction.
```

---

**Prompt 3: Multiple Choice Quiz Generator**

*When to use: Creating a quiz for a specific topic or reading*

```
Write a [NUMBER]-question multiple choice quiz for the following.

Subject: [SUBJECT]
Grade level: [GRADE]
Topic or reading: [DESCRIBE THE CONTENT BEING ASSESSED]
Bloom's levels to include: [REMEMBERING / UNDERSTANDING / APPLYING / ANALYZING — specify mix]
Number of questions: [10-20 QUESTIONS]
Number of answer choices: [3 or 4]

For each question:
- A clear question stem
- 4 answer options (A-D) — one correct, three plausible distractors
- The correct answer marked

Ensure:
- Questions cover a range of the content (not all on one subtopic)
- Distractors represent real misconceptions (not obviously wrong)
- Mix of text-based and conceptual questions if applicable
- Questions are in order from easier → harder

After the quiz: provide an answer key with a brief explanation of why each correct answer is correct.
```

---

**Prompt 4: Short Answer / Free Response Test Questions**

*When to use: Creating free response questions with scoring guides*

```
Write short answer / free response test questions for the following.

Subject: [SUBJECT]
Grade level: [GRADE]
Topic: [TOPIC]
Number of questions: [NUMBER]
Target response length: [2-5 SENTENCES / 1 PARAGRAPH / EXTENDED RESPONSE]
Bloom's level: [UNDERSTANDING / ANALYZING / EVALUATING / MIX]

For each question:
1. The student-facing question
2. Sample strong response (what a mastery-level answer looks like)
3. Scoring guide (what earns full credit / partial credit / no credit)
4. Common wrong answers and why students make those mistakes

Make the questions require thinking — not just recall. A strong free response question can't be answered by Googling a single fact.
```

---

**Prompt 5: Report Card Comments Generator**

*When to use: Writing individualized report card or progress report comments*

```
Write report card comments for the following students.

Grade level: [GRADE]
Subject: [SUBJECT]
Grading period: [Q1 / SEMESTER / TRIMESTER]
Character limit: [NUMBER] characters per comment (or words per comment)

For each student, provide the following:
Student 1: [NAME]
- Academic performance: [GRADE/LEVEL and what they're doing well or struggling with]
- Effort and engagement: [HIGH / MEDIUM / INCONSISTENT]
- Specific strength: [ONE SPECIFIC THING]
- Growth area: [ONE SPECIFIC AREA TO IMPROVE]
- Social/behavioral note: [IF RELEVANT]

[REPEAT FORMAT FOR EACH STUDENT — up to 10 per request]

Write a comment for each student that:
- Is specific to them (not a merge of a template)
- Mentions at least one concrete example or skill
- Is professional, warm, and informative
- Fits within the character limit
- Does NOT use jargon that parents won't understand
- Notes growth since last period if relevant

Also: provide 5 general comment templates for common student profiles I can customize.
```

---

**Prompt 6: IEP Accommodation Integration Plan**

*When to use: Planning how to implement IEP accommodations into daily instruction*

```
Create an IEP accommodation implementation plan for a student.

Student profile: [DESCRIBE WITHOUT USING STUDENT'S NAME — e.g., "a 6th grade student with dyslexia and processing speed challenges"]
IEP accommodations listed: [LIST THE ACCOMMODATIONS FROM THE IEP]
Subject: [SUBJECT]
Typical class activities: [TYPES OF TASKS THIS STUDENT FACES REGULARLY]
Available supports: [CO-TEACHER / PARAPROFESSIONAL / TECHNOLOGY / SPECIFIC TOOLS]

Create an implementation plan that:
1. Lists each accommodation with specific, concrete classroom application
2. Notes how/when each accommodation is applied (which tasks, which assessments)
3. Describes modifications vs. accommodations (and which each item is)
4. Includes proactive strategies (before the challenge, not just during)
5. Notes how to implement without singling the student out
6. Lists which accommodations apply on assessments
7. Suggests alternative assessment formats where appropriate
8. Notes communication protocol with special education teacher

This should be a practical document a teacher can reference daily — not a compliance checklist.
```

---

**Prompt 7: Peer Review Protocol**

*When to use: Creating structured peer feedback protocols for student writing or projects*

```
Create a peer review protocol for the following assignment.

Subject: [SUBJECT]
Grade level: [GRADE]
Assignment being reviewed: [DESCRIPTION]
Peer review goals: [WHAT STUDENTS SHOULD LOOK FOR AND COMMENT ON]
Time available: [MINUTES]
Format: [IN-CLASS WRITTEN / DIGITAL / DISCUSSION-BASED]

Create a peer review protocol that includes:
1. Setup instructions (how to exchange work, time per review, expectations)
2. A structured response form (not just "good job / needs work")
3. 4-6 specific response prompts (what to look for, how to give useful feedback)
4. Sentence frames for giving critical feedback politely ("I noticed... / You might consider... / One question I have...")
5. A rating system for key criteria (if appropriate)
6. A self-reflection prompt AFTER receiving peer feedback
7. Teacher monitoring tips (how to circulate and keep reviews honest and kind)

The protocol should make peer feedback feel safe and useful — not like a judgment exercise.
```

---

**Prompt 8: Standards-Based Quiz with Answer Key**

*When to use: Creating a quiz directly tied to specific standards*

```
Write a standards-aligned quiz with answer key for the following.

Subject: [SUBJECT]
Grade level: [GRADE]
Standard being assessed: [STANDARD CODE AND DESCRIPTION]
Number of items: [NUMBER]
Item types: [MULTIPLE CHOICE / SHORT ANSWER / TRUE-FALSE / CONSTRUCTED RESPONSE / MIX]
Cognitive level: [RECALL / COMPREHENSION / APPLICATION / ANALYSIS]

Create:
1. A complete quiz formatted for students (headers, clear instructions, spacing)
2. An answer key with correct answers
3. Scoring guide (how many points each item is worth)
4. A "diagnostic notes" section: what a wrong answer on each item tells you about student understanding
5. A re-teaching note: if most students miss question X, what mini-lesson addresses that gap?

Format the quiz cleanly enough to print immediately.
```

---

**Prompt 9: Writing Conference Questions**

*When to use: Preparing for one-on-one writing conferences with students*

```
Create a writing conference toolkit for [GRADE LEVEL] students.

Conference purpose: [WHAT STAGE OF WRITING — planning / drafting / revising / editing]
Key writing skills for this grade and assignment: [LIST 4-6 SKILLS]
Common student challenges: [WHAT YOU TYPICALLY SEE]
Conference time: [5-8 MINUTES PER STUDENT]

Create:
1. 5 opening questions to understand where the student is (not yes/no questions)
2. Diagnostic checklist (what you're listening/looking for in their response)
3. Teaching points for the most common issues (specific language to say — scripts for each issue)
4. Questions to ask after a teaching point to check understanding
5. A protocol to end the conference with one clear goal for the student to act on immediately
6. A teacher notetaking template to track what was discussed for each student

Good conferences are teaching moments, not evaluation moments. Every conference should end with the student doing something, not just hearing something.
```

---

**Prompt 10: Student Self-Assessment Tool**

*When to use: Creating self-assessment tools that build metacognition*

```
Create a student self-assessment tool for the following.

Grade level: [GRADE]
Subject: [SUBJECT]
Unit or assignment: [TOPIC]
Learning objectives: [LIST 4-6]
Format: [CHECKLIST / RATING SCALE / REFLECTIVE QUESTIONS / PORTFOLIO REFLECTION]

Create a self-assessment that:
1. Uses language students can understand and apply honestly
2. Asks students to identify specific evidence of their learning
3. Includes questions about their effort, not just their product
4. Has a "next steps" section where students set their own goals
5. Can be completed in 5-10 minutes
6. Is designed to precede teacher feedback (so teacher can respond to student's self-perception)

Also: a teacher protocol for using self-assessments productively (not just filing them — how to use this data)

The goal: students who can accurately evaluate their own work become independent learners. Build that skill explicitly.
```

---

**Prompt 11: Diagnostic Pre-Assessment**

*When to use: Assessing prior knowledge before starting a unit*

```
Create a pre-assessment for the beginning of a unit.

Subject: [SUBJECT]
Grade level: [GRADE]
Unit: [UNIT TITLE]
Key vocabulary: [10-15 KEY TERMS]
Core concepts: [MAIN IDEAS OF THE UNIT]
Skills: [SKILLS THE UNIT WILL BUILD]

Create a pre-assessment that:
1. Takes no more than 15 minutes to complete
2. Assesses prior vocabulary knowledge (quick: "put a checkmark if you know this word, X if not, ? if unsure")
3. Assesses prior conceptual understanding (3-5 questions at recall/comprehension level)
4. Assesses foundational skills needed for the unit
5. Identifies misconceptions (1-2 questions with common wrong answers as choices)
6. Includes a self-assessment section (how confident do you feel about this topic?)
7. Does NOT count for a grade — it's information for me

After the assessment: a teacher analysis guide (how to group students based on results, what to prioritize in early lessons based on data).
```

---

**Prompt 12: Group Project Rubric with Individual Accountability**

*When to use: Designing fair assessment for group work*

```
Create a group project rubric with individual accountability measures.

Assignment: [GROUP PROJECT DESCRIPTION]
Grade level: [GRADE]
Group size: [3-4 students]
Duration: [DAYS/WEEKS]
Key competencies assessed: [LIST 4-5]
Grading preference: [SAME GROUP GRADE / INDIVIDUAL GRADES / COMBINATION — specify]

Create:
1. Group rubric (4 criteria × 4 levels) for the shared product
2. Individual contribution rubric (how you'll assess each person's unique role)
3. Peer assessment form (how group members evaluate each other fairly)
4. Process portfolio requirements (evidence of contribution: notes, drafts, role records)
5. Individual reflection prompt (each student answers after the project)
6. Final grade composition breakdown (group product: X% / individual contribution: Y% / reflection: Z%)

Address the free rider problem explicitly: how does this rubric catch students who don't contribute while still rewarding those who do?
```

---

**Prompt 13: Intervention Planning for Struggling Students**

*When to use: Planning targeted interventions for students who are behind*

```
Create an intervention plan for a student who is struggling.

Grade level: [GRADE]
Subject: [SUBJECT]
Student profile: [DESCRIBE GENERALLY — skill level, specific gaps, what they can and can't do]
Specific skill gap: [THE SPECIFIC THING THEY CAN'T DO YET]
Available intervention time: [MINUTES / WEEK — pull-out / in-class / lunch / before-after school]
Resources available: [CO-TEACHER / SOFTWARE / AIDE / SPECIFIC MATERIALS]
Student's engagement: [MOTIVATED / DISENGAGED / ANXIOUS]

Create an intervention plan including:
1. Skill gap diagnosis (what does "not meeting standard" look like specifically?)
2. Entry point for instruction (what skill must be in place before this skill?)
3. 4-week intervention sequence (what to teach, in what order, how to check)
4. Specific activities and materials for each week
5. Progress monitoring plan (how you'll know if it's working)
6. Decision point: what happens after 4 weeks if not improving?
7. Communication plan with parents and special education team

Intervention is different from re-teaching. Re-teaching uses the same approach twice. Intervention changes the approach.
```

---

**Prompt 14: Portfolio Assessment Design**

*When to use: Setting up a student portfolio assessment system*

```
Design a portfolio assessment system for the following.

Subject: [SUBJECT]
Grade level: [GRADE]
Portfolio purpose: [SHOWCASE BEST WORK / DOCUMENT GROWTH / GRADUATION REQUIREMENT / PARENT COMMUNICATION]
Duration: [SEMESTER / YEAR]
Format: [PHYSICAL / DIGITAL — platform if digital]
Standards or competencies being documented: [LIST]

Design the portfolio system including:
1. Selection criteria (how students decide what to include — and WHY student choice matters)
2. Minimum requirements (what must be included vs. optional items)
3. Reflection prompts for each artifact (what do students write about each piece?)
4. Cover letter or introduction format (student explains the portfolio)
5. Grading approach (how you evaluate the portfolio — process, reflection, growth, content)
6. Portfolio conference protocol (how you discuss the portfolio with each student)
7. Parent communication about the portfolio
8. A sample portfolio rubric

The portfolio should answer: "What have I learned? How have I grown? What am I proud of?" not "Here are my assignments."
```

---

**Prompt 15: End-of-Year / Semester Reflection for Students**

*When to use: Creating a meaningful end-of-term reflection activity*

```
Create an end-of-year or end-of-semester reflection activity for students.

Grade level: [GRADE]
Subject: [SUBJECT]
What students have learned this year: [MAJOR UNITS / SKILLS / THEMES]
Format: [WRITTEN REFLECTION / DISCUSSION / LETTER / CREATIVE PROJECT]
Time: [ONE CLASS PERIOD]

Create a reflection activity that:
1. Honors the year's learning without just cataloging it
2. Asks students to identify their own growth (not just "what did you learn?")
3. Includes at least one question about how they changed as a learner, not just what they know
4. Connects learning to their life outside school
5. Gives you data about what resonated and what didn't
6. Ends on a note of accomplishment and forward-looking motivation

Specific prompts to include:
- "The most important thing I learned this year was ___"
- "I used to think ___, now I think ___"
- "I surprised myself when ___"
- "The skill from this class I'll use most in the future is ___, because ___"
- "One thing I wish I'd done differently is ___, and next year I'll ___"

Add: an optional teacher reflection prompt (for your own use — what worked, what to change next year).
```

---

**Prompt 16: Parent-Friendly Assessment Summary**

*When to use: Summarizing assessment results for parents who don't understand data*

```
Write a parent-friendly explanation of a student's assessment results.

Grade level: [GRADE]
Assessment type: [STATE TEST / BENCHMARK / UNIT TEST / READING ASSESSMENT / OTHER]
Student's results: [DESCRIBE — scores, levels, percentiles]
What the assessment measures: [BRIEF DESCRIPTION]
What the results mean: [HOW TO INTERPRET]
Student's strengths in the data: [WHAT THEY'RE DOING WELL]
Student's growth areas: [WHERE THEY NEED TO IMPROVE]
What we're doing at school: [INSTRUCTIONAL RESPONSE]
What families can do at home: [SPECIFIC SUGGESTIONS]

Write a parent letter (1 page) that:
1. Explains what the assessment measures in plain language
2. Presents the student's results honestly but constructively
3. Translates scores into what it means practically ("your child reads like a typical 4th grader at this point in the year")
4. Notes strengths genuinely
5. Explains the growth area with a specific, actionable strategy for home
6. Invites a conversation if they have questions

Avoid: "proficient," "benchmark," "stanine," or any other education jargon without explanation.
```

---

**Prompt 17: Oral Assessment / Presentation Rubric**

*When to use: Grading oral presentations or discussions fairly*

```
Create an oral presentation or discussion rubric for the following.

Grade level: [GRADE]
Type: [FORMAL PRESENTATION / SOCRATIC SEMINAR / DEBATE / DEMONSTRATION / READER'S THEATER / OTHER]
Subject: [SUBJECT]
Key skills to assess: [LIST 4-5 — e.g., content knowledge, clarity, evidence use, engagement, eye contact, response to questions]
Duration: [MINUTES PER STUDENT/GROUP]
Audience: [CLASS ONLY / OUTSIDE AUDIENCE / TEACHER ONLY]

Create:
1. An oral assessment rubric (4-5 criteria × 4 levels)
2. Student prep checklist (what to practice before presenting)
3. Audience behavior expectations (how listeners behave during presentations)
4. Feedback form for peers (3-4 structured questions — not just "what was good?")
5. Teacher observation notes template (what to listen for and record while student presents)
6. Self-assessment for students after presenting

Make the rubric specific enough that students know exactly what distinguishes "good" from "excellent" before they present.
```

---

**Prompt 18: Retake and Recovery Policy Language**

*When to use: Writing a fair, clear retake/reassessment policy for students and families*

```
Write a retake and reassessment policy for my class.

Grade level: [GRADE]
Subject: [SUBJECT]
School/district grading philosophy: [TRADITIONAL / STANDARDS-BASED / MASTERY-BASED]
My personal philosophy on retakes: [STUDENTS SHOULD HAVE MULTIPLE CHANCES / RETAKES WITH REQUIREMENTS / LIMITED RETAKES — describe]
Requirements I want for retakes: [STUDY SESSION FIRST? CORRECTIONS? ALTERNATIVE ASSESSMENT? — describe]
Assessment types this applies to: [TESTS ONLY / QUIZZES AND TESTS / MAJOR PROJECTS / ALL]
Deadlines: [IS THERE A WINDOW FOR RETAKES? WHEN?]

Write:
1. A clear student-facing retake policy (what's allowed, how to request it, what's required first)
2. A parent FAQ about the policy (3-5 common questions)
3. The grade calculation explanation (how the retake score is used — replace, average, other)
4. The philosophy statement (why this policy exists — connects learning to growth, not punishment)

Policy should feel fair, encouraging, and specific — not like a punishment for failing or a loophole for gaming grades.
```

---

**Prompt 19: Benchmark Analysis and Action Plan**

*When to use: After a benchmark assessment, planning your instructional response*

```
Write a benchmark data analysis and instructional action plan.

Grade level: [GRADE]
Subject: [SUBJECT]
Assessment: [BENCHMARK NAME AND DATE]
Class results:
- Class average: [SCORE / LEVEL]
- Percentage at/above grade level: [%]
- Questions or skills with class-wide struggles: [LIST ITEMS WHERE MANY STUDENTS STRUGGLED]
- Students needing intervention: [NUMBER — not names]
- Students who exceeded expectations: [NUMBER]

Write an analysis and action plan that:
1. Summarizes the class performance honestly
2. Identifies 2-3 specific skills that need re-teaching (from the data — not assumptions)
3. Plans a re-teaching sequence for each skill gap
4. Identifies small groups for intervention and enrichment
5. Plans how to accelerate proficient students during intervention time
6. Sets a timeline and check-in point to see if the plan is working
7. Notes what worked (don't only focus on gaps — celebrate what the data shows students can do)

This is data-to-instruction work. The analysis is only as valuable as the action it generates.
```

---

**Prompt 20: Writing a Letter of Recommendation**

*When to use: Writing student letters of recommendation for high school, college, or scholarships*

```
Write a letter of recommendation for a student.

Student name: [NAME]
Grade level: [GRADE]
Purpose: [COLLEGE APPLICATION / SCHOLARSHIP / PROGRAM ADMISSION / AWARD]
How long I've known them: [DURATION AND CONTEXT]
Their strongest qualities: [LIST 3-4 SPECIFIC STRENGTHS]
Specific anecdote or example: [A MEMORABLE MOMENT THAT ILLUSTRATES WHO THEY ARE]
Academic performance: [DESCRIBE — not just grade, but how they engage and think]
Character qualities: [WHAT STANDS OUT ABOUT WHO THEY ARE AS A PERSON]
Why they'd succeed in this context: [SPECIFIC TO THE PROGRAM / COLLEGE / AWARD]
My overall assessment: [HOW STRONGLY YOU RECOMMEND THEM]

Write a 3-4 paragraph letter that:
1. Opens with a strong, specific claim about the student (not "I am pleased to recommend...")
2. Supports the claim with a specific story or example
3. Connects their qualities to success in the specific program/context
4. Closes with a genuine, confident endorsement
5. Sounds like it came from someone who actually knows this student — not a template

The best recommendation letters tell a story. The worst ones describe a GPA.
```

---

**Prompt 21: Math Error Analysis Assessment**

*When to use: Creating an activity where students analyze common mistakes*

```
Create a math error analysis activity for the following topic.

Grade level: [GRADE]
Math topic: [SPECIFIC SKILL OR CONCEPT]
Common errors students make: [LIST 5-7 COMMON MISTAKES — or ask AI to generate them]
Format: [WORKSHEET / DISCUSSION CARDS / DIGITAL ACTIVITY]

For each error:
1. Show a worked problem with the error included (no indication it's wrong)
2. Ask students: "Find the error, explain what went wrong, correct it"
3. Ask: "Why do you think a student might make this mistake?"
4. Ask: "What rule or concept did the student misunderstand?"

Create 8-10 error analysis problems with:
- A variety of error types (conceptual, procedural, computational)
- Student-facing instructions
- An answer key with explanation of each error
- A discussion question connecting the errors to deeper understanding

Error analysis builds metacognition — students who can diagnose others' mistakes rarely make the same mistakes themselves.
```

---

**Prompt 22: Gifted and Enrichment Extension Activities**

*When to use: Creating meaningful extension work for gifted or advanced students*

```
Create extension activities for gifted or advanced students in the following unit.

Subject: [SUBJECT]
Grade level: [GRADE]
Unit: [UNIT TITLE]
Standard lesson content: [BRIEF SUMMARY OF WHAT THE CLASS IS DOING]
Advanced students' profile: [WHAT THEY CAN ALREADY DO — are they ahead in skills, depth, breadth, or all three?]

Create 5 extension activities that:
1. Go deeper into the topic (not just more problems — more complexity, nuance, perspective)
2. Are genuinely challenging, not just more of the same
3. Can be done independently without teacher direction
4. Connect the unit topic to bigger ideas, real-world applications, or other disciplines
5. Have a product students can share with the class (teaches peers, validates their work)

Each activity:
- Title and brief student-facing description
- Learning goal (what depth of understanding this builds)
- Materials needed
- Time estimate
- Optional: suggested resource (book, website, dataset, video)

These should make advanced students think "I actually want to do this" — not "more homework for being smart."
```

---

**Prompt 23: Student Growth Portfolio Letter**

*When to use: Helping students write their own portfolio introduction letters*

```
Write a student portfolio introduction letter template for the following context.

Grade level: [GRADE]
Portfolio purpose: [WHAT THE PORTFOLIO IS DESIGNED TO SHOW]
Audience for the letter: [TEACHER / PARENTS / SCHOLARSHIP COMMITTEE / NEXT YEAR'S TEACHER]
Skills demonstrated in the portfolio: [LIST KEY LEARNING OBJECTIVES]

Create:
1. A letter template with [BRACKET VARIABLES] students fill in with their specific work
2. Sentence starters and examples for each paragraph
3. Guiding questions students answer before writing (to generate their ideas first)
4. A model letter showing what strong, specific writing looks like (not vague)

Students should write letters that answer: "What have I learned? How do I know? What did it take to get here?" Not: "Here is my portfolio. I worked hard. I hope you like it."
```

---

**Prompt 24: Fluency and Reading Assessment Protocol**

*When to use: Setting up oral reading fluency or comprehension assessments*

```
Create a reading assessment protocol for the following.

Grade level: [GRADE]
Assessment type: [ORAL READING FLUENCY / RUNNING RECORD / READING CONFERENCE / COMPREHENSION CHECK]
Purpose: [DIAGNOSTIC / PROGRESS MONITORING / BENCHMARK]
Frequency: [HOW OFTEN YOU'LL ASSESS]
Number of students: [CLASS SIZE — affects logistics]

Create:
1. Step-by-step assessment protocol (what to do, what to record, how long it takes)
2. Data recording form
3. Student-facing task (what the student is asked to do during the assessment)
4. Scoring guide with level descriptors
5. Interpretation guide (what different score ranges tell you)
6. Logistics plan (how to assess while the rest of the class is occupied)
7. Data-to-instruction action guide (what to do with different results)
8. Parent communication template for sharing results

Assessment is only useful if it changes instruction. Build that connection in from the start.
```

---

**Prompt 25: Summative Assessment Design Guide**

*When to use: Designing a fair and comprehensive end-of-unit test or project*

```
Design a summative assessment for the following unit.

Subject: [SUBJECT]
Grade level: [GRADE]
Unit: [UNIT TITLE]
Standards assessed: [LIST]
Duration: [TESTING TIME OR PROJECT TIMELINE]
Format: [TEST / PERFORMANCE TASK / PROJECT / COMBINATION]

If a test: design a test that includes:
- Multiple choice (addresses recall and comprehension — [NUMBER] questions)
- Short answer (addresses application and analysis — [NUMBER] questions)
- Extended response or essay (synthesis and evaluation — [NUMBER / DESCRIPTION])
- Test blueprint (which standards appear in which questions)
- Answer key and scoring guide
- Estimated time per section

If a performance task: design a task where students:
- Apply knowledge to a novel, realistic scenario
- Demonstrate multiple standards simultaneously
- Produce a product that shows understanding (not just regurgitation)
- Are assessed with a rubric tied to standards

For either format: a validity check — does every standard have at least 2 assessment items? Does the assessment require students to actually demonstrate the unit's big ideas?
```

---

*Next: `04-classroom-management-prompts.md` → 22 prompts for behavior, routines, SEL, and differentiation*
