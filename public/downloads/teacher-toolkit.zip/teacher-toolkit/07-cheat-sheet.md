# 07 — Cheat Sheet

*Top 15 power prompts + 10 Golden Rules for teachers using AI*

---

## Top 15 Power Prompts (Copy-Ready)

---

**#1 — Instant Lesson Plan**
```
Write a complete [GRADE] [SUBJECT] lesson plan on [TOPIC]. Standard: [STANDARD]. Duration: [MINUTES]. Include: learning objectives, warm-up, direct instruction, guided practice, independent activity, exit ticket, and differentiation for struggling and advanced learners.
```

**#2 — Discussion Questions (All Bloom's Levels)**
```
Write 15 discussion questions for [GRADE] students on [TOPIC/TEXT]. Distribute across all Bloom's taxonomy levels: remembering (3), understanding (3), applying (3), analyzing (3), evaluating (2), creating (1). Label each. Include 3 genuinely debatable questions.
```

**#3 — Rubric Generator**
```
Create an analytic rubric for [ASSIGNMENT] for [GRADE] students. 4-5 criteria rows, 4 performance levels (4-1 scale). Write specific, observable language at each level — no vague descriptors. Also write a student-friendly version for self-assessment.
```

**#4 — Report Card Comments**
```
Write [NUMBER] report card comments for [GRADE] [SUBJECT]. Under [WORD/CHARACTER LIMIT]. For each student: [PERFORMANCE LEVEL], [ONE STRENGTH], [ONE GROWTH AREA], [ENGAGEMENT NOTE]. Be specific. No vague praise. Each comment should sound like it was written for this specific student.
```

**#5 — Parent Email — Concern**
```
Write an email to a parent about their [GRADE] student who is struggling with [SPECIFIC ISSUE]. I've already tried [INTERVENTIONS]. I'm requesting [MEETING / INFORMATION / HOME SUPPORT]. Warm but direct. 3-4 paragraphs. Collaborative tone — not accusatory.
```

**#6 — Differentiated Activity (3 Levels)**
```
Take this activity: [DESCRIBE ACTIVITY OR PASTE IT]. Create 3 versions: Version A for students 1-2 grade levels below (scaffold vocabulary and complexity), Version B (current), Version C for advanced students (add depth, complexity, or extension). Keep the learning objective the same across all three.
```

**#7 — Exit Tickets (10 Options)**
```
Generate 10 exit ticket options for a [GRADE] [SUBJECT] lesson on [TOPIC]. The learning objective is [OBJECTIVE]. Time: 2-5 minutes. Vary the format: include multiple choice, short answer, sentence frame, 3-2-1, rate + explain, and at least 2 others. Write the exact student-facing prompt for each.
```

**#8 — Sub Plans**
```
Write substitute teacher plans for my [GRADE] [SUBJECT] class on [DATE]. Class of [NUMBER] students. We're in the middle of [UNIT]. I need activities that don't require new content instruction. Include: schedule with timing, student-facing instructions, behavior protocols, early finisher activity, and what to do in an emergency.
```

**#9 — Behavior Concern Email to Parent**
```
Write an email to a parent about a behavioral incident in my [GRADE] class. What happened (factually): [DESCRIBE BRIEFLY]. What I did: [TEACHER/ADMIN RESPONSE]. What I need: [AWARENESS / MEETING / SUPPORT]. Tone: factual and collaborative, not punitive or alarming. 3-4 paragraphs.
```

**#10 — Vocabulary Instruction Plan**
```
Create student-friendly definitions, examples, and non-examples for these [GRADE] [SUBJECT] vocabulary words: [LIST WORDS]. Also suggest 3 vocabulary activities for introduction, practice, and review. Include sentence frames for ELL students.
```

**#11 — Warm-Up Activities (10 Options)**
```
Generate 10 bell-ringer / warm-up activities for my [GRADE] [SUBJECT] class during our [UNIT] unit. Each should take 3-5 minutes. Vary the format. Write the exact student-facing prompt for each so I can put it on the board immediately.
```

**#12 — Restorative Conversation Script**
```
Write a restorative conversation script for a teacher to use with a [GRADE] student after [INCIDENT]. Use restorative questions: What happened? What were you thinking? Who was affected? What can you do to make it right? What support do you need? Include: how to open, how to handle defensiveness, and how to close with an action plan.
```

**#13 — Parent Welcome Letter**
```
Write a welcome letter to families from their [GRADE] [SUBJECT] teacher [YOUR NAME]. Include: brief class overview, top 3-4 expectations, how to reach me, response time, key upcoming dates, and 1-2 sentences about me personally. Warm, professional, under one page.
```

**#14 — Peer Review Protocol**
```
Create a peer review protocol for [GRADE] students reviewing [ASSIGNMENT TYPE]. Time: [MINUTES]. Include: setup instructions, a structured response form with 4-6 specific prompts, sentence frames for giving critical feedback kindly, and a student self-reflection after receiving feedback.
```

**#15 — IEP Accommodation Implementation Plan**
```
Create an implementation guide for these IEP accommodations: [LIST ACCOMMODATIONS]. Grade: [GRADE], Subject: [SUBJECT]. For each accommodation: the specific classroom application, when/how I apply it, how I implement it without singling the student out, and how it applies on assessments.
```

---

## 10 Golden Rules for Teachers Using AI

---

**Rule 1: Always specify the grade level.**
AI without grade context produces generic output. "5th grade" and "8th grade" produce completely different lesson plans. Never skip this.

**Rule 2: Describe your students, not just the topic.**
"Class of 28 7th graders, 5 ELL students at intermediate level, 4 with reading IEPs, typical range of motivation" produces output 10x more useful than "my class."

**Rule 3: Review everything before using it with students.**
AI can write plausible-sounding but factually incorrect content, especially in science and history. You're the expert. Read it. Catch the errors before students do.

**Rule 4: Start with what you know, let AI do the formatting.**
You already know what you want to teach. Use AI to structure it, format it, generate examples, and produce student-facing materials — not to decide what to teach.

**Rule 5: Use it for the least valuable work first.**
Sub plans. Report card comment templates. Quiz formatting. Parent email drafts. These are tasks where AI saves hours without requiring your professional judgment. Start there.

**Rule 6: Edit to match your voice and your students.**
AI doesn't know that your class loves Minecraft references, that one student needs extra patience in explanations, or that last week's lesson went terribly and kids need a reboot. You do. Edit accordingly.

**Rule 7: Batch similar tasks.**
Run 10 parent emails in one session. Generate all 5 exit tickets for the week at once. Create all 10 warm-ups for a unit in one sitting. Batching reduces the setup time per output dramatically.

**Rule 8: Use AI for first drafts, not final products.**
The first draft is the hardest part. AI solves the blank page problem. Your job is to take the draft and make it excellent, appropriate, and yours.

**Rule 9: Keep a prompt bank.**
When you find a prompt that produces great results, save it. Build a personal library of your best prompts over time. These compound — your 50th prompt session is dramatically more efficient than your first.

**Rule 10: AI is a tool, not a teacher.**
The thing that makes your classroom work — your relationships, your judgment, your read on a room, your ability to pivot when something isn't landing — AI can't do any of that. Use it for the parts of teaching that don't require those gifts. Save your irreplaceable skills for the students.

---

## Quick Reference: Situation → Prompt Number

| I need to... | File | Prompt # |
|-------------|------|---------|
| Build a lesson plan | Lesson Planning | #1 |
| Create discussion questions | Lesson Planning | #4 |
| Write a rubric | Assessment | #1 |
| Write report card comments | Assessment | #5 |
| Differentiate an activity | Classroom Mgmt | #4 (or cheat sheet #6) |
| Draft a parent concern email | Parent Communication | #4 |
| Plan parent conferences | Parent Communication | #6 |
| Create a behavior plan | Classroom Mgmt | #12 |
| Write sub plans | Lesson Planning | #12 |
| Handle an upset parent | Parent Communication | #8 |
| Generate exit tickets | Lesson Planning | #13 |
| Write IEP accommodation plan | Classroom Mgmt | #5 |

---

*Print this page. Keep it on your desk. The whole toolkit is a reference — the cheat sheet is your daily driver.*
