# 06 — Workflow SOPs

*5 complete workflow playbooks for a teacher's most time-intensive recurring tasks*

---

## SOP 1: Weekly Lesson Planning Workflow (3-Hour Sunday Setup)

**Goal:** Plan an entire week of lessons in 3 hours instead of spread across the week.

### Step 1: Review and Reset (20 min)
- Review last week's exit tickets / formative data — who got it? Who didn't?
- Note which lessons went well and why
- Pull out the unit plan — where are you in the sequence?

### Step 2: Set This Week's Learning Targets (15 min)
- Identify 5 specific learning targets (one per day or per class)
- Write them as "I can" statements
- Use Prompt #27 from Lesson Planning if you need help translating standards

### Step 3: Generate Lesson Plans (90 min — 18 min per lesson)
For each lesson day, use Prompt #1 from Lesson Planning:
- Fill in: grade, topic, standard, time, class context
- Generate the full plan
- Read critically — adjust what AI got wrong
- Identify any materials you need to prep

### Step 4: Create Student Materials (30 min)
- Use Prompt #3 for any worksheets or activities
- Use Prompt #13 for exit tickets
- Set up any digital tools or platforms

### Step 5: Differentiation Check (15 min)
For any lesson with mixed ability levels:
- Run Prompt #7 (Differentiation) for the most complex lesson of the week
- Note what you'll have ready for struggling learners and fast finishers (Prompt #26)

### Step 6: Parent Communication (10 min)
- Draft weekly newsletter using Prompt #2 from Parent Communication
- Schedule for Monday or Tuesday delivery

---

## SOP 2: Report Card / Progress Report Season Workflow

**Goal:** Complete report card comments and grades in the least possible time, at the highest quality.

### Step 1: Data Gathering (1 hour)
- Pull grades from your grade book
- Note patterns: who improved? Who declined? Who's exactly where expected?
- Review your behavior and participation notes for any student who needs a fuller comment

### Step 2: Batch Comment Writing (use Prompt #5 from Assessment)
- Group students into 4-5 performance profiles:
  - Exceeding expectations
  - Meeting expectations (strong engagement)
  - Meeting expectations (average engagement)
  - Approaching expectations (specific skill gap)
  - Significantly below expectations
- Generate a template comment for each profile
- Customize each comment with student-specific details (use Prompt #5 in batches of 5-10 students)

### Step 3: Quality Check
For each comment:
- Is it specific? (not "works hard" — what does that look like?)
- Is it honest? (not falsely positive for struggling students)
- Is it actionable? (parent can do something with this information)
- Is it under the character limit?

### Step 4: Hard Conversations First
- For any student with a failing grade or serious concern, draft the parent communication BEFORE report cards go home (Prompt #15 from Parent Communication)
- Send those emails 24-48 hours before report cards go home — no parent should be surprised

---

## SOP 3: Parent-Teacher Conference Cycle (Fall and Spring)

**Goal:** Run efficient, meaningful conferences that leave families feeling informed and partnered.

### Week Before Conferences: Prep

**For each student:**
1. Pull key data: grades, assessment results, attendance, behavior notes
2. Use Prompt #6 from Parent Communication to prep talking points
3. Identify: one genuine strength, one specific growth area, one action plan item
4. Flag any families who will likely have concerns — pre-plan your responses

**Create a conference schedule:**
- Build in 5-minute buffers between appointments
- Schedule challenging conversations mid-block (not first or last — you need energy for them)

### During Conferences (15-20 minutes each)

**Minutes 1-2:** Greet warmly, ask one question about their student before you say anything ("What's [student name] been talking about from school lately?")

**Minutes 2-7:** Review the data — start with strengths (use specific evidence, not impressions)

**Minutes 7-12:** Address the growth area with specific data and a plan

**Minutes 12-17:** Ask what's happening at home, invite questions, agree on next steps

**Minute 17-20:** Summarize next steps, shake hands, genuinely thank them for coming

### After Conferences:

For any conference where action items were agreed:
- Send a brief follow-up email within 48 hours (use Prompt #22 from Classroom Management adapted for parent context)
- Log the conversation in your CRM / communication log
- Update any student support plans based on new information

---

## SOP 4: Differentiation Planning for a Mixed-Ability Class

**Goal:** Systematically ensure all students are appropriately challenged without overwhelming yourself.

### Step 1: Know Your Learner Levels (Once per unit start)

**Tier your class into three groups:**
- Approaching grade level (need more scaffolding)
- On grade level (standard instruction)
- Above grade level (need extension)

Note: these are fluid — some students are above in math but approaching in reading. Tier by skill, not by student identity.

### Step 2: Plan the Core Lesson

Build the on-grade-level lesson first (use Prompt #1 from Lesson Planning). This is the anchor.

### Step 3: Layer In Differentiation (use Prompt #7)

**For approaching students:**
- Simplify vocabulary (not content)
- Add visual supports
- Reduce length of independent work
- Provide sentence frames
- Allow partnership for initial tasks

**For above-level students:**
- Add complexity (not quantity)
- Open-ended extension questions
- Research component
- Teaching/explaining to others
- Connection to real-world application

### Step 4: Prepare Materials (10 minutes extra per lesson)

- Print modified versions if needed (label unobtrusively)
- Prepare digital differentiation if students use devices
- Stage materials at tables/groups before students arrive

### Step 5: During the Lesson: Strategic Grouping

Use the lesson's collaborative work time to run a small group with approaching students while others work independently. This is your differentiation gold time.

### Step 6: Monitor and Adjust

Use exit tickets daily to track who's getting it and who isn't. Adjust groups as needed — they're not permanent.

---

## SOP 5: End-of-Year Wrap-Up Workflow (Final 2 Weeks of School)

**Goal:** Close the year meaningfully, wrap up administrative tasks, and leave a clean handoff.

### Week 1: Learning Wrap-Up

**Day 1-2: Final assessments**
- Administer summative assessments if applicable
- Grade with efficient rubrics

**Day 3-4: Reflection and celebration**
- Run the student reflection activity (use Prompt #15 from Assessment)
- Celebrate accomplishments with the class — make the last week feel earned
- Student portfolio review if applicable

**Day 5: Communication**
- Send end-of-year letter to families (use Prompt #9 from Parent Communication)
- Send any final grade notifications

### Week 2: Administrative and Handoff

**Day 6-7: Records and handoff notes**
For each student who needs special considerations next year:
- Write brief transition notes for next year's teacher
- Flag: IEP/504 students, behavioral considerations, relationship dynamics, effective strategies

**Day 8-9: Classroom pack-up**
- Organize materials for next year
- Document what worked and what to change (while memory is fresh)
- Write 3 notes to yourself for September: "Do this earlier, don't do this, add this"

**Day 10: Personal reflection**
Use these prompts for your own reflection:
- What did I learn about teaching this year?
- Which students surprised me?
- What would I do differently?
- What am I most proud of?

This reflection shapes your teaching far more than any PD session. Don't skip it.

---

*Return to: `07-cheat-sheet.md` → Top 15 power prompts and 10 Golden Rules*
