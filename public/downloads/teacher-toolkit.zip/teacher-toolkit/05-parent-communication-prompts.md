# 05 — Parent Communication Prompts

*20 prompts for parent emails, conferences, newsletters, and difficult conversations*

---

**Prompt 1: Welcome to My Classroom Letter**

*When to use: Sending a welcome letter to families at the start of the school year*

```
Write a welcome letter to families at the start of the school year.

Grade level: [GRADE]
Subject: [SUBJECT]
Teacher name: [YOUR NAME]
School name: [SCHOOL]
Class overview: [BRIEF DESCRIPTION — what students will learn this year]
Key expectations: [3-4 MAJOR EXPECTATIONS for students and families]
How to reach me: [EMAIL / PHONE / PLATFORM]
Response time commitment: [E.G., "I respond to emails within 24 hours on school days"]
Upcoming important dates: [FIRST WEEK EVENTS, OPEN HOUSE, IMPORTANT DEADLINES]
Something personal about me: [1-2 SENTENCES to humanize the letter]

Write a letter that:
1. Is warm, welcoming, and reflects your genuine enthusiasm for the year
2. Gives families the essential logistics without overwhelming them
3. Invites family involvement and partnership
4. Sets a tone of collaboration (not "here are the rules" but "here's how we work together")
5. Is under one page — families don't read long letters

This letter shapes the first impression families have of you. Make it feel like the start of a partnership.
```

---

**Prompt 2: Weekly / Monthly Class Newsletter**

*When to use: Sending regular updates to families about classroom happenings*

```
Write a [WEEKLY / MONTHLY] class newsletter for families.

Grade level: [GRADE]
Subject: [SUBJECT]
Teacher name: [YOUR NAME]
Time period: [WEEK OF / MONTH OF]

Content to include:
- What we learned this week/month: [BRIEF SUMMARY — 2-3 things]
- Coming up next: [UPCOMING TOPICS OR ACTIVITIES]
- Reminders and dates: [LIST]
- Homework or home practice suggestions: [IF ANY]
- A moment to highlight (optional): [SOMETHING GOOD THAT HAPPENED]
- Ask from families: [IS THERE ANYTHING YOU NEED?]

Write a newsletter that:
1. Is brief enough that a busy parent will actually read it (under 300 words)
2. Uses friendly, accessible language
3. Gives parents enough context to ask their child meaningful questions
4. Highlights something positive about the classroom
5. Has a consistent format families can count on each week/month

The newsletter works when parents feel connected — not informed. Aim for that feeling.
```

---

**Prompt 3: Positive Phone Call Script**

*When to use: Making a proactive positive call to a family about their student*

```
Write a script for a positive phone call to a student's family.

Student: [FIRST NAME ONLY — or describe as "the student"]
What they did that was noteworthy: [SPECIFIC — not vague praise]
How long they've been in your class: [CONTEXT]
Any relationship context with the family: [HAVE YOU SPOKEN BEFORE? ANY HISTORY?]
Your goal for this call: [PURE POSITIVE / ALSO WANT TO MENTION SOMETHING / BUILD RELATIONSHIP]

Write a call script (2-3 minutes) that includes:
1. Introduction and reason for calling (lead with "I'm calling with good news" — this alone will shock them)
2. The specific thing their student did (with detail — not "doing great")
3. Why it mattered
4. A genuine invitation for their response
5. Close with warmth

Positive calls are one of the most powerful things a teacher can do for family relationships — and they take 3 minutes. Script it so you actually make them.
```

---

**Prompt 4: Concern-Based Parent Email (Academic)**

*When to use: Reaching out to a family about academic struggles before they become a crisis*

```
Write an email to a parent about a student's academic struggles.

Student: [DESCRIBE — grade level, how long in your class]
Academic concern: [SPECIFIC — what skill/grade/pattern is concerning]
What you've tried already: [INTERVENTIONS, EXTRA SUPPORT, ACCOMMODATIONS]
What's needed from the family: [INFORMATION / SUPPORT AT HOME / MEETING]
Your tone goal: [CONCERNED BUT NOT ALARMING / COLLABORATIVE / DIRECT]
Any sensitive context: [IS THERE A HOME SITUATION OR HISTORY YOU'RE AWARE OF?]

Write an email that:
1. Opens warmly — not with the problem immediately
2. States the concern clearly and specifically (not vague — "struggling" isn't specific)
3. Shares what you've already tried
4. Invites collaboration — what can we do together?
5. Proposes a specific next step (meeting, phone call, trial period)
6. Does NOT catastrophize or suggest a diagnosis
7. Is professional but not cold

Length: 3-4 paragraphs. The goal: the parent feels like you're a partner, not an adversary.
```

---

**Prompt 5: Difficult Behavioral Concern Email**

*When to use: Notifying a family about a serious behavioral incident*

```
Write an email to a parent about a behavioral incident.

Incident: [DESCRIBE WHAT HAPPENED — factually, objectively]
When and where: [DATE / CLASS / CONTEXT]
Student involved (describe, no name): [STUDENT PROFILE — grade, history]
What you did / administrative response: [ACTIONS TAKEN]
What is needed from the family: [AWARENESS / CONVERSATION / PLAN / MEETING]
Any prior communications about this student: [PREVIOUS CONTACTS — context]
Administrative awareness: [HAS ADMIN BEEN NOTIFIED? ARE THEY INVOLVED?]

Write an email that:
1. Uses factual, non-interpretive language (what happened, not what it meant)
2. Does not blame or shame the student or family
3. States what happened and what was done
4. Asks specifically for what you need from the family
5. Proposes a follow-up step
6. Is professional even if the situation was frustrating

Note: For serious incidents (safety concerns, harassment, illegal behavior), check with administration before contacting parents independently.
```

---

**Prompt 6: Parent-Teacher Conference Preparation Guide**

*When to use: Preparing for a parent-teacher conference, especially a challenging one*

```
Create a parent-teacher conference preparation guide for the following student.

Student profile: [GRADE LEVEL, performance level, behavioral/social context]
Parent/guardian: [WHO IS COMING — parent, grandparent, guardian?]
Conference purpose: [ROUTINE / CONCERN-BASED / REQUESTED BY PARENT / SPECIAL EDUCATION-RELATED]
Your goals: [WHAT DO YOU WANT THE PARENT TO UNDERSTAND? WHAT DO YOU NEED FROM THEM?]
Data to present: [GRADES, WORK SAMPLES, ASSESSMENTS, BEHAVIOR LOG — what you have]
Anticipated parent questions or concerns: [WHAT DO YOU EXPECT THEM TO ASK?]
Sensitive information: [ANYTHING THAT NEEDS CAREFUL FRAMING]

Create a conference prep guide with:
1. Opening statement (first 60 seconds — sets the tone, warm but focused)
2. 3-4 agenda items with key talking points and supporting data for each
3. Strength-based statement about the student (lead with genuine positive)
4. The concern or growth area (specific and evidence-based)
5. Your proposed action plan (what you'll do, what you need from home)
6. Anticipated hard questions and your prepared responses
7. Closing (clear next steps, how to follow up)

Conferences go sideways when teachers are unprepared for the first hard question. Prepare for 3.
```

---

**Prompt 7: IEP Meeting Communication**

*When to use: Communicating with a family before or after an IEP meeting*

```
Write a pre-IEP meeting communication to a family.

Meeting date and purpose: [DATE / ANNUAL REVIEW / INITIAL EVALUATION / AMENDMENT]
Who will be at the meeting: [TEAM MEMBERS]
What will be discussed: [BRIEF AGENDA]
Data being shared: [CURRENT LEVELS, GOALS, ASSESSMENT RESULTS]
Parent rights summary: [BRIEF NOTE ON THEIR RIGHTS IN THE IEP PROCESS]
Specific items you want them to be prepared for: [ANY DECISION POINTS]
Language needs: [IS AN INTERPRETER NEEDED?]

Write a communication that:
1. Explains the purpose of the meeting in plain language
2. Lists who will be there
3. Invites the family to share their perspective before the meeting
4. Notes any decisions that will need to be made
5. Shares procedural safeguards information in accessible language
6. Closes with contact information for questions

IEP meetings can be intimidating for families. A pre-meeting communication makes them feel prepared and like equal partners — not guests at a meeting about their child.
```

---

**Prompt 8: Response to Upset or Angry Parent**

*When to use: Responding to a hostile or accusatory message from a parent*

```
Write a professional, de-escalating response to an upset or angry parent message.

Their message (summarize or paste): [WHAT THEY SAID — their complaint or accusation]
What actually happened (your account): [THE FACTS AS YOU UNDERSTAND THEM]
Is the concern valid: [YES / PARTIALLY / NO — briefly]
Your goal: [DE-ESCALATE / PROVIDE INFORMATION / SCHEDULE A MEETING / INVOLVE ADMINISTRATION]
Tone guidance: [STAY PROFESSIONAL / FIRM BUT WARM / EMPATHETIC]

Write a response that:
1. Acknowledges their feelings without agreeing that the complaint is valid
2. Thanks them for raising the concern
3. Provides factual context (not a defense — just information)
4. Proposes a conversation if the situation is complex
5. Does NOT apologize for something that didn't happen
6. Does NOT be sarcastic, dismissive, or defensive in tone
7. Invites resolution, not continued conflict

Before sending: if this email could be misread, forwarded to administration, or escalate — have a colleague or admin review it first.
```

---

**Prompt 9: End-of-Year Letter to Families**

*When to use: Sending a closing letter to families at the end of the school year*

```
Write an end-of-year letter to families.

Grade level: [GRADE]
Subject: [SUBJECT]
Teacher name: [YOUR NAME]
What the class accomplished this year: [3-4 HIGHLIGHTS]
What students grew in: [SKILLS, HABITS, DISPOSITIONS]
A memorable moment from the class: [SOMETHING SPECIFIC]
Summer suggestions: [WAYS TO KEEP LEARNING OVER THE SUMMER — optional]
Your personal note: [SOMETHING GENUINE ABOUT THIS CLASS OR YEAR]

Write a letter that:
1. Celebrates the year with specific, genuine detail
2. Thanks families for their partnership
3. Acknowledges the students' growth (not just academic — growth as people)
4. Wishes them well going forward
5. Is warm and personal — not a form letter

Under 250 words. This letter should make families feel that their child was truly seen this year.
```

---

**Prompt 10: Student Struggling — Requesting a Meeting**

*When to use: Requesting an in-person meeting with a family about a serious academic or behavioral concern*

```
Write an email requesting a parent meeting about a student who is significantly struggling.

Student situation: [DESCRIBE THE CONCERN — academic, behavioral, social-emotional, or combination]
Urgency: [ROUTINE CHECK-IN / MODERATELY URGENT / URGENT — needs attention soon]
What you want to accomplish in the meeting: [SPECIFIC GOALS]
What you're bringing to the meeting: [DATA / WORK SAMPLES / PLAN]
Timing preference: [FLEXIBILITY YOU HAVE FOR SCHEDULING]
Who will be at the meeting: [YOU ONLY / WITH COUNSELOR / WITH ADMIN / WITH SPED TEAM]

Write an email that:
1. States clearly why you're requesting the meeting (without catastrophizing)
2. Conveys care for the student — this isn't a summons, it's a partnership request
3. Names what you'd like to accomplish together
4. Proposes specific times or a scheduling mechanism
5. Is appropriately serious without being alarming

The tone sets the stage for the meeting. An accusatory email creates a defensive parent. A collaborative email creates a partner.
```

---

**Prompt 11: Grade Level Transition Information Letter**

*When to use: Informing families about the transition to a new grade or school*

```
Write a transition information letter for families whose students are moving to the next grade or school level.

Current grade: [GRADE]
Transition to: [NEXT GRADE / MIDDLE SCHOOL / HIGH SCHOOL]
Key differences in the new environment: [WHAT CHANGES — schedule, expectations, independence level, teacher model]
Skills students should have: [WHAT THEY'LL NEED TO BE READY]
What families can do to support the transition: [SPECIFIC SUGGESTIONS]
Key dates: [ORIENTATION / REGISTRATION / LAST DAY / OTHER]
Who to contact with questions: [CONTACT INFO]

Write a letter that:
1. Acknowledges that transitions can feel big for students and families
2. Briefly describes what to expect in the new environment
3. Highlights what students have learned to prepare them
4. Gives 3-5 specific things families can do to support readiness
5. Answers the most common question families have about this transition
6. Closes with encouragement

Make families feel confident, not anxious.
```

---

**Prompt 12: Homework Policy Explanation**

*When to use: Explaining your homework policy and philosophy to families*

```
Write a homework policy explanation for families.

Grade level: [GRADE]
Subject: [SUBJECT]
Your homework philosophy: [WHY YOU ASSIGN OR DON'T ASSIGN HOMEWORK — your reasoning]
Homework expectations: [HOW MUCH / HOW OFTEN / WHAT TYPE]
What to do if homework is too hard: [PROTOCOL]
What to do if homework isn't completed: [CONSEQUENCE AND GRACE POLICY]
How families can help: [SPECIFIC, PRACTICAL SUGGESTIONS]
Platform for submitting or viewing homework: [TOOL OR LOCATION]

Write a 1-page policy explanation that:
1. Explains your homework philosophy honestly (why homework looks the way it does)
2. States expectations clearly
3. Gives families a specific protocol for confusion or difficulty
4. Distinguishes between "support" and "doing it for them" (this boundary is often blurry)
5. Addresses the most common family frustration about homework at this grade level
6. Invites communication if something doesn't work

Families support what they understand. Help them understand.
```

---

**Prompt 13: Tutoring Referral Letter**

*When to use: Recommending tutoring or outside support for a student*

```
Write a tutoring referral communication to a family.

Student profile: [GRADE, SUBJECT, SPECIFIC SKILL GAPS]
Why you're recommending tutoring: [SPECIFIC REASON — what tutoring would address]
Urgency: [OPTIONAL ENRICHMENT / WOULD HELP SIGNIFICANTLY / STRONGLY RECOMMENDED]
What tutoring should focus on: [SPECIFIC SKILLS OR CONCEPTS]
How to find a tutor: [SCHOOL RESOURCES / GENERAL GUIDANCE]
What you're doing at school: [WHAT CLASSROOM SUPPORT IS ALREADY IN PLACE]
Cost sensitivity: [ARE FREE OPTIONS AVAILABLE? SHOULD YOU MENTION THEM?]

Write a letter that:
1. States the recommendation clearly without alarming the family
2. Explains specifically what tutoring would address
3. Notes what school-based support is already happening
4. Gives practical guidance on finding support
5. Invites conversation about questions
6. Does NOT make families feel like they've failed

Tutoring referrals land better when families understand the specific skill gap, not just "needs help."
```

---

**Prompt 14: Celebration and Recognition Email**

*When to use: Sharing exciting student news or accomplishments with families*

```
Write an email to a family celebrating a student achievement.

Student: [DESCRIBE — grade level, how long you've known them]
Achievement: [SPECIFIC — award, growth milestone, act of leadership, published work, competition result, etc.]
Why it matters: [WHAT THIS ACHIEVEMENT REPRESENTS — effort, growth, persistence]
Context for the achievement: [WHAT THEY DID TO EARN IT]
Your personal note about this student: [SOMETHING GENUINE]

Write an email (under 200 words) that:
1. Leads with the good news (no preamble)
2. Is specific — not "your student did great" but "here's exactly what they did"
3. Connects the achievement to their effort, not just talent
4. Expresses genuine pride in this student
5. Invites the family to celebrate

These are the emails families keep. Make them worth keeping.
```

---

**Prompt 15: Explaining a Failing Grade**

*When to use: Communicating to a family that their student is failing or at serious academic risk*

```
Write an email explaining that a student is failing or in danger of failing.

Student situation: [GRADE, SUBJECT, CURRENT GRADE/LEVEL, WHAT CONTRIBUTED TO THIS]
What has already been communicated: [PRIOR CONTACTS WITH THIS FAMILY]
What the student needs to do: [SPECIFIC REQUIREMENTS — missing work, retakes, intervention]
What you've done to support: [WHAT'S BEEN TRIED]
Deadline or decision point: [IS THERE A GRADE DEADLINE? A RETENTION RISK? AN INTERVENTION TIMELINE?]
Resources available: [TUTORING, MAKE-UP OPPORTUNITIES, AFTER-SCHOOL HELP]

Write an email that:
1. Is direct — don't soften the news to the point of being unclear
2. States the current grade and what caused it
3. Explains what the student needs to do specifically to recover
4. Lists what support is available
5. States the timeline and any consequences clearly
6. Invites an immediate conversation

Families deserve direct information. Softening a failing grade to "areas for growth" helps no one.
```

---

**Prompt 16: Response to Parent Complaint About Another Student**

*When to use: A parent complains about another student's behavior toward their child*

```
Write a response to a parent who is complaining about another student.

Complaint summary: [WHAT THE PARENT SAID ABOUT THE OTHER STUDENT]
What you know about the situation: [YOUR UNDERSTANDING — has this been observed? reported? investigated?]
What you can and cannot share: [YOU CANNOT DISCUSS OTHER STUDENTS' DISCIPLINARY RECORDS]
What you've done or will do: [STEPS BEING TAKEN]
What the parent's child needs: [SUPPORT OR ACKNOWLEDGMENT]

Write a response that:
1. Acknowledges their concern genuinely
2. Explains you're investigating / have investigated
3. Does NOT discuss the other student's discipline or any action taken against them (this is private)
4. Focuses on what you're doing to ensure their student's wellbeing
5. Invites a meeting or call if they want to discuss further
6. Does NOT make promises about consequences for the other student

This is one of the trickiest parent communications. You're balancing privacy law, relationships, and legitimate parental concern at the same time.
```

---

**Prompt 17: Technology and Screen Time Policy Email**

*When to use: Communicating your classroom technology policy and expectations to families*

```
Write an email explaining classroom technology policy and expectations to families.

Grade level: [GRADE]
Devices in your classroom: [1:1 / SHARED / BYOD / NO DEVICES — describe]
Technology uses at school: [HOW DEVICES ARE USED — research, assignments, assessments, etc.]
Phone policy: [PHONES ALLOWED / NOT ALLOWED / LOCKED AWAY / SCHOOL POLICY]
Home digital citizenship expectations: [WHAT YOU NEED FROM FAMILIES REGARDING SCREEN TIME, MONITORING, SAFETY]
Platform families need to know: [SCHOOLOGY / CANVAS / CLASS DOJO / GOOGLE CLASSROOM / OTHER]
Acceptable use reminders: [KEY RULES]

Write an email that:
1. Describes the classroom technology policy clearly
2. Explains how technology is used to support learning (not just as distraction prevention)
3. Gives families the access information they need (platform login, monitoring)
4. Notes the phone policy and why
5. Offers digital safety resources if appropriate for grade level
6. Invites families to reach out with questions
```

---

**Prompt 18: Attendance and Tardiness Communication**

*When to use: Communicating with a family about chronic absence or tardiness*

```
Write a communication to a family about attendance or tardiness concerns.

Student situation: [DAYS ABSENT / TARDIES THIS MONTH / YEAR-TO-DATE]
Pattern: [IS THERE A PATTERN — Mondays, after appointments, specific periods?]
Academic impact: [WHAT THEY'VE MISSED — specifically]
School policy: [WHAT THE ATTENDANCE REQUIREMENT IS, ANY CONSEQUENCES]
Your approach: [CHECKING IN BEFORE ESCALATING / ALREADY ESCALATED]
Empathy context: [ANY KNOWN HOME CIRCUMSTANCES THAT CONTRIBUTE — illness, transportation, work?]

Write a communication that:
1. States the attendance data factually (number of absences/tardies)
2. Describes the academic impact specifically (not "falling behind" — "missed 3 lab days and the introduction to fractions unit")
3. Expresses care, not accusation — something may be wrong at home
4. Asks if there's anything the school can do to support attendance
5. Notes the school's concern (not threat) about continued absences
6. Proposes a conversation

Attendance calls work when families feel the school cares about their kid, not just the record. Lead with care.
```

---

**Prompt 19: Learning Differences Explanation Email**

*When to use: Explaining a potential learning difficulty to a family for the first time*

```
Write an email to a family raising the possibility that their child may have a learning difference or need evaluation.

Context: [WHY YOU'RE RAISING THIS — specific observations, patterns, performance]
What you've observed: [SPECIFIC, OBSERVABLE BEHAVIORS — not diagnosis language]
What you're not saying: [YOU ARE NOT DIAGNOSING — important to establish]
Next step you're recommending: [REFERRAL TO COUNSELOR / STUDENT SUPPORT TEAM / EVALUATION REQUEST]
Resources you can offer: [WHAT SUPPORT IS AVAILABLE AT SCHOOL]
How to have this conversation: [EMAIL FIRST / CALL FIRST / MEETING — what's most appropriate]

Write an email that:
1. Shares your observations in non-diagnostic, factual language
2. Does NOT use terms like "I think she has ADHD/dyslexia/etc." — describe what you see, not a label
3. Expresses genuine care and concern (this is coming from wanting to help)
4. Explains the next step clearly (who to contact, what an evaluation involves)
5. Reassures the family that getting support early is good, not a crisis
6. Invites immediate questions and conversation

Learning difference conversations are among the most important and most feared. Do them with care, not avoidance.
```

---

**Prompt 20: Family Engagement Invitation**

*When to use: Inviting families to get involved in classroom learning*

```
Write an invitation for families to participate in classroom learning.

Type of participation: [VOLUNTEER IN CLASS / VIRTUAL READ-ALOUD / CAREER PRESENTATION / CULTURAL SHARE / FIELD TRIP CHAPERONE / OTHER]
What you need: [SPECIFIC REQUEST — time, expertise, presence]
Date and time: [DATE / ONGOING / FLEXIBLE]
What the family member would do: [SPECIFIC DESCRIPTION — not vague "volunteer help"]
Why this matters: [HOW IT BENEFITS STUDENTS AND STRENGTHENS THE COMMUNITY]
Logistics: [SIGN-UP METHOD / BACKGROUND CHECK IF NEEDED / OTHER]

Write an invitation that:
1. Is specific about what you're asking for (vague invitations don't generate responses)
2. Makes participation feel accessible (different options for different schedules and comfort levels)
3. Connects their contribution to student learning (not just "we'd love help")
4. Removes barriers (what about language? transportation? time?)
5. Expresses genuine welcome

Families participate when they feel truly needed and truly welcome — not just tolerated. Build both into the invitation.
```

---

*Next: `06-workflow-sops.md` → 5 complete workflow playbooks for teachers*
