# 02 — Lesson Planning Prompts

*27 prompts for lesson plans, unit planning, activities, discussion questions, and engagement strategies*

---

**Prompt 1: Full Lesson Plan Generator**

*When to use: Building a complete lesson plan from scratch*

```
Write a complete lesson plan for the following class.

Subject: [SUBJECT]
Grade level: [GRADE]
Topic: [SPECIFIC TOPIC]
Standard(s): [STANDARD CODE AND DESCRIPTION]
Class duration: [MINUTES]
Prior knowledge: [WHAT STUDENTS ALREADY KNOW]
Student context: [CLASS SIZE, ANY RELEVANT INFO — ELL students, IEPs, ability range]
Available materials: [MATERIALS, TECHNOLOGY, TEXTBOOK]
Learning goal: [WHAT STUDENTS WILL BE ABLE TO DO BY END OF LESSON]

Include in the lesson plan:
1. Learning objectives (2-3, using action verbs — Bloom's taxonomy)
2. Essential question
3. Vocabulary to pre-teach (4-6 words)
4. Hook/warm-up (5-10 min) — engaging opening that connects to prior knowledge or sparks curiosity
5. Direct instruction / input (10-15 min)
6. Guided practice activity (15-20 min) — teacher-facilitated
7. Independent practice or student activity (10-15 min)
8. Closure / exit ticket (5 min)
9. Assessment: How will I know students met the objective?
10. Differentiation: accommodations for struggling learners and extensions for advanced learners
11. Materials list

Write this as a usable teacher document — not an outline, a complete plan ready to teach from.
```

---

**Prompt 2: Unit Plan Overview**

*When to use: Mapping out a multi-week unit before building individual lessons*

```
Create a unit plan overview for the following unit.

Subject: [SUBJECT]
Grade level: [GRADE]
Unit title: [TITLE]
Duration: [NUMBER OF WEEKS / DAYS]
Standards addressed: [LIST RELEVANT STANDARDS]
Central question or theme: [OVERARCHING QUESTION]
Prior learning: [WHAT STUDENTS KNOW COMING IN]
End goal: [WHAT STUDENTS WILL BE ABLE TO DO BY END OF UNIT]

Create a unit overview that includes:
1. Unit overview paragraph (what this unit is about and why it matters)
2. Essential questions (3-5)
3. Big ideas / enduring understandings (what students should remember in 5 years)
4. Skills and knowledge by the end of the unit
5. Assessment plan: formative checks + summative assessment description
6. Day-by-day scope and sequence (brief title + objective for each lesson)
7. Vocabulary list (8-12 key terms)
8. Resources needed (text, materials, technology)
9. Differentiation considerations for the unit as a whole

Format as a planning document I can use to guide building individual lessons.
```

---

**Prompt 3: Student-Facing Activity or Worksheet**

*When to use: Creating a structured activity or worksheet for students*

```
Create a student-facing activity for the following lesson.

Subject: [SUBJECT]
Grade level: [GRADE]
Topic: [SPECIFIC TOPIC]
Learning objective: [WHAT STUDENTS PRACTICE OR DEMONSTRATE]
Activity type: [GRAPHIC ORGANIZER / READING RESPONSE / PROBLEM SET / ANALYSIS TASK / WRITING TASK / OTHER]
Time: [MINUTES AVAILABLE]
Reading level: [GRADE LEVEL or ADJUSTED LEVEL]
Format: [INDIVIDUAL / PARTNER / SMALL GROUP]

Create a student-facing activity that:
1. Has a clear title and brief directions students can follow independently
2. Scaffolds the task from easier to harder (if applicable)
3. Uses language appropriate for [GRADE LEVEL] students
4. Includes 6-10 focused items, questions, or tasks
5. Has a reflection or exit question at the end

Write this as something I can print and hand out — formatted cleanly, student-ready.
```

---

**Prompt 4: Discussion Questions (Bloom's Taxonomy)**

*When to use: Generating tiered discussion questions for a reading, concept, or topic*

```
Write a set of discussion questions for the following topic or text.

Subject: [SUBJECT]
Grade level: [GRADE]
Topic or text: [DESCRIPTION]
Discussion format: [WHOLE CLASS / SOCRATIC SEMINAR / SMALL GROUP / PARTNER TALK]

Generate 15 questions distributed across Bloom's taxonomy levels:

Remembering (3 questions): Factual recall — what happened, who, when, where
Understanding (3 questions): Explaining and summarizing concepts
Applying (3 questions): Using knowledge in a new context
Analyzing (3 questions): Breaking down, finding patterns, comparing
Evaluating (2 questions): Making judgments, defending positions
Creating (1 question): Synthesis — design, imagine, propose

Label each question with its Bloom's level. Vary the question stems. Include at least 3 questions that don't have a single right answer — genuinely debatable.
```

---

**Prompt 5: Engaging Warm-Up Activities**

*When to use: Generating bell-ringers, warm-ups, or do-now activities*

```
Generate 10 different warm-up / bell-ringer activities for the following unit or topic.

Subject: [SUBJECT]
Grade level: [GRADE]
Unit or topic: [TOPIC]
Time for warm-up: [3-7 MINUTES]
Goals for warm-ups: [ACTIVATE PRIOR KNOWLEDGE / PREVIEW NEW MATERIAL / REVIEW RECENT LEARNING / MIX]

Create 10 warm-up activities. For each: a title, a brief description, and the exact student-facing prompt or task. Vary the format — include: quick writes, think-pair-share prompts, visual prompts, sentence frames, opinion polls, connections to current events, and knowledge checks.

These should be immediately usable — I should be able to put the student prompt on the board and walk away.
```

---

**Prompt 6: Project-Based Learning Design**

*When to use: Designing a PBL unit or major project*

```
Design a project-based learning unit for the following.

Subject: [SUBJECT]
Grade level: [GRADE]
Standards: [STANDARDS]
Duration: [WEEKS]
Real-world connection: [WHAT REAL-WORLD PROBLEM OR QUESTION WILL ANCHOR THE PROJECT?]
Available resources: [MATERIALS, TECHNOLOGY, COMMUNITY CONNECTIONS]
Final product: [WHAT WILL STUDENTS CREATE — presentation, model, product, proposal, report]

Design a PBL unit including:
1. Driving question (student-facing, open-ended, requires investigation)
2. Entry event (how you'll launch the project to hook students)
3. Need to know list (what students will identify as their learning gaps)
4. Learning sequence (how knowledge and skills build toward the final product)
5. Milestones and checkpoints (when drafts, peer reviews, check-ins happen)
6. Rubric for final product (4 criteria with 4 performance levels each)
7. Reflection prompt for students at project end
8. Connection to real-world audience or impact

PBL works when students see the purpose. Build that "why this matters" into every stage.
```

---

**Prompt 7: Differentiated Instruction Plan**

*When to use: Adapting a lesson for students with varying needs*

```
Differentiate the following lesson for multiple learner needs.

Lesson topic: [TOPIC]
Grade level: [GRADE]
Standard lesson summary: [BRIEF DESCRIPTION OF WHAT YOU'RE TEACHING]
Key learning objective: [WHAT ALL STUDENTS SHOULD ACHIEVE]

Differentiate for:
1. **Struggling learners / below grade level**: What modifications to content, process, or product will help them access the objective?
2. **On-grade-level learners**: The standard lesson
3. **Advanced / gifted learners**: What extensions, depth, or complexity challenges them beyond the standard?
4. **ELL students at [BEGINNER / INTERMEDIATE / ADVANCED] level**: Language supports, sentence frames, visual supports, modified text
5. **Students with [IEP ACCOMMODATION TYPE — e.g., extended time, preferential seating, reduced workload, chunked directions]**: How the lesson accommodates these without singling students out

For each group: list the specific modification, the rationale, and what I need to prepare.

Also: a grouping strategy for this lesson (how to seat/group students for this activity).
```

---

**Prompt 8: Vocabulary Instruction Plan**

*When to use: Planning how to explicitly teach key vocabulary for a unit*

```
Design a vocabulary instruction plan for the following unit.

Subject: [SUBJECT]
Grade level: [GRADE]
Unit: [UNIT NAME]
Vocabulary words: [LIST 10-15 KEY TERMS]
Prior vocabulary knowledge: [WHAT STUDENTS LIKELY KNOW]
Instructional approach: [FRAYER MODEL / WORD WALLS / CONTEXT CLUES / SEMANTIC MAPPING / MIX]

Create a vocabulary plan including:
1. Tier 1 / Tier 2 / Tier 3 classification for each word
2. Student-friendly definitions for each term (grade-appropriate language, not dictionary definition)
3. An example and non-example for each term
4. 3 vocabulary activities to use throughout the unit (introduction, practice, review)
5. Vocabulary assessment strategy
6. How to support ELL students with these terms (visuals, cognates, home language connection)

Format the definitions and examples as a student handout I can print.
```

---

**Prompt 9: Cross-Curricular Connections**

*When to use: Finding connections between your subject and others, for interdisciplinary teaching*

```
Identify cross-curricular connections for the following unit.

Subject: [YOUR SUBJECT]
Grade level: [GRADE]
Unit: [UNIT TITLE AND BRIEF DESCRIPTION]
Standards you're addressing: [YOUR STANDARDS]

For each of these subject areas, identify a specific connection to your unit:
- ELA/Reading: [How does this connect to reading, writing, speaking, listening?]
- Math: [Any quantitative or data connections?]
- Science: [Any scientific concepts or methods that connect?]
- Social Studies / History: [Historical or civic connections?]
- Art / Music: [Creative expressions of the topic?]
- Health / PE: [Any physical or wellness connections?]
- Technology / Computer Science: [Digital tools or coding connections?]

For each connection:
- State the specific connection in one sentence
- Suggest one activity that explores the connection
- Note which standards from that subject area might align
- Rate the strength of the connection: strong / moderate / stretch

Identify the 2 strongest connections worth pursuing for a formal cross-curricular project or collaboration.
```

---

**Prompt 10: Socratic Seminar Preparation**

*When to use: Setting up a structured Socratic seminar*

```
Prepare materials for a Socratic seminar on the following topic or text.

Subject: [SUBJECT]
Grade level: [GRADE]
Text or topic: [TITLE AND BRIEF DESCRIPTION]
Duration: [MINUTES]
Class size: [NUMBER] (will you run inner/outer circle? Groups?)
Student preparation: [WHAT THEY'LL READ OR DO BEFORE THE SEMINAR]

Create:
1. 3-5 seminar preparation questions for students to answer in writing before class
2. The opening seminar question (open-ended, no single correct answer, invites genuine disagreement)
3. 8-10 follow-up discussion questions in case conversation stalls (varied Bloom's levels)
4. A student self-assessment checklist (what good seminar participation looks like)
5. A teacher observation/grading tool (how you'll assess participation quality, not quantity)
6. Instructions for student roles if running inner/outer circle format
7. Closing prompt for written reflection after the seminar

Socratic seminars fail when questions are too narrow. Make sure each question could generate 15 minutes of genuine discussion.
```

---

**Prompt 11: Reading Comprehension Support**

*When to use: Creating scaffolded supports for a complex reading*

```
Create reading comprehension supports for the following text.

Subject: [SUBJECT]
Grade level: [GRADE]
Text title and type: [FICTION / NONFICTION / PRIMARY SOURCE / TECHNICAL]
Reading level of text: [GRADE LEVEL or LEXILE if known]
Reading level of students: [RANGE IN YOUR CLASS]
Key learning goal: [WHAT STUDENTS SHOULD GET FROM THIS TEXT]
Challenging elements: [VOCABULARY / TEXT STRUCTURE / CONCEPTS / ALL THREE]

Create the following supports:
1. Pre-reading activity (3-5 minutes to activate background knowledge)
2. Vocabulary pre-teach (5 most critical words with student-friendly definitions)
3. Text-dependent questions (8 questions, from literal → inferential → evaluative)
4. Annotation guide (5-7 symbols or strategies with instructions for what to annotate and why)
5. Close reading prompt (1 passage to read twice with specific focus questions)
6. Post-reading synthesis task (brief writing or discussion that consolidates understanding)
7. Modified reading guide for ELL or struggling readers (simplified questions, sentence frames)
```

---

**Prompt 12: Substitute Teacher Plans**

*When to use: Creating complete, foolproof sub plans*

```
Write substitute teacher plans for my class.

Subject: [SUBJECT]
Grade level: [GRADE]
Date of absence: [DATE]
Class period(s): [SCHEDULE]
Students: [NUMBER OF STUDENTS, any important notes for sub — e.g., seating chart, any students with special needs to be aware of]
Materials available: [WHAT IS READY / WHERE IS IT]
Curriculum status: [WHERE YOU ARE IN THE UNIT]

Create sub plans that:
1. Begin with a "Dear Substitute" overview paragraph
2. Include a detailed schedule with time allocations
3. Have activities that DON'T require the sub to teach new content
4. Include student-facing instructions they can follow independently
5. List 3-5 specific student names the sub can rely on
6. Note which students may need extra support or monitoring
7. Include an emergency/early finisher activity
8. End with notes on where to leave work and what to report back

The best sub plans run themselves. Design for the sub who has never seen your subject.
```

---

**Prompt 13: Exit Ticket Generator**

*When to use: Creating quick formative assessment checks for end of lesson*

```
Generate 10 exit ticket options for the following lesson.

Subject: [SUBJECT]
Grade level: [GRADE]
Lesson objective: [WHAT STUDENTS SHOULD HAVE LEARNED]
Time for exit ticket: [2-5 MINUTES]

Create 10 different exit ticket options that directly assess the learning objective. Vary the format:
- Multiple choice question (1 question with 4 options and correct answer marked)
- Short answer (1-2 sentences)
- Sentence frame completion ("Today I learned that ___. One question I still have is ___.")
- Quick sketch or visual
- 3-2-1 format (3 things learned, 2 questions, 1 connection)
- True/false with justification
- One-word summary with justification
- Rate your understanding + what confused you
- Quick writing prompt
- Agree/disagree statement with evidence

For each: the student-facing prompt exactly as it would appear on the board or handout. Keep each under 5 minutes.
```

---

**Prompt 14: Technology Integration Plan**

*When to use: Incorporating technology meaningfully into a lesson*

```
Design a technology-integrated lesson for the following.

Subject: [SUBJECT]
Grade level: [GRADE]
Topic: [TOPIC]
Available technology: [1:1 CHROMEBOOKS / SHARED LAPTOPS / IPADS / SMARTBOARD / PHONES / OTHER]
Available tools/platforms: [GOOGLE WORKSPACE / CANVAS / SCHOOLOGY / SPECIFIC APPS]
Learning objective: [WHAT STUDENTS WILL DO]
Technology goal: [HOW TECH SHOULD ENHANCE — not replace — the learning]

Design a lesson where technology:
1. Gives students agency they couldn't have without it
2. Allows for collaboration, creation, or research
3. Provides differentiation or personalization
4. Is purposeful — remove the tech and the lesson should be noticeably weaker

Include:
- A tech-enhanced warm-up or engagement hook
- The main tech-integrated activity with step-by-step student instructions
- How you'll manage devices (protocols to establish before the lesson)
- A backup plan if technology fails
- A non-tech component to the lesson (not everything should be screen time)
- A formative assessment that uses or doesn't use tech (your choice)
```

---

**Prompt 15: Novel Study Unit Plan**

*When to use: Planning a complete novel study*

```
Design a novel study unit for the following book.

Book title and author: [TITLE] by [AUTHOR]
Grade level: [GRADE]
Subject: [ELA / HUMANITIES / OTHER]
Duration: [WEEKS]
Standards addressed: [STANDARDS]
Essential question: [BIG QUESTION — or let AI suggest one]

Design a complete novel study including:
1. Unit essential question and driving themes
2. Reading schedule (chapters per day/week with calendar)
3. Pre-reading activities (2-3 to build background knowledge and interest)
4. During-reading activities (5-7 tasks spread across the book — annotations, reading journals, discussions)
5. Discussion questions by section (3-5 questions per major section)
6. Vocabulary strategy for the book
7. Literary analysis mini-lessons needed (themes, characterization, point of view, etc.)
8. Summative assessment options (3 choices — essay / creative / visual/project)
9. Essay prompts (3 analytical essay prompts)
10. Post-reading connections activity
11. Recommended companion texts or media

Format as a unit planning guide with all student-facing materials noted but not fully written out (those are separate prompts).
```

---

**Prompt 16: Math Lesson Plan with Conceptual and Procedural Balance**

*When to use: Building a math lesson that doesn't just teach procedures*

```
Write a math lesson plan that balances conceptual understanding and procedural fluency.

Grade level: [GRADE]
Topic: [MATH TOPIC — e.g., dividing fractions, linear equations, geometric transformations]
Standard: [STANDARD CODE AND DESCRIPTION]
Prior knowledge: [WHAT STUDENTS ALREADY KNOW]
Common misconceptions: [WHAT STUDENTS TYPICALLY GET WRONG HERE]
Duration: [MINUTES]

Create a lesson that includes:
1. Conceptual warm-up (why does this make sense mathematically? — not just how to do it)
2. Problem-based opening task (students grapple with a real-world or novel problem before instruction)
3. Direct instruction connecting the concept to the procedure
4. Multiple representations (visual, numerical, algebraic, contextual — where applicable)
5. Collaborative practice problem set (5-6 problems, progressing in difficulty)
6. Error analysis activity (have students find and fix the mistake in worked examples)
7. Exit ticket (2 problems — one conceptual, one procedural)
8. Differentiation (support for struggling, extension for advanced)
9. Common misconceptions to watch for and how to address them in real time
```

---

**Prompt 17: Science Lab Design**

*When to use: Creating a structured lab or inquiry investigation*

```
Design a science lab investigation for the following topic.

Grade level: [GRADE]
Topic / concept: [SCIENCE CONCEPT]
Standard: [NGSS or STATE STANDARD]
Type of inquiry: [STRUCTURED / GUIDED / OPEN]
Duration: [CLASS PERIODS]
Materials available: [LIST]
Safety considerations: [NOTE ANY]
Prior knowledge: [WHAT STUDENTS KNOW]

Design a complete lab that includes:
1. Question / driving question
2. Background knowledge section (key vocabulary and concept review)
3. Hypothesis format (If ___ then ___ because ___)
4. Materials list with quantities
5. Step-by-step procedure (numbered, clear, safe)
6. Data collection table (formatted and ready to fill in)
7. Analysis questions (5-7 questions that require thinking, not just reporting data)
8. Error analysis section
9. Conclusion paragraph prompts / sentence frames
10. Extension investigation (for early finishers)
11. Safety reminders

Write the lab in student-facing language, formatted cleanly enough to print and use.
```

---

**Prompt 18: Writing Assignment Design**

*When to use: Creating a full writing assignment with scaffolding*

```
Design a writing assignment for the following.

Subject: [SUBJECT]
Grade level: [GRADE]
Writing type: [NARRATIVE / ARGUMENTATIVE / INFORMATIONAL / ANALYTICAL / CREATIVE]
Topic: [WRITING PROMPT TOPIC]
Standards: [ELA WRITING STANDARDS]
Length: [WORD COUNT OR PAGE COUNT]
Timeline: [HOW MANY CLASS PERIODS / DAYS]

Create a complete writing assignment package:
1. Student-facing prompt (clear, specific, engaging — not "write an essay about X")
2. Pre-writing graphic organizer
3. Planning guide / outline template
4. Mentor text annotation task (how to analyze a model before writing)
5. Drafting checkpoints (what to have done by each class period)
6. Peer review protocol (structured questions for partners to respond to)
7. Revision checklist (self-assessment before turning in)
8. Rubric (4 criteria, 4 performance levels — matches the assignment)
9. Sentence starters/frames for transitions and citations (if applicable)
10. Extension: prompt for students who finish early

The best writing assignments give students enough structure to not be overwhelmed and enough freedom to have a voice.
```

---

**Prompt 19: Formative Assessment Plan**

*When to use: Planning how to check for understanding throughout a unit*

```
Design a formative assessment plan for the following unit.

Subject: [SUBJECT]
Grade level: [GRADE]
Unit: [UNIT TITLE]
Duration: [WEEKS]
Key learning objectives: [LIST 4-6]

Design a formative assessment calendar that includes:
1. Weekly check-in strategies (low-stakes, quick — exit tickets, mini-quizzes, think-alouds)
2. Mid-unit formative task (more substantial — a paragraph, a problem set, a lab conclusion)
3. Ongoing formative practices (annotation checks, participation monitoring, homework review)
4. How I'll use each assessment to adjust instruction (data-to-action plan)
5. How students will use feedback to improve (self-assessment, peer feedback)
6. Digital vs. paper options for each check-in

Important: Distinguish formative from summative. Formative is for learning — it shouldn't count heavily for grades. Explain how I'll communicate this to students and parents.

For each formative strategy: what am I looking for? What response tells me a student is getting it vs. not?
```

---

**Prompt 20: Flipped Classroom Video Script**

*When to use: Creating a script for a short instructional video students watch before class*

```
Write a script for a short instructional video for the following lesson.

Subject: [SUBJECT]
Grade level: [GRADE]
Topic: [SPECIFIC CONCEPT]
Video length target: [5-8 MINUTES]
Student context: [WHAT THEY KNOW COMING IN, WHAT THEY NEED TO LEARN]
Style: [TALKING HEAD / SCREENSHARE / ANIMATED EXPLANATION / WHITEBOARD]

Write a video script that:
1. Opens with a hook — why this concept matters (30 seconds)
2. Defines key vocabulary (brief, memorable definitions — not textbook)
3. Explains the concept with one clear worked example
4. Shows a second example from a different angle
5. Highlights the 1-2 most common mistakes students make
6. Ends with a preview of what students will do in class tomorrow
7. Includes a "pause and try" moment where students practice before seeing the answer
8. Includes [INSTRUCTOR NAME] markers and [VISUAL] stage directions

Keep the language conversational — students watch these in their bedroom, not a lecture hall. No jargon without explanation.
```

---

**Prompt 21: Review Game Design**

*When to use: Creating a review game or activity before a test*

```
Design a review game or activity for the following content.

Subject: [SUBJECT]
Grade level: [GRADE]
Content being reviewed: [UNIT OR TOPIC]
Key concepts and skills: [LIST 8-12 ITEMS TO REVIEW]
Duration: [MINUTES]
Class size: [NUMBER]
Energy level desired: [HIGH ENERGY / FOCUSED / FLEXIBLE]
Materials available: [WHITEBOARD / DEVICES / CARDS / NOTHING SPECIAL]

Design a review activity that:
1. Has a clear name and brief teacher instructions
2. Has student-facing instructions (simple enough to explain in 2 minutes)
3. Reviews ALL the key content items (no just the easy stuff)
4. Creates genuine engagement, not just repetition
5. Works for your specific class size and materials

Create 2 options:
Option A: High-energy competitive format (teams, points, winner)
Option B: Collaborative mastery format (everyone improves together)

For each: provide 20 sample review questions drawn from the content listed.
```

---

**Prompt 22: Primary Source Analysis Activity**

*When to use: Building structured activities around primary source documents*

```
Create a primary source analysis activity for the following document.

Subject: [SOCIAL STUDIES / HISTORY / ELA / SCIENCE / OTHER]
Grade level: [GRADE]
Primary source: [TITLE, DATE, AUTHOR of the document — or describe it]
Unit context: [WHERE IN THE UNIT THIS FITS]
Learning objective: [WHAT STUDENTS SHOULD UNDERSTAND FROM THIS SOURCE]
Time: [MINUTES]

Create a structured primary source analysis activity:
1. Source context card (Who wrote it? When? Why? Historical context — 3-4 sentences for students)
2. First read: vocabulary support (5 words with student-friendly definitions)
3. Second read: annotation guide (what to look for, mark, and question)
4. SOAPS analysis or similar framework (Source, Occasion, Audience, Purpose, Subject)
5. Corroboration questions (how does this source connect to/conflict with what they already know?)
6. Bias and perspective questions (whose voice is present? Whose is missing?)
7. Essential question connection (how does this source help answer the unit's essential question?)
8. Modified version for ELL or struggling readers (simplified but not dumbed down)
```

---

**Prompt 23: Current Events Connection Lesson**

*When to use: Connecting curriculum content to a current news event*

```
Design a lesson that connects a current event to curriculum content.

Subject: [SUBJECT]
Grade level: [GRADE]
Current event: [DESCRIBE THE NEWS EVENT OR TOPIC]
Curriculum connection: [HOW THIS CONNECTS TO WHAT YOU'RE STUDYING]
Standards addressed: [STANDARDS]
Time available: [CLASS PERIOD OR MINUTES]

Design a lesson that:
1. Presents the current event in age-appropriate, neutral framing
2. Connects it specifically to curriculum content (not just "it's in the news")
3. Requires students to use skills from the curriculum to analyze the event
4. Distinguishes between facts and opinions in media coverage
5. Asks: What does our subject tell us about why this is happening?
6. Includes a discussion protocol so the conversation stays productive
7. Addresses teacher neutrality (how to facilitate discussion of controversial topics)
8. Includes a reflection or writing task

This lesson should feel relevant without being political or overwhelming for students.
```

---

**Prompt 24: Instructional Coaching Observation Write-Up**

*When to use: Writing lesson reflection notes for an observation or coaching cycle (for instructional coaches)*

```
Write a post-observation coaching feedback document for a teacher.

Observer: [COACH NAME]
Teacher: [TEACHER NAME]
Date and subject observed: [DATE / SUBJECT / GRADE]
Observation focus: [WHAT YOU WERE SPECIFICALLY WATCHING FOR — agreed upon in pre-conference]
What you observed: [DESCRIBE WHAT HAPPENED — specific, descriptive, non-evaluative]
Student learning evidence: [WHAT YOU SAW STUDENTS DO OR SAY]
Teacher moves noted: [SPECIFIC ACTIONS THE TEACHER TOOK]
Areas of strength: [WHAT WORKED — specific evidence]
Area for growth: [1 SPECIFIC FOCUS — with evidence]
Coaching question for post-conference: [OPEN QUESTION TO PROMPT TEACHER REFLECTION]

Write feedback that:
1. Is evidence-based — references specific moments, not impressions
2. Is non-evaluative in language (describe → don't judge)
3. Centers student learning, not teacher performance
4. Highlights strengths genuinely before growth areas
5. Uses a coaching question that prompts the teacher's own thinking
6. Frames the growth area as a specific, actionable experiment to try

Tone: Collegial and supportive. The goal is teacher growth, not performance evaluation.
```

---

**Prompt 25: Standards-Based Grade Explanation**

*When to use: Explaining standards-based grading to students or families*

```
Write a clear explanation of standards-based grading for [STUDENTS / PARENTS].

Grade level context: [GRADE]
Standards being assessed: [LIST THE KEY STANDARDS OR COMPETENCIES]
Grading scale used: [4-3-2-1 / MASTERY LEVELS / OTHER — with descriptions]
How this differs from traditional grading: [KEY DIFFERENCES]
Common questions parents or students ask: [LIST 3-5 QUESTIONS YOU ANTICIPATE]

Write a 1-page explanation that:
1. Explains what standards-based grading means in plain language
2. Describes the scale and what each level means (with examples)
3. Explains how to improve a score (specific — not just "try harder")
4. Addresses the most common concern: "Is my child getting an A?"
5. Notes what stays the same from traditional grading
6. Includes 3 FAQs with clear answers

Write a parent-facing version and a shorter student-facing version.
```

---

**Prompt 26: Anchor Activities for Fast Finishers**

*When to use: Creating meaningful work for students who finish early*

```
Create a bank of anchor activities for students who finish early.

Subject: [SUBJECT]
Grade level: [GRADE]
Unit or topic: [CURRENT UNIT]
Student ability level: [THESE ARE TYPICALLY ADVANCED LEARNERS / ALL LEVELS]
Time frame: [5-20 MINUTES — typical wait time]
Format preference: [INDEPENDENT ONLY / CAN INCLUDE PARTNER ACTIVITIES]

Create 10 anchor activities with:
- A short title and description
- The exact student-facing instructions
- What materials they need
- The learning goal or extension skill it addresses
- Estimated time

Ensure anchor activities:
- Don't just add more of the same work (busywork discourages fast finishers)
- Challenge students to go deeper, not further
- Are self-directing (don't require teacher attention)
- Connect to the current unit OR allow student-driven exploration
- Vary in type (writing, research, creative, challenge problems, teaching others, etc.)
```

---

**Prompt 27: Learning Target Language for Students**

*When to use: Translating standards into student-friendly "I can" statements*

```
Translate the following standards into student-friendly learning targets.

Standards: [LIST 5-10 STANDARDS WITH CODES AND DESCRIPTIONS]
Grade level: [GRADE]
Subject: [SUBJECT]
Format: [I CAN STATEMENTS / WE ARE LEARNING TO / LEARNING INTENTIONS]

For each standard:
1. Write a student-friendly learning target in age-appropriate language ("I can..." not standards jargon)
2. Write a brief success criteria ("I know I've got it when I can...")
3. Write a self-assessment question students can ask themselves
4. Suggest one quick way to demonstrate mastery of this target

Also suggest: How would you group or sequence these targets across a unit so they build on each other?

The test of a good learning target: Can a student read it, understand it, and use it to evaluate their own work? If not, rewrite it.
```

---

*Next: `03-assessment-feedback-prompts.md` → 25 prompts for rubrics, quizzes, and meaningful feedback*
