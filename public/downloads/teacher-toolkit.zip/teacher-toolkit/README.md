# 📚 The Teacher's AI Prompt Toolkit

**100+ battle-tested AI prompts for K-12 and higher education teachers**

---

## What's Inside

This toolkit gives you instant access to copy-paste-ready prompts for every part of a teacher's workflow — from building lesson plans to writing parent communications, from designing assessments to managing classroom behavior, from differentiating instruction to handling IEP documentation.

Every prompt is:
- **Grade-level aware** — Built for real classroom work, not generic education content
- **Structured** — Uses `[BRACKET VARIABLES]` so you can customize in seconds
- **Standards-aligned** — Designed to produce output you can actually use in your classroom
- **Time-saving** — Turns 2-hour tasks into 10-minute tasks

---

## File Guide

| File | Contents | Prompts |
|------|----------|---------|
| [01-quick-start-guide.md](01-quick-start-guide.md) | Setup, system prompts, best practices | — |
| [02-lesson-planning-prompts.md](02-lesson-planning-prompts.md) | Lesson plans, units, activities, objectives | 27 |
| [03-assessment-feedback-prompts.md](03-assessment-feedback-prompts.md) | Rubrics, quizzes, feedback, grading comments | 25 |
| [04-classroom-management-prompts.md](04-classroom-management-prompts.md) | Behavior plans, routines, SEL, differentiation | 22 |
| [05-parent-communication-prompts.md](05-parent-communication-prompts.md) | Parent emails, conferences, newsletters, reports | 20 |
| [06-workflow-sops.md](06-workflow-sops.md) | 5 complete workflow playbooks | — |
| [07-cheat-sheet.md](07-cheat-sheet.md) | Top 15 power prompts + 10 Golden Rules | 15 |

**Total: 100+ prompts**

---

## Who This Is For

- **K-12 classroom teachers** (all subjects and grade levels)
- **Special education teachers** managing IEPs and differentiated instruction
- **College and university instructors** building courses and managing student communication
- **Instructional coaches** supporting teacher development
- **New teachers** who want to fast-track their planning and communication skills
- **Veteran teachers** who want to reclaim time without sacrificing quality

---

## How to Use

1. Start with **[01-quick-start-guide.md](01-quick-start-guide.md)** — set up your subject and grade system prompt
2. Use **[02-lesson-planning-prompts.md](02-lesson-planning-prompts.md)** for your biggest time sink
3. Bookmark **[07-cheat-sheet.md](07-cheat-sheet.md)** for quick daily use
4. Use **[05-parent-communication-prompts.md](05-parent-communication-prompts.md)** when you have hard emails to write

---

*Built for teachers who went into this profession to teach — not to write paperwork.*
