# PRODUCT INFO — The Teacher's AI Prompt Toolkit

*Internal reference for sales, marketing, and distribution*

---

## Product Details

| Field | Value |
|-------|-------|
| **Product Name** | The Teacher's AI Prompt Toolkit |
| **Price** | $47 |
| **Format** | 7 Markdown files (digital download) |
| **Total Prompts** | 100+ ready-to-use AI prompts |

---

## Sales Description

Teachers spend hours every week on tasks that don't require their expertise — writing the same type of parent email for the 40th time, formatting a quiz they could have templated, generating discussion questions they already know how to ask. Meanwhile, the work that actually matters — building relationships, adapting to student needs, designing meaningful learning experiences — gets squeezed into whatever time is left.

**The Teacher's AI Prompt Toolkit** gives you 100+ AI prompts built for the classroom. Not generic writing prompts — lesson plan generators, rubric builders, parent communication scripts, differentiation strategies, behavior intervention templates, and IEP accommodation language — all ready to use.

**Stop spending Sunday night on paperwork. Start here.**

---

## Target Audience

**Primary:** K-12 classroom teachers, all subjects and grade levels. Typically 1-15 years experience. Managing 20-30+ students, regular parent communication, standards-based grading, and increasing documentation requirements.

**Secondary:** Special education teachers, instructional coaches, college instructors, teachers returning from leave who need to refresh their practice.

---

## All Included Files

| File | Prompt Count |
|------|-------------|
| `01-quick-start-guide.md` | Setup and system prompts |
| `02-lesson-planning-prompts.md` | 27 prompts |
| `03-assessment-feedback-prompts.md` | 25 prompts |
| `04-classroom-management-prompts.md` | 22 prompts |
| `05-parent-communication-prompts.md` | 20 prompts |
| `06-workflow-sops.md` | 5 SOPs |
| `07-cheat-sheet.md` | 15 prompts + 10 rules |

**Total: 100+ prompts, 5 workflow SOPs**

---

*Last updated: March 2026*
