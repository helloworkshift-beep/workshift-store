# The Sales Rep's AI Prompt Toolkit

## 60 AI Prompts to Prospect Faster, Close More Deals, and Hit Quota Every Month

---

*From the team at **Workshift** — workshift.store*

---

&nbsp;

---

## Welcome

You're holding the unfair advantage your quota doesn't know about yet.

This toolkit was built for sales reps who are tired of staring at a blank screen before a cold email, fumbling through objection handling, or spending Sunday evening catching up on CRM notes. Every prompt inside was designed by people who have lived in the trenches — carried a bag, missed a forecast, and celebrated a big close.

AI won't close deals for you. But it will get you into more conversations, keep you sharper on calls, and eliminate the busywork that eats your selling time. Think of it as having a seasoned sales trainer in your pocket, available 24/7, who never gets tired of helping you prep.

---

## How to Use This Toolkit

**Pick your moment, then pick a prompt.** This isn't a book to read cover-to-cover. It's a reference you grab when you need it — before a cold call blitz, right before a discovery call, after a proposal goes quiet.

**Paste, tweak, and fire.** Every prompt uses `[PLACEHOLDERS]` in brackets. Replace them with your real details before submitting. The more specific you are with placeholders, the more precise and useful the AI output will be.

**Iterate.** If the first response isn't quite right, reply with: *"Make it shorter / more direct / focused on [specific angle]."* AI is a conversation, not a vending machine.

**Keep a swipe file.** When a prompt produces something great, save it. You'll reuse it. Build your own library of winning prompts over time.

---

## Tips for Best Results

1. **Use a capable model.** These prompts are optimized for ChatGPT (GPT-4o), Claude, or Gemini Advanced. Free tiers will work but may produce blander output.

2. **Add context generously.** The more you tell the AI about your prospect, company, product, and situation, the sharper the output. Don't be stingy with details.

3. **Treat the output as a first draft.** Add your own voice. If it sounds too polished or robotic, dial it back. Prospects buy from humans.

4. **Don't spray and pray.** A personalized AI-assisted email beats 50 generic ones. Use these prompts to go deeper, not just faster.

5. **Combine prompts.** Use a research prompt to build a prospect profile, then feed that profile into an outreach prompt. Chain them together for compound results.

---

&nbsp;

---