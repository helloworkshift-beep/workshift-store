# Section 6: Negotiation & Closing

*7 Prompts*

---

### 47. The Discount Request Handler

**When to use:** When a prospect asks for a lower price and you want to negotiate from a position of strength — not panic.

**Prompt:**

> A prospect just asked for a [X%] discount on [PRODUCT/SERVICE], bringing the price from [FULL PRICE] to [REQUESTED PRICE]. Before I respond, help me think through this strategically: (1) What are the possible real reasons behind this request — budget, internal pressure, negotiation habit, or genuine value doubt? (2) What questions should I ask to understand which it is? (3) If I'm willing to offer a discount, what should I ask for in return (faster close, longer contract, case study rights, reference call, etc.)? (4) Draft two responses: one that holds price while reinforcing value, one that offers a conditional discount with a clear exchange. I want to close this deal, but not at the cost of setting a precedent.

**Pro tip:** Never give a discount without getting something in return — a concession without an exchange teaches prospects that your first price is always negotiable.

---

### 48. The Urgency Creator (No Fake Deadlines)

**When to use:** When you need to create legitimate urgency at the end of a sales cycle without manufacturing a false deadline.

**Prompt:**

> I'm trying to close a deal with [COMPANY NAME] by [TARGET DATE]. The prospect is interested but not urgent — there's no compelling event I've uncovered yet. I don't want to use fake "end of quarter pricing" tactics. Help me identify: (1) real business reasons this deal should close by [TARGET DATE] that I could surface in conversation, (2) questions I can ask to help the prospect connect their own goals and timelines to the urgency I need, (3) a value-based urgency message I can use in my next call or email — something that creates momentum without manufactured pressure. Also suggest: is there a small, low-risk action (a pilot, a kickoff date, an intro call with the CSM) that creates forward motion before the formal close?

**Pro tip:** Real urgency comes from their world, not yours — your job is to help them connect the dots between their goals and the cost of delay.

---

### 49. The Negotiation Scenario Planner

**When to use:** Before a negotiation meeting where you expect pushback on price, terms, or contract length.

**Prompt:**

> I'm heading into a negotiation meeting with [COMPANY NAME] for a deal worth [DEAL VALUE]. The key stakeholder is [TITLE]. Based on our conversations, I expect they'll push on: [LIST EXPECTED NEGOTIATION POINTS — e.g., price, contract length, payment terms, SLA requirements]. Help me prepare a negotiation playbook that includes: (1) my ideal outcome, acceptable outcome, and walk-away position for each point, (2) potential concessions I could offer that cost me little but feel valuable to them, (3) concessions I should never make, and (4) one opening move for each point that anchors the conversation favorably. I want to walk in knowing my range on every variable so I'm never caught flat-footed.

**Pro tip:** Enter every negotiation knowing your walk-away point in advance — if you figure it out in the moment, you'll almost always give up too much.

---

### 50. The Verbal Commitment to Paper Script

**When to use:** When a prospect has verbally said "yes" but hasn't signed and you need to convert enthusiasm into a closed deal.

**Prompt:**

> A prospect at [COMPANY NAME] verbally told me they want to move forward with [PRODUCT/SERVICE]. They said [QUOTE OR PARAPHRASE OF THEIR VERBAL COMMITMENT]. But I haven't received a signed agreement yet and it's been [TIMEFRAME]. Help me craft a follow-up communication that: (1) reflects their commitment back to them in a positive way, (2) clearly outlines the next 3 steps to get to a signed agreement, (3) removes any friction by offering to help with what's needed (order form, legal review, etc.), and (4) sets a specific date for the signature. The tone should feel like a project starting, not a sale closing — make it feel like forward motion, not pressure.

**Pro tip:** A verbal yes is a starting gun, not a finish line — move immediately to the next concrete step and never let more than 24 hours pass without a follow-up action.

---

### 51. The Multi-Option Close Architect

**When to use:** When you want to present pricing or package options in a way that makes "yes" easier and focuses the conversation on which option, not whether.

**Prompt:**

> I'm building a pricing proposal for [COMPANY NAME] and I want to present 3 options (Good / Better / Best or similar tiering). My product is [PRODUCT/SERVICE] and I know from discovery that they care most about [TOP 1-2 PRIORITIES]. Help me: (1) structure 3 tiers that make the middle option feel like the obvious, smart choice, (2) name each tier in a way that speaks to outcomes rather than features, (3) make the top tier aspirational but not out of reach, (4) make the bottom tier credible but slightly uncomfortable — enough that most buyers naturally move up. Draft the brief descriptions for each tier (2-3 sentences each) and suggest how to present them sequentially for maximum impact.

**Pro tip:** Present the highest option first — it anchors the conversation and makes the middle option feel like a bargain by comparison.

---

### 52. The Contract Redline Response Strategist

**When to use:** When legal sends back a redlined contract and you need to understand what's worth fighting for and what to let go.

**Prompt:**

> I received a redlined contract back from [COMPANY NAME]'s legal team. The key changes they're requesting are: [LIST THE MAIN REDLINES — e.g., removal of auto-renewal clause, reduction in liability cap, shorter payment terms, addition of termination for convenience]. I sell [PRODUCT/SERVICE] at [PRICE POINT / CONTRACT STRUCTURE]. Help me think through each requested change: (1) what's the real risk to my company if I accept it, (2) is this a standard ask or a red flag, (3) what's a reasonable counter-position for each, and (4) what should I escalate to my own legal team versus handle in conversation? Give me a simple framework for prioritizing which redlines to fight, accept, or trade.

**Pro tip:** Pick 2-3 redlines to push back on firmly — trying to fight every change signals inflexibility and slows the deal; let small things go to win what matters.

---

### 53. The Close Call Script

**When to use:** For the final close conversation — the meeting where you're asking for the signed order.

**Prompt:**

> I have a closing meeting with [COMPANY NAME] scheduled for [DATE]. The deal is for [PRODUCT/SERVICE] at [DEAL VALUE]. My main contact is [TITLE] and the key stakeholders are [LIST]. Based on everything that's happened so far: [BRIEF DEAL SUMMARY — key wins, outstanding concerns, current status]. Help me script a closing meeting agenda that: (1) opens by recapping their goals and the journey so far (2 minutes), (2) confirms agreement on key terms before presenting the final document, (3) handles any remaining concerns proactively, (4) asks for the business clearly and confidently without being pushy, and (5) maps out the "what happens next" onboarding story so the close feels like a beginning, not an ending. Draft my opening statement and the exact words to use when asking for the signature.

**Pro tip:** The best close is simply a confident summary of everything they've already agreed to — if you've done your job, signing should feel like the logical next step, not a leap.

---

&nbsp;

---