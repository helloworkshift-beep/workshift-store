# Section 4: Handling Objections

*8 Prompts*

---

### 31. The "We Already Have a Solution" Objection Handler

**When to use:** When a prospect tells you they're already using a competitor or have a current solution in place.

**Prompt:**

> A prospect just said: "We already use [COMPETITOR/CURRENT SOLUTION] and it's working fine for us." I sell [PRODUCT/SERVICE]. Help me craft a response that: (1) genuinely acknowledges their current solution without dismissing it, (2) asks a smart question that plants a seed of doubt or curiosity without being pushy, (3) opens the door to a comparison conversation without directly attacking the competitor. Give me 3 response options — one very soft/curious, one slightly more direct, one that leads with a relevant insight. All should feel like natural conversation, not a rehearsed rebuttal. Under 60 words each.

**Pro tip:** The goal at this stage is not to win the argument — it's to earn 5 more minutes of curiosity. Measure success by whether they keep talking.

---

### 32. The "Too Expensive" Objection Reframe

**When to use:** When a prospect pushes back on price and you want to shift the conversation from cost to value.

**Prompt:**

> A prospect said: "This is more than we were expecting to spend" or "It's too expensive." My product is [PRODUCT/SERVICE], priced at [PRICE RANGE or PRICING MODEL]. The core value I deliver is [SPECIFIC OUTCOMES — e.g., "reduces ramp time by 6 weeks" or "saves the average team 10 hours per week per rep"]. Help me craft a response that: (1) acknowledges the concern without caving, (2) reframes the conversation around ROI and cost of inaction, (3) helps them see the price relative to the problem it solves, not just as a line item. Give me 2 response options — one short and direct, one that walks through a simple value calculation. Neither should feel defensive or desperate.

**Pro tip:** Never apologize for your price — it signals that you don't believe in your own value.

---

### 33. The "Not a Priority Right Now" Delay Breaker

**When to use:** When a qualified prospect keeps pushing the conversation to a future quarter and there's no urgency.

**Prompt:**

> A prospect is consistently saying things like "This isn't a priority right now," "Let's revisit in Q3," or "We have too much going on." Based on my discovery, I believe the pain is real and the fit is strong. The key details: [BRIEF SUMMARY — their pain, their goals, what they're trying to accomplish this year]. Help me craft a response that: (1) respects their stated reality, (2) gently surfaces the cost of waiting — in time, money, or missed goals, (3) offers a very low-friction way to keep momentum without pressuring them. Also suggest: is there a compelling event I could tie this to, or a question I should ask to uncover a hidden reason for the delay?

**Pro tip:** "Not a priority" often means "I don't see enough value yet" — your job is to make the cost of doing nothing more vivid than the discomfort of deciding now.

---

### 34. The "I Need to Talk to My Boss" Stall Handler

**When to use:** When a prospect uses their boss or committee as a shield to avoid moving forward.

**Prompt:**

> A prospect said: "I need to run this by my boss/team/committee before we go any further." This happens at [CURRENT STAGE — e.g., end of the second call, after I sent the proposal]. My product is [PRODUCT/SERVICE] and the deal size is [ROUGH VALUE]. Help me: (1) understand whether this is a legitimate process step or a stall tactic, and how to tell the difference, (2) craft a response that advances the deal without making them feel pressured, (3) suggest a specific way to offer to be part of the conversation with decision-makers rather than being filtered out, and (4) identify what I should send them that makes it easy to get internal buy-in on my behalf. Draft a follow-up email that supports their internal selling.

**Pro tip:** The best way to handle this objection is to make your champion look smart — give them the ammunition to win internally without you in the room.

---

### 35. The "We're Going with a Competitor" Last-Chance Response

**When to use:** When a prospect tells you they've decided to go with someone else and you want one last respectful shot before accepting the loss.

**Prompt:**

> A prospect just told me they're going with [COMPETITOR NAME] instead of my product ([PRODUCT/SERVICE NAME]). This was a [DEAL SIZE/TIMEFRAME] opportunity. Help me craft a response that: (1) congratulates them genuinely without sounding sarcastic, (2) asks 1-2 respectful questions to understand what drove the decision (for my own learning), (3) plants a seed that keeps the door open if things don't work out with the competitor, and (4) leaves a strong professional impression so they remember me positively. Keep the whole response under 100 words and make it feel like it comes from someone who's confident, not desperate.

**Pro tip:** Deals lost to competitors have a 15-25% chance of coming back within 18 months — your job now is to be the obvious call when that happens.

---

### 36. The "We're Doing This In-House" Objection

**When to use:** When a prospect tells you they're going to build the capability themselves rather than buy your solution.

**Prompt:**

> My prospect said: "We're thinking about building this ourselves rather than buying a solution." I sell [PRODUCT/SERVICE] and the prospect is a [COMPANY SIZE] company in [INDUSTRY]. Help me build a response that: (1) validates their capability and doesn't dismiss the idea, (2) surfaces the real, often hidden costs of building vs. buying — time, talent, maintenance, opportunity cost, (3) reframes what they'd be giving up in time-to-value by building, and (4) offers a compelling reason to at least evaluate the comparison before committing. Give me a conversational response and 3 sharp follow-up questions to guide the discussion.

**Pro tip:** The "build vs. buy" objection is really a "we think we're special enough that off-the-shelf won't work" belief — find out what they think they'd need to customize and address that specifically.

---

### 37. The "Your Contract is Too Long / Too Risky" Commitment Objection

**When to use:** When a prospect is hesitant about a long-term contract, an annual commitment, or the perceived lock-in risk.

**Prompt:**

> A prospect is hesitating about the commitment level in our contract. They said something like: "[QUOTE OR PARAPHRASE — e.g., 'A 12-month contract feels like a big risk before we know it works' or 'We're not comfortable with annual upfront payment']." My pricing is [BRIEF PRICING STRUCTURE]. Help me craft a response that: (1) acknowledges the risk they're feeling without dismissing it, (2) reframes the commitment as a sign of their own confidence in achieving outcomes, (3) offers creative risk-mitigation options I could suggest (pilots, success milestones, shorter initial terms), and (4) asks a question to uncover the real fear behind the contract concern — is it financial, political, or trust-based?

**Pro tip:** Offering a shorter pilot period at a slight premium often converts faster than a discount on the annual — they want proof, not savings.

---

### 38. The Objection Preparation War Room

**When to use:** Before a major presentation or proposal meeting where you expect tough objections and want to be fully prepared.

**Prompt:**

> I have a major meeting with [COMPANY NAME] in [TIMEFRAME]. The stakeholders attending are: [LIST TITLES]. My product is [PRODUCT/SERVICE] and we're at [DEAL STAGE]. Based on the industry, company size, and stakeholder mix, anticipate the 6 most likely objections I'll face in this meeting. For each objection: (1) write out the likely exact words they'll use, (2) give me a 2-3 sentence response that addresses it confidently, (3) suggest one question I can ask to turn the objection into a discussion rather than a debate. Organize this as a one-page cheat sheet I can review the morning of the meeting.

**Pro tip:** Practice each response out loud the night before — hearing yourself say it builds muscle memory so you're calm and articulate when it matters.

---

&nbsp;

---