# Section 7: CRM & Admin Work

*7 Prompts*

---

### 54. The Call Notes to CRM Entry Converter

**When to use:** After a call when you have messy notes and need a clean, structured CRM entry in minutes, not 30 minutes.

**Prompt:**

> I just finished a call with [PROSPECT/CUSTOMER NAME] at [COMPANY NAME]. Here are my raw notes from the call: [PASTE YOUR UNSTRUCTURED NOTES — bullet points, fragments, whatever you have]. Convert these into a clean, structured CRM call log with the following sections: (1) Call Summary (2-3 sentences), (2) Key Pain Points Identified, (3) Stakeholders Mentioned and Their Roles, (4) Next Steps (with owner and target date), (5) Open Questions and Risks, and (6) Deal Stage Update. Use clear, scannable language — this entry will be read by my manager and future me. Flag anything that seems like a deal risk or needs immediate attention.

**Pro tip:** Do this immediately after every call before the details fade — 5 minutes of good notes saves an hour of reconstruction next week.

---

### 55. The Weekly Pipeline Review Prep

**When to use:** Before your weekly pipeline review with your manager to walk in sharp and avoid being caught off guard by hard questions.

**Prompt:**

> I have a pipeline review with my manager in [TIMEFRAME]. Here's my current pipeline: [PASTE YOUR DEALS — company name, deal size, stage, close date, last activity]. Help me prepare by: (1) flagging deals that look at risk based on close date vs. activity level, (2) identifying which deals need immediate attention this week, (3) anticipating the 3-5 hardest questions my manager will ask about specific deals and helping me draft honest, thoughtful answers, and (4) suggesting one specific action I should take on each at-risk deal before the review. I want to walk into that meeting owning the conversation, not reacting to it.

**Pro tip:** Your manager's job in pipeline reviews is to help you — come in with your own assessment and they'll spend time advising, not interrogating.

---

### 56. The Account Summary for Handoff

**When to use:** When you're transitioning an account to a new rep, a CSM, or onboarding team and need a thorough yet concise handoff document.

**Prompt:**

> I'm handing off [COMPANY NAME] to [RECIPIENT — a new rep, CSM, or onboarding team]. Here's everything I know about the account: [PASTE YOUR NOTES — contact info, deal history, pain points, promises made, relationship dynamics, known risks]. Create a professional account handoff document that includes: (1) Company overview and why they bought, (2) Key contacts and relationship map (who to trust, who to watch), (3) Commitments and expectations we set during the sales process, (4) Known risks or sensitivities to be aware of, (5) Suggested first actions for the new owner in the first 30 days. Keep it clear and practical — the person receiving this needs to get up to speed in 10 minutes.

**Pro tip:** Include a "landmine" section — the one thing that would torpedo the relationship if handled wrong. Future you (or your colleague) will be grateful.

---

### 57. The Activity Report Generator

**When to use:** When you need to submit a weekly or monthly activity report to your manager or for your own tracking.

**Prompt:**

> Help me write a concise weekly activity report for the week of [DATE RANGE]. Here's my raw activity log: [PASTE RAW DATA — calls made, emails sent, meetings held, proposals sent, deals closed, etc.]. Format this as a clean report with: (1) Key metrics at a glance (calls, meetings, emails, pipeline created, deals closed), (2) Top 3 wins or positive developments this week, (3) Top 3 challenges or at-risk items, (4) Focus for next week. Keep it under 300 words. Make me sound like someone who has their act together — because I do, I just don't have time to write it up beautifully.

**Pro tip:** Track your activity for 4-6 weeks and use the AI to spot patterns — you'll start to see what activities actually correlate with your pipeline growth.

---

### 58. The Email Inbox Triage & Response Drafts

**When to use:** When you have a backlog of prospect and customer emails and need to respond quickly without spending half your day writing.

**Prompt:**

> I have several emails in my inbox that need responses. For each one, draft a brief, professional reply that I can review and send with minimal edits. Here are the emails: Email 1: [PASTE EMAIL 1 + CONTEXT OF THE RELATIONSHIP/DEAL]. Email 2: [PASTE EMAIL 2 + CONTEXT]. Email 3: [PASTE EMAIL 3 + CONTEXT]. For each reply: keep it under 100 words unless the situation requires more, use a warm but efficient tone, address the specific question or request directly, and include a clear next step or call to action. Flag any email where you think I need to tread carefully or escalate before responding.

**Pro tip:** Always add one human touch before sending AI-drafted replies — a sentence that references something specific to the person or conversation so it never feels like a form letter.

---

### 59. The Forecast Commentary Writer

**When to use:** When you need to submit forecast commentary to leadership and want to communicate clearly and credibly about your pipeline confidence.

**Prompt:**

> I need to write forecast commentary for my [WEEKLY/MONTHLY/QUARTERLY] submission. Here is my committed pipeline: [PASTE DEALS YOU'RE COMMITTING — name, value, stage, close date, brief status]. Here are my upside deals: [PASTE UPSIDE DEALS WITH SAME FORMAT]. Help me write crisp, honest commentary for each committed deal (2-3 sentences) covering: deal status, key risk, and what needs to happen to close. Then write a brief overall summary paragraph that gives leadership confidence in my call. Avoid vague language like "things are progressing well" — I want specific, evidence-based language that shows I know exactly where each deal stands.

**Pro tip:** Good forecast commentary is about demonstrating control, not optimism — managers trust reps who accurately predict both wins and risks.

---

### 60. The Personal Performance Debrief

**When to use:** At the end of each month or quarter to reflect honestly on what worked, what didn't, and what to do differently.

**Prompt:**

> I want to run a monthly performance debrief. Here's my data from [MONTH/QUARTER]: Quota: [QUOTA AMOUNT]. Achieved: [ACTUAL AMOUNT]. Pipeline at start of period: [VALUE]. Deals won: [LIST BRIEFLY]. Deals lost: [LIST BRIEFLY + REASON IF KNOWN]. Key activities (calls, emails, meetings): [DATA]. Help me run a structured self-assessment: (1) What does the data actually say about my performance — beyond the top-line number? (2) Where in the pipeline did deals most often stall or die, and what does that suggest? (3) What 2-3 patterns emerge from the wins and losses? (4) What are the 3 most important things to change or improve next period? I want honest analysis, not cheerleading.

**Pro tip:** Do this monthly, not quarterly — by the time you review a full quarter, you've already repeated the same mistakes 90 days in a row.

---

&nbsp;

---

# What's Next

You've got 60 prompts. Now use them.

The reps who get the most out of this toolkit aren't the ones who read it once — they're the ones who keep it open during their prospecting blocks, pull it up before big calls, and reach for it the moment they're stuck. Bookmark it. Save it somewhere you'll actually find it.

A few suggestions as you build your practice:

**Start with the section that hurts most.** If cold outreach is your weakness, start there. If you always struggle to close, go to Section 6. Fix the biggest leak in your pipeline first.

**Build your own library.** When you find a prompt that consistently produces great output, save the customized version. Over time, you'll develop a personal prompt kit that reflects your voice, your product, and your market.

**Share what works.** If a prompt changes how you work or helps you land a big deal, tell your team. The best sales organizations treat prompts like playbooks — shared, refined, improved by everyone.

---

## More Toolkits at Workshift

This is one of a growing collection of AI prompt toolkits built for professionals who want to work smarter.

Explore the full collection at **[workshift.store](https://workshift.store)**:

- 📋 **The Project Manager's AI Prompt Toolkit** — *$67*
- 🏡 **The Real Estate Agent's AI Prompt Toolkit** — *$47*
- 🎯 **The Marketer's AI Prompt Toolkit** — *$67*
- 🔄 **The Scrum Master's AI Prompt Toolkit** — *$57*
- 🔬 **The UX Researcher's AI Prompt Toolkit** — *$57*

Each toolkit is built the same way this one was — by people who understand the job, not just the technology. No fluff. No generic advice. Just prompts that work.

---

*The Sales Rep's AI Prompt Toolkit*
*© Workshift — workshift.store*
*All rights reserved. For personal use only. Not for redistribution.*

---