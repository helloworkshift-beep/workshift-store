# Section 3: Discovery Calls & Qualification

*10 Prompts*

---

### 21. The Pre-Call Research Summary

**When to use:** 30 minutes before a discovery call when you want to walk in sharp and confident.

**Prompt:**

> I have a discovery call in 30 minutes with [PROSPECT NAME], [THEIR TITLE] at [COMPANY NAME]. Here's what I know: [PASTE EVERYTHING YOU HAVE — LinkedIn bio, company website info, news, previous email thread, notes from any prior conversation]. Summarize this into a fast pre-call brief with: (1) 3 things most likely on their mind professionally right now, (2) the 2-3 most relevant pain points my solution ([BRIEF PRODUCT DESCRIPTION]) likely addresses for them, (3) 5 sharp discovery questions tailored to their specific situation, and (4) one thing I should absolutely not assume going into this call. Keep it tight — I need this in 2 minutes flat.

**Pro tip:** Read the brief out loud once before the call — hearing it out loud locks it in better than just skimming it.

---

### 22. The MEDDIC Qualification Checklist

**When to use:** After a discovery call to evaluate whether the deal is real and worth your time before moving it to the next stage.

**Prompt:**

> I just finished a discovery call with [PROSPECT NAME] at [COMPANY NAME]. Here are my notes from the call: [PASTE CALL NOTES]. Evaluate this deal against the MEDDIC qualification framework: Metrics, Economic Buyer, Decision Criteria, Decision Process, Identify Pain, and Champion. For each element, tell me: (1) what I confirmed or uncovered, (2) what's still unknown or unclear, and (3) the single best question I should ask in my next interaction to fill that gap. Finish with an overall assessment: is this deal qualified, developing, or should I consider disqualifying? Be honest — don't just tell me what I want to hear.

**Pro tip:** Run this after every discovery call, not just the ones that feel uncertain — even great calls have blind spots.

---

### 23. The Discovery Question Bank

**When to use:** When you're preparing for a discovery call with a new type of prospect or entering an unfamiliar industry and want to sharpen your questions.

**Prompt:**

> I'm preparing for discovery calls with [PROSPECT'S ROLE] at [INDUSTRY] companies. I sell [PRODUCT/SERVICE] and my product addresses these core pain areas: [LIST 3-4 PAIN AREAS]. Generate a discovery question bank of 20 questions organized into 4 categories: (1) current state and status quo questions, (2) pain and impact questions that help quantify the problem, (3) future state and motivation questions, (4) process and decision questions to understand how they buy. Questions should be open-ended, conversational, and feel like they come from genuine curiosity — not an interrogation. Flag the 5 questions you'd recommend leading with in a first discovery call.

**Pro tip:** Never read questions off a list — internalize 5-7 of your favorites so they come out naturally, then let the conversation pull you to the others.

---

### 24. The Pain Quantification Drill

**When to use:** During or after discovery when you need to help a prospect translate their vague pain into a real business number.

**Prompt:**

> My prospect said their biggest pain is: [QUOTE OR PARAPHRASE WHAT THEY SAID — e.g., "our reps spend too much time on admin work" or "we're losing deals because our proposals take too long"]. I need to help them quantify this problem in dollars, hours, or percentage impact so it becomes a compelling business case. Help me craft 4-5 follow-up questions I can ask to help them articulate the financial impact of this pain themselves (don't tell them — help them discover it). Also give me a simple back-of-napkin calculation framework I could walk them through on the call to estimate the cost of inaction.

**Pro tip:** When the prospect does the math themselves, the number becomes theirs — it's ten times more persuasive than a number you hand them.

---

### 25. The Qualification Disqualification Helper

**When to use:** When you have a nagging feeling a deal isn't right but you're tempted to keep it in your pipeline because it feels good to have it there.

**Prompt:**

> I'm evaluating whether to continue investing time in a prospect. Here's the situation: [DESCRIBE THE DEAL — company size, contact, what they said, what stage you're at, any concerns you have]. I sell [PRODUCT/SERVICE] and my ideal customer looks like: [BRIEF ICP]. Play devil's advocate. Based on what I've shared, give me: (1) 3 warning signs this deal might not be worth pursuing, (2) the 3 questions I should ask to either confirm or dispel each concern, and (3) a recommendation: dig in, qualify further, or walk away. Don't try to be nice — I need honesty to protect my pipeline quality.

**Pro tip:** Healthy pipelines are built on ruthless disqualification — a "no" now is better than a "no" after 6 months of work.

---

### 26. The Current State vs. Future State Mapper

**When to use:** When you want to help a prospect vividly see the gap between where they are and where they could be — the foundation of a compelling value proposition.

**Prompt:**

> I'm preparing for a discovery call with [PROSPECT'S ROLE] at a [INDUSTRY] company. My product is [PRODUCT/SERVICE] and it helps with [CORE USE CASE]. Help me build a Current State vs. Future State map for this persona. Current State: describe what their world looks like without my solution — the manual work, the inefficiencies, the risks, the frustrations. Future State: describe what their world looks like after implementing my solution — what they can stop doing, what they can start doing, how their metrics improve. Use specific, vivid language that resonates with this role. I'll use this as a mental framework to guide discovery, not as a script to read aloud.

**Pro tip:** Share the future state vision early, then spend discovery confirming or adjusting it — it's faster than building it from scratch during the call.

---

### 27. The Stakeholder-Specific Question Set

**When to use:** When you're meeting a new stakeholder in a deal — someone with a different title, priorities, and concerns than your main contact.

**Prompt:**

> I have a meeting with [STAKEHOLDER TITLE — e.g., CFO, CTO, Head of Legal, VP of HR] at [COMPANY NAME]. This is a stakeholder I haven't spoken to before in this deal. My existing contact is [ORIGINAL CONTACT TITLE] and the core pain we've been discussing is [PAIN POINT]. My product is [PRODUCT/SERVICE]. Help me: (1) understand what this new stakeholder's typical concerns and priorities are for a purchase like this, (2) anticipate the questions they're likely to ask me, (3) generate 5 discovery questions tailored specifically to their role, and (4) identify one potential objection from this person I should proactively address. I want to walk in speaking their language, not my champion's.

**Pro tip:** End the meeting by asking: "What would you need to see to feel confident recommending this internally?" — it uncovers their personal criteria before they become blockers.

---

### 28. The Call Debrief & Next Step Planner

**When to use:** Immediately after a discovery call while the details are still fresh, to capture insights and plan the right follow-through.

**Prompt:**

> I just finished a discovery call with [PROSPECT NAME], [THEIR TITLE] at [COMPANY NAME]. Here are my raw notes: [PASTE NOTES]. Help me: (1) summarize the top 3 pain points they shared, with their own language where possible, (2) identify what stage of the buying journey they're in and how motivated they seem, (3) note any gaps in information I still need, (4) suggest the single strongest next step to advance this deal (be specific — not just "send a follow-up"), and (5) draft a brief follow-up email (under 150 words) that recaps key points, confirms the next step, and positions me as someone who listened carefully.

**Pro tip:** Send the follow-up email within 2 hours of the call — your credibility window is widest when the conversation is fresh in their mind.

---

### 29. The Multi-Stakeholder Discovery Debrief

**When to use:** After a discovery call with multiple stakeholders in the room, when you need to untangle who said what and what it means for the deal.

**Prompt:**

> I just finished a discovery call with multiple stakeholders at [COMPANY NAME]. The attendees were: [LIST NAMES AND TITLES]. Here are my notes: [PASTE NOTES]. Help me analyze this meeting by: (1) identifying each stakeholder's apparent priority and concern based on what they said, (2) mapping them to likely roles — economic buyer, champion, influencer, blocker, or neutral, (3) noting any tensions or misalignments between stakeholders that could complicate the deal, (4) recommending how I should follow up differently with each person. I want to leave this debrief knowing who to focus on, who to watch, and what the real decision dynamics look like.

**Pro tip:** Send a personalized follow-up to each stakeholder that specifically addresses their stated concern — generic group emails signal you weren't really listening.

---

### 30. The BANT Rapid Qualifier

**When to use:** When you need to quickly assess budget, authority, need, and timing during or after an early qualification conversation.

**Prompt:**

> I had a brief qualifying conversation with [PROSPECT NAME], [THEIR TITLE] at [COMPANY NAME]. Here are my notes: [PASTE NOTES]. Evaluate what I know against the BANT framework: Budget (do they have funds and is this a priority spend?), Authority (can this person approve or strongly influence the decision?), Need (is the pain real, articulated, and urgent?), and Timeline (is there a compelling event or timeframe driving action?). For each factor, rate it as strong, weak, or unknown, and suggest the one best question to ask next to fill in the gaps. Give me a bottom-line assessment: should I advance this or hold at this stage?

**Pro tip:** Use BANT as a minimum bar, not a ceiling — a deal that passes BANT still needs a champion and a clear decision process to close.

---

&nbsp;

---