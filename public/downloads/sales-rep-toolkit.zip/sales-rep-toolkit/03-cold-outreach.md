# Section 2: Cold Outreach — Email & LinkedIn

*10 Prompts*

---

### 11. The Trigger-Based Cold Email

**When to use:** When you have a specific reason to reach out — a news event, funding announcement, job posting, or company milestone.

**Prompt:**

> Write a cold outreach email to [PROSPECT NAME], [THEIR TITLE] at [COMPANY NAME]. The trigger/reason for reaching out is: [SPECIFIC TRIGGER — e.g., "they just raised a $20M Series B," "they posted 3 new AE roles this week," "their CEO just spoke about scaling revenue at a conference"]. I sell [PRODUCT/SERVICE] which helps [BUYER ROLE] at companies like theirs to [CORE OUTCOME — e.g., ramp new reps 40% faster, reduce churn by identifying at-risk accounts earlier]. The email should: be under 100 words, open with the trigger (not with "I"), connect their situation to a problem I solve, and close with a single low-friction ask. Do not use phrases like "I hope this email finds you well" or "I wanted to reach out."

**Pro tip:** Test two versions — one that leads with the trigger, one that leads with a provocative question — and alternate them to see which gets more replies.

---

### 12. The Pain-Led Cold Email

**When to use:** When you don't have a specific trigger but you know the prospect's role deeply enough to speak to their day-to-day frustrations.

**Prompt:**

> Write a cold email to a [PROSPECT'S ROLE] at a [COMPANY SIZE] [INDUSTRY] company. I don't have a specific trigger, so lead with a pain point that resonates deeply with this persona. The pain I want to address is: [SPECIFIC PAIN POINT — e.g., "their sales team is wasting hours per week on manual CRM data entry" or "they're losing pipeline visibility when reps work remote"]. My solution is [PRODUCT/SERVICE] and the outcome I deliver is [MEASURABLE RESULT IF POSSIBLE]. Keep it under 120 words. Make the opening line feel like I'm reading their mind — not pitching them. End with a soft ask to start a conversation, not to schedule a demo.

**Pro tip:** The opening line is everything — ask the AI to generate 5 different opening lines, pick the sharpest one, and build the email around it.

---

### 13. The Social Proof Email

**When to use:** When you have a strong customer story in the same industry or role as your prospect and want to lead with credibility.

**Prompt:**

> Write a cold email for [PROSPECT NAME], [THEIR TITLE] at [COMPANY NAME]. I want to lead with a customer success story to establish credibility. The story: [CUSTOMER NAME or "a similar company"] was struggling with [PROBLEM], and after implementing [PRODUCT/SERVICE], they achieved [SPECIFIC RESULT — e.g., "reduced ramp time by 6 weeks" or "grew pipeline 3x in 90 days"]. Connect this result to why it might be relevant for [PROSPECT'S COMPANY] based on [WHAT YOU KNOW ABOUT THEIR SITUATION]. Keep it under 120 words. Don't oversell. The goal is intrigue, not a pitch. Close with a question that invites them to share if they face a similar challenge.

**Pro tip:** Always use a real result with a number — "improved efficiency" is forgettable; "saved 8 hours per rep per week" is not.

---

### 14. The Pattern-Interrupt Subject Line Generator

**When to use:** When your open rates are suffering and your subject lines feel like every other email in the inbox.

**Prompt:**

> I need 10 subject lines for cold sales emails targeting [PROSPECT'S ROLE] at [INDUSTRY] companies. My product is [PRODUCT/SERVICE] and the core message I'm testing is about [THEME — e.g., pipeline visibility, reducing rep ramp time, cutting manual reporting work]. Generate 10 subject lines across these styles: (1) curiosity-driven, (2) pain-led, (3) direct benefit, (4) question format, (5) name-drop/social proof, and (6) pattern-interrupt/unexpected. Make them feel like they came from a human, not a marketing department. No clickbait. No "Quick question" or "Following up" — those are banned.

**Pro tip:** Subject lines under 6 words consistently outperform longer ones on mobile — ask the AI to rewrite its favorites in 5 words or fewer.

---

### 15. The LinkedIn Connection Request

**When to use:** When you want to connect with a prospect on LinkedIn without being immediately flagged as a sales pitch.

**Prompt:**

> Write 3 LinkedIn connection request messages (under 300 characters each) to send to [PROSPECT'S ROLE] at companies in the [INDUSTRY] space. I sell [PRODUCT/SERVICE]. I want the message to feel genuinely human, reference something specific and real (their content, their company, their role), and NOT immediately pitch. Give me one version that references their content/posts, one that references a shared interest or group, and one that's simply a smart, warm professional intro. Flag any that feel too salesy.

**Pro tip:** LinkedIn's character limit punishes preamble — get to the genuine reason you're connecting in the first sentence.

---

### 16. The LinkedIn Follow-Up Message Sequence

**When to use:** After connecting with a prospect on LinkedIn who hasn't responded to your first message.

**Prompt:**

> I connected with [PROSPECT NAME], [THEIR TITLE] at [COMPANY NAME] on LinkedIn [X DAYS] ago. I sent an initial message: [PASTE YOUR ORIGINAL MESSAGE]. They haven't responded yet. Write a 3-message follow-up sequence for LinkedIn. Message 1 (Day 4): add value — share a relevant insight, stat, or resource related to [PAIN POINT/INDUSTRY TOPIC] with a soft close. Message 2 (Day 10): create mild curiosity with a reframe or provocative question. Message 3 (Day 18): a short, graceful breakup message that leaves the door open. Each message should be under 150 words and feel nothing like a typical sales cadence.

**Pro tip:** The "breakup" message in step 3 often gets the most replies — people respond when they think the conversation is ending.

---

### 17. The Referral Request Email

**When to use:** When a happy customer could introduce you to someone in their network who matches your ICP.

**Prompt:**

> Write a brief, natural email asking [CUSTOMER NAME], my contact at [CUSTOMER'S COMPANY], for a referral introduction to someone in their network. They've been a customer for [TIMEFRAME] and have seen strong results: [1-2 SENTENCE RESULT SUMMARY]. I'm looking to connect with [TARGET PROFILE — e.g., VP of Sales at mid-market SaaS companies]. The email should: feel like it's from a friend, not a sales rep running a process; be short (under 100 words); make the ask easy and specific; and give them an out if they don't have anyone in mind right now. No guilt trips. No "you'd really be helping me out."

**Pro tip:** Send referral requests right after a customer celebrates a win — timing it to a moment of success doubles the response rate.

---

### 18. The Re-Engagement Email (Cold Prospect Gone Quiet)

**When to use:** When a prospect you've been emailing has gone completely silent and you want one last genuine shot before removing them from the sequence.

**Prompt:**

> I've been trying to reach [PROSPECT NAME], [THEIR TITLE] at [COMPANY NAME] for [TIMEFRAME]. They initially showed interest by [ORIGINAL ENGAGEMENT — e.g., opened 4 emails, responded once to ask for more info, filled out a form] but have since gone silent. Write a short re-engagement email (under 80 words) that does three things: acknowledges the silence without being passive-aggressive, gives them a face-saving out (things get busy, priorities shift), and offers one new, genuinely interesting piece of value — a stat, a story, or a perspective on [RELEVANT PAIN POINT] — that makes opening the email worth their while. End with one dead-simple question.

**Pro tip:** Change the sender name on this email if you can — "from the desk of [your manager's name]" re-engagements can break the pattern and get opened.

---

### 19. The Event-Based Outreach Email

**When to use:** Before or after an industry conference, webinar, or virtual event where you know prospects will be in attendance.

**Prompt:**

> Write a pre-event and post-event email sequence for reaching out to [PROSPECT'S ROLE] who are attending or spoke at [EVENT NAME]. I sell [PRODUCT/SERVICE] and I'll also be at the event / I watched the event (choose which applies). Pre-event email (send 5 days before): reference the event naturally, find a relevant hook connecting the event theme to [PAIN POINT], and ask if they'd be open to a 15-minute coffee or quick conversation at the event. Post-event email (send 2 days after): reference a specific session or insight from the event, tie it back to something relevant, and invite a follow-up conversation. Both emails under 120 words. Human, not templated.

**Pro tip:** Name-dropping a specific session speaker or insight in the post-event email is the difference between "mass blast" and "you were paying attention."

---

### 20. The Multi-Threading Email (Reaching New Stakeholders)

**When to use:** When your main contact has gone cold and you want to respectfully reach out to another stakeholder in the same account.

**Prompt:**

> I've been working with [ORIGINAL CONTACT NAME], [THEIR TITLE] at [COMPANY NAME], but our conversations have stalled. I want to reach out to [NEW CONTACT NAME OR TITLE], [THEIR ROLE], who I believe is also involved in decisions around [PRODUCT CATEGORY/PAIN POINT]. Write an email that: doesn't throw my original contact under the bus, acknowledges I may have already been in touch with their colleague, makes a fresh and relevant point about [KEY BUSINESS CHALLENGE], and asks for [SIMPLE NEXT STEP]. Keep it under 100 words and make it feel like I did my homework — not like I'm desperate.

**Pro tip:** Always CC or at least mention your original contact — going around someone without acknowledgment is a trust-killer if it comes out later.

---

&nbsp;

---