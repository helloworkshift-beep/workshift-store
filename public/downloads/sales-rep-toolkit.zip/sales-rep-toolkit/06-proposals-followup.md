# Section 5: Proposals & Follow-up

*8 Prompts*

---

### 39. The Executive Summary Writer

**When to use:** When you need to open your proposal with a summary that speaks to business outcomes, not product features.

**Prompt:**

> Write an executive summary for a proposal I'm sending to [COMPANY NAME]. The key stakeholders reading this are: [LIST TITLES — e.g., VP of Sales, CFO]. My product is [PRODUCT/SERVICE] and here's what I learned in discovery: [PASTE KEY PAIN POINTS, GOALS, AND BUSINESS CONTEXT FROM YOUR DISCOVERY CALLS]. The executive summary should: open with their situation and goals (not my product), articulate the cost or risk of their current state, describe the future state they can achieve with our solution, and close with a clear statement of what we're recommending and why. Aim for 200-250 words. No jargon. No "we're excited to partner with you."

**Pro tip:** Have your champion review the executive summary before you send — if they say "this nails it," the economic buyer will too.

---

### 40. The Business Case Builder

**When to use:** When a prospect or their finance team needs a clear ROI justification to get the deal approved internally.

**Prompt:**

> I need to build a business case for [COMPANY NAME] to justify the investment in [PRODUCT/SERVICE]. Here's what I know from discovery: Current pain/problem: [DESCRIPTION]. Estimated scope: [NUMBER OF USERS, TEAMS, OR TRANSACTIONS AFFECTED]. Current cost of the problem: [ANY DATA POINTS — time lost, error rates, missed revenue, etc.]. Investment: [YOUR PRICE]. Help me construct a business case that includes: (1) a cost-of-inaction analysis showing what doing nothing costs per month/year, (2) a conservative ROI calculation showing expected return on investment, (3) a payback period estimate, and (4) 2-3 non-financial benefits that matter to senior decision-makers. Use conservative assumptions and show your math — this needs to hold up to CFO scrutiny.

**Pro tip:** Label your assumptions clearly as "conservative" — it signals honesty and makes the business case more credible, not less.

---

### 41. The Proposal Follow-Up Email Sequence

**When to use:** After sending a proposal to a prospect who has gone quiet — you need to follow up without sounding needy.

**Prompt:**

> I sent a proposal to [PROSPECT NAME] at [COMPANY NAME] [X DAYS] ago. They haven't responded. The proposal was for [PRODUCT/SERVICE] at [ROUGH PRICE POINT]. Write a 3-part follow-up sequence: Follow-up 1 (Day 3 after sending): brief, warm check-in that adds a small piece of new value — a relevant stat, case study, or insight — and asks if they have questions. Follow-up 2 (Day 7): re-anchor to the business problem and the cost of delay; create mild urgency without manufactured deadlines. Follow-up 3 (Day 14): the breakup message — brief, graceful, keeps the door open. All messages under 100 words. No "just checking in." No "per my last email."

**Pro tip:** On Follow-up 2, reference a specific number from the business case — it signals you were listening and keeps the ROI conversation active.

---

### 42. The Mutual Action Plan Creator

**When to use:** When you want to keep momentum after a positive meeting and create shared accountability for moving the deal forward.

**Prompt:**

> I just had a strong meeting with [PROSPECT NAME] at [COMPANY NAME] and they seem genuinely interested in moving forward. My product is [PRODUCT/SERVICE] and the deal size/complexity is [BRIEF DESCRIPTION]. Help me create a Mutual Action Plan (MAP) — a shared timeline of steps for both parties to get from where we are today to a signed agreement. Include: a proposed close date working backwards, key milestones (next meeting, legal review, stakeholder sign-off, etc.), clear owner for each step (their side vs. my side), and a note on what could delay each step. Format it as a clean table or numbered list I can paste into an email and send immediately after the call.

**Pro tip:** Call it a "success plan" or "go-live roadmap" when presenting it to the prospect — "action plan" sounds like homework, but "success plan" sounds like a partnership.

---

### 43. The Case Study Match Generator

**When to use:** When you need to quickly identify and frame the most relevant customer story for a specific prospect.

**Prompt:**

> I'm preparing a proposal for [COMPANY NAME], a [COMPANY SIZE] [INDUSTRY] company. Their key pain points are: [PAIN POINTS FROM DISCOVERY]. My product is [PRODUCT/SERVICE]. I have the following customer stories available: [BRIEFLY DESCRIBE 2-3 CASE STUDIES — company type, challenge, result]. Help me: (1) identify which case study best matches this prospect's situation and why, (2) reframe the case study narrative to make it as relevant as possible to [COMPANY NAME]'s specific context, and (3) draft a 2-3 sentence version I can include in the proposal or email. If none of the case studies are a strong match, suggest what kind of story would be most compelling and how I could approximate it with what I have.

**Pro tip:** Swap industry names and titles to mirror the prospect's world as closely as possible — a story about "a similarly-sized fintech" hits harder than "one of our enterprise clients."

---

### 44. The Proposal Personalization Checklist

**When to use:** Before hitting send on any proposal to make sure it's genuinely tailored and not a templated document with their name dropped in.

**Prompt:**

> I've drafted a proposal for [COMPANY NAME]. Before I send it, help me evaluate how personalized and compelling it is. Here is the proposal: [PASTE PROPOSAL TEXT]. Review it against these criteria: (1) Does it open with their situation, not my product? (2) Does it use the prospect's own language (words they used in discovery)? (3) Does every feature or capability mentioned connect to a specific pain they articulated? (4) Is the pricing section tied to value, not just a number? (5) Is there a clear, specific next step? For each criterion, give me a score (1-3) and one concrete improvement suggestion. Be tough — I'd rather fix it now than lose the deal.

**Pro tip:** Read the proposal through the eyes of someone who's never heard of your company — if it could have been written for any prospect, it's not personal enough.

---

### 45. The "Proposal Stuck in Committee" Strategy Session

**When to use:** When your proposal is buried in an internal approval process and you need a strategy to move it forward.

**Prompt:**

> My proposal to [COMPANY NAME] has been stuck in [APPROVAL STAGE — e.g., legal review, budget committee, executive approval] for [TIMEFRAME]. My main contact is [CONTACT TITLE] and the deal is worth [DEAL SIZE]. Here's what I know about what's happening internally: [DESCRIBE ANY CONTEXT — who's involved, what concerns have been raised, any political dynamics]. Help me develop a strategy to accelerate this without annoying my champion or damaging the relationship. Specifically: (1) What questions should I ask my champion right now? (2) What content or support materials could help them push it forward? (3) Is there a way for me to engage the decision-maker directly, and if so, how? Give me an action plan for the next 7 days.

**Pro tip:** The single best question to ask your champion: "What would need to be true for this to get approved in the next two weeks?"

---

### 46. The Win/Loss Debrief Questionnaire

**When to use:** After closing or losing a deal to extract maximum learning and sharpen your process for next time.

**Prompt:**

> I just [WON / LOST] a deal with [COMPANY NAME]. The deal was for [PRODUCT/SERVICE] at [DEAL VALUE] and the sales cycle was [LENGTH]. Here's a summary of how it went: [DESCRIBE THE KEY EVENTS — first contact, discovery, proposal, competitive dynamics, deciding factors]. Help me run a structured win/loss debrief by generating 10 questions I should answer honestly (and ask the prospect if possible). Organize them into: (1) questions about why we won/lost, (2) questions about what I could have done differently at each stage, (3) questions about the competitive landscape, and (4) questions about what I should replicate or avoid next time. I want insights I can actually use, not generic lessons.

**Pro tip:** For losses, ask the prospect directly — most people will tell you honestly if you ask sincerely and without defensiveness within 48 hours of their decision.

---

&nbsp;

---