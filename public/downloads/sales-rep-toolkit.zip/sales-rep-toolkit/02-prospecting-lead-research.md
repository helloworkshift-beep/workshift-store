# Section 1: Prospecting & Lead Research

*10 Prompts*

---

### 1. The Ideal Customer Profile Builder

**When to use:** When you're entering a new market or territory and need to sharpen exactly who you should be targeting.

**Prompt:**

> I'm a sales rep selling [PRODUCT/SERVICE] to companies in the [INDUSTRY] space. My product helps with [CORE VALUE PROPOSITION — e.g., reducing onboarding time, improving supply chain visibility]. Based on this, help me build a detailed Ideal Customer Profile (ICP). Include: company size (employees and revenue), industry verticals, tech stack signals, common pain points, buying triggers, and the most likely job titles involved in the purchase decision. Format it as a clean, scannable profile I can reference during prospecting.

**Pro tip:** After generating the ICP, ask the AI to identify 5 specific companies that match the profile using publicly available signals — it'll help you validate the output immediately.

---

### 2. The Prospect Intelligence Brief

**When to use:** Before a first call or email with a new prospect to get up to speed fast without spending an hour on LinkedIn and Google.

**Prompt:**

> I have a first conversation scheduled with [PROSPECT NAME], [PROSPECT'S ROLE] at [COMPANY NAME]. Their company is in the [INDUSTRY] space and appears to be around [COMPANY SIZE] employees. Here's what I know so far: [PASTE ANY NOTES, LINKEDIN SNIPPETS, OR NEWS YOU HAVE]. Build me a pre-call intelligence brief that includes: a 3-sentence company summary, likely business priorities based on their stage and industry, potential pain points my solution ([BRIEF PRODUCT DESCRIPTION]) could address, conversation hooks or icebreakers, and 3 smart questions I should ask to open strong.

**Pro tip:** Paste the prospect's LinkedIn "About" section and their company's latest press release directly into the prompt for dramatically sharper output.

---

### 3. The Trigger Event Scanner

**When to use:** When you want to identify companies that have recently experienced events that make them likely buyers right now.

**Prompt:**

> I sell [PRODUCT/SERVICE] which is most valuable to companies that are [COMMON BUYING TRIGGER — e.g., scaling their sales team, going through a digital transformation, recently acquired, expanding into new markets]. Generate a list of 10 specific trigger events or buying signals I should be monitoring for in the [INDUSTRY] industry. For each trigger, explain why it creates urgency for my solution and suggest where I might find or track that signal (LinkedIn, news sources, job boards, etc.).

**Pro tip:** Turn the output into a weekly 15-minute research ritual — check each signal source once a week and you'll always have warm reasons to reach out.

---

### 4. The Lookalike Account Finder

**When to use:** When you've closed a great customer and want to find 10 more just like them.

**Prompt:**

> One of my best customers is [COMPANY NAME]. They are a [COMPANY SIZE] company in [INDUSTRY], and they use my product ([PRODUCT/SERVICE]) primarily to [PRIMARY USE CASE]. The main champion was [BUYER'S ROLE/TITLE]. Based on this profile, describe the 5 most important attributes that made this a great-fit customer. Then suggest 10 types of companies (you can name real ones if you know them) that share these attributes and would likely have the same pain points. For each, give me one sentence on why they'd be a strong fit.

**Pro tip:** Feed this output into LinkedIn Sales Navigator's account filters — the attributes the AI identifies translate directly into searchable filters.

---

### 5. The Job Posting Intelligence Report

**When to use:** When a company is hiring in a specific function — that's a buying signal hiding in plain sight.

**Prompt:**

> A company called [COMPANY NAME] is actively hiring for [JOB TITLE(S) THEY'RE POSTING — e.g., "5 Enterprise Account Executives" and "a VP of Revenue Operations"]. I sell [PRODUCT/SERVICE] which helps with [RELEVANT BUSINESS FUNCTION]. Analyze what these job postings likely signal about their current business priorities, pain points, and growth stage. Then help me build a hypothesis about why they might need my solution right now, and suggest a compelling angle for an outreach message that connects their hiring activity to the problem I solve.

**Pro tip:** Paste the actual job description text into the prompt — the language companies use to hire reveals exactly how they think about their problems.

---

### 6. The Competitor Customer Sniper

**When to use:** When you want to approach prospects who are currently using a competitor's product and may be ready for a switch.

**Prompt:**

> I'm going after prospects who currently use [COMPETITOR NAME] as their [PRODUCT CATEGORY] solution. My product is [PRODUCT/SERVICE NAME] and it's meaningfully better in these ways: [LIST 2-3 GENUINE DIFFERENTIATORS]. Help me: (1) identify the most common complaints and frustrations users have with [COMPETITOR NAME] based on what you know about the market, (2) craft a prospect list criteria I can use to find their customers (e.g., what they might say on LinkedIn, review sites, job postings), and (3) suggest a non-aggressive angle for initial outreach that acknowledges they're likely already in a solution but opens a conversation.

**Pro tip:** Check G2, Capterra, or Trustpilot reviews for the competitor first — real customer complaints are gold for this prompt.

---

### 7. The Executive Org Chart Mapper

**When to use:** Before a complex enterprise deal where you need to understand the power map and know who controls the budget, who influences the decision, and who will block it.

**Prompt:**

> I'm working a deal at [COMPANY NAME], a [COMPANY SIZE] company in [INDUSTRY]. The main contact I have is [CONTACT NAME], [THEIR TITLE]. I'm selling [PRODUCT/SERVICE] which typically involves [BRIEF DESCRIPTION OF STAKEHOLDERS — e.g., IT, Finance, and the business unit head]. Help me map out the likely org chart and decision-making structure for a purchase like this. Who are the typical economic buyers, champions, influencers, and potential blockers? Suggest specific job titles I should identify and engage, and give me one sentence on how to approach each role.

**Pro tip:** After mapping the org, ask: "Draft me a brief email to each stakeholder type, tailored to their likely concerns about this purchase."

---

### 8. The Industry Pain Point Deep Dive

**When to use:** When you're prospecting into a new vertical and need to sound like you've been selling into it for years.

**Prompt:**

> I'm starting to prospect into the [INDUSTRY] industry. My product, [PRODUCT/SERVICE], helps with [CORE CAPABILITY]. Act as a seasoned [INDUSTRY] industry expert. Give me: (1) the top 5 business challenges companies in this industry face right now, (2) how those challenges translate into day-to-day pain for the [BUYER TITLE] persona, (3) the language and terminology insiders use when talking about these problems (words and phrases I should use to sound credible), and (4) any recent trends or macro forces making these problems worse or more urgent. I want to walk into conversations sounding like I truly understand their world.

**Pro tip:** Follow up by asking the AI to role-play as a skeptical [BUYER TITLE] so you can practice your pitch against realistic objections before your first call.

---

### 9. The Champion Identification Playbook

**When to use:** When you're inside a prospect account but struggling to find the internal advocate who will push your deal forward.

**Prompt:**

> I'm working a deal at [COMPANY NAME]. I've been talking to [CURRENT CONTACT], [THEIR TITLE], but I'm not sure they have enough influence or motivation to be a true champion for my solution. I sell [PRODUCT/SERVICE] and it solves [PRIMARY PAIN POINT]. Help me: (1) define what makes an ideal internal champion for a deal like this, (2) identify the 3-4 job titles most likely to have both the pain and the influence I need, (3) suggest how I might get introduced to or identify these people within the account, and (4) give me talking points to coach my current contact into becoming a stronger champion themselves.

**Pro tip:** Ask the AI to help you write a "champion enablement email" — content your contact can forward internally to build buzz before the formal evaluation.

---

### 10. The Account Prioritization Scorer

**When to use:** When you have a large list of accounts and need to ruthlessly prioritize where to spend your time this week.

**Prompt:**

> I have a list of [NUMBER] accounts I'm considering prospecting. I need to prioritize them based on fit and likelihood to buy. My product is [PRODUCT/SERVICE] and my ICP looks like: [PASTE ICP SUMMARY OR KEY CRITERIA — company size, industry, tech stack, etc.]. Help me build a simple scoring rubric (1-3 points per criterion) that I can apply to each account to rank them. Include 6-8 scoring criteria that actually predict good fit and buying readiness. Then score these sample accounts for me: [PASTE 3-5 ACCOUNTS WITH BRIEF DETAILS]. I want to come out of this knowing exactly which 10 accounts deserve my attention first.

**Pro tip:** Rebuild this scoring model every quarter — what predicts a great customer shifts as your product and market evolve.

---

&nbsp;

---