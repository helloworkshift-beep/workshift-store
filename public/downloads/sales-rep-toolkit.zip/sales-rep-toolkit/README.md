# Sales Rep's AI Prompt Toolkit
## 60 AI Prompts to Prospect Faster, Close More Deals, and Hit Quota Every Month

**From Workshift — workshift.store**

---

## What's Inside

| File | Contents |
|------|----------|
| 01-welcome-and-guide.md | Intro, how to use, best practice tips |
| 02-prospecting-lead-research.md | 10 prompts — ICP, triggers, account intel |
| 03-cold-outreach.md | 10 prompts — Email & LinkedIn |
| 04-discovery-calls.md | 10 prompts — Qualification & MEDDIC |
| 05-objection-handling.md | 8 prompts — Price, timing, competition |
| 06-proposals-followup.md | 8 prompts — Proposals, follow-up, ghosting |
| 07-negotiation-closing.md | 7 prompts — Negotiation & closing tactics |
| 08-crm-admin.md | 7 prompts — Notes, reporting, updates |

**Total: 60 prompts**

---

More toolkits at workshift.store
