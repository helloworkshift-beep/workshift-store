# 🧑‍💼 The HR & Recruiter's AI Prompt Toolkit

**93 battle-tested AI prompts for HR managers, recruiters, and people ops**

---

## What's Inside

| File | Contents | Prompts |
|------|----------|---------|
| 01-quick-start-guide.md | How to use this toolkit | — |
| 02-job-descriptions-evp.md | JDs, EVP copy, DEI statements, bias audits | 14 |
| 03-sourcing-outreach.md | LinkedIn InMail, cold outreach, Boolean strings | 13 |
| 04-screening-interviews.md | Phone screens, structured interview guides, scorecards | 13 |
| 05-candidate-experience.md | Status updates, rejections, offer letters, negotiations | 12 |
| 06-onboarding.md | 30/60/90-day plans, welcome messages, remote onboarding | 9 |
| 07-hr-communications.md | Policy changes, PIPs, layoffs, terminations, RTO | 12 |
| 08-performance-retention.md | Reviews, stay interviews, promotions, exit interviews | 13 + 3 bonus |

**Total: 93 prompts**

---

## Who This Is For

- **In-house recruiters** who need to move faster without sacrificing quality
- **HR managers** who write the same types of communications over and over
- **People ops leads** standardizing the employee experience across the company
- **Talent acquisition teams** building or scaling an outbound sourcing function
- **HRBPs** who need help with the difficult, high-stakes conversations

---

## How to Use

1. Start with **01-quick-start-guide.md** — 5 minutes, saves hours
2. Go to the section matching your current task
3. Replace every `[BRACKETED PLACEHOLDER]` with your real details
4. Paste into ChatGPT, Claude, or any AI tool
5. Always review before sending — especially for sensitive communications

**Critical rule for HR:** AI handles the structure. You own the judgment. Never send a PIP, termination notice, or rejection email without reading it carefully and adjusting for your company's tone, legal context, and the individual's situation.

---

## File Guide by Situation

| What you're working on | Go to |
|------------------------|-------|
| Writing a new job description | 02 — Prompt 1, 2 |
| Reaching out to a passive candidate | 03 — Prompt 1, 2, 3 |
| Prepping a structured interview | 04 — Prompt 4, 5 |
| Sending a rejection email | 05 — Prompt 6, 7, 8 |
| Building a 30/60/90-day plan | 06 — Prompt 1, 2 |
| Writing a PIP | 07 — Prompt 5, 6 |
| Handling a layoff communication | 07 — Prompt 8, 9 |
| Running a performance review | 08 — Prompt 1, 2 |
| Conducting a stay interview | 08 — Prompt 4, 5 |

---

*Workshift · workshift.store · helloworkshift@gmail.com*
