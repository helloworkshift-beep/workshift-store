## Section 3: Screening & Interviews

*Screening questions, structured interview guides, scorecards, and assessment frameworks that reduce bias and improve hiring decisions.*

---

**INT-01 — Phone Screen Question Guide**

```
Create a structured phone screen guide for a [ROLE] position. The phone screen should be 20–30 minutes and help us quickly assess whether to move the candidate forward.

Role context:
- Level: [JUNIOR / MID / SENIOR / LEAD]
- Top 3 things we're assessing at this stage: [LIST — e.g., communication, baseline technical knowledge, motivation]
- Deal-breakers to uncover early: [LIST — e.g., salary misalignment, location requirements, start date conflicts]

Deliverable:
- 5–7 questions (not a full interrogation — leave time for the candidate to ask questions)
- Scoring notes for what "good" vs "concerning" looks like for each question
- 2–3 questions the candidate should ask us to gauge their preparation and interest
- Standard logistics questions to confirm before ending the call
```

---

**INT-02 — Structured Interview Guide (Behavioral, STAR Format)**

```
Build a structured behavioral interview guide for a [ROLE] position using the STAR method (Situation, Task, Action, Result).

Competencies to assess: [LIST 4–5 — e.g., communication, problem-solving, cross-functional collaboration, leadership, resilience]

For each competency, provide:
- Primary question
- 2 follow-up probes (to get past rehearsed answers)
- What strong evidence looks like (scoring anchor — 3 levels: below expectations / meets / exceeds)
- Red flags to listen for

Also include:
- Opening context-setting script (2–3 sentences to set expectations for the interview)
- Closing question: "What questions do you have for us?"
- Suggested time allocation for a 60-minute interview
```

---

**INT-03 — Technical / Skills-Based Interview Guide**

```
Create a technical interview guide for a [ROLE — e.g., Senior Software Engineer, Data Analyst, UX Designer] position.

Skills to assess: [LIST CORE TECHNICAL SKILLS]
Seniority level: [LEVEL]
Interview format: [e.g., live coding, case study, portfolio review, whiteboard, take-home]
Time available: [DURATION]

Include:
- 3–5 technical questions or problems, ordered from moderate to complex
- Evaluation criteria for each (what are we actually testing?)
- How to assess process and communication, not just the answer
- What good looks like at this seniority level vs. overqualified vs. underqualified
- Instructions for the interviewer on how to give hints without giving away answers
```

---

**INT-04 — Culture Add / Values Alignment Interview Questions**

```
Write 8–10 interview questions to assess culture add and values alignment for a role at [COMPANY].

Our values: [LIST YOUR COMPANY VALUES]
What "culture add" means to us (not just "culture fit"): [DESCRIBE — what new perspectives or experiences would strengthen the team?]

For each question:
- Write the question
- Note which value or culture dimension it's assessing
- Write 2 follow-up probes
- Describe what a genuinely aligned answer sounds like vs. a rehearsed/surface-level one

Important: Avoid questions that screen for sameness. We want people who share our values, not necessarily our backgrounds.
```

---

**INT-05 — Interview Scorecard Template**

```
Build an interview scorecard template for a [ROLE] position.

Competencies to rate (use these from my interview guide or suggest better ones):
[LIST COMPETENCIES OR SAY "SUGGEST BASED ON ROLE"]

For each competency:
- Rating scale: 1–4 (1 = does not meet bar, 4 = exceptional)
- Behavioral anchors for each rating level
- Evidence field (what did you actually observe?)

Also include:
- Overall recommendation field: Strong Yes / Yes / No / Strong No
- Hiring manager notes field
- "What would change your mind?" field (for borderline candidates)
- One field for: "What specific strength did this candidate bring that we haven't seen in others?"

Format as a clean table or checklist I can copy into a Google Form or ATS.
```

---

**INT-06 — Case Study / Work Sample Assignment**

```
Design a take-home case study or work sample assignment for a [ROLE] candidate.

Role context:
- What they'll be doing day-to-day: [DESCRIBE]
- Key skills we're evaluating: [LIST]
- Level: [SENIORITY]

Assignment requirements:
- Must be completable in [TIME LIMIT — e.g., 2–3 hours] — respect the candidate's time
- Must reflect real work, not trick questions
- Should allow candidates to show their thinking process, not just final output

Deliverable:
1. The assignment brief (written as if sent to the candidate)
2. Evaluation rubric (what we're looking for and how we'll score it)
3. A note at the top explaining the purpose and time expectation (candidates resent unpaid work — acknowledge it)

Also flag: should we compensate candidates for this? [YES/NO — write a note on what to include]
```

---

**INT-07 — Reference Check Script**

```
Write a reference check script for a [ROLE] candidate named [CANDIDATE NAME].

Reference context:
- Reference's relationship to candidate: [e.g., former manager, peer, direct report]
- Years they worked together: [TIMEFRAME]
- Areas I most want to probe: [LIST — e.g., leadership style, handling of conflict, technical depth, reliability]
- Any concerns from the interview process to verify: [OPTIONAL — describe]

Include:
- Opening script (how to frame the call, set them at ease to be honest)
- 8–10 questions, ordered from warm-up to specific
- How to ask about weaknesses in a way that gets real answers (not "they're a perfectionist")
- A specific question about whether they'd hire this person again, and what it would take
- Red flag phrases to listen for
```

---

**INT-08 — Panel Interview Coordination Guide**

```
We're running a panel interview for a [ROLE] candidate. Help me coordinate it.

Panel members: [LIST NAMES / TITLES — e.g., Hiring Manager, Team Lead, HR, Cross-functional Partner]
Interview duration: [TOTAL TIME]
Format: [ALL AT ONCE or SEQUENTIAL ROUNDS]

Deliverables:
1. Role assignments — who asks what (assign competencies to each panelist to avoid repetition)
2. Pre-interview alignment agenda (10–15 min sync before the interview)
3. Debrief structure for after (how to collect and compare feedback without groupthink)
4. Instructions for the panel on note-taking during the interview
5. Candidate-facing preparation email (what to expect, who they'll meet, format of the day)
```

---

**INT-09 — Candidate Debrief Facilitation Guide**

```
Facilitate a post-interview debrief for a [ROLE] candidate named [CANDIDATE NAME].

Interviewers: [LIST NAMES / ROLES]
Time available for debrief: [DURATION — e.g., 30 minutes]
Goal: Reach a hire/no-hire decision (or next-step decision) without groupthink or anchoring bias.

Write a debrief facilitation script that includes:
1. How to collect independent ratings BEFORE anyone shares opinions
2. A structured discussion order (start with most junior voice, end with most senior)
3. How to handle disagreements between strong yes and strong no
4. Questions to ask if the group is on the fence
5. How to document the decision and rationale
6. What to do if we can't reach consensus today

Important: Include a reminder about legal guardrails — what not to say or document.
```

---

**INT-10 — Interview Question Bank (Role-Specific)**

```
Generate an interview question bank for a [ROLE] position. I need a variety of questions to draw from across multiple interview rounds.

Include:
- 5 opening/warm-up questions (low stakes, build rapport)
- 10 behavioral questions (past experience, STAR-format)
- 5 situational questions (hypothetical scenarios relevant to this role)
- 5 motivational questions (why this role, career goals, what they're optimizing for)
- 5 critical thinking / problem-solving questions
- 3 questions specifically for senior/leadership versions of this role

Label each question with what it's assessing. Flag any questions that could be legally risky and suggest alternatives.
```

---

**INT-11 — Offer Stage Technical Assessment (Abbreviated)**

```
We've completed interviews for [CANDIDATE NAME] for our [ROLE] position. Before making an offer, we want one final, short technical check.

What we want to verify: [SPECIFIC SKILL OR KNOWLEDGE GAP FROM INTERVIEWS]
Time we'll ask them to spend: [30 MINUTES MAX — this isn't a free project]
Format: [LIVE CALL / ASYNC WRITTEN RESPONSE / SHORT EXERCISE]

Write:
1. The brief we'll send the candidate (frame it as a final conversation, not another test)
2. The specific question or task (focused and fair)
3. Evaluation criteria — pass/fail bar

Note: This should feel collaborative and low-pressure. If we've already decided we want them, this should feel like a formality that clarifies one detail.
```

---

**INT-12 — Structured Interview Questions for Diverse Candidate Panels**

```
I want to make sure our interview questions work well across diverse candidate pools — including candidates who have non-traditional backgrounds, career gaps, or different cultural communication styles.

Current interview questions to audit: [PASTE YOUR QUESTIONS]

Review for:
1. Questions that assume traditional career paths (e.g., prestigious schools, no gaps, linear progression)
2. Questions that favor extroverted communication styles
3. Questions that disadvantage candidates with international experience
4. Framing that could feel adversarial rather than exploratory

For each flagged question: suggest a more inclusive alternative that tests the same underlying competency.

Also suggest: 2 questions we should add to surface candidates with non-traditional paths who would excel here.
```

---

**INT-13 — Candidate Preparation Email (Before Interview)**

```
Write a preparation email to send to [CANDIDATE NAME] before their interview for the [ROLE] position at [COMPANY].

Interview details:
- Date/time: [DETAILS]
- Format: [e.g., video call via Zoom, in-person, phone]
- Interviewers they'll meet: [NAMES AND TITLES]
- Agenda/structure: [e.g., 30-min behavioral, 30-min case study]
- What to prepare: [e.g., bring work samples, review our recent product launch, come with questions]
- Link or address: [MEETING LINK OR LOCATION]
- Contact for questions: [NAME + EMAIL]

Tone: Warm and welcoming. We want them to walk in feeling prepared, not anxious. This email should make us look like an organization that respects candidates' time and experience.
```

---

---