## Section 5: Onboarding

*30/60/90-day plans, welcome messages, first-week agendas, and everything that determines whether a new hire stays or leaves within six months.*

---

**ONB-01 — Pre-Boarding Welcome Email**

```
Write a pre-boarding welcome email to send to [NEW HIRE NAME] after they've signed their offer but before their first day.

Their start date: [DATE]
Their role: [ROLE]
Their manager: [MANAGER NAME]

Include:
- Genuine excitement about them joining (specific to what they'll bring)
- Practical logistics: [WHAT THEY NEED TO KNOW BEFORE DAY 1 — equipment shipping, paperwork, system access, dress code if relevant, parking/building access]
- What their first day will look like (schedule or rough agenda)
- Who their main contact is for questions before day 1
- One fun/human thing about the team or company they'll want to know

Tone: Warm, organized, and reassuring. New hire anxiety is real. This email should make them feel like they made the right decision.
```

---

**ONB-02 — First Week Agenda**

```
Build a first-week onboarding agenda for [NEW HIRE NAME], a new [ROLE] joining [TEAM/DEPARTMENT] at [COMPANY].

Their manager: [MANAGER NAME]
Team size: [NUMBER]
Work arrangement: [REMOTE / ON-SITE / HYBRID]

Structure the week (Mon–Fri) with:
- Day 1: Focus on belonging, logistics, and team introductions (not information overload)
- Day 2–3: Role-specific orientation, tools access, key processes
- Day 4–5: First real project or contribution opportunity (even small)

Include:
- Suggested meetings to schedule and with whom
- What NOT to schedule in week 1 (avoid overwhelming them)
- End-of-week check-in agenda (30 min with manager)
- "Quick wins" to build early confidence

Format as a day-by-day calendar outline.
```

---

**ONB-03 — 30/60/90-Day Onboarding Plan**

```
Create a 30/60/90-day onboarding plan for [NEW HIRE NAME], a [ROLE] joining [COMPANY].

Context:
- Team/department: [DETAILS]
- Their primary goals for the first 90 days (as defined by the hiring manager): [LIST]
- Key stakeholders they need to build relationships with: [LIST]
- Systems/tools they need to learn: [LIST]
- Any specific project or deliverable expected by day 90: [DETAILS]

Format:
**Days 1–30 (Learn):** Focus areas, specific tasks, key relationships
**Days 31–60 (Contribute):** First contributions, projects, feedback checkpoints
**Days 61–90 (Deliver):** Defined outcomes, milestones, first performance conversation

Include:
- Success metrics for each phase (how will we know it's going well?)
- Weekly check-in cadence with manager
- Resources and documentation to review each phase
```

---

**ONB-04 — New Hire Announcement (Internal)**

```
Write an internal announcement to introduce [NEW HIRE NAME] to the company (or team).

About the new hire:
- Name: [NAME]
- Role/title: [ROLE]
- Department: [DEPARTMENT]
- Start date: [DATE]
- What they'll be working on: [BRIEF DESCRIPTION]
- Background/experience highlights (things they'd be comfortable sharing): [DETAILS]
- One fun/personal detail: [e.g., "Based in Austin, obsessed with sourdough, has a rescue greyhound named Gary"]

Channels to adapt for:
1. Company-wide Slack announcement (casual, under 100 words, emoji welcome)
2. Department email (slightly more formal, more context on their role)
3. Optional: LinkedIn welcome post from the company page

Tone: Warm and human. New employees are watching how they're introduced — it tells them a lot about the culture.
```

---

**ONB-05 — Manager's Onboarding Checklist**

```
Build an onboarding checklist for a hiring manager whose new [ROLE] starts in [NUMBER] days.

The manager's name: [MANAGER NAME]
New hire's name: [NEW HIRE NAME]

Organize into three phases:

**Before Day 1:**
- System access and equipment
- Team introductions pre-scheduled
- Workspace setup (physical or virtual)
- Documents/reading materials queued
- First-day schedule planned

**Week 1:**
- Check-ins to schedule
- Team norms and working agreements conversation
- Role clarity conversation (what does success look like?)
- Admin and tools walkthroughs

**Weeks 2–4:**
- Stakeholder intro meetings
- First project assignment
- Early feedback conversation
- 30-day check-in scheduled

Flag anything with a deadline or dependency. Format as a checklist with checkboxes.
```

---

**ONB-06 — Buddy Program Pairing Message**

```
We have an onboarding buddy program. Write the initial message introducing [NEW HIRE NAME] to their onboarding buddy, [BUDDY NAME].

Context:
- New hire's role: [ROLE]
- Buddy's role: [ROLE]
- How long buddy has been at company: [TIMEFRAME]
- What the buddy program involves: [DESCRIPTION — e.g., weekly coffee chats for 90 days, go-to person for informal questions]

Write two versions:
1. Message to the buddy (explaining who they're matched with, what's expected, and how to prepare)
2. Message to the new hire (introducing their buddy and explaining what to use them for)

Tone: Warm and low-pressure. The buddy program should feel like a gift, not a task.
```

---

**ONB-07 — 30-Day Check-In Conversation Guide**

```
Write a guide for a manager's 30-day check-in conversation with their new hire, [NEW HIRE NAME], [ROLE].

The goal of this conversation: assess how onboarding is going, surface early concerns, and adjust the plan if needed — before problems become problems.

Include:
- Opening (set the right tone — this is a two-way conversation)
- 8–10 questions to ask the new hire (cover: clarity of role, team relationships, tools/resources, what's going well, what's confusing)
- How to ask about early frustrations in a way that gets honest answers
- What the manager should share in return (their early impressions, feedback, adjustments)
- How to close with clear next steps
- Red flags to listen for (signs the onboarding isn't working)

Note: Remind the manager that this is NOT a performance review. It's a support conversation.
```

---

**ONB-08 — Remote Employee Onboarding Plan**

```
Create a remote-specific onboarding plan for [NEW HIRE NAME], a [ROLE] who will be working remotely at [COMPANY].

The challenges of remote onboarding:
- Isolation and slow team relationship-building
- Missing the informal "watercooler" context
- Tech setup without in-person support
- Understanding culture without physical cues

Address all of these with specific tactics. Include:
- Virtual day-1 agenda (schedule video calls, not just async tasks)
- Who to schedule informal 1:1s with in the first 2 weeks (beyond their immediate team)
- Tools and channels they need to know immediately
- How to participate in existing rituals (meetings, channels, traditions)
- What to do when they're confused or stuck — escalation path
- First 30 days success markers specific to remote context
```

---

**ONB-09 — Onboarding Survey (60-Day)**

```
Write a 60-day onboarding survey for new hires at [COMPANY].

Goals:
- Understand if onboarding prepared them to do their job
- Identify gaps in training, tools, or support
- Assess team integration and manager relationship
- Surface early disengagement signals

Include:
- 10–12 questions (mix of Likert scale and open-ended)
- Organized into 3 sections: Role Clarity, Team & Culture, Support & Resources
- One question about what would have made onboarding better
- One question about how confident they feel in their role right now
- Anonymity option with clear explanation of how results are used

Write the intro copy explaining why we're asking and when they'll hear results.
```

---

---