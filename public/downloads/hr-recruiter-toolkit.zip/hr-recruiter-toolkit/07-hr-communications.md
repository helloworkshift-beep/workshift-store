## Section 6: HR Communications

*Policy announcements, all-hands prep, layoff communications, difficult conversations, and everything that tests whether HR can actually communicate.*

---

**HRC-01 — Policy Update Announcement**

```
Write a company-wide announcement for a policy update or change.

Policy details:
- Policy name: [e.g., Remote Work Policy, PTO Policy, Expense Policy]
- What's changing: [DESCRIBE THE CHANGE CLEARLY]
- What's NOT changing (to reduce anxiety): [LIST]
- Effective date: [DATE]
- Why we're making this change: [HONEST REASON — e.g., company growth, legal requirement, feedback from employees]
- What employees need to DO as a result of this change: [ACTIONS REQUIRED, IF ANY]
- Where to find the full policy: [LINK OR LOCATION]
- Who to contact with questions: [CONTACT]

Tone: Direct and transparent. Don't bury the lede. Say what changed in the first two sentences. If this is an unpopular change, acknowledge that you understand it may be disappointing — don't gaslight people.
```

---

**HRC-02 — All-Hands Meeting Preparation Guide**

```
Help me prepare for an all-hands meeting at [COMPANY].

Meeting context:
- Date/time: [DETAILS]
- Attendees: [WHOLE COMPANY / DEPARTMENT]
- Format: [IN-PERSON / VIRTUAL / HYBRID]
- Duration: [LENGTH]
- Key topics to cover: [LIST]
- Sensitive or difficult news to address (if any): [DESCRIBE]
- Tone we want to strike: [e.g., energizing, honest reset, celebratory, serious]

Deliverables:
1. Suggested agenda with time allocations
2. Opening 2-minute script for the CEO/executive opening
3. Talking points for each agenda item
4. How to handle tough Q&A questions (especially ones we hope no one asks)
5. Closing statement that leaves people with the right feeling

Include guidance on what NOT to say — phrases that will land poorly even if well-intentioned.
```

---

**HRC-03 — Layoff / Reduction in Force Communication**

```
Help me write communications for a company layoff affecting [NUMBER or %] of employees at [COMPANY].

Context:
- Reason for the layoff: [HONEST REASON — e.g., economic conditions, strategic pivot, funding shortfall]
- Affected roles/teams: [DESCRIBE]
- Severance offered: [DETAILS]
- Healthcare continuation: [DETAILS]
- Outplacement support: [IF ANY]
- Timeline: [WHEN NOTIFICATIONS HAPPEN]

Write:
1. Manager notification script (what managers say to affected employees — in person or on call)
2. Email to affected employees immediately after notification
3. Email to remaining employees (what they receive the same day)
4. FAQ document for the remaining team (anticipate the questions people are afraid to ask)

Tone: Human, direct, and accountable. Do not use "we had to make the difficult decision to right-size." Say what happened and why. People deserve that.
```

---

**HRC-04 — Difficult Conversation Prep (Performance)**

```
Help me prepare for a difficult performance conversation with [EMPLOYEE NAME], [ROLE], on [DATE].

Situation:
- The issue: [DESCRIBE SPECIFICALLY — behavior, output, attendance, conduct]
- How long this has been a concern: [TIMEFRAME]
- Previous conversations or documentation: [DETAILS OR "THIS IS THE FIRST FORMAL CONVERSATION"]
- What outcome we need from this conversation: [e.g., awareness, a plan, a warning, a decision]
- HR context: [Is this a formal warning? Precursor to a PIP? Just a coaching conversation?]

Write:
1. Opening statement (how to begin without it feeling like an ambush)
2. How to present the specific issue with facts, not feelings
3. How to give the employee space to respond
4. What to say if they get defensive or emotional
5. How to close with clarity — next steps, accountability, timeline
6. Documentation notes to capture after the meeting
```

---

**HRC-05 — Performance Improvement Plan (PIP)**

```
Draft a Performance Improvement Plan for [EMPLOYEE NAME], [ROLE], in the [DEPARTMENT] department at [COMPANY].

Context:
- Manager: [MANAGER NAME]
- PIP start date: [DATE] | Review date: [DATE — typically 30–90 days]
- Areas of concern: [LIST SPECIFIC PERFORMANCE GAPS — be factual, not editorial]
- Prior feedback given: [DESCRIBE WHEN AND HOW]
- Expected outcomes (specific and measurable): [LIST]

PIP structure:
1. Statement of purpose (supportive, not punitive in tone)
2. Specific performance concerns (with examples and dates where possible)
3. Required improvements (SMART — specific, measurable, achievable, relevant, time-bound)
4. Support we will provide (training, check-ins, resources)
5. Check-in cadence during the PIP
6. Consequences if improvement is not achieved
7. Employee acknowledgment section

Important: This document may become a legal record. Be specific, factual, and free from personal opinion.
```

---

**HRC-06 — Harassment or Misconduct Investigation: Initial Response Email**

```
An employee has raised a concern about potential harassment or misconduct at [COMPANY]. Help me write the initial response to acknowledge the complaint and outline next steps.

Context:
- Complainant (do not use their name in documentation without consent): [USE "the reporting employee"]
- Nature of the concern (broad category, don't include specifics): [e.g., workplace harassment, discrimination, conduct concern]
- Who received the report: [HR/Manager/Ethics Hotline]

Write an acknowledgment email to the reporting employee that:
- Thanks them for coming forward
- Confirms we take this seriously and will investigate promptly
- Explains the investigation process at a high level (without promising outcomes)
- Confirms confidentiality to the extent possible (don't promise full confidentiality — it's not always possible)
- Names their point of contact during the process
- Reminds them of our non-retaliation policy

Tone: Serious, supportive, and professional. Do not minimize or over-promise.
```

---

**HRC-07 — Resignation Acceptance and Offboarding Initiation**

```
[EMPLOYEE NAME], [ROLE], in [DEPARTMENT] has resigned. Write communications to handle this professionally.

Details:
- Last day: [DATE]
- Reason given: [OPTIONAL — if relevant]
- Whether we want to counter (if yes, write a separate counter conversation — mark this as "no counter"): [YES/NO]
- Exit interview: [SCHEDULED / TO BE SCHEDULED]

Write:
1. Resignation acknowledgment email to the employee (warm, professional, sets offboarding logistics)
2. Internal announcement to their team (once the employee has been notified — how to share the news with the team)
3. Offboarding checklist outline (what HR needs to coordinate: equipment return, systems access, final pay, references policy)

Tone: Gracious. How we treat people on the way out is as important as how we treat them on the way in.
```

---

**HRC-08 — Return to Office Announcement**

```
Write a return-to-office (RTO) announcement for [COMPANY].

Policy details:
- What's being required: [e.g., 3 days/week in office, full-time return, pilot program]
- Effective date: [DATE]
- Which employees it affects: [ALL / SPECIFIC ROLES / SPECIFIC LOCATIONS]
- Exceptions or accommodations process: [HOW EMPLOYEES CAN REQUEST EXCEPTIONS]
- Why we're making this decision: [HONEST REASON — be specific, not vague]
- What we're doing to support the transition: [e.g., commuter benefits, flexible hours, catered lunch days]

Important: Many employees will be unhappy about this. Write the announcement in a way that:
- Leads with the reasoning (respect their intelligence)
- Acknowledges this is a change that affects people's lives
- Opens a genuine dialogue (don't just announce — invite questions)
- Does NOT use "collaborate better" as the only justification without specifics
```

---

**HRC-09 — Benefits Open Enrollment Announcement**

```
Write a company-wide benefits open enrollment announcement for [COMPANY].

Open enrollment details:
- Enrollment window: [START DATE] to [END DATE]
- What's changing from last year: [LIST CHANGES — don't make people dig for this]
- What's staying the same: [BRIEF SUMMARY]
- Key actions employees MUST take by [DEADLINE]: [LIST]
- Where to find info and enroll: [LINK / PLATFORM]
- Info sessions or webinars scheduled: [DETAILS OR N/A]
- Contact for questions: [NAME + EMAIL/PHONE]

Tone: Clear, organized, and human. Benefits enrollment is confusing — make it as easy as possible. Use headers and bullets, not paragraphs. Lead with what they need to DO, not with background context.
```

---

**HRC-10 — Termination Meeting Script (Involuntary)**

```
Help me prepare for an involuntary termination meeting with [EMPLOYEE NAME], [ROLE], on [DATE].

Context:
- Reason for termination: [PERFORMANCE / CONDUCT / LAYOFF / ROLE ELIMINATION]
- Has there been prior documentation/warning? [YES — describe / NO — explain why immediate]
- Severance offered: [DETAILS OR N/A]
- Benefits continuation: [COBRA/DETAILS]
- Final paycheck: [DETAILS]
- Equipment return: [PROCESS]
- Systems access: [WHEN DEACTIVATED]
- References policy: [WHAT WE WILL SAY]

Write:
1. Meeting script (should take 5–10 minutes — this is not a debate)
2. What to do if they become emotional, argue, or threaten legal action
3. What NOT to say (common mistakes that create legal exposure)
4. What HR should document immediately after

Note: This should be humane but clear. Do not give false hope. Do not over-explain. Say it once, clearly.
```

---

**HRC-11 — Sensitive Internal FAQ (Addressing Rumors or Uncertainty)**

```
Employees are circulating rumors or have concerns about [TOPIC — e.g., upcoming layoffs, acquisition, leadership changes, company finances]. Help me write an internal FAQ to address it directly.

What we know and can share: [LIST]
What we can't share yet and why: [LIST — be honest about constraints, not evasive]
The core concern employees have: [ARTICULATE THE REAL FEAR, even if uncomfortable]

Write an FAQ with 6–8 questions, including:
- The question everyone is afraid to ask (answer it directly)
- Timing/process questions
- "What does this mean for me?" questions
- What happens next

Tone: Honest and calm. If there is uncertainty, name it. Employees trust leaders who admit what they don't know far more than leaders who over-reassure. "We don't know yet, but here's what we do know" is a complete sentence.
```

---

**HRC-12 — Accommodations Request Response**

```
An employee, [EMPLOYEE NAME], has requested a workplace accommodation for [REASON — e.g., disability, medical condition, religious observance, pregnancy].

We are responding to acknowledge the request and begin the interactive process.

Write a response email that:
- Acknowledges the request warmly and without judgment
- Confirms we are committed to the interactive process under [ADA / applicable law]
- Outlines the next steps (documentation needed, meeting to discuss, timeline)
- Names their point of contact
- Confirms confidentiality of their medical/personal information
- Does NOT approve or deny the accommodation in this communication (premature)

Tone: Supportive, professional, and clear. This is a legal process but it should feel like a human conversation. The employee shared something personal — treat it that way.
```

---

---