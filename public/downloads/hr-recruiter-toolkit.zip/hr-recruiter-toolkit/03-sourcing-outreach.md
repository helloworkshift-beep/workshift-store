## Section 2: Sourcing & Outreach

*LinkedIn InMail, cold outreach, passive candidate messaging, and referral programs that actually convert.*

---

**SRC-01 — LinkedIn InMail (Cold Outreach, First Touch)**

```
Write a personalized LinkedIn InMail to a passive candidate for a [ROLE] role at [COMPANY].

Candidate details (from their profile):
- Current role/company: [DETAILS]
- Notable experience or skills: [DETAILS]
- Something specific about their background that caught my eye: [SPECIFIC DETAIL]

Role details:
- Why this role is interesting/different: [HOOK]
- Compensation range: [RANGE or "competitive"]
- Key selling points: [2–3 THINGS]

Rules:
- Under 100 words — passive candidates don't read walls of text
- Be specific about WHY them, not just that we're hiring
- Don't ask for a call immediately — ask if they're open to hearing more
- No subject lines like "Exciting Opportunity!" — be direct

Write 2 versions: one warmer/conversational, one more direct/professional.
```

---

**SRC-02 — LinkedIn InMail Follow-Up (No Response)**

```
Write a follow-up LinkedIn message for a passive candidate who didn't respond to my first outreach for a [ROLE] position at [COMPANY].

Context:
- Days since first message: [NUMBER]
- First message summary: [BRIEF RECAP]
- New hook or additional info to add: [e.g., salary range revealed, team update, etc.]

Rules:
- Don't guilt-trip or pressure them
- Add something new — don't just "bump" the conversation
- Give them an easy out (acknowledge they may not be looking)
- Under 75 words

Write 2 versions: one that leans into the role, one that opens a longer-term networking door.
```

---

**SRC-03 — LinkedIn InMail (Diversity Sourcing — Senior Underrepresented Candidates)**

```
Write a LinkedIn InMail for a senior [ROLE] candidate from an underrepresented background. I want this message to feel genuinely inclusive — not performative or tokenizing.

Context:
- Role: [ROLE] at [COMPANY]
- What we're genuinely doing on DEI: [SPECIFIC INITIATIVES — don't list vague platitudes]
- Why this specific person: [SPECIFIC REASON from their profile]

Rules:
- Do NOT mention their demographic identity explicitly — that's presumptuous
- DO lead with their expertise and specific contributions
- Mention our DEI work only if it's genuine and specific, and only once
- The goal is a real conversation, not a quota check
- Under 100 words
```

---

**SRC-04 — Employee Referral Program Launch Email**

```
Write an internal email to launch (or re-energize) our employee referral program for open roles.

Details:
- Current open roles to highlight: [LIST]
- Referral bonus: [$AMOUNT, when it's paid, conditions]
- How to submit a referral: [PROCESS]
- Deadline or urgency: [IF ANY]

Tone: Energetic but not desperate. Make employees feel like they're doing a friend a favor, not doing HR a favor. Be specific about what makes a great referral for each role — don't just say "anyone who'd be a great fit."

Include one paragraph about why referral hires tend to work out well (sets expectations and motivates quality referrals, not just volume).
```

---

**SRC-05 — Cold Email Outreach (Non-LinkedIn)**

```
Write a cold email to a passive candidate I found through [SOURCE — e.g., GitHub, a conference talk, a published article, a podcast] for a [ROLE] position at [COMPANY].

Candidate context:
- What they did that caught my attention: [SPECIFIC WORK OR ACHIEVEMENT]
- Why it's relevant to this role: [CONNECTION]

Email details:
- Subject line: Write 3 options — none should say "opportunity" or "exciting"
- Body: Under 120 words
- CTA: Low-friction (reply with a question, not "book a 30-min call")

Make it clear I actually looked at their work. Generic outreach gets deleted.
```

---

**SRC-06 — Sourcing Boolean Search String Generator**

```
Help me build Boolean search strings to find candidates for a [ROLE] position.

Role requirements:
- Core skills/tools: [LIST]
- Nice-to-have skills: [LIST]
- Industry background preferred: [INDUSTRY OR "OPEN"]
- Location or remote: [DETAILS]
- Seniority: [LEVEL]

Generate:
1. A LinkedIn search string using LinkedIn Boolean operators
2. A Google X-Ray search string for LinkedIn profiles (site:linkedin.com/in/)
3. A GitHub search string (if technical role)
4. A list of 10 alternative job titles I should also search for this role

Explain how to modify each string to broaden or narrow results.
```

---

**SRC-07 — University / Campus Recruiting Outreach**

```
Write an outreach message to a university career center (or a student directly) for a [INTERNSHIP / ENTRY-LEVEL ROLE] position at [COMPANY].

Details:
- Role: [ROLE]
- Target school(s): [SCHOOLS OR "any accredited university"]
- Program/major relevance: [RELEVANT PROGRAMS]
- Timeline: [START DATE, application deadline]
- What's unique about this opportunity for a student: [SPECIFIC LEARNING, MENTORSHIP, COMPENSATION]

For career center email: Professional, includes all logistics, easy to forward to students.
For direct student message (LinkedIn or email): Conversational, focuses on growth and learning, not corporate fluff.

Write both versions.
```

---

**SRC-08 — Recruiting Agency Brief**

```
Write a brief to send to a recruiting/staffing agency for a [ROLE] position we need help filling.

Include:
- Company overview: [COMPANY, INDUSTRY, SIZE, STAGE]
- Role title and level: [DETAILS]
- Must-have qualifications: [LIST]
- Nice-to-have: [LIST]
- Compensation range (what we'll share): [RANGE]
- Interview process overview: [STAGES]
- Timeline: [START DATE NEEDED]
- What we've already tried / where we've sourced: [CHANNELS USED]
- Cultural fit notes: [KEY TRAITS, TEAM DYNAMICS]
- Deal-breakers: [WHAT WOULD AUTO-DQ A CANDIDATE]

Be specific and direct. Agencies waste everyone's time when the brief is vague.
```

---

**SRC-09 — Talent Community/Pipeline Email (Stay in Touch)**

```
Write an email to send to a candidate we couldn't hire right now but want to keep in our talent pipeline for future roles.

Context:
- Candidate name: [NAME]
- Role they applied for: [ROLE]
- Why we're not moving forward now: [REASON — e.g., timing, no current headcount, overqualified for this level]
- When we might have relevant openings: [TIMEFRAME OR "unclear"]
- What we genuinely liked about them: [SPECIFIC QUALITIES]

Tone: Warm and honest. Don't string them along — make clear there's no current role. But make them feel like we mean it when we say we want to reconnect. Include a specific ask (e.g., follow our LinkedIn page, or "reply to this email if you're still looking in 3 months and I'll prioritize your file").
```

---

**SRC-10 — Conference / Event Networking Script**

```
I'm attending [EVENT/CONFERENCE NAME] and want to recruit candidates for [ROLE(S)] at [COMPANY]. Write me:

1. A 30-second verbal pitch about [COMPANY] and what we're building — something I can say naturally at a mixer
2. A follow-up message to send on LinkedIn the day after meeting someone interesting (reference the event)
3. A business card / QR code landing page blurb (2–3 sentences)

Role I'm primarily recruiting for: [ROLE]
Company stage: [e.g., Series A, bootstrapped, public]
What makes us interesting to candidates right now: [HOOK]

Make the verbal pitch sound human, not rehearsed.
```

---

**SRC-11 — Re-Engagement Email (Silver Medalist Candidates)**

```
Write an email to re-engage a "silver medalist" — a strong candidate we didn't hire last time who's worth reaching out to again.

Context:
- Candidate name: [NAME]
- Role they applied for previously: [ROLE] | Date: [WHEN]
- Why we didn't hire them then: [HONEST REASON — e.g., went with internal, hired someone more senior, role changed]
- New role we want to consider them for: [NEW ROLE]
- Why they'd be a good fit for this one: [SPECIFIC REASON]

Tone: Genuine and warm. Acknowledge the time that passed. Don't pretend nothing happened. Be direct about why you're reaching back out now and what's different about this opportunity. Under 150 words.
```

---

**SRC-12 — Sourcing Strategy for Hard-to-Fill Role**

```
I'm struggling to fill a [ROLE] position at [COMPANY]. Help me build a sourcing strategy.

Context:
- What we've tried: [LIST CHANNELS USED]
- Why it's hard to fill: [e.g., niche skill set, competitive market, low brand recognition, comp constraints]
- Compensation range: [RANGE]
- Location requirements: [IN-OFFICE / REMOTE / HYBRID]
- Timeline: [WHEN WE NEED SOMEONE]

Deliverables:
1. 5 sourcing channels we haven't tried that are worth testing for this specific role
2. How to adjust our messaging to stand out in a crowded market
3. A list of 10 communities, forums, or Slack groups where this type of candidate hangs out
4. A suggestion for whether we should adjust our requirements or comp to increase candidate pool
```

---

**SRC-13 — Internal Posting Announcement (Slack/Teams)**

```
Write a brief Slack or Teams message to announce a new internal job opening for [ROLE] on [TEAM/DEPARTMENT].

Keep it under 100 words. Include:
- What the role is and why it exists
- Key things that make it interesting
- How to apply or who to contact
- Application deadline

Tone: Casual and genuinely enthusiastic. This is an internal channel, not a job board. Make it feel like a colleague announcing something cool, not HR copying from a job posting.

Write both a plain-text version and a version with Slack formatting (bold, emoji where appropriate).
```

---

---