## Section 7: Performance & Retention

*Review frameworks, stay interview guides, engagement surveys, and the tools that keep good people from becoming someone else's hire.*

---

**PER-01 — Annual Performance Review Framework**

```
Build an annual performance review framework for [COMPANY].

Context:
- Company size: [SIZE]
- Review cycle: [e.g., calendar year, fiscal year, hire anniversary]
- Who reviews whom: [e.g., manager-only, 360, peer + manager]
- Compensation tied to review: [YES/NO — if yes, describe connection]
- Current pain points with our review process: [DESCRIBE IF KNOWN]

Deliverable:
1. Review form structure (sections, questions, rating scale with anchors)
2. Manager guide (how to prepare, how to write fair assessments, how to deliver feedback)
3. Employee self-assessment template (5–7 reflective prompts)
4. Calibration process outline (if applicable)
5. Common rating biases to brief managers on (recency bias, halo effect, etc.)
6. Timeline template (when to complete each step)
```

---

**PER-02 — Performance Review: Written Assessment (Manager)**

```
Help me write a performance review assessment for [EMPLOYEE NAME], [ROLE], for the [REVIEW PERIOD] review cycle.

My notes and observations:
- What they did well this year: [LIST SPECIFIC ACCOMPLISHMENTS]
- Areas for growth: [LIST SPECIFIC GAPS OR DEVELOPMENT AREAS]
- Key projects/contributions: [LIST]
- How they showed up on the team: [COLLABORATION, CULTURE CONTRIBUTION]
- Overall performance: [EXCEEDS / MEETS / BELOW EXPECTATIONS]

Write the assessment in clear, professional narrative form. Be specific — cite actual work, behaviors, and outcomes. Avoid vague language like "strong performer" without evidence. Include:
- A brief summary paragraph
- Strengths section (2–3 paragraphs)
- Growth areas section (honest but developmental in tone)
- Looking ahead (what you want to see in the next review period)
```

---

**PER-03 — Employee Self-Assessment Template**

```
Write a self-assessment template for employees to complete before their performance review at [COMPANY].

The self-assessment should:
- Prompt reflection, not just list accomplishments
- Surface things the manager might not know
- Give employees ownership of the narrative
- Be honest about challenges, not just wins

Include 7–10 prompts such as:
- What am I most proud of this year, and why does it matter?
- Where did I fall short of my own standards, and what did I learn?
- What do I want more of in my work next year?
- Where do I need more support from my manager?
- What would a stretch version of my career look like in 2–3 years?

Write instructions at the top explaining how to use the template and how honest responses will be received.
```

---

**PER-04 — Stay Interview Guide**

```
Build a stay interview guide for managers to use with employees who are valuable and at risk of leaving.

Context:
- [COMPANY] has [HIGH TURNOVER / COMPETITIVE MARKET / RECENT DISRUPTION — choose what's relevant]
- Target audience for stay interviews: [e.g., all employees / high performers / employees at 1-year mark]
- Format: [30-minute 1:1 with manager]

Include:
- How to open the conversation so it doesn't feel like surveillance
- 10–12 stay interview questions that surface real retention drivers (not generic "what motivates you")
- How to probe for the real reasons someone might leave (often unstated)
- What to do with the information (creates accountability — a stay interview with no follow-up makes things worse)
- How to handle it if an employee says they ARE thinking of leaving
- Template for documenting themes and follow-up actions

Note: The point is to PREVENT departures. Be genuine. If you won't act on the feedback, don't ask.
```

---

**PER-05 — Promotion Justification / Calibration Document**

```
Help me write a promotion justification document for [EMPLOYEE NAME], [CURRENT ROLE], being considered for promotion to [TARGET ROLE/LEVEL] at [COMPANY].

Their accomplishments that support promotion:
- Scope of work expanded beyond current level: [EXAMPLES]
- Leadership or ownership demonstrated: [EXAMPLES]
- Impact delivered: [METRICS OR SPECIFIC OUTCOMES]
- Feedback from stakeholders/peers: [SUMMARY]
- How they compare to the target level expectations: [DETAILS]

Write a calibration document that:
1. States the promotion case clearly and early
2. Addresses each relevant criteria for the target level
3. Anticipates objections (if any) and responds to them
4. Recommends timing and compensation adjustment
5. Is written for a calibration committee or senior leadership, not just the manager's own notes
```

---

**PER-06 — Employee Engagement Survey**

```
Build an employee engagement survey for [COMPANY] to deploy [QUARTERLY / ANNUALLY / PULSE].

We want to measure: [LIST — e.g., overall engagement, manager effectiveness, role clarity, growth opportunities, psychological safety, intent to stay]

Requirements:
- [15–20 questions for annual / 5–8 for pulse]
- Mix of Likert scale (agreement, frequency) and 1–2 open-ended questions
- Benchmarkable categories (so we can track trends over time)
- Anonymity clearly stated

Include:
- Survey introduction (why we're asking, what we do with results, anonymity policy)
- Questions organized by category
- Instructions for scoring and analyzing results
- Suggested timeline for sharing results back to employees (critical — most companies fail here)
- Template email to share results, including what we're committing to improve
```

---

**PER-07 — Underperformance Coaching Conversation (Pre-PIP)**

```
Help me prepare for an early coaching conversation with [EMPLOYEE NAME], [ROLE], whose performance is declining before it reaches PIP territory.

Situation:
- What I'm observing: [SPECIFIC BEHAVIORS OR RESULTS — factual]
- When I first noticed this: [TIMEFRAME]
- Whether I've said anything yet: [YES / NO]
- What I think might be going on (if known): [e.g., personal issues, disengagement, wrong role, lack of clarity]

This is a coaching conversation, NOT a warning. Write a guide for:
1. How to open (curious, not accusatory)
2. Questions to understand what's going on from their perspective
3. How to share what I'm observing without triggering defensiveness
4. How to collaboratively identify what support or change is needed
5. How to set clear expectations for what improvement looks like and by when
6. When to escalate to a formal PIP (what would trigger that next step)
```

---

**PER-08 — 360-Degree Feedback Request Email**

```
Write an email requesting 360-degree feedback for [EMPLOYEE NAME], [ROLE], as part of their [PERFORMANCE REVIEW / DEVELOPMENT CONVERSATION].

The email will go to [NUMBER] reviewers: peers, stakeholders, and/or direct reports.

Include:
- What 360 feedback is and why it matters
- How the feedback will be used (and won't be used — important for trust)
- Anonymity assurance (or honest explanation if feedback is attributed)
- Link or instructions to complete the feedback form: [LINK OR "TO BE ADDED"]
- Specific guidance on what good feedback looks like (specific examples > vague impressions)
- Deadline: [DATE]
- Who to contact with questions: [CONTACT]

Tone: Clear and appreciative. Reviewers are doing us a favor — make it easy and meaningful.
```

---

**PER-09 — Manager Effectiveness Survey**

```
Write a manager effectiveness survey for employees to evaluate their direct manager at [COMPANY].

Managers being evaluated: [ALL / SPECIFIC COHORT]
Survey framing: Developmental (results shared with manager + their manager) vs. Accountability (informs performance review) — choose one and frame accordingly: [CHOOSE]

Include 10–15 questions across:
- Communication and clarity
- Feedback and coaching
- Trust and psychological safety
- Career development support
- Workload and resource management
- Recognition

Also include 2 open-ended questions:
1. What is this manager's greatest strength?
2. What one thing could they change to be more effective?

Write the intro that explains how results are used and who sees them. If managers will see their results, say that upfront — it builds trust.
```

---

**PER-10 — Promotion Conversation Script (Delivering the Good News)**

```
Write a script for delivering a promotion to [EMPLOYEE NAME] during a 1:1 meeting.

Details:
- New title: [TITLE]
- New compensation: [$AMOUNT — salary + any equity/bonus changes]
- Effective date: [DATE]
- What changed in their scope/responsibilities: [DESCRIPTION]
- Why they earned this: [SPECIFIC EVIDENCE — the moment you knew]
- Written offer/letter to follow: [YES/NO + TIMING]

Structure:
1. The opening (don't drag it out — tell them early in the meeting, not at the end)
2. The "why" — be specific about what they did that earned this
3. Walk through the new comp and title
4. Discuss what changes (responsibilities, expectations)
5. Invite their reaction and questions
6. Close with excitement about what's next

Tone: Celebratory and specific. A generic "you've done great work" promotion feels hollow. Make them feel seen.
```

---

**PER-11 — High Performer Recognition Program Design**

```
Help me design a simple high performer recognition program for [COMPANY].

Context:
- Company size: [SIZE]
- Current recognition practices: [DESCRIBE OR "AD HOC / NONE"]
- Budget available: [$RANGE OR "MINIMAL CASH — FOCUS ON NON-MONETARY"]
- What we want to achieve: [e.g., reduce regrettable turnover, boost morale, create a culture of feedback]

Design:
1. Nomination process (who nominates, how often, criteria)
2. Selection process (avoid it becoming a popularity contest)
3. Recognition formats (public, private, monetary, experiential — match to what employees actually want)
4. How to announce and celebrate (without embarrassing introverts)
5. How to ensure equity in who gets recognized (bias audit)
6. Metrics to track whether it's working
```

---

**PER-12 — Career Development Conversation Guide**

```
Create a guide for managers having career development conversations with their direct reports.

Context:
- Company stage: [STARTUP / GROWTH / ENTERPRISE]
- Available career paths: [DESCRIBE — or "limited vertical options, focus on lateral growth"]
- How often these conversations should happen: [RECOMMEND CADENCE]

Include:
- Questions to open the conversation and understand long-term goals
- How to distinguish "this person wants to grow in this company" vs. "this person wants to grow, period"
- How to be honest about what opportunities exist (and don't) without discouraging them
- How to create a development plan: skills to build, experiences to seek, connections to make
- What to do when someone's career goals aren't achievable at this company
- How to avoid the trap of "development conversations" that produce no action

Also write a template for documenting and following up on the conversation.
```

---

**PER-13 — Exit Interview Guide**

```
Create an exit interview guide for [COMPANY] to use with departing employees.

Goals:
- Understand why people leave (real reasons, not diplomatic ones)
- Identify patterns that HR can act on
- Leave departing employees with a positive final impression

Format: 30-minute conversation (in-person or video call preferred over survey alone)

Include:
- Who should conduct exit interviews (NOT direct manager — HR or neutral party)
- 10–12 questions covering: reason for leaving, what we could have done differently, what they valued, what they'd change, would they return or refer others
- How to ask "what's the real reason you're leaving?" after the first diplomatic answer
- How to handle when they cite the manager (common and uncomfortable)
- Documentation template to capture themes over time
- How to report aggregate findings to leadership without identifying individuals
- What to do with the data (most companies collect it and do nothing — that's a culture problem)
```

---

---

## Bonus Prompts: Quick Hits

*High-utility single-use prompts for common HR tasks.*

---

**BONUS-01 — Job Offer Comparison Matrix (For Candidates)**

```
I want to give our offer to [CANDIDATE NAME] more context when they're comparing us to competing offers. Help me write a brief "why us" comparison guide I can share.

Our strengths vs. typical competitors: [LIST — be honest about weaknesses too]
What we know about their competing offer (if anything): [DETAILS OR "UNKNOWN"]
The factors candidates in this market tend to weigh: [e.g., comp, equity, flexibility, growth, stability, mission]

Write a 200-word document (not a sales pitch — a genuine guide) to help them make the best decision for them. Include one sentence acknowledging that if another offer is a better fit, they should take it. Authenticity matters more than winning.
```

---

**BONUS-02 — Hiring Manager Training: Interview Bias Briefing**

```
Write a short briefing document for hiring managers on the most common interview biases and how to mitigate them.

Cover:
1. Affinity bias ("they remind me of me")
2. Halo/horn effect
3. Confirmation bias
4. Recency bias
5. Attribution bias (judging mistakes differently based on who makes them)

For each bias:
- Define it in plain language
- Give a real interview example of it in action
- Provide a concrete technique to counter it

Close with: three rules for the debrief room that help the team surface bias before it influences the decision.

Format: One page max. This is a training doc — write it to be read quickly, not referenced in a meeting.
```

---

**BONUS-03 — HR Department Year-End Report**

```
Help me write an annual HR report to share with leadership and/or the board at [COMPANY].

Data and context I have:
- Headcount start of year: [NUMBER] | End of year: [NUMBER]
- Hires made: [NUMBER] | Separations: [NUMBER] (voluntary/involuntary breakdown: [DETAILS])
- Time to fill (average): [DAYS]
- Offer acceptance rate: [%]
- Retention rate: [%]
- Engagement score (if surveyed): [SCORE / CHANGE FROM PRIOR YEAR]
- Key HR initiatives launched this year: [LIST]
- What didn't work: [HONEST ASSESSMENT]
- Priorities for next year: [LIST]

Write a 1–2 page narrative report that:
- Leads with what mattered (don't bury the lede in headcount tables)
- Connects HR data to business outcomes
- Is honest about what we got wrong and what we're doing about it
- Ends with clear priorities and resource requests for next year
```

---

---

*End of HR & Recruiter's AI Prompt Toolkit — 90 prompts across 7 sections + 3 bonus prompts*

---

**Version:** 1.0
**Built for:** Workshift (workshift.store)
**License:** Single-user, non-transferable. Do not redistribute.