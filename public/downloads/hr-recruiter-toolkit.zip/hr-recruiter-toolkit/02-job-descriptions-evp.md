## Section 1: Job Descriptions & Employer Value Proposition

*Compelling JDs, employer brand copy, and value propositions that attract the right candidates — and repel the wrong ones.*

---

**JD-01 — Full Job Description (Standard)**

```
Act as a senior HR copywriter with 10 years of experience writing job descriptions that attract high-quality applicants. Write a compelling job description for a [ROLE] position at [COMPANY], a [COMPANY SIZE] [INDUSTRY] company. 

Include:
- A 2–3 sentence company intro that leads with mission, not history
- Day-in-the-life opening paragraph (not a bullet-point dump)
- Core responsibilities: [LIST 4–6 RESPONSIBILITIES]
- Must-have qualifications: [LIST]
- Nice-to-have qualifications: [LIST]
- What we offer (compensation, benefits, flexibility): [LIST]
- A closing paragraph that tells candidates exactly what the hiring process looks like

Tone: [TONE — e.g., startup-casual, corporate-professional, mission-driven nonprofit]
Avoid: jargon, "ninja/rockstar/guru" language, and phrases like "fast-paced environment"
```

---

**JD-02 — Job Description Rewrite (Existing JD)**

```
I have an existing job description that feels stale and isn't attracting the right candidates. Rewrite it to be more compelling, human, and specific — without losing the core requirements.

Here is the original job description:
[PASTE EXISTING JD]

Goals for the rewrite:
- Lead with why this role matters, not just what it does
- Replace vague phrases with concrete expectations
- Make the requirements section honest (separate must-haves from nice-to-haves)
- Add a brief "what success looks like in 90 days" section
- Keep it under [TARGET LENGTH — e.g., 500 words / 700 words]

Tone: [DESIRED TONE]
```

---

**JD-03 — Employer Value Proposition (EVP) Statement**

```
Act as an employer branding consultant. Write a clear, authentic Employer Value Proposition (EVP) statement for [COMPANY], a [COMPANY SIZE] [INDUSTRY] company.

Context about our company:
- Culture: [DESCRIBE — e.g., remote-first, collaborative, high-autonomy]
- What we're proud of: [LIST 3–5 THINGS]
- What makes us different from competitors: [DESCRIBE]
- Current team size and growth trajectory: [DETAILS]
- Compensation philosophy: [DETAILS]

Deliverables:
1. A 1–2 sentence master EVP tagline
2. A 150-word EVP narrative for careers page use
3. Three supporting proof points (specific, not fluffy)

Avoid generic phrases like "we're like a family" or "unlimited growth potential."
```

---

**JD-04 — Careers Page "About Us" Copy**

```
Write a careers page "About Us" section for [COMPANY]. This should make a prospective candidate feel excited about what we do and who we are — not like they're reading a Wikipedia entry.

Company details:
- What we do: [DESCRIPTION]
- Founded: [YEAR] | Size: [HEADCOUNT] | Stage: [e.g., Series B / bootstrapped / public]
- Mission: [MISSION STATEMENT IF YOU HAVE ONE]
- Culture highlights: [3–5 SPECIFIC THINGS]
- Recent wins or milestones: [OPTIONAL]

Length: 150–200 words
Tone: [TONE]
End with a line that invites them to explore open roles.
```

---

**JD-05 — Remote/Hybrid Work Policy Blurb for JDs**

```
Write a clear, honest 3–4 sentence blurb about our remote/hybrid work policy to include in job descriptions. Candidates care about this — don't be vague.

Our actual policy:
- Work arrangement: [FULLY REMOTE / HYBRID / IN-OFFICE]
- If hybrid: required in-office days per week: [NUMBER] | Office location: [CITY]
- Time zone requirements: [e.g., must overlap with EST core hours 10am–3pm]
- Equipment: [e.g., we ship a MacBook / bring your own / stipend provided]
- Home office stipend: [AMOUNT or N/A]

Make it feel like a benefit, not a footnote.
```

---

**JD-06 — Compensation Transparency Statement**

```
Write a compensation transparency blurb for our job postings. We want to be honest about pay without locking ourselves in unnecessarily. 

Our pay details:
- Role: [ROLE]
- Salary range: [RANGE — e.g., $85,000–$105,000]
- How we determine where someone lands in the range: [CRITERIA — e.g., experience level, location, skills]
- Equity offered: [YES/NO — if yes, describe briefly]
- Bonus: [YES/NO + details]
- Pay review cadence: [e.g., annual reviews in January]

Write 3–5 sentences that are honest, warm, and remove salary anxiety for candidates. Include a line explaining that we don't negotiate based on prior salary — we pay based on role scope and skills.
```

---

**JD-07 — Diversity, Equity & Inclusion (DEI) Statement for JDs**

```
Write a genuine, specific DEI statement for our job postings that goes beyond boilerplate equal opportunity language.

About our DEI efforts:
- Current initiatives or programs: [LIST OR "EARLY STAGE"]
- ERGs or affinity groups: [LIST OR N/A]
- Specific commitments we've made: [LIST — e.g., blind resume review, diverse interview panels]
- Accommodations process: [HOW CANDIDATES CAN REQUEST]

Write a 75–100 word statement that sounds like a real company that cares, not a legal checkbox. End with a clear invitation for candidates who need accommodations to reach out, and explain how to do so.
```

---

**JD-08 — Senior/Executive-Level Job Description**

```
Write a job description for a senior executive role: [EXACT TITLE] at [COMPANY].

This is a [C-LEVEL / VP / DIRECTOR] position. The tone should reflect the seniority of the hire — sophisticated, focused on impact and leadership, not task lists.

Role context:
- Reports to: [TITLE]
- Team size they'll lead: [NUMBER]
- Key mandate / why this role exists now: [CONTEXT]
- Top 3 outcomes we need them to deliver in year 1: [LIST]
- Ideal background: [DESCRIBE]
- Compensation range: [RANGE]

Format: No bullet-point dump. Use short paragraphs. Open with the business challenge this leader will solve. Close with why this is an exceptional opportunity right now.
```

---

**JD-09 — Entry-Level / Early Career Job Description**

```
Write a job description for an entry-level [ROLE] position at [COMPANY] that genuinely welcomes candidates who are early in their careers — without condescending to them.

Key details:
- What they'll actually be doing day-to-day: [DESCRIBE]
- What they'll learn and grow into: [DESCRIBE]
- Hard requirements (the real non-negotiables): [LIST — keep it short]
- Things we'll teach them: [LIST]
- Mentorship or development programs available: [DESCRIBE OR N/A]
- Starting salary range: [RANGE]

Avoid "2+ years of experience required" for entry-level roles. Frame requirements as skills or traits, not years. Make it clear this is a role where someone can actually build their career.
```

---

**JD-10 — Contract / Freelance Role Posting**

```
Write a project posting for a contract/freelance [ROLE] engagement at [COMPANY].

Project details:
- Scope of work: [DESCRIBE]
- Timeline: [START DATE] to [END DATE or ESTIMATED DURATION]
- Time commitment: [HOURS PER WEEK]
- Rate range: [$/hr or project-based amount]
- Remote or on-site: [SPECIFY]
- Tools/tech required: [LIST]
- Deliverables: [LIST]
- Point of contact / who they'll work with: [TITLE]

Tone: Professional but direct. Contractors want the facts fast — skip the culture section and get to the work. Include a clear next step for interested candidates.
```

---

**JD-11 — Internal Job Posting (Internal Mobility)**

```
Write an internal job posting for a [ROLE] position on the [TEAM/DEPARTMENT] team. This will be shared internally to encourage employees to apply before we go external.

Context:
- Why this role is open: [REASON — e.g., growth, backfill, new function]
- What's different about applying internally vs externally: [ANY PERKS / PROCESS DIFFERENCES]
- Role description and requirements: [DETAILS]
- Who to contact or how to apply: [PROCESS]
- Application deadline: [DATE]

Tone: Warm and encouraging. We want people to feel like applying internally is valued and celebrated — not risky. Remind them that applying won't affect their current position.
```

---

**JD-12 — "Why Work Here" Social Media Post (LinkedIn/Careers)**

```
Write 3 different LinkedIn posts we can use to promote working at [COMPANY] and drive applications to our open [ROLE] role.

Version 1: Lead with culture — what it's actually like to work here
Version 2: Lead with impact — what the work means and who benefits from it
Version 3: Lead with the people — highlight the team, their backgrounds, or a recent win

Company context: [BRIEF DESCRIPTION]
Role being promoted: [ROLE + LINK OR APPLICATION INFO]
Tone: [TONE — e.g., founder-voice, talent team voice, casual]
Each post: 150–200 words, ends with a clear CTA.

Do not use hollow phrases like "we're looking for passionate people" without backing them up.
```

---

**JD-13 — Job Description Bias Audit**

```
Review this job description for language that may unintentionally deter qualified candidates — particularly women, candidates of color, neurodivergent candidates, or those without traditional backgrounds.

[PASTE JOB DESCRIPTION]

Check for:
1. Gendered language (e.g., "aggressive," "dominate," "nurturing")
2. Credential inflation (degree requirements where skills would suffice)
3. Years-of-experience requirements that may be arbitrary
4. Cultural fit language that could signal homogeneity
5. Unnecessarily long requirements lists that deter non-dominant-group applicants (who typically apply only when they meet 100% of criteria)
6. Jargon or insider language that disadvantages outsiders

Return: A flagged version with specific suggestions for each issue. Keep changes minimal — we're editing, not rewriting.
```

---

**JD-14 — Benefits Summary for Job Postings**

```
Write a compelling benefits summary section for our job postings. This should make candidates genuinely excited — not feel like we're reading from an HR policy document.

Our actual benefits:
- Health insurance: [DETAILS — e.g., medical/dental/vision, % company covers]
- PTO: [DAYS or UNLIMITED — be honest about actual culture]
- 401(k): [MATCH DETAILS]
- Parental leave: [WEEKS, any distinction primary/secondary caregiver]
- Learning & development: [BUDGET, programs]
- Wellness: [STIPEND, programs]
- Other perks: [LIST]

Write it in a conversational style. Lead with the things that actually differentiate us. If we have weaknesses (e.g., no equity, average PTO), don't hide them — just don't feature them. Candidates respect honesty.
```

---

---