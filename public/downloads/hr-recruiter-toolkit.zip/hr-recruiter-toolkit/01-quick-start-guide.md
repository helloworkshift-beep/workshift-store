# 01 — Quick Start Guide

**Read this first. It takes 5 minutes.**

---

## The One Rule for HR Prompts

**Context is everything — and so is judgment.**

AI can draft a PIP. It can write a rejection email. It can generate a layoff announcement. But you are responsible for what goes out. The more context you give, the better the output. The more carefully you review, the more human it sounds.

❌ Weak: "Write a rejection email"
✅ Strong: "Write a rejection email to [NAME] who interviewed for [ROLE]. They made it to the final round but we chose another candidate. They were strong — we may want to stay in touch. Keep it warm, specific, and not a template."

---

## How to Use These Prompts

### Step 1: Find your situation
Each section covers a specific part of the HR and recruiting workflow. Go to the section that matches what you need right now.

### Step 2: Copy the full prompt
Don't paraphrase — copy the whole block. The structure matters.

### Step 3: Fill in every bracket
Replace every `[BRACKETED PLACEHOLDER]` with real information. Each field improves the output.

### Step 4: Paste and review
Read the output carefully. Adjust for your company's tone, legal requirements, and the specific person involved.

### Step 5: For sensitive communications — always review twice
Rejections, PIPs, terminations, layoffs, and any communication involving a specific person's employment status should always be reviewed by a human before sending. AI gets the structure right. You get the stakes right.

---

## Special Guidance: High-Stakes Communications

Some prompts in this toolkit handle difficult situations — PIPs, terminations, layoff announcements, rescinding offers. Use these as starting points only:

- **Always consult your legal/HR leadership** before sending PIPs or termination notices
- **Personalize rejections** — generic rejection emails damage your employer brand
- **Layoff communications** should reflect your company's actual values and situation; never send AI-generated text verbatim
- **Performance conversations** are human moments first, documentation second

---

## Quick Wins to Start With

If you're new to this toolkit, start here:

1. **Rewrite your worst job description** — 02, Prompt 2 (JD Rewrite)
2. **Write one compelling LinkedIn InMail** — 03, Prompt 1
3. **Build a structured interview guide for your next open role** — 04, Prompt 4
4. **Revamp your standard rejection email** — 05, Prompt 6

These four alone will improve your candidate experience more than most things you could do this week.

---

*Now go build a team.*
