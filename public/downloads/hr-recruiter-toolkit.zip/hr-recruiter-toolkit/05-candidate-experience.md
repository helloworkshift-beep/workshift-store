## Section 4: Candidate Experience

*Status updates, rejection letters, offer communications, and all the emails that define how candidates feel about your company.*

---

**CX-01 — Application Acknowledgment Email**

```
Write an automated application acknowledgment email for candidates who apply to any role at [COMPANY].

Include:
- Confirmation we received their application for [ROLE]
- Honest timeline expectation (don't promise what you won't deliver): [REALISTIC TIMELINE — e.g., "We review applications within 2 weeks and will reach out if there's a match"]
- What the process looks like broadly (no more than 3 steps)
- A genuine reason to be excited about [COMPANY] — one sentence, specific
- Contact for accessibility or accommodation requests

Tone: Human. Not "Your application has been received. Ref #20234." Treat them like a person, not a ticket. Under 150 words.
```

---

**CX-02 — Status Update Email (Candidate in Process)**

```
Write a status update email for a candidate who is actively in our process and we haven't communicated with in [NUMBER] days.

Candidate: [NAME]
Role: [ROLE]
Current stage: [STAGE — e.g., waiting on references, internal alignment, final decision]
Honest status: [WHAT'S ACTUALLY HAPPENING — e.g., key decision-maker is traveling, we're still interviewing, waiting on headcount approval]
Estimated next update: [DATE OR TIMEFRAME]

Tone: Honest and warm. Don't be vague. Candidates hate "we're still in the process." Tell them something real. If there's a delay on our end, own it. Under 150 words.
```

---

**CX-03 — Rejection Email (Post-Application, Pre-Interview)**

```
Write a rejection email for a candidate who applied but we will not be moving forward with — they haven't interviewed yet.

Details:
- Candidate name: [NAME]
- Role applied for: [ROLE]
- Reason (internal only, don't share verbatim): [REASON — e.g., missing key qualification, role on hold, stronger applicants at this time]

Tone: Genuine and brief. Not "after careful consideration we regret to inform you." Just honest human language. Acknowledge their time. Don't give false hope but don't be cold. Optional: offer to keep them in mind for future roles if that's genuine — if not, don't say it.

Under 120 words. No hollow phrases.
```

---

**CX-04 — Rejection Email (Post-Interview — Phone Screen)**

```
Write a rejection email for a candidate after a phone screen we will not be moving forward with.

Details:
- Candidate name: [NAME]
- Role: [ROLE]
- What we appreciated about them: [1–2 GENUINE THINGS]
- Reason we're not moving forward (internal framing, write the message tactfully): [REASON]
- Whether to invite future applications: [YES/NO]

Tone: Personal, not templated. Reference something specific from the conversation if possible. Thank them for their time in a way that feels real. Under 150 words.
```

---

**CX-05 — Rejection Email (Post-Final Interview — Difficult)**

```
Write a rejection email for a finalist candidate — someone who made it to the final round and we genuinely liked, but we went with someone else.

This is the hard one. Do it right.

Details:
- Candidate name: [NAME]
- Role: [ROLE]
- What they did well: [SPECIFICS FROM INTERVIEWS]
- Why we chose someone else (frame carefully): [HONEST BUT TACTFUL REASON — e.g., more relevant industry experience, different seniority match, small but meaningful difference in approach]
- Whether to keep in touch or refer them to other opportunities: [YES — and say why / NO]

Tone: Human, specific, warm. Do NOT use "we went in a different direction." Say something real. Acknowledge the effort they invested. If you mean it, give them a concrete reason to stay in touch. This email will be remembered.
```

---

**CX-06 — Verbal Offer Script**

```
Write a verbal offer script for extending an offer to [CANDIDATE NAME] for the [ROLE] position at [COMPANY].

Offer details:
- Base salary: [$AMOUNT]
- Bonus: [DETAILS OR N/A]
- Equity: [DETAILS OR N/A]
- Start date: [DATE]
- Benefits summary: [HIGHLIGHTS]
- Offer letter to follow: [TIMING]
- Deadline to decide: [DATE]

Include:
1. Opening — express genuine excitement about them specifically
2. Walk through the offer components (don't just list numbers — contextualize them)
3. Invite questions
4. Set the timeline for written offer
5. What to do if they want to negotiate — acknowledge that it's okay and you'll work through it together

Tone: Celebratory but not pressuring. This should feel like great news delivered by someone who means it.
```

---

**CX-07 — Written Offer Letter**

```
Write a formal offer letter for [CANDIDATE NAME] for the [ROLE] position at [COMPANY].

Employment details:
- Start date: [DATE]
- Employment type: [FULL-TIME / PART-TIME / CONTRACT]
- Reporting to: [MANAGER TITLE]
- Base salary: [$AMOUNT] paid [BI-WEEKLY / SEMI-MONTHLY]
- Bonus target: [% or AMOUNT + CONDITIONS]
- Equity: [TYPE, AMOUNT, VESTING SCHEDULE]
- Benefits: [HEALTH, 401K, PTO, OTHER]
- Work arrangement: [ON-SITE / REMOTE / HYBRID + DETAILS]
- Contingencies: [BACKGROUND CHECK / I-9 / OTHER]
- Offer expiration date: [DATE]

Tone: Professional and warm. This is a legal document but it doesn't have to read like one. The first paragraph should feel welcoming, not bureaucratic. Include a signature block for both parties.
```

---

**CX-08 — Counter-Offer Response (They Came Back)**

```
[CANDIDATE NAME] has received a counter-offer from their current employer and is reconsidering our offer for [ROLE]. Help me craft a response.

Situation:
- Their counter: [WHAT THEY TOLD US — e.g., current employer matched salary, offered promotion]
- Our position: [WHAT WE CAN FLEX ON, IF ANYTHING]
- Why we think they should still choose us: [GENUINE REASONS]
- What they valued about our opportunity in interviews: [NOTES FROM CONVERSATIONS]

Write:
1. A response script for a phone call (5 minutes max — don't beg)
2. A follow-up email after the call
3. A graceful "we understand" message if they ultimately decline

Do not pressure them. Make our case clearly once. Let them decide.
```

---

**CX-09 — Offer Negotiation Response**

```
[CANDIDATE NAME] has asked to negotiate their offer for [ROLE]. Help me respond professionally.

Current offer: [DETAILS]
What they asked for: [SPECIFIC REQUEST — e.g., +$10k salary, more equity, extra week of PTO, signing bonus]
What we can do: [WHAT WE'RE ABLE TO FLEX ON, IF ANYTHING]
What we can't flex on and why: [HONEST CONSTRAINTS]

Write:
1. A response if we can meet their ask (fully or partially) — be specific about what we're doing
2. A response if we can't meet their ask — explain why without being defensive, and if possible offer an alternative (e.g., 6-month review, extra PTO instead of cash)
3. A closing statement for either scenario that reaffirms our excitement about them

Tone: Collaborative, not adversarial. Negotiation is healthy — respond like a partner, not a gatekeeper.
```

---

**CX-10 — Candidate Withdrawal / Declination Acknowledgment**

```
[CANDIDATE NAME] has withdrawn from our process or declined our offer for the [ROLE] position. Write a response.

Context:
- Stage they withdrew from: [STAGE]
- Reason they gave (if any): [REASON]
- Was this a top candidate we'd want to re-engage in the future? [YES/NO]

Write a brief, gracious response that:
- Thanks them sincerely without being over-the-top
- Acknowledges their reason (if appropriate)
- If they're someone we'd want to re-engage: opens a door for future conversations naturally
- Doesn't burn the bridge or make them feel guilty

Under 100 words. No "we wish you all the best in your future endeavors."
```

---

**CX-11 — Interview Experience Survey (Post-Interview)**

```
Write a brief candidate experience survey to send after an interview (regardless of outcome).

We want honest feedback on:
- How clear was our communication?
- Was the interview process respectful of their time?
- Did the role and company match what we described?
- Would they recommend applying to [COMPANY] to a friend?

Format:
- 5–7 questions max
- Mix of 1–5 scale and one open-ended question
- Anonymous option clearly stated
- Takes under 3 minutes to complete

Include a brief intro explaining why we're asking and what we do with the results. If we don't actually use this data to improve, don't send the survey.
```

---

**CX-12 — Reneging an Offer (We Have To Pull Back)**

```
We need to rescind a job offer for [CANDIDATE NAME] for the [ROLE] position. This is difficult and we need to handle it with integrity.

Reason for rescinding: [HONEST REASON — e.g., business conditions changed, headcount frozen, company acquisition, position eliminated]

Note: If this is due to something the candidate did (failed background check, dishonesty discovered), that's a different situation — clarify which scenario this is.

Write:
1. A script for the phone call (always call first — don't email this)
2. A follow-up written confirmation
3. Any goodwill gestures we should offer (e.g., severance equivalent, referrals, outplacement help)
4. What NOT to say — legal and reputational guardrails

Tone: Honest, accountable, and human. We caused real harm here. Own it.
```

---

---