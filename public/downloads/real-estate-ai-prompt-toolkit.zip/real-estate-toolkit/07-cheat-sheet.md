# 07 — Cheat Sheet
### Top 15 Power Prompts · Top 5 Free AI Tools · Golden Rules of Prompting

---

> Print this page. Pin it above your desk. Use it every day.

---

## TOP 15 POWER PROMPTS
### Quick-Reference Format — Copy, Fill Brackets, Paste

---

**1. MLS Description (Any Home)**
*Best for: Getting a solid MLS description in under 5 minutes*

```
Act as an expert real estate copywriter. Write a 300-word MLS description for a [NUMBER]-bed, [NUMBER]-bath, [SQ FT] sq ft home in [NEIGHBORHOOD]. Key features: [LIST 6-8 FEATURES]. Asking [$ PRICE]. Tone: warm and professional. No clichés. Lead with the best feature, end with a call to action.
```

---

**2. Luxury Listing Opener**
*Best for: High-end listings where the first sentence sets the tone*

```
Write an opening paragraph for a luxury real estate listing in [NEIGHBORHOOD]. The home features [TOP 3 LUXURY FEATURES]. Tone: sophisticated, aspirational — never salesy. Make it feel like a lifestyle, not a spec sheet. Under 80 words.
```

---

**3. 10 Listing Headlines**
*Best for: Zillow titles, email subject lines, social media hooks*

```
Generate 10 compelling headlines for a [PROPERTY TYPE] in [AREA]. Key selling points: [FEATURE 1], [FEATURE 2], [FEATURE 3]. Under 12 words each. Mix emotional, benefit-driven, and location-based angles. No clichés.
```

---

**4. Buyer First Contact Text**
*Best for: Responding to a new buyer lead within 5 minutes*

```
Write a first-contact text message to a buyer lead named [NAME] who inquired about [PROPERTY/AREA]. Warm, human, no pitch. Ask one question to start a real conversation. Under 160 characters.
```

---

**5. Seller First Contact Email**
*Best for: Responding to a seller inquiry — establish expertise fast*

```
Write a first-contact email (subject line + 120-word body) to [NAME] who inquired about selling their home at [ADDRESS or AREA]. Tone: confident, consultative — like a trusted advisor. Offer to share what their home is worth. One clear next step at the end.
```

---

**6. Follow-Up After Silence**
*Best for: Reviving a cold lead who stopped responding*

```
Write a short, non-pushy follow-up text to [NAME] who hasn't responded in [X DAYS]. Lead with a fresh hook (new info, market update, a relevant listing), not "just checking in." Under 100 words. End with an easy out.
```

---

**7. Offer Presentation Summary**
*Best for: Sending a written offer summary to a seller*

```
Write an offer presentation summary for my seller [NAME] on [ADDRESS]. Offer: [$PRICE], [FINANCING TYPE], [CONTINGENCIES], close [DATE]. My recommendation: [ACCEPT/COUNTER/DECLINE and WHY]. Tone: clear, advisory. 200 words. Include next steps.
```

---

**8. Just Sold Instagram Caption**
*Best for: Quick social proof post after closing*

```
Write an Instagram caption celebrating a just-sold home in [AREA]. Key result: [SALE RESULT — e.g., sold in 4 days, $X over asking, 6 offers]. Tell a mini-story (setup → challenge → result). 120 words. CTA for sellers to reach out. 15 hashtags in a separate block.
```

---

**9. Market Update Social Post**
*Best for: Positioning yourself as the local market expert*

```
Write an Instagram caption sharing this local market data for [CITY/NEIGHBORHOOD]: [STAT 1], [STAT 2], [STAT 3]. Translate numbers into plain language — what does this mean for buyers and sellers right now? 150 words. End with an offer to answer DMs. Hashtags: local + educational.
```

---

**10. Expired Listing First Contact**
*Best for: Standing out when reaching out to an expired listing*

```
Write a first-contact email to a homeowner whose listing just expired at [ADDRESS] after [X] days on market. Lead with empathy and a specific insight about why it may not have sold (overpricing / poor marketing / timing). Don't trash the prior agent. Offer something valuable. 150 words. One clear ask at the end.
```

---

**11. FSBO First Contact**
*Best for: Starting a relationship with a For Sale By Owner*

```
Write a first-contact message to a FSBO seller at [ADDRESS]. Don't pitch a listing. Offer one of these: [a buyer who might be interested / a free CMA / info on what buyers in their price range want]. Tone: helpful colleague, zero condescension. 120 words. Easy CTA.
```

---

**12. Agent Bio (Short)**
*Best for: Zillow, website bios, and marketing materials*

```
Write a 130-word agent bio for [YOUR NAME], [NUMBER] years in real estate, specializing in [NICHE/AREA], at [BROKERAGE]. Include one personal detail. Third person. Lead with market expertise. No buzzwords: no "passionate," "dedicated," or "hardworking." Sound like a trusted expert, not a resume.
```

---

**13. Monthly Newsletter**
*Best for: Your monthly email to past clients and sphere*

```
Write a monthly real estate email newsletter for [MONTH/YEAR]. Agent: [NAME], market: [CITY]. Market update: [KEY STAT]. Feature article: [TOPIC]. Local news: [ITEM]. End with CTA: [CALL/REFERRAL/VALUATION]. 3 subject line options. 450 words total. Tone: knowledgeable neighbor, not mass email.
```

---

**14. CMA Summary Narrative**
*Best for: Turning your CMA spreadsheet into a story sellers can follow*

```
Write a 350-word CMA summary narrative for [SELLER NAME] at [ADDRESS]. Active comps: [COMP 1 PRICE, COMP 2 PRICE, COMP 3 PRICE]. Sold comps: [COMP 1 SOLD, COMP 2 SOLD, COMP 3 SOLD]. My recommended price: [$X]. Why: [YOUR REASONING]. Tone: analytical, confident, advisory. Include what happens if priced too high. End with next steps.
```

---

**15. Price Reduction Announcement (Social)**
*Best for: Re-energizing a listing after a price reduction*

```
Write an Instagram caption announcing a price reduction on [PROPERTY DESCRIPTION]. Was: [$OLD PRICE]. Now: [$NEW PRICE] — a [$DIFFERENCE / %] reduction. Why now is the time: [2-3 REASONS OR FEATURES]. Tone: exciting, opportunity-focused. 110 words. CTA: DM or link in bio. Hashtags included.
```

---

## TOP 5 FREE AI TOOLS FOR REAL ESTATE AGENTS

---

### 🥇 ChatGPT (OpenAI)
**URL:** chat.openai.com
**Free tier:** GPT-3.5 unlimited, GPT-4o with daily limits
**Best for:** MLS descriptions, emails, social posts, scripts — the workhorse
**Real estate use:** Use this for 80% of your prompt-based tasks. GPT-4o produces notably better results than GPT-3.5.
**Pro tip:** Set a Custom Instruction (Settings → Personalization) with your market, niche, and tone so every output is pre-calibrated.

---

### 🥈 Claude (Anthropic)
**URL:** claude.ai
**Free tier:** Claude 3.5 Sonnet — generous daily usage
**Best for:** Long-form content — newsletters, seller presentations, detailed emails, agent bios
**Real estate use:** When you need something that sounds deeply human and well-written, Claude edges out ChatGPT. Great for anything a client reads closely.
**Pro tip:** Paste in a sample of your own past writing and say "write in this style" for more on-brand output.

---

### 🥉 Google Gemini
**URL:** gemini.google.com
**Free tier:** Fully free, Gemini 1.5 Flash
**Best for:** Quick social captions, fast rewrites, and research-backed content
**Real estate use:** Gemini pulls from current web data, making it useful for content that references market trends without you having to look up all the stats.
**Pro tip:** Use Gemini for brainstorming and speed; switch to ChatGPT or Claude for final polish.

---

### Perplexity AI
**URL:** perplexity.ai
**Free tier:** Generous — cited search + AI reasoning
**Best for:** Neighborhood research, school ratings, commute data, local market context
**Real estate use:** Ask "What are the pros and cons of living in [NEIGHBORHOOD] in [CITY] in 2025?" before writing your neighborhood description. Paste the results into your listing prompt.
**Pro tip:** Perplexity gives you cited sources — great for market stats you can actually reference.

---

### Canva AI (Magic Write)
**URL:** canva.com
**Free tier:** Free Canva account includes Magic Write (limited uses)
**Best for:** Writing short copy directly inside your social media graphics and templates
**Real estate use:** Design a listing flyer or social post template, then use Magic Write to generate the text without leaving Canva. Faster than copying between tools.
**Pro tip:** Use AI-generated captions from ChatGPT, then paste them into Canva for design — the best of both tools.

---

## THE GOLDEN RULES OF PROMPTING

### Rule 1: Specificity Beats Length
A prompt with 5 specific details outperforms a vague prompt every time. "3-bed home in Riverside Heights with a renovated kitchen and mountain views, priced at $575K" → far better output than "nice home."

### Rule 2: Give It Context
Tell the AI who you are, what this content is for, and who will read it. The more context, the more relevant the output. "This is for a luxury seller who has never sold before and is nervous about pricing" changes the tone dramatically.

### Rule 3: Tell It What NOT to Do
Negative instructions are powerful. "No clichés," "don't mention the address," "avoid exclamation points" — these constraints prevent generic output.

### Rule 4: Use Role Assignment
"Act as a luxury real estate copywriter with 15 years of experience" produces better copy than a prompt with no role. It activates a frame of reference for the AI.

### Rule 5: Ask for Variations
When you get good output, ask for 3 variations. When you get mediocre output, don't just retry — add a constraint or change one variable. "Same thing but shorter" or "same structure but more emotional" often unlocks what you needed.

### Rule 6: One Task Per Prompt
Don't ask for an MLS description AND a social caption AND a follow-up email in one prompt. Each task gets a fresh, focused prompt and a fresh chat window.

### Rule 7: Read Before You Send
This is non-negotiable. AI makes up details sometimes. It may say "close to the new Whole Foods" when there isn't one. Always read before you post, send, or input into MLS.

### Rule 8: Save Your Best Prompts
When a prompt produces exceptional output, save the filled-in version. You'll want to use it again for similar properties or situations.

### Rule 9: Edit Like a Human, Not a Robot
The AI gives you a draft. Your job is to add the 20% that makes it yours — a specific detail, a local reference, your voice, a sentence that only you could write. The draft is free. The final polish is what makes it effective.

### Rule 10: Build a Swipe File
Every time AI produces a great headline, a killer opening line, or a subject line with a high open rate — save it. Over time, you'll build a library of proven formulas you can adapt without needing to run a prompt at all.

---

## QUICK REFERENCE: WHICH FILE FOR WHAT

| Task | File |
|------|------|
| MLS descriptions | `02-listing-prompts.md` |
| Listing headlines | `02-listing-prompts.md` |
| New listing social post | `04-marketing-prompts.md` |
| Open house announcement | `02-listing-prompts.md` |
| First contact to a lead | `03-client-communication-prompts.md` |
| Follow-up emails | `03-client-communication-prompts.md` |
| Offer presentation | `03-client-communication-prompts.md` |
| Closing day message | `03-client-communication-prompts.md` |
| Review request | `03-client-communication-prompts.md` or `05-business-operations-prompts.md` |
| Instagram captions | `04-marketing-prompts.md` |
| Agent bio | `04-marketing-prompts.md` |
| Monthly newsletter | `04-marketing-prompts.md` |
| Video scripts | `04-marketing-prompts.md` |
| CMA narrative | `05-business-operations-prompts.md` |
| FSBO outreach | `05-business-operations-prompts.md` |
| Expired listing outreach | `05-business-operations-prompts.md` |
| Cold call scripts | `05-business-operations-prompts.md` |
| Zillow bio | `05-business-operations-prompts.md` |
| Recruiting message | `05-business-operations-prompts.md` |
| Full listing workflow | `06-workflow-sops.md` (Workflow 1) |
| Lead nurture sequence | `06-workflow-sops.md` (Workflow 2) |
| Monthly content batching | `06-workflow-sops.md` (Workflow 3) |
| Open house follow-up | `06-workflow-sops.md` (Workflow 4) |
| Listing appointment prep | `06-workflow-sops.md` (Workflow 5) |

---

*That's the whole toolkit. Now go use it.*
