# 03 — Client Communication Prompts
### 20 AI Prompts for Every Stage of the Client Relationship

---

> These prompts cover the full client lifecycle — from first contact to referral request. Every message you'll ever need to write, done in minutes.

---

## FIRST CONTACT

---

**Buyer First Contact — Inbound Lead**
*When to use: A buyer just registered on Zillow, your website, or inquired on a listing — your first response.*

```
Act as a friendly, professional real estate agent writing a first-contact email/text to a new buyer lead. The goal is to start a real conversation — not pitch, not overwhelm, not sound like a robot.

Lead details:
- Lead's name: [NAME]
- How they came in: [e.g., Zillow inquiry on 123 Main St, website registration, Facebook ad]
- What they inquired about or their stated interest: [e.g., 3-bedroom homes under $450K, specific property, "just browsing"]
- Your name: [YOUR NAME]
- Your market area: [CITY/AREA]

Requirements:
- Length: 80-120 words
- Tone: warm, human, curious — like a neighbor reaching out, not a salesperson
- Ask one specific question to start a conversation (don't ask 5 questions at once)
- Do not include your license number, lengthy bios, or market reports in this first message
- Do not use "I would love to help you!" or similar hollow phrases
- End with a soft, low-pressure call to action
- Write both an email version (with subject line) and a text version (under 160 characters)
```

---

**Seller First Contact — Inbound Lead**
*When to use: A homeowner reached out about selling — your first response to establish expertise and set up a conversation.*

```
Act as a top-producing listing agent writing a first response to a seller inquiry. This person is thinking about selling and reached out for information. Your goal is to seem knowledgeable and low-pressure, and to book a call or consultation.

Lead details:
- Seller's name: [NAME]
- How they came in: [e.g., Zillow "What's My Home Worth" request, referral from [PERSON], website contact form]
- What they said or indicated: [e.g., "thinking about selling in the spring," "just curious about value," "need to sell ASAP"]
- Their address (if provided): [ADDRESS or "they haven't shared yet"]
- Your name: [YOUR NAME]
- Your specialization: [e.g., your neighborhood specialist, listing agent for [AREA]]

Requirements:
- Length: 120-160 words
- Tone: confident, knowledgeable, consultative — not "I'll get you top dollar!" hype
- Position yourself as a market expert, not a salesperson
- Offer something of value (market data, a quick call to share what their home is worth)
- End with one clear next step — book a call, reply with a good time, visit a specific link
- Write both email (with subject line) and text versions
```

---

**Cold Outreach — Sphere of Influence (Past Contact)**
*When to use: Reaching out to someone in your sphere who you haven't spoken to in 6+ months — restarting the relationship without being weird about it.*

```
Write a short, natural message to a past contact in my sphere of influence. This person knows me but we haven't talked in a while. I want to re-engage without making it obviously transactional or real estate pushy.

Contact details:
- Name: [NAME]
- How I know them: [e.g., former coworker, neighbor from 3 years ago, met at a chamber event last year]
- Last time we spoke (approximately): [TIMEFRAME]
- Anything personal I remember: [e.g., they have two kids, they mentioned wanting to move someday, they just got promoted] (or leave blank)
- My name: [YOUR NAME]

Requirements:
- Length: 60-90 words
- Tone: genuine, casual, friendly — like a human text, not a CRM drip
- Do NOT mention real estate in the first message (unless they brought it up before)
- Reference something personal or shared if possible
- End with a low-pressure opener to reconnect (coffee, catching up, etc.)
- Text message format only
```

---

**First Meeting Confirmation & Prep Email**
*When to use: After booking a buyer or seller consultation — confirming the meeting and setting expectations.*

```
Write a pre-meeting confirmation email for an upcoming buyer or seller consultation. This should confirm the logistics, set the agenda, and build excitement without overwhelming them with info.

Meeting details:
- Client name: [NAME]
- Meeting type: [BUYER CONSULTATION / SELLER CONSULTATION / LISTING APPOINTMENT]
- Date and time: [DATE AND TIME]
- Location: [ADDRESS or "via Zoom — link below"]
- Zoom link (if virtual): [LINK or N/A]
- What we'll cover: [e.g., home search process, financing overview, what to expect / OR: market analysis, pricing strategy, marketing plan]
- Anything to bring or prepare: [e.g., mortgage pre-approval if they have one, list of must-haves, photos of the home]
- Your name: [YOUR NAME]

Requirements:
- Length: 150-200 words
- Tone: professional but warm, like a trusted advisor
- Confirm the details clearly at the top
- Briefly describe the agenda so they know what to expect
- Include one sentence that builds confidence in the meeting ("By the end of our call, you'll have a clear picture of...")
- Close warmly, leave the door open for questions before the meeting
```

---

## FOLLOW-UP MESSAGES

---

**Follow-Up After No Response — Buyer Lead (3-Day)**
*When to use: You contacted a buyer lead 3 days ago and haven't heard back.*

```
Write a short, non-pushy follow-up to a buyer lead who hasn't responded to my first message.

Details:
- Lead's name: [NAME]
- What I originally reached out about: [e.g., their Zillow inquiry on 456 Elm St, their website registration for homes in [AREA]]
- When I first reached out: [3 DAYS AGO or specific date]
- Any new info to share: [e.g., a similar home just came on the market, rates dropped slightly this week] (or leave blank)
- My name: [YOUR NAME]

Requirements:
- Length: 50-80 words
- Tone: breezy, low-pressure, zero guilt-tripping
- Do NOT say "just following up" — find a fresher hook
- Give them an easy out (acknowledge they may be busy or not ready)
- Offer something of value if possible, not just "did you see my last message?"
- Text version preferred
```

---

**Follow-Up After No Response — Cold Lead (2-Week)**
*When to use: A lead who went cold after initial contact — this is your "hail mary" before removing them from active follow-up.*

```
Write a "last attempt" follow-up to a lead who has gone completely silent for 2 weeks. This message should be direct, honest, and give them a clear exit if they're not interested — while leaving the door open if they ever are.

Details:
- Lead's name: [NAME]
- What they originally inquired about: [CONTEXT]
- How many times I've reached out (approximately): [NUMBER]
- My name: [YOUR NAME]

Requirements:
- Length: 60-100 words
- Tone: honest, confident, zero desperation
- Use the "permission to close your file?" approach — give them an explicit out
- If they want out, make it 100% comfortable to say so
- If they're still interested, this message should make it easy to re-engage
- Don't say "I don't want to bother you" — it sounds weak
- Text version
```

---

**After-Showing Follow-Up**
*When to use: After showing a buyer one or more homes — checking in and moving the conversation forward.*

```
Write a follow-up message to a buyer client after a property showing or series of showings.

Details:
- Buyer's name: [NAME]
- Properties shown: [ADDRESS(ES) or general description — e.g., "the three homes in Riverside"]
- Their apparent reaction: [e.g., loved the kitchen on Elm St, seemed unsure about the lot size on Oak Ave, really liked the second one]
- Next step we discussed (if any): [e.g., sleep on it, I'll send comps, they want to see more]
- My name: [YOUR NAME]

Requirements:
- Length: 100-140 words
- Tone: supportive, observant, not pushy
- Reference what they responded to emotionally (the thing they lit up about)
- Ask a specific question to advance the process (not "what did you think?")
- Suggest a clear next step
- Email with subject line + text version
```

---

## OFFER SITUATIONS

---

**Offer Presentation to Seller**
*When to use: Presenting a buyer's offer to your seller client — in writing, as a follow-up to a call.*

```
Act as a listing agent writing to your seller client to present an offer. This is a follow-up to a phone call where you briefly covered it, now putting it in writing clearly.

Offer details:
- Seller's name: [NAME]
- Property address: [ADDRESS]
- Offer price: [$AMOUNT]
- Asking price: [$ASKING PRICE]
- Earnest money: [$AMOUNT]
- Down payment: [% or $AMOUNT]
- Financing type: [e.g., conventional, cash, FHA, VA]
- Contingencies: [e.g., inspection, financing, appraisal — list all]
- Proposed closing date: [DATE]
- Possession: [DATE or "at closing"]
- Any special terms or requests: [e.g., seller to leave appliances, buyer requesting $5K in concessions]
- Your recommendation: [e.g., solid offer, recommend accepting / recommend countering at $X / multiple offers coming — advise holding]

Requirements:
- Length: 200-280 words
- Tone: professional, clear, advisory — you are their trusted advisor
- Lay out the key terms clearly without legal jargon
- Share your professional recommendation clearly
- Mention next steps (deadline to respond, how to counter if desired)
```

---

**Multiple Offer Situation — Seller Notification**
*When to use: When you receive multiple offers on a listing and need to formally notify your seller and explain the process.*

```
Write a message to my seller client explaining that we have received multiple offers and outlining how we will handle the process.

Situation details:
- Seller's name: [NAME]
- Property address: [ADDRESS]
- Number of offers received: [NUMBER]
- Offer deadline (if setting one): [DATE AND TIME or "we are reviewing as they come in"]
- How we will handle it: [e.g., setting a best-and-final deadline for all buyers / reviewing and responding to each / highest and best by [DATE]]
- Any notable details: [e.g., one cash offer, two conventional, one waiving inspection]

Requirements:
- Length: 180-240 words
- Tone: excited but controlled, professional
- Congratulate them genuinely (this is great news)
- Clearly explain the process we'll use and why
- Set expectations for timing
- Remind them that price isn't the only factor (terms, financing type, contingencies matter)
- End with clear next steps
```

---

**Offer Rejection / Counter Notification to Buyer's Agent**
*When to use: Notifying the buyer's agent that their offer was not accepted or is being countered.*

```
Write a professional email to a buyer's agent notifying them that their buyer's offer on my listing has been [rejected / countered].

Details:
- Property address: [ADDRESS]
- Buyer's agent name: [NAME]
- Their offer price: [$AMOUNT]
- Outcome: [REJECTED / COUNTERED AT $X with terms Y]
- Reason (if appropriate to share): [e.g., seller received a higher offer / seller countered for $X and [modified terms] / seller has decided to accept another offer]
- Any door left open: [e.g., they are backup position #2 / if the primary falls through we'll be in touch / the offer stood out but price was the deciding factor]

Requirements:
- Length: 100-150 words
- Tone: respectful, professional, empathetic — buyer's agents talk and your reputation matters
- Be clear but kind — this is disappointing news for them and their client
- If countering, be precise about the counter terms
- If rejecting, thank them for the offer and leave the door open for future business
```

---

**Buyer Offer Rejection — Coaching Email**
*When to use: Your buyer's offer was rejected — you need to deliver the news and keep them engaged.*

```
Write an email to my buyer client whose offer was just rejected. I need to deliver the bad news clearly while keeping them motivated and engaged in the search.

Details:
- Buyer's name: [NAME]
- Property they offered on: [ADDRESS or description]
- Their offer: [$AMOUNT]
- What happened: [e.g., seller accepted a higher offer / seller countered at $X / seller chose a cash offer with no contingencies]
- What I know about why: [e.g., we were $15K below the accepted offer / all cash won the day]
- What's next: [e.g., I have 2 new listings to show you this weekend / let's revisit your search criteria / I'll reach out to backup position]
- Your name: [YOUR NAME]

Requirements:
- Length: 150-200 words
- Tone: empathetic first, then strategic — acknowledge the disappointment, then pivot
- Don't minimize how they feel, but don't dwell either
- Explain clearly what happened and what we learned
- End with a specific next step that keeps momentum going
```

---

## CLOSING & POST-CLOSE

---

**Closing Day Congratulations — Buyer**
*When to use: On the day your buyer closes on their new home.*

```
Write a closing day message to a buyer client who just closed on their new home. This should feel personal, celebratory, and sincere — not templated.

Details:
- Buyer's name(s): [NAME(S)]
- Property address: [ADDRESS]
- Closing date: [TODAY'S DATE]
- Anything special about the journey: [e.g., they looked for 8 months, this was their first home, they moved from out of state, they had one offer fall through before this]
- A specific memory or moment from working together: [e.g., the look on their face when they first walked in / when they almost gave up and we found this one]
- Your name: [YOUR NAME]

Requirements:
- Length: 120-180 words
- Tone: warm, genuine, celebratory — this is a human moment
- Make it feel personal, not mass-produced
- Do not ask for a referral or review in this message (not today)
- Bonus: include a short wish or piece of advice for their new chapter
- Works as email or text — write both, keeping text under 300 characters
```

---

**Closing Day Congratulations — Seller**
*When to use: On the day your seller closes and the sale is complete.*

```
Write a closing day message to a seller client. This is a significant life transition — acknowledge it meaningfully.

Details:
- Seller's name(s): [NAME(S)]
- Property address: [ADDRESS]
- Sale price: [$PRICE]
- What they're doing next: [e.g., moving to [CITY], downsizing, buying their next home, retiring] (or leave blank if unknown)
- Anything memorable about the process: [e.g., they lived there for 22 years, raised their kids there, it was their parents' home]
- Your name: [YOUR NAME]

Requirements:
- Length: 120-160 words
- Tone: warm, thoughtful, slightly bittersweet if appropriate (selling a family home is emotional)
- Acknowledge the milestone genuinely
- Wish them well in their next chapter sincerely
- Email version + text version (under 300 characters)
- Save referral and review requests for the post-close check-in
```

---

**Post-Close Check-In (30-Day)**
*When to use: 30 days after closing — checking in, building the relationship, and opening the door to referrals.*

```
Write a 30-day post-close check-in message to a recent buyer or seller client. The goal is to maintain the relationship and naturally open the door to referrals — without being salesy about it.

Details:
- Client's name: [NAME]
- They were a: [BUYER / SELLER]
- Closing date (approximate): [DATE — 30 days ago]
- Property: [ADDRESS]
- Anything you know about how they're settling in: [e.g., they were excited to start renovating the kitchen, they had a big family gathering planned]
- Your name: [YOUR NAME]

Requirements:
- Length: 120-160 words
- Tone: genuine, interested, not transactional
- Ask about them first — how are they settling in?
- Offer something useful: [e.g., contractor recommendations, utility transfer info, neighborhood tips] (or leave as a general offer of help)
- The referral mention should feel natural: one sentence, at the end, low pressure
- Email + text versions
```

---

## REFERRAL & TESTIMONIAL REQUESTS

---

**Referral Request — Active Client**
*When to use: Asking a happy, active client for referrals while you're still working together and they're feeling great about the experience.*

```
Write a natural, non-awkward referral request to a current client who is clearly happy with my service. I want to ask without making it weird or transactional.

Details:
- Client's name: [NAME]
- Current stage: [e.g., just found a great home, just listed and got multiple offers, closing next week]
- Why they're happy: [e.g., we got them $30K over asking, we found them a home in a difficult market, the process was smooth]
- Your name: [YOUR NAME]

Requirements:
- Length: 80-120 words
- Tone: grateful, humble, genuine — not scripted
- Acknowledge their experience first
- Make the ask feel natural, not like a form letter
- Give them an easy, low-effort action (text a name, introduce over email, share your number)
- Text version
```

---

**Testimonial / Review Request**
*When to use: Asking a past client for a Google, Zillow, or Realtor.com review after a successful transaction.*

```
Write a review request message to a past client asking them to leave a review on [PLATFORM]. Make it easy, personal, and give them enough direction that they actually do it.

Details:
- Client's name: [NAME]
- Platform: [Google / Zillow / Realtor.com / Yelp]
- Review link: [INSERT LINK]
- Transaction highlight: [e.g., we sold their home in 6 days for over asking / helped them close on their dream home after 4 months of searching]
- Your name: [YOUR NAME]

Requirements:
- Length: 100-150 words
- Tone: appreciative, easy, friendly
- Remind them briefly of something specific we accomplished together (make them remember the win)
- Tell them exactly what to do and include the link prominently
- Acknowledge that you know their time is valuable — keep it short and simple
- Bonus: suggest 1-2 things they could mention so they're not staring at a blank box
- Text + email versions
```

---

**Holiday / Seasonal Check-In (Sphere Touch)**
*When to use: Annual or seasonal touch point with past clients and sphere of influence — not transactional, just staying top of mind.*

```
Write a [HOLIDAY/SEASON] message to send to my past clients and sphere of influence. This is a genuine relationship touch — not a real estate update or market report.

Details:
- Holiday or occasion: [e.g., Thanksgiving, New Year, Summer check-in, Home Anniversary]
- Tone I want: [e.g., warm and heartfelt, fun and light, professional and sincere]
- Anything specific about this year: [e.g., "it's been an incredible year" / "the market has been wild" / leave neutral]
- Whether to include a real estate note: [YES — one subtle sentence / NO — purely personal]
- Your name: [YOUR NAME]

Requirements:
- Length: 60-100 words
- Tone: [AS SPECIFIED ABOVE]
- Feel personal, not mass-produced (even though it is)
- If including real estate note, make it one sentence max, at the end
- Write as text message — should feel like a note from a friend
```

---

**Database Anniversary / Home Anniversary Message**
*When to use: Reaching out to a past buyer on the anniversary of their home purchase — one of the most effective touches in real estate.*

```
Write a home purchase anniversary message to a past buyer client. This is one of the most meaningful relationship touches in real estate — use it well.

Details:
- Client's name: [NAME]
- Property address: [ADDRESS]
- Anniversary: [1ST / 2ND / 5TH / etc.] year since closing
- Closing date: [DATE]
- Anything you remember: [e.g., they were first-time buyers, they moved across the country, it was a competitive win]
- Your name: [YOUR NAME]

Requirements:
- Length: 80-120 words
- Tone: warm, celebratory, personal
- Make it feel like you actually remembered — because you did (or your CRM did, which is the same thing)
- Reference the milestone — a year (or more) of memories in that home
- Naturally include an offer of value: current home value update, any help they need
- Do NOT make this primarily a sales pitch — the relationship IS the value
- Text version
```

---

*Next: `04-marketing-prompts.md` → 20 prompts for social media, bios, newsletters & video*
