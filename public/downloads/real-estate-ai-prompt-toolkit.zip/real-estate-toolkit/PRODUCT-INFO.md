# PRODUCT-INFO.md
### Everything You Need to List This Product on Gumroad

---

## PRODUCT DETAILS

**Product Name:**
The Real Estate Agent's AI Prompt Toolkit: 100+ Done-for-You Prompts to Write Listings, Win Clients & Grow Your Business in Minutes

**Short Name (for URL/slug):**
real-estate-ai-prompt-toolkit

**Price:** $47

**File Format:** Digital download (ZIP containing 9 Markdown files, readable in any text editor, browser, or Notion)

**Category:** Real Estate → Tools & Templates

---

## GUMROAD SALES DESCRIPTION (250 words)

You became a real estate agent to help people — not to stare at a blinking cursor trying to figure out how to write a listing description, follow-up email, or Instagram caption.

This toolkit changes that.

The Real Estate Agent's AI Prompt Toolkit gives you 100+ ready-to-use AI prompts built specifically for real estate — every type of listing, every stage of the client relationship, and every marketing channel you need to show up on.

Here's what's inside:

**📋 25 Listing Prompts** — MLS descriptions for every property type (standard, luxury, fixer-upper, investment, condo), headlines, neighborhood copy, virtual tour scripts, open house announcements, and price reduction copy.

**💬 20 Client Communication Prompts** — First contact, follow-up, offer presentation, multiple offers, closing day messages, post-close check-ins, referral and testimonial requests.

**📱 20 Marketing Prompts** — Instagram, Facebook, LinkedIn, agent bio (short and long), monthly newsletters, YouTube scripts, and educational Reels.

**⚙️ 15 Business Operations Prompts** — CMA summaries, FSBO and expired listing outreach, cold call scripts, voicemail scripts, review requests, Zillow bio, and recruiting messages.

**🔄 5 Complete Workflow SOPs** — Step-by-step systems for: new listing launch (30 min), 21-day lead nurture sequence, monthly content batch, open house follow-up, and seller presentation prep.

Every prompt uses [BRACKETS] for easy customization. Every prompt includes a "When to use" guide. Every prompt was written by and for real estate agents.

This isn't a generic prompt list. This is your unfair advantage.

**$47. One time. Yours forever.**

---

## 5 HEADLINE OPTIONS

**Option A (Benefit-Forward):**
> 100+ AI Prompts That Write Your Listings, Emails & Social Content — So You Can Focus on Selling Real Estate

**Option B (Time-Focused):**
> Stop Wasting Hours on Copy. This AI Prompt Toolkit Writes Your MLS Descriptions, Client Emails & Marketing in Minutes.

**Option C (Authority/Specificity):**
> The Only AI Prompt Toolkit Built Specifically for Real Estate Agents — 100+ Prompts for Listings, Clients, Marketing & More

**Option D (Problem/Solution):**
> Blank Page? Never Again. 100+ Done-for-You AI Prompts for Every Real Estate Task You Hate Writing.

**Option E (Social Proof Angle):**
> Top Agents Are Using AI to Write Faster and Better. Here Are the 100+ Prompts They're Using.

---

## GUMROAD TAGS

```
real estate
real estate agent
AI prompts
ChatGPT prompts
real estate marketing
listing description
MLS description
real estate tools
agent tools
real estate templates
prompt templates
real estate copywriting
social media real estate
real estate email templates
productivity tools
digital download
real estate business
agent marketing
```

---

## PRODUCT THUMBNAIL COPY SUGGESTIONS

For your Gumroad cover image, use one of these short punchy lines:

- **"100+ AI Prompts for Real Estate Agents"**
- **"Write Listings & Win Clients with AI — Done-for-You Prompts"**
- **"The Real Estate AI Toolkit — $47"**
- **"From Blank Page to Published Copy in 5 Minutes"**

Recommended cover design: dark professional background (navy or charcoal), clean white text, a subtle house icon or AI/robot icon. Avoid stock photos — use clean typography.

---

## WHAT TO PUT IN YOUR GUMROAD CONFIRMATION EMAIL

Subject: Your Real Estate AI Prompt Toolkit is here 🏠

---

Hey [BUYER NAME],

Your toolkit is ready — download it from the link below.

**Quick Start:**
1. Unzip the file
2. Open `README.md` first — it's your map
3. Then open `01-quick-start-guide.md` to learn exactly how to use these with ChatGPT or Claude
4. Pick your first task and find the right prompt

If you have questions or want to share a win, reply to this email. I'd love to hear how it's going.

And if this toolkit saves you time (it will), please leave a review on Gumroad — it helps other agents find it.

Go get 'em,
[YOUR NAME]

---

## UPSELL / FUTURE PRODUCT IDEAS

Consider bundling or upselling these companion products:

1. **Real Estate Agent's AI Content Calendar** — 12-month social media content plan with 365 prompts ($27)
2. **Luxury Listing Masterclass** — Advanced prompt techniques for $1M+ properties ($67)
3. **Done-for-You Listing Descriptions (Custom)** — You send specs, I write the MLS description using AI ($19/listing or $97/month)
4. **Real Estate Email Newsletter Templates** — 12 pre-written monthly newsletters, just fill in your local data ($37)
5. **AI Prompt Toolkit for Real Estate Teams** — Multi-agent license with team workflow SOPs ($197)

---

## AFFILIATE PROGRAM SUGGESTED TERMS

- Commission: 40% per sale ($18.80 per $47 sale)
- Ideal affiliates: real estate coaches, brokerage trainers, real estate podcast hosts, MLS tool companies
- Suggested promo copy: "I've been using this toolkit for my clients and it's genuinely one of the best $47 investments an agent can make in their business."

---

*Product version: 1.0 | Last updated: 2025*
