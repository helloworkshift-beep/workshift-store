# 🏠 The Real Estate Agent's AI Prompt Toolkit
### 100+ Done-for-You AI Prompts to Write Listings, Win Clients & Grow Your Business in Minutes

---

## Welcome

You just got your hands on the most practical AI prompt library built specifically for real estate agents. This isn't a collection of generic writing prompts — every single prompt was designed with real estate workflows in mind, tested for clarity, and formatted so you can copy, customize, and launch in under 5 minutes.

Whether you're a solo agent juggling 10 listings or a team lead trying to scale content production without hiring a copywriter, this toolkit gives you professional-grade output every time.

---

## What's Inside

| File | Description | Prompts |
|------|-------------|---------|
| `01-quick-start-guide.md` | How to use this toolkit with AI tools, tips, bracket guide | — |
| `02-listing-prompts.md` | MLS descriptions, headlines, neighborhood copy, tour scripts | 25 |
| `03-client-communication-prompts.md` | Emails & messages for every stage of the client relationship | 20 |
| `04-marketing-prompts.md` | Social media, bios, newsletters, video scripts | 20 |
| `05-business-operations-prompts.md` | CMA summaries, outreach scripts, reviews, recruiting | 15 |
| `06-workflow-sops.md` | 5 complete step-by-step workflows using AI | — |
| `07-cheat-sheet.md` | Quick-reference power prompts + AI tool guide | 15 |

**Total: 95+ unique prompts across 7 categories**

---

## Quick Setup (3 Steps)

### Step 1 — Pick Your AI Tool
Open one of the following (all free to start):
- **ChatGPT** → [chat.openai.com](https://chat.openai.com) (GPT-4o recommended)
- **Claude** → [claude.ai](https://claude.ai) (excellent for longer copy)
- **Gemini** → [gemini.google.com](https://gemini.google.com)
- **Copilot** → [copilot.microsoft.com](https://copilot.microsoft.com)

### Step 2 — Open a Prompt File
Start with `02-listing-prompts.md` if you have a listing to write, or `03-client-communication-prompts.md` if you need to reach out to a client. Each prompt has a "When to use" line so you can find the right one fast.

### Step 3 — Fill In the Brackets & Paste
Every prompt uses `[BRACKETS]` for the parts you customize. Fill those in, paste the whole prompt into your AI tool, and hit send. Edit the output lightly, then publish.

**Average time from prompt to published copy: 4–8 minutes.**

---

## How This Toolkit Is Organized

### 📋 Listing Prompts (`02-listing-prompts.md`)
The heart of the toolkit. Covers every listing type:
- Standard MLS descriptions (3–5 bedrooms, all price points)
- Luxury & high-end property copy
- Fixer-upper / investor-appeal descriptions
- Income property & multi-family
- Neighborhood & community descriptions
- Virtual tour scripts
- Open house event copy
- Price reduction announcements
- Listing headlines

### 💬 Client Communication (`03-client-communication-prompts.md`)
Never stare at a blank email again. Scripts for:
- First-touch buyer & seller outreach
- Follow-ups when leads go cold
- Offer presentations & rejections
- Multiple offer situations
- Closing day messages
- Post-close check-ins
- Referral & testimonial requests

### 📱 Marketing (`04-marketing-prompts.md`)
Batch your content in one sitting:
- Instagram captions (new listing, just sold, market update, brand)
- Facebook posts & LinkedIn articles
- Agent bio (short & long form)
- Monthly email newsletters
- YouTube/Reel video scripts
- Educational posts that build trust

### ⚙️ Business Operations (`05-business-operations-prompts.md`)
The behind-the-scenes stuff that moves your business:
- CMA presentation summaries
- Seller offer comparison write-ups
- FSBO & expired listing outreach
- Cold call & voicemail scripts
- Review request messages
- Zillow & Realtor.com bios
- Team recruiting messages

### 🔄 Workflow SOPs (`06-workflow-sops.md`)
Five complete workflows that tell you exactly when and how to use these prompts together:
1. New Listing in 30 Minutes
2. 21-Day Lead Follow-Up Email Sequence
3. Monthly Marketing Batch Session
4. Open House Follow-Up System
5. Seller Presentation Prep

---

## Tips Before You Start

1. **More detail = better output.** When filling in brackets, don't be stingy. The more context you give the AI, the more specific and useful the output.

2. **The AI doesn't know your market.** Add local flavor manually — neighborhood names, school districts, nearby landmarks. The prompts leave room for this.

3. **Always read before you send.** AI output is a draft, not a final. Spend 2 minutes reading it before publishing. Fix anything that sounds off.

4. **Save your best outputs.** When an AI gives you something great, save it. Build a swipe file. Reuse structure, not just content.

5. **You own the output.** Everything generated with these prompts is yours to use, publish, and profit from.

---

## Support & Updates

Questions? Reach out to the seller on Gumroad. If this toolkit helped your business, please leave a review — it means the world and helps other agents find it.

---

*Version 1.0 | Built for agents who are serious about working smarter.*
