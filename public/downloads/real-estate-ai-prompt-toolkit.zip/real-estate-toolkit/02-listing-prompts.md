# 02 — Listing Prompts
### 25 AI Prompts for MLS Descriptions, Headlines, Neighborhood Copy, Tour Scripts & More

---

> **How to use this file:** Find the prompt that matches your situation. Fill in every `[BRACKET]`. Paste into ChatGPT or Claude. Edit lightly. Publish.

---

## MLS DESCRIPTIONS

---

**Standard MLS Description — Single Family Home**
*When to use: Your go-to prompt for any traditional residential listing, 2–5 bedrooms, any price point.*

```
Act as an expert real estate copywriter. Write a compelling MLS property description for the following home. 

Property details:
- Address/Area: [NEIGHBORHOOD OR CITY]
- Bedrooms: [NUMBER]
- Bathrooms: [NUMBER]
- Square footage: [SQ FT]
- Lot size: [LOT SIZE]
- Year built: [YEAR]
- Garage: [GARAGE TYPE AND SIZE]
- Key interior features: [LIST 5-8 FEATURES — e.g., renovated kitchen, hardwood floors, primary suite with walk-in closet]
- Key exterior features: [LIST 3-5 FEATURES — e.g., covered patio, fenced yard, mature trees]
- Recent updates: [UPDATES — e.g., new roof 2022, HVAC 2021, fresh paint throughout]
- School district: [SCHOOL DISTRICT NAME]
- Nearby: [2-3 LOCAL HIGHLIGHTS — e.g., 5 min to downtown, walking distance to park]
- Asking price: [$PRICE]

Requirements:
- Length: 250-350 words
- Tone: warm and professional
- Lead with the most compelling feature, not the address
- Avoid clichés like "nestled," "cozy," "charming," or "a must see"
- End with a strong call to action
- Do not use bullet points — write in flowing paragraph form
```

---

**Luxury Property MLS Description**
*When to use: High-end listings ($750K+), estate properties, or any home where premium positioning is critical.*

```
Act as a luxury real estate copywriter who has written descriptions for properties featured in Architectural Digest. Write an elevated, aspirational MLS description for this luxury property.

Property details:
- Location: [NEIGHBORHOOD/AREA — be specific about prestige]
- Style/Architecture: [e.g., Modern Mediterranean, Contemporary, Colonial Revival]
- Bedrooms: [NUMBER] | Bathrooms: [NUMBER]
- Square footage: [SQ FT] | Lot: [ACREAGE OR LOT SIZE]
- Luxury finishes: [LIST — e.g., Carrara marble, Sub-Zero appliances, custom millwork, coffered ceilings]
- Outdoor/entertaining features: [e.g., resort-style pool, outdoor kitchen, motor court, guesthouse]
- Smart home/tech features: [e.g., Lutron lighting, whole-home audio, Savant system]
- Views or unique setting: [e.g., golf course views, waterfront, mountain backdrop]
- Garage/parking: [e.g., 4-car garage with EV charging]
- Asking price: [$PRICE]

Requirements:
- Length: 350-450 words
- Tone: sophisticated, aspirational, exclusive — never salesy
- Appeal to buyers who prioritize lifestyle and status, not square footage
- Open with an evocative image or lifestyle statement, not specs
- Weave in the emotional experience of living there
- End with an understated, confident call to action — no exclamation points
```

---

**Fixer-Upper / Value-Add MLS Description**
*When to use: Properties that need work, cosmetic updates, or are priced below market for condition.*

```
Act as a real estate copywriter who specializes in positioning value-add properties. Write an honest, compelling MLS description that attracts the right buyer — someone who sees potential and wants a deal.

Property details:
- Location/Neighborhood: [AREA]
- Bedrooms: [NUMBER] | Bathrooms: [NUMBER]
- Square footage: [SQ FT]
- Condition notes: [BE SPECIFIC — e.g., original 1970s kitchen, needs flooring throughout, roof replaced 2019, good bones]
- What's already done/good: [LIST POSITIVES — e.g., new electrical panel, solid structure, great lot, desirable street]
- Potential: [e.g., ADU possibility, great floorplan for open concept remodel, large lot for addition]
- Asking price: [$PRICE]
- Comparable renovated homes in area: [$COMP PRICE] (optional — helps position the value)

Requirements:
- Length: 200-280 words
- Tone: honest, straightforward, opportunity-focused
- Lead with the opportunity, not the problems
- Use language that appeals to investors and handy buyers without being misleading
- Highlight what makes this worth buying (location, lot, bones, price)
- Avoid hiding issues — buyers appreciate honesty and it protects you legally
```

---

**Investment / Income Property Description**
*When to use: Multi-family, rental properties, vacation rentals, or any property marketed to investors.*

```
Act as a real estate investment copywriter. Write an MLS description for an income-producing property that speaks directly to real estate investors.

Property details:
- Property type: [e.g., duplex, triplex, single-family rental, vacation rental]
- Location: [CITY/NEIGHBORHOOD]
- Total units: [NUMBER] | Total bedrooms: [NUMBER] | Total bathrooms: [NUMBER]
- Total square footage: [SQ FT]
- Current monthly rent: [$AMOUNT] (or "currently vacant — market rents estimated at [$AMOUNT]/mo")
- Expenses (if known): [HOA, taxes, insurance estimate]
- Cap rate or GRM (if known): [NUMBER]
- Condition: [CONDITION NOTES]
- Key features for investors: [e.g., separately metered units, long-term tenants, recent roof, low-maintenance exterior]
- Zoning: [ZONING — e.g., R-2, allows ADU]
- Asking price: [$PRICE]

Requirements:
- Length: 200-300 words
- Tone: factual, data-forward, professional
- Lead with the income potential and return, not the physical description
- Include relevant financial metrics naturally in the copy
- Appeal to both local and out-of-state investors
- End with what makes this a smart buy — location, cash flow, upside
```

---

**Condo / Townhome MLS Description**
*When to use: Any attached dwelling — condos, townhomes, patio homes, or planned community units.*

```
Act as a real estate copywriter. Write a compelling MLS description for a condo or townhome that highlights the lifestyle and low-maintenance appeal of attached living.

Property details:
- Building/Community name: [NAME]
- Location: [CITY/NEIGHBORHOOD]
- Floor: [FLOOR NUMBER] (if applicable)
- Bedrooms: [NUMBER] | Bathrooms: [NUMBER]
- Square footage: [SQ FT]
- Unit features: [LIST — e.g., updated kitchen, balcony with city views, in-unit laundry, 9-ft ceilings]
- Building/community amenities: [LIST — e.g., rooftop deck, fitness center, concierge, pool, dog park]
- HOA fee: [$AMOUNT/month] — covers: [WHAT'S INCLUDED]
- Parking: [e.g., 1 deeded parking space in secure garage]
- Nearby: [WALKABILITY HIGHLIGHTS — restaurants, transit, parks]
- Asking price: [$PRICE]

Requirements:
- Length: 220-300 words
- Tone: lifestyle-focused, aspirational but grounded
- Emphasize what makes condo/townhome living a smart choice (lock and leave, amenities, location)
- Speak to likely buyer profile: [e.g., first-time buyer / downsizer / urban professional / investor]
- End with a clear call to action
```

---

**New Construction / Builder Description**
*When to use: Brand new homes, spec builds, or pre-sale properties in a new development.*

```
Act as a real estate copywriter specializing in new construction. Write an MLS description for a newly built home that conveys quality, modern living, and the peace of mind of buying new.

Property details:
- Builder name: [BUILDER]
- Community/Subdivision: [NAME]
- Location: [CITY/AREA]
- Plan name or number: [PLAN]
- Bedrooms: [NUMBER] | Bathrooms: [NUMBER]
- Square footage: [SQ FT]
- Standard features included: [LIST KEY INCLUSIONS — e.g., quartz counters, LVP flooring, SS appliances, 9-ft ceilings]
- Upgrades in this specific home: [LIST ANY UPGRADES]
- Warranty: [e.g., 1-year workmanship, 10-year structural]
- Estimated completion: [DATE OR "Move-in Ready"]
- HOA: [$AMOUNT] — includes: [WHAT'S COVERED]
- Asking price: [$PRICE]

Requirements:
- Length: 230-300 words
- Tone: confident, modern, trustworthy
- Emphasize the advantages of new over resale (warranty, efficiency, modern layout, no deferred maintenance)
- Highlight the community and location
- Call to action that creates some urgency (limited homes remaining, etc.)
```

---

## LISTING HEADLINES

---

**Listing Headline Generator**
*When to use: Any time you need attention-grabbing headlines for Zillow, social media, email subject lines, or flyers — generate 10 at once.*

```
Act as a real estate marketing copywriter. Generate 10 compelling property listing headlines for the following home. These will be used across Zillow, Instagram, Facebook, and email subject lines.

Property highlights:
- Type: [PROPERTY TYPE — e.g., 4-bed ranch, modern townhome, lakefront cabin]
- Key selling feature #1: [MOST COMPELLING FEATURE — e.g., completely renovated, stunning views, huge lot]
- Key selling feature #2: [SECOND BEST FEATURE]
- Location appeal: [e.g., top-rated school district, walkable downtown, quiet cul-de-sac]
- Price point: [e.g., priced under $400K, offered at $1.2M, exceptional value at $325K]
- Target buyer: [e.g., growing family, investor, downsizer, first-time buyer]

Requirements:
- Mix styles: some use numbers, some use emotion, some use urgency, some use questions
- No clichés (no "dream home," "stunning," "gorgeous," "amazing")
- Each headline should be under 12 words
- Label each with its best use case (Zillow title, Instagram hook, email subject, etc.)
```

---

**Price Reduction Announcement**
*When to use: When a seller reduces the asking price and you need to re-energize interest in the listing.*

```
Act as a real estate agent writing a price reduction announcement. Write 3 versions of this announcement — one for MLS remarks update, one for social media, and one for an email to your buyer database.

Property details:
- Address or description: [PROPERTY DESCRIPTION]
- Original price: [$ORIGINAL PRICE]
- New price: [$NEW PRICE]
- Reduction amount: [$DIFFERENCE] / [% REDUCTION]
- Days on market: [NUMBER]
- Key features (remind buyers why this is worth seeing): [LIST 3-4 FEATURES]
- What's changed or any new info: [e.g., seller motivated, offer by [DATE] preferred, flexible closing]

Requirements:
- MLS update: 100-150 words, professional tone, lead with the new price
- Social media: 80-120 words, create excitement and urgency, can use emojis
- Email to database: 150-200 words, personal tone, remind them why they looked and why now is the time
- All three should feel fresh — like this is new news, not a desperate plea
```

---

## NEIGHBORHOOD DESCRIPTIONS

---

**Neighborhood / Area Description**
*When to use: When listing remarks need to sell the location as much as the home, or for website neighborhood pages.*

```
Act as a real estate agent who knows this neighborhood deeply. Write a compelling neighborhood description that would make someone excited to buy here.

Neighborhood details:
- Neighborhood name: [NAME]
- City/Metro: [CITY]
- Character/vibe: [e.g., historic and walkable, suburban and family-friendly, up-and-coming arts district]
- Housing stock: [e.g., 1950s ranch homes, craftsman bungalows, new construction townhomes]
- Walkability: [SCORE or description — e.g., very walkable, car-dependent but close to X]
- Schools: [SCHOOL NAMES AND REPUTATION]
- Nearby dining/shopping: [SPECIFIC PLACES — e.g., 3 blocks from Main Street with 20+ restaurants]
- Parks/recreation: [SPECIFIC PARKS OR AMENITIES]
- Commute/transit: [e.g., 20 min to downtown, 2 blocks from Metro station]
- Recent changes/development: [e.g., new Whole Foods opened, major employer moved in nearby]
- Median home price: [$PRICE] (optional)
- Who lives here: [BUYER PROFILE — e.g., young professionals, families, retirees, mix]

Requirements:
- Length: 200-250 words
- Tone: enthusiastic but authentic — not a tourism brochure
- Use specific details, not generic language
- Make it feel like insider knowledge, not a Wikipedia article
- End with a sentence that ties the neighborhood back to the buying decision
```

---

**Hyper-Local Street or Block Description**
*When to use: When the specific street or block is a major selling point — quiet cul-de-sac, tree-lined avenue, waterfront street.*

```
Write a short, vivid description of what it's like to live on this specific street or in this specific pocket of the neighborhood. This will be used in the listing remarks.

Details:
- Street name or area: [NAME]
- What makes this location special: [e.g., dead-end street with no through traffic, lined with 50-year-old oak trees, one block from the lake]
- Neighbor vibe: [e.g., longtime residents who know each other, active community with block parties]
- What you see/hear/experience: [e.g., kids playing outside, quiet evenings, morning walks to the coffee shop]
- Any physical features: [e.g., wide lots, sidewalks, streetlights, mature landscaping]

Requirements:
- Length: 80-120 words
- Tone: personal, evocative, like a neighbor describing it to a friend
- Paint a picture — what does it feel like to live here?
- No sales language — just authentic description
```

---

## VIRTUAL TOUR SCRIPTS

---

**Virtual Tour Voiceover Script — Standard Home**
*When to use: Recording a video walkthrough or virtual tour for YouTube, social media, or MLS video.*

```
Act as a real estate video scriptwriter. Write a natural, engaging voiceover script for a video walkthrough of this home. The script should feel like a knowledgeable friend showing you around, not a sales pitch.

Property details:
- Bedrooms: [NUMBER] | Bathrooms: [NUMBER]
- Square footage: [SQ FT]
- Room-by-room walkthrough order: [LIST ROOMS IN ORDER — e.g., front yard → foyer → living room → kitchen → dining → primary suite → bedrooms → backyard]
- Key features per room: [LIST STANDOUT FEATURES FOR EACH ROOM]
- Overall vibe/style: [e.g., modern farmhouse, traditional, mid-century]
- Target buyer: [e.g., growing family, empty nester, first-time buyer]
- Asking price: [$PRICE]

Requirements:
- Total length: 300-400 words (approx. 2-2.5 min of speaking time)
- Tone: warm, conversational, knowledgeable
- Use transitions between rooms naturally ("As we move into the kitchen..." / "Step outside and you'll find...")
- Highlight the emotional experience of each space, not just the specs
- End with agent contact info placeholder and call to action
- Format as a script with [ROOM LABEL] headers so it's easy to record in sections
```

---

**Short-Form Video Script (Reel/TikTok Style)**
*When to use: 30-60 second listing video for Instagram Reels, TikTok, or Facebook.*

```
Write a 30-60 second script for a fast-paced listing video reel. This will have quick cuts between shots with text overlays and a voiceover.

Property details:
- Top 5 most visual features: [LIST — e.g., chef's kitchen, pool, master closet, views, curb appeal]
- Location highlight: [NEIGHBORHOOD/AREA]
- Price: [$PRICE]
- Bedrooms/bathrooms: [BED/BATH]
- One emotional hook: [e.g., "imagine summer mornings by this pool" / "work from home with this view"]

Requirements:
- Format: [SHOT DESCRIPTION] | VOICEOVER TEXT | TEXT OVERLAY
- Opening line must hook in first 2 seconds
- Use short punchy sentences — max 8 words per line
- End with a clear CTA (link in bio, DM me, schedule a showing)
- Total script: under 120 words
- Include 2-3 spot suggestions for trending audio moments (music drop, silence for impact)
```

---

## OPEN HOUSE DESCRIPTIONS

---

**Open House Announcement — Social Post + Email**
*When to use: Promoting an upcoming open house on social media and via email.*

```
Act as a real estate marketing specialist. Write an open house announcement in two formats: a social media post and a short email.

Event details:
- Property address: [ADDRESS]
- Property highlights: [TOP 3-4 SELLING FEATURES]
- Open house date: [DAY, DATE]
- Open house time: [START TIME - END TIME]
- Hosted by: [AGENT NAME]
- Refreshments (if any): [e.g., coffee and pastries will be served]
- Asking price: [$PRICE]
- Any special draws: [e.g., raffle entry for attendees, new price, seller will be present to share the story of the home]

Requirements for social post:
- 100-150 words
- Lead with an invitation, not just logistics
- Include date, time, address clearly
- Emojis welcome — keep it festive and inviting
- Hashtag suggestions at the end (local + real estate)

Requirements for email:
- Subject line + body
- 150-200 words
- Personal, warm tone — like you're personally inviting your contacts
- Mention what makes this home worth the trip
- RSVP or "add to calendar" CTA
```

---

**Open House Event Description for Zillow/MLS**
*When to use: Adding open house details and a draw to your Zillow or MLS listing.*

```
Write a short, compelling open house event description to add to our MLS/Zillow listing. This should make people want to attend, not just know the logistics.

Open house details:
- Date and time: [DATE AND TIME]
- Property highlights (remind them why they're coming): [TOP 3 FEATURES]
- What they'll experience: [e.g., professional staging throughout, refreshments, neighborhood info packets available]
- Any time-sensitive element: [e.g., offers reviewed after open house, seller accepting backup offers, this is the only scheduled open house]

Requirements:
- 80-120 words
- Tone: inviting, slightly urgent
- Make attending feel like an experience, not just a chore
- End with: "We look forward to seeing you."
```

---

## PRICE REDUCTION & SPECIAL SITUATION DESCRIPTIONS

---

**Motivated Seller / Quick Close Description**
*When to use: When the seller genuinely needs to move quickly and that's a feature, not a weakness.*

```
Act as a real estate copywriter. Write an MLS description for a property where the seller's motivation to close quickly is actually a buyer benefit. Frame this strategically — it's an opportunity, not desperation.

Property details:
- Description: [PROPERTY BASICS — beds, baths, sqft, area]
- Key features: [LIST]
- Condition: [CONDITION]
- Price: [$PRICE]
- Seller timeline: [e.g., must close within 30 days, relocation, estate sale]
- Flexibility offered: [e.g., flexible possession, will consider offers with contingencies, as-is priced accordingly]

Requirements:
- Length: 200-260 words
- Frame urgency as buyer opportunity, not seller weakness
- Lead with the property, not the situation
- Mention the timeline and flexibility naturally in the second half
- This should attract decisive buyers who are ready to move, not bargain hunters who will lowball
```

---

**As-Is / Estate Sale Description**
*When to use: Properties sold as-is, estate sales, probate listings, or bank-owned properties.*

```
Write an honest, professional MLS description for an as-is property or estate sale. The goal is to attract the right buyers (investors, flippers, cash buyers) while being fully transparent about the condition.

Property details:
- Type: [ESTATE SALE / AS-IS / PROBATE / INVESTOR SPECIAL]
- Location: [AREA — emphasize location value]
- Bedrooms: [NUMBER] | Bathrooms: [NUMBER] | Square footage: [SQ FT]
- Condition overview: [BE SPECIFIC — e.g., original condition throughout, newer roof, needs full interior update]
- What's good / what has value: [e.g., large lot, solid structure, great bones, excellent location]
- Known issues (if any that must be disclosed): [LIST]
- Asking price: [$PRICE]
- Terms: [e.g., cash or hard money only, no repairs, no credits, sold as-is]

Requirements:
- Length: 180-240 words
- Tone: straightforward, respectful, opportunity-focused
- Don't apologize for the condition — position it as priced accordingly
- Appeal to investors, flippers, and buyers who want to put their own stamp on a home
- End with clear terms so the right buyers self-select
```

---

**Seller Concession / Rate Buydown Description**
*When to use: When the seller is offering to buy down the buyer's interest rate or cover closing costs — a powerful differentiator in high-rate markets.*

```
Write an MLS description and a separate social media post highlighting that the seller is offering a mortgage rate buydown or closing cost concession. This should make the financial benefit crystal clear without oversimplifying it.

Property details:
- Property description: [BEDS/BATHS/SQFT/AREA]
- Key features: [TOP FEATURES]
- Asking price: [$PRICE]
- Seller concession: [e.g., seller offering 2/1 buydown, seller offering up to $10,000 toward closing costs, seller offering 1-0 buydown]
- Estimated payment impact: [e.g., buyer's payment is $X lower in year 1 with this buydown — or leave blank if unknown]

Requirements:
- MLS description: 220-280 words — lead with the home, mention concession in the final paragraph
- Social post: 100-140 words — lead with the financial benefit, keep it simple and exciting
- Don't use technical jargon buyers won't understand
- Make it feel like a rare opportunity (because in today's market, it is)
```

---

**Coming Soon Teaser**
*When to use: Building buzz before a listing goes live on MLS — for social media, email, and your sphere.*

```
Write a "Coming Soon" teaser for a property that's not yet live on MLS. The goal is to build buzz, collect leads, and create demand before it hits the market.

Property teaser details:
- General location (not exact address yet): [NEIGHBORHOOD/AREA]
- Property type: [e.g., stunning 4-bed colonial, rare mid-century modern, charming craftsman bungalow]
- One irresistible detail you can share: [e.g., "the backyard will blow you away" / "completely renovated top to bottom" / "water views from every room"]
- Expected list date: [DATE or "hitting the market [DAY]"]
- How to get early access: [e.g., DM me, text [NUMBER], click the link in my bio]

Requirements:
- Social post version: 80-120 words, build intrigue, don't reveal everything, end with a strong CTA to get early access
- Email version: 120-160 words, more personal, for your existing database
- Use FOMO language — people who see it first have an advantage
- Emojis welcome on social version
```

---

**Back on Market Description**
*When to use: When a listing comes back on market after a deal fell through — repositioning is critical.*

```
Write an MLS description for a property that has come back on the market after a previous sale fell through. This needs to be handled carefully — explain the situation without creating doubt.

Property details:
- Property description: [BEDS/BATHS/SQFT/AREA/KEY FEATURES]
- Why it came back: [e.g., buyer financing fell through (no fault of property), buyer had personal change of plans, home inspection passed — deal fell for unrelated reasons]
- Any inspections or reports completed: [e.g., clean home inspection report available, roof certification completed]
- Asking price: [$PRICE — same or adjusted]

Requirements:
- Length: 200-260 words
- Lead with the property — don't open with "back on market"
- Address the BOM status briefly and clearly near the end, in a way that builds confidence
- Mention any completed inspections or reports as a positive (buyer did the work already)
- Tone: matter-of-fact, confident, reassuring
```

---

*Next: `03-client-communication-prompts.md` → 20 prompts for every client conversation*
