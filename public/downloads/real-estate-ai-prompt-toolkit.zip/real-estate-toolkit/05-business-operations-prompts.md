# 05 — Business Operations Prompts
### 15 AI Prompts for CMAs, Outreach Scripts, Prospecting, Reviews & Recruiting

---

> The back-end of your business — the prospecting, the presentations, the scripts, and the systems that generate listings and listings generate income.

---

## PRICING & PRESENTATIONS

---

**CMA Summary for Sellers**
*When to use: After running a comparative market analysis — translating the data into a clear, seller-friendly narrative.*

```
Act as a listing agent who has just completed a comparative market analysis. Write a clear, professional CMA summary narrative that explains the data and your pricing recommendation to a seller in plain language.

CMA details:
- Property address: [ADDRESS]
- Seller's name: [NAME]
- Property details: [BEDS/BATHS/SQFT/CONDITION]
- Active comparables (currently on market): 
  - Comp 1: [ADDRESS, PRICE, BEDS/BATHS, SQ FT, DAYS ON MARKET]
  - Comp 2: [ADDRESS, PRICE, BEDS/BATHS, SQ FT, DAYS ON MARKET]
  - Comp 3: [ADDRESS, PRICE, BEDS/BATHS, SQ FT, DAYS ON MARKET]
- Sold comparables (last 90 days):
  - Comp 1: [ADDRESS, SOLD PRICE, BEDS/BATHS, SQ FT, DAYS ON MARKET]
  - Comp 2: [ADDRESS, SOLD PRICE, BEDS/BATHS, SQ FT, DAYS ON MARKET]
  - Comp 3: [ADDRESS, SOLD PRICE, BEDS/BATHS, SQ FT, DAYS ON MARKET]
- Current market conditions: [e.g., seller's market / balanced / buyer's market / average DOM is X days / list-to-sale ratio is X%]
- Your recommended price range: [$LOW - $HIGH]
- Your specific recommended list price: [$PRICE]
- Why this price: [YOUR REASONING — e.g., positions above X comp but below Y to attract buyer pool]

Requirements:
- Length: 300-400 words
- Tone: analytical, confident, advisory — like a trusted consultant presenting a recommendation
- Structure: market overview → comparable analysis → recommended price → why this price → what happens if priced differently → next steps
- Use plain language — no industry jargon
- Include a brief note on what happens if priced too high (risk of sitting) and too low (risk of leaving money on the table) — frame as education, not fear
- This should replace or supplement a verbal CMA presentation
```

---

**Offer Comparison Summary for Sellers**
*When to use: When a seller receives multiple offers — presenting them in a comparable, apples-to-apples format.*

```
Write a multiple offer comparison summary for a seller who has received [NUMBER] offers on their property. Help them understand the key differences clearly and professionally.

Property and offer details:
- Property address: [ADDRESS]
- Asking price: [$PRICE]

Offer 1:
- Buyer: [e.g., Buyer A or anonymized]
- Price: [$AMOUNT]
- Earnest money: [$AMOUNT]
- Financing: [TYPE — cash / conventional / FHA / VA]
- Down payment: [%]
- Pre-approval status: [e.g., fully underwritten / standard pre-approval / proof of funds for cash]
- Inspection contingency: [YES / NO / limited]
- Appraisal contingency: [YES / NO / waived up to $X]
- Financing contingency: [YES / NO]
- Proposed closing: [DATE]
- Possession: [DATE or at closing]
- Other terms: [e.g., seller concessions requested, personal property requests, escalation clause up to $X]
- Offer strength overall: [YOUR ASSESSMENT]

[Repeat for Offer 2, Offer 3, etc.]

Your recommendation: [WHICH OFFER AND WHY]

Requirements:
- Format: begin with a brief intro paragraph, then a summary table comparing all offers side by side, then a written analysis of each offer's strengths and weaknesses, then your recommendation
- Length: 400-500 words total
- Tone: objective, clear, advisory
- Use the table to make comparison visual and simple
- In the written analysis, explain nuances the table can't show (e.g., "the cash offer is $10K less but eliminates appraisal risk in a rising market")
- End with your recommendation and reasoning, then next steps
```

---

**Pre-Listing Presentation Email**
*When to use: Sending your value proposition to a seller before or after a listing appointment.*

```
Write a pre-listing presentation email to send to a potential seller client before our in-person or Zoom listing appointment. The goal is to set the stage, demonstrate expertise, and generate excitement for the meeting.

Details:
- Seller's name: [NAME]
- Their property address: [ADDRESS]
- Meeting date and time: [DATE, TIME]
- What you'll cover in the meeting: [e.g., CMA and pricing strategy, marketing plan, timeline, next steps]
- One proof point about your track record: [e.g., average 7 days on market, sold X homes in this zip code last year, consistently sell above asking]
- Your name: [YOUR NAME]
- Your brokerage: [BROKERAGE]
- Your website or calendar link: [LINK]

Requirements:
- Length: 200-260 words
- Tone: confident, professional, prepared — they should feel like they're meeting with an expert, not just an agent
- Brief agenda overview so they know what to expect
- One specific stat or proof point (not a list of 10 — just one great one)
- End with anticipation-building language and a reminder of the time/date
- Subject line: 3 options to choose from
```

---

## PROSPECTING & OUTREACH

---

**FSBO Outreach — First Contact**
*When to use: Reaching out to a For Sale By Owner — your first touchpoint.*

```
Write a first-contact message to a For Sale By Owner (FSBO) homeowner. The goal is to differentiate from every other agent who called, not pitch them to list with me, but start a real conversation.

FSBO details:
- Property address: [ADDRESS]
- How I found them: [e.g., Zillow FSBO listing, yard sign, public MLS entry]
- Any info about the property or their situation: [e.g., "I noticed the listing has been up for about 3 weeks" / "I see you're asking $X, which is right in the range of recent sales in your area"]
- My legitimate value to them: [e.g., I have buyer clients who might be interested / I can share what buyers in this price range are looking for / I can provide a free CMA to make sure they're priced right]
- My name: [YOUR NAME]
- My phone: [PHONE]

Requirements:
- Length: 120-160 words (email version) and 80-100 words (handwritten note or door knock leave-behind version)
- Tone: respectful, helpful, zero condescension — don't imply they can't do it themselves
- DO NOT pitch them to list with you in the first contact
- Offer something genuinely valuable with no strings attached
- Acknowledge that they're trying to save commission — don't fight it
- Position yourself as a resource, not a competitor
- End with an easy, low-pressure CTA
```

---

**FSBO Outreach — Second Touch (Value-First Follow-Up)**
*When to use: Following up with a FSBO after your first contact — offering tangible value.*

```
Write a second-touch follow-up to a FSBO homeowner who I contacted a week ago. They haven't listed yet. I want to provide real value without pitching for the listing.

Details:
- FSBO's name (if known): [NAME or "homeowner"]
- Property address: [ADDRESS]
- Time since first contact: [APPROXIMATELY 1 WEEK]
- Value I'm offering this time: [e.g., "I have a buyer client actively looking in your price range" / "I pulled the recent comps and wanted to share what homes near you actually sold for" / "I noticed a small thing in your listing photos that might be costing you showings"]
- My name: [YOUR NAME]

Requirements:
- Length: 100-140 words
- Tone: helpful colleague, not salesperson
- Lead with the value, not with yourself
- Make the offer concrete and specific
- If you have a buyer, don't oversell it — just make a genuine introduction
- No pressure, no urgency tactics
- Easy reply CTA
```

---

**Expired Listing Outreach — First Contact**
*When to use: Reaching out to a homeowner whose listing just expired on the MLS.*

```
Write a first-contact message to a homeowner whose listing just expired. This person is frustrated and has already been approached by every agent in town. Stand out by leading with empathy and insight, not a pitch.

Details:
- Homeowner's name (if available): [NAME or "homeowner"]
- Property address: [ADDRESS]
- Days on market before expiring: [APPROXIMATELY]
- Price it was listed at: [$PRICE] (if known)
- What you know or suspect went wrong (choose what applies): [e.g., overpriced for the market / poor marketing / photos were not professional / limited showing times]
- What you would do differently: [YOUR STRATEGY — keep it brief for the first touch]
- My name: [YOUR NAME]
- My phone: [PHONE]

Requirements:
- Length: 150-200 words (letter/email) and a 60-80 word text option
- Tone: empathetic and confident — acknowledge the frustration without piling on their prior agent
- Do NOT trash the previous agent
- Lead with what you know about WHY it didn't sell — show insight, not just interest
- Offer a specific conversation, not just "I'd love to help"
- End with a direct but low-pressure ask to talk
```

---

**Expired Listing Letter — In-Depth**
*When to use: A longer outreach letter for an expired listing — for direct mail or door-knocking leave-behind.*

```
Write a one-page letter to a homeowner whose listing recently expired. This is for direct mail or a door-knocking leave-behind — it needs to be compelling enough to make them call me.

Details:
- Property address: [ADDRESS]
- Approximate DOM before expiring: [NUMBER]
- What you know about the property: [any observations from the public listing — price, photos, features]
- Market context: [e.g., "In [AREA], the average DOM is X days. Homes priced and marketed correctly are selling."]
- Your differentiators: [e.g., professional photography, 3D tours, aggressive digital marketing, proven pricing strategy, your specific track record in their area]
- Proof point: [e.g., "I sold X homes in [NEIGHBORHOOD] last year, averaging Y days on market"]
- Your name: [YOUR NAME]
- Your brokerage: [BROKERAGE]
- Your phone: [PHONE]

Requirements:
- Length: 300-380 words (one page)
- Tone: confident, empathetic, proof-forward — not humble, not arrogant
- Address the elephant in the room (it didn't sell — here's why, here's what I'd do differently)
- Do not list 20 things — give them 3 clear differentiators that matter
- End with a strong, direct CTA and deadline-adjacent urgency (while the market is still [active / transitioning / etc.])
```

---

## PHONE SCRIPTS

---

**Cold Call Script — Absentee Owner / Investor**
*When to use: Calling absentee property owners or investors in your target market.*

```
Write a cold call script for reaching out to an absentee property owner or real estate investor about potentially selling one of their properties.

Details:
- Property address you're calling about: [ADDRESS]
- Owner's name: [NAME]
- What you know: [e.g., they've owned the property for X years, it's a rental, it's vacant, it was recently inherited]
- Your market knowledge: [e.g., "properties on that street have sold quickly at strong prices lately" / "investors are actively buying in that zip code"]
- Your name: [YOUR NAME]
- Your brokerage: [BROKERAGE]
- Your phone: [PHONE]

Requirements:
- Length: Full script, 250-350 words
- Format: [OPENER] → [REASON FOR CALL] → [VALUE STATEMENT] → [DISCOVERY QUESTIONS] → [OBJECTION RESPONSES] → [CLOSE / NEXT STEP]
- Tone: confident, conversational, not robotic — this should sound like a real person made it
- Include 2-3 common objections and suggested responses (e.g., "I'm not interested in selling" / "I already have an agent" / "What do you know about the value?")
- The goal is not to get a listing on the first call — it's to get a conversation or a follow-up
```

---

**Voicemail Script — Prospecting**
*When to use: Leaving a voicemail for a cold or warm prospect — make it worth calling back.*

```
Write 3 voicemail scripts for different prospecting scenarios. Voicemails need to be short, create mild curiosity, and give a reason to call back.

Scenarios:
1. First-time voicemail to a cold prospect (absentee owner, FSBO, or expired)
2. Follow-up voicemail after no response to first outreach
3. Warm lead (they registered on your website or inquired previously) — follow-up voicemail

Details for all three:
- Your name: [YOUR NAME]
- Your phone number: [PHONE]
- Market area: [CITY/AREA]
- The one reason they should call back: [e.g., "I have info about a recent sale near your property that might surprise you" / "I have a buyer looking for exactly your type of property" / "There's a quick update about the [NEIGHBORHOOD] market I think you'd want to know"]

Requirements:
- Each voicemail: 40-60 seconds when read aloud (approximately 80-110 words)
- Tone: confident and calm — never desperate or salesy
- Never say "I'm just calling to follow up" — give them a specific reason to call back
- End with your name and number said twice (clearly and slowly)
- Label each script with the scenario
```

---

**Review Request — Phone/Text Script**
*When to use: Asking a past client for a review over the phone or via text — a verbal or text request often outperforms email.*

```
Write a natural, conversational review request script — both a phone conversation version and a text message version.

Details:
- Client's name: [NAME]
- Platform you want the review on: [Google / Zillow / Realtor.com]
- Review link: [LINK]
- What you helped them accomplish: [e.g., "we got you $X over asking" / "found your home in a tough market" / "navigated a really complex transaction"]
- Your name: [YOUR NAME]

Requirements for phone script:
- Length: 80-120 words
- Natural conversation flow — not a monologue
- Ask permission first ("I have a quick favor to ask...")
- Make it easy ("it literally takes 2 minutes and the link is super simple")
- Offer to text the link while they're on the phone
- Include response if they say they'd be happy to (confirm next steps) and if they hesitate (handle gracefully)

Requirements for text:
- 60-80 words max
- Send after the phone call as a follow-through
- Include the link prominently
- Make the ask specific ("Even just 2-3 sentences would mean the world")
- Grateful, low-pressure, genuine
```

---

**Zillow / Realtor.com Profile Bio**
*When to use: Writing or updating your Zillow agent profile bio — a critical first impression for buyers and sellers researching agents.*

```
Write a Zillow agent profile bio for [AGENT NAME]. This bio needs to rank for local search terms while also sounding like a real human being wrote it.

Details:
- Agent name: [YOUR NAME]
- Markets served: [CITIES/ZIP CODES]
- Specialty: [e.g., buyer representation, listings, luxury, first-time buyers, investment]
- Years of experience: [NUMBER]
- Volume or rankings: [e.g., sold $X last year / top X% of agents in [AREA] / X+ transactions]
- Languages spoken (if applicable): [LANGUAGES]
- Certifications: [e.g., ABR, SRES, CRS, SRS]
- Brokerage: [BROKERAGE]
- One personal connection to the market: [e.g., born and raised in [CITY] / lived here for X years / own investment properties in the area]
- Client philosophy in one sentence: [e.g., "I treat every client like they're the only one I have"]

Requirements:
- Length: 200-280 words
- Written in third person
- First paragraph: establish market expertise and volume naturally
- Second paragraph: specialty and what makes you different
- Third paragraph: personal connection and client philosophy
- Naturally include the city/area names multiple times (for search ranking) without it feeling keyword-stuffed
- End with a direct invitation to reach out
- Avoid: "passionate," "dedicated," "hardworking," "goes above and beyond"
```

---

## TEAM & BROKERAGE

---

**Agent Recruiting Message**
*When to use: Reaching out to an agent you want to recruit to your team or brokerage.*

```
Write a recruiting message to a real estate agent I'd like to recruit to [MY TEAM / MY BROKERAGE]. This person is currently active at another brokerage. My goal is to start a conversation, not sell them immediately.

Details:
- Recruit's name: [NAME]
- What I know about them: [e.g., they're in the top X% of their office, they specialize in [AREA], we've interacted on a few deals, mutual connection referred them]
- My team/brokerage name: [NAME]
- What I genuinely offer: [e.g., higher splits, better leads, training and mentorship, team environment, specific tech or tools, more marketing support]
- One specific thing about them that made me want to reach out: [BE SPECIFIC — not generic flattery]
- My name: [YOUR NAME]

Requirements:
- Length: 120-160 words (email or LinkedIn message)
- Tone: collegial, direct, respectful of their current position
- Lead with the specific observation about them — show you did your homework
- Do NOT lead with your compensation package or split structure
- Frame the conversation as an exploration ("I'd love to buy you coffee and share what we're building...")
- Zero pressure — make it easy to say no and also easy to say yes
- Subject line: 3 options (email version)
```

---

**Team Introduction Email — New Agent Onboarding**
*When to use: Welcoming a new agent to your team and introducing them to the database and sphere.*

```
Write a team introduction email to send to my database introducing a new agent who has joined our team. This should build credibility for the new agent and reinforce our team's growth.

Details:
- New agent's name: [NAME]
- Background: [e.g., X years of experience, comes from [PREVIOUS BROKERAGE / CAREER], specializes in [AREA/NICHE]]
- Why you're excited to have them: [GENUINE REASON]
- What they'll be helping with: [e.g., buyer consultations, listings in [AREA], investor clients]
- Team/brokerage name: [YOUR TEAM NAME]
- Your name: [YOUR NAME]

Requirements:
- Length: 160-220 words
- Tone: excited, personal, team-forward
- Briefly introduce [NEW AGENT NAME] like you'd introduce a friend — with warmth and specificity
- Reinforce that the team's clients continue to get excellent service
- Include a soft mention of what the team can help them with
- CTA: invite replies, questions, or referrals to the new agent
```

---

**Performance Review / Goal-Setting Summary**
*When to use: Summarizing a quarterly or annual performance review for yourself or a team member — turning your numbers into a narrative.*

```
Act as a business advisor. Write a professional performance summary and goal-setting narrative based on the following metrics. This will be used as a personal accountability document and/or team review.

Performance data:
- Period: [Q1 2025 / Full Year 2024 / etc.]
- Agent/team name: [NAME]
- Transactions closed: [NUMBER]
- Total sales volume: [$AMOUNT]
- Average sale price: [$AMOUNT]
- New listings taken: [NUMBER]
- Buyers represented: [NUMBER]
- Average days on market for listings: [NUMBER]
- List-to-sale price ratio: [%]
- New leads generated: [NUMBER]
- Conversion rate (leads to clients): [%]
- Reviews received: [NUMBER] | Average rating: [X/5]
- Top performing lead source: [SOURCE]
- Biggest challenge this period: [DESCRIBE]
- Biggest win this period: [DESCRIBE]
- Goals for next period: [LIST 3-4 GOALS]

Requirements:
- Length: 350-450 words
- Tone: honest, analytical, forward-looking
- Section 1: Results summary (what happened)
- Section 2: What worked and why
- Section 3: Where the gaps are
- Section 4: Priority goals for next period with brief rationale
- Write in first person — this is the agent's own voice
- Be direct about underperformance without being harsh
- End on a genuinely motivated, action-oriented note
```

---

*Next: `06-workflow-sops.md` → 5 complete step-by-step workflows for using AI in your business*
