# 04 — Marketing Prompts
### 20 AI Prompts for Social Media, Agent Bio, Email Newsletters & Video Scripts

---

> Use these prompts to batch your monthly content in one sitting, build your personal brand, and show up consistently without burning out.

---

## INSTAGRAM CAPTIONS

---

**New Listing Instagram Caption**
*When to use: Announcing a new listing on Instagram — should stop the scroll and drive DMs or saves.*

```
Act as a real estate social media strategist. Write an Instagram caption for a new listing announcement that stops the scroll, communicates the key details, and drives DMs or link-in-bio clicks.

Listing details:
- Property type: [e.g., 4-bed craftsman, downtown condo, lakefront cabin]
- Location/neighborhood: [AREA]
- Price: [$PRICE]
- Top 3 visual features (what looks amazing in photos): [LIST]
- One emotional hook: [e.g., "backyard built for summer entertaining" / "work from home with this view" / "first home vibes in a forever home"]
- Call to action: [e.g., "DM me for a private showing" / "Link in bio for full details" / "Comment 'INFO' and I'll send details"]
- Your name/handle: [@HANDLE]

Requirements:
- Length: 100-160 words
- Open with a hook (not "Just listed!" — everyone does that)
- Use 2-3 line breaks for readability on mobile
- Include key details naturally in the copy (not as a spec list)
- Emojis: 3-6 max, placed strategically — not randomly
- End with CTA
- Hashtag block: 15-20 relevant hashtags in a separate comment (provide these too) — mix of local, neighborhood, property type, lifestyle
```

---

**Just Sold Instagram Caption**
*When to use: Celebrating a closed transaction — social proof, momentum, and authority building.*

```
Write an Instagram caption celebrating a just-sold property. This should build credibility, celebrate the clients (without oversharing personal details), and position you as the agent to call.

Sale details:
- Property type and area: [TYPE in AREA]
- Sold price (optional — include if it's impressive): [$PRICE or omit]
- Days on market: [NUMBER or "in under [X] days"]
- Any impressive stats: [e.g., sold $22K over asking / 6 offers received / sold in 4 days]
- Brief client story (anonymized): [e.g., "this family was ready for more space" / "my sellers needed to move fast for a job relocation"]
- Your name/handle: [@HANDLE]

Requirements:
- Length: 100-150 words
- Lead with the result, not the property
- Tell a mini-story (setup → challenge/goal → result)
- Include a line that speaks to future sellers: what could you do for someone reading this?
- CTA: encourage sellers considering a move to reach out
- 15 hashtags in a separate comment
```

---

**Market Update Instagram Caption**
*When to use: Sharing local market data to position yourself as the area expert.*

```
Write an Instagram caption sharing local real estate market data in a way that's interesting and useful to homeowners and buyers — not dry or technical.

Market data:
- Area: [CITY/NEIGHBORHOOD]
- Time period: [e.g., February 2025, Q1 2025]
- Key stat #1: [e.g., "median home price is $X, up X% from last year"]
- Key stat #2: [e.g., "average days on market: X days"]
- Key stat #3: [e.g., "X% of homes sold above asking price"]
- What this means for buyers: [YOUR INTERPRETATION]
- What this means for sellers: [YOUR INTERPRETATION]
- Source: [e.g., MLS data, local association report]
- Your name/handle: [@HANDLE]

Requirements:
- Length: 120-180 words
- Lead with the most surprising or interesting stat — make them stop
- Translate data into plain language (what does it mean for a real person?)
- Position yourself as the interpreter, not just a data reporter
- End with an offer to answer questions or DM for a personalized update
- Include hashtags block (local market + real estate education focused)
```

---

**Personal Brand / Behind the Scenes Instagram Caption**
*When to use: Humanizing your brand — sharing your story, your why, or a day in your life.*

```
Write an Instagram caption for a personal brand post that gives followers a glimpse behind the scenes and builds an authentic connection.

Details:
- Topic: [e.g., why I became a real estate agent, what a typical Tuesday looks like, the hardest part of my job, what I love about this neighborhood, a mistake I made early in my career]
- Key message or takeaway: [e.g., "this job isn't glamorous but it's the most rewarding thing I've done" / "I care about every client like they're family"]
- Anything personal you're comfortable sharing: [e.g., "I grew up in this city" / "I have 2 kids and they're why I hustle" / "I left corporate America to do this"]
- Your name/handle: [@HANDLE]

Requirements:
- Length: 120-200 words
- Tone: genuine, first-person, vulnerable without oversharing
- Start with a specific moment or observation, not a statement about yourself
- Let the insight or lesson emerge naturally from the story
- Don't make it a pitch — the relationship IS the marketing
- End with a question to drive comments (e.g., "What made you choose your career?")
- 10-12 hashtags, personal brand focused
```

---

**Open House Reminder Caption**
*When to use: Day-of or day-before reminder for an upcoming open house.*

```
Write a fun, inviting Instagram caption reminding followers about this weekend's open house.

Details:
- Property description: [QUICK DESCRIPTION — e.g., a beautifully updated 3-bed in [NEIGHBORHOOD]]
- Date and time: [DAY, DATE, TIME RANGE]
- Address: [FULL ADDRESS]
- One irresistible feature to mention: [e.g., the backyard is stunning / the kitchen was just renovated / incredible views]
- Refreshments or special touch (if any): [e.g., coffee and pastries / wine and cheese / kids activities outside]
- Your name/handle: [@HANDLE]

Requirements:
- Length: 80-120 words
- Tone: inviting, fun, low pressure — like you're hosting a party, not a sales event
- Make people WANT to come, even if they're just curious
- Include all logistics clearly
- End with a "bring a friend" line — more foot traffic is always better
- 10-15 hashtags
```

---

## FACEBOOK POSTS

---

**Facebook Listing Post — Detailed**
*When to use: Sharing a new listing on Facebook where longer copy performs better than on Instagram.*

```
Write a Facebook post for a new listing that's longer and more detailed than an Instagram caption. Facebook audiences respond to storytelling and detail.

Listing details:
- Property type: [TYPE]
- Address: [ADDRESS]
- Bedrooms: [NUMBER] | Bathrooms: [NUMBER] | Square footage: [SQ FT]
- Price: [$PRICE]
- Key features (list 6-8): [FEATURES]
- Neighborhood/location highlights: [LOCAL HIGHLIGHTS]
- Open house (if scheduled): [DATE, TIME]
- Who is this home perfect for: [TARGET BUYER e.g., growing family, first-timer, investor]
- Your name: [YOUR NAME]
- Your phone/email/link: [CONTACT]

Requirements:
- Length: 200-280 words
- Tone: enthusiastic but informative — like sharing an exciting find with friends
- Open with a compelling question or statement that hooks the reader
- Use line breaks every 2-3 sentences for readability
- Include property details in flowing prose, not a bullet list
- Add scheduling or inquiry CTA at the end
- Suggest: 5-8 hashtags maximum (Facebook doesn't need the hashtag wall)
```

---

**Facebook Community Content Post**
*When to use: Posting non-listing content that builds your local brand and drives organic engagement.*

```
Write a Facebook post about something happening in the local community. This is not a listing or a sales post — it's content that shows I'm plugged into and care about this area.

Details:
- Community topic: [e.g., new restaurant opening in [NEIGHBORHOOD], upcoming farmers market season starting, local school winning a championship, new park development approved]
- Your connection to it: [e.g., "I walked by last week and had to try it" / "my kids go to this school" / "this is why I love living and working in [CITY]"]
- Any relevant real estate angle (optional, keep subtle): [e.g., "this is one of the many reasons [NEIGHBORHOOD] home values have been climbing" — or omit entirely]
- Your name: [YOUR NAME]

Requirements:
- Length: 100-160 words
- Tone: local resident, not real estate agent — neighborly and enthusiastic
- Share genuine enthusiasm for the community
- End with a question to spark comments (e.g., "Have you tried it yet?" or "What's your favorite spot nearby?")
- Zero hard sell — the brand building happens naturally
```

---

## LINKEDIN POSTS

---

**LinkedIn Market Insight Post**
*When to use: Positioning yourself as a market expert with professional buyers, sellers, executives, and relocation clients.*

```
Write a LinkedIn post sharing a real estate market insight. My LinkedIn audience includes professionals, executives, and people who might be considering relocation or investment.

Insight details:
- Topic: [e.g., current buyer demand in [CITY], impact of interest rates on local inventory, why [NEIGHBORHOOD] is outperforming the market, what corporate relocation clients need to know about [CITY]]
- Key data point or observation: [SPECIFIC DATA OR INSIGHT]
- Professional angle: [e.g., what this means for executives considering a move / what investors should know / how corporate relocation buyers can compete in today's market]
- Your expertise/background: [e.g., "As an agent specializing in [AREA] for [X] years..."]
- Your name: [YOUR NAME]

Requirements:
- Length: 200-300 words
- Tone: professional, analytical, confident — like a market expert sharing a POV
- Lead with the insight, not your bio
- Support with specific data or observation
- End with an invitation to connect or have a conversation — not a hard pitch
- LinkedIn format: short paragraphs, no bullet lists in the opening, use them only to support a point
- 3-5 professional hashtags
```

---

**LinkedIn Agent Introduction Post**
*When to use: New to LinkedIn or refreshing your LinkedIn presence — introducing yourself to your professional network.*

```
Write a LinkedIn introduction post for a real estate agent. This should establish expertise, tell the professional story, and invite connections without being a resume.

Details:
- Your name: [NAME]
- Markets you serve: [CITIES/AREAS]
- Years of experience: [NUMBER]
- Specialty or niche: [e.g., luxury homes, first-time buyers, investment properties, relocation, commercial]
- Professional background before real estate (if applicable): [e.g., 10 years in corporate finance / former teacher / military background]
- Why you love this work: [YOUR GENUINE REASON]
- What you can help your network with: [e.g., buying, selling, investing, relocation, referrals to your market]
- Your brokerage: [BROKERAGE NAME]

Requirements:
- Length: 200-280 words
- Tone: professional, personal, confident — not a job application
- Lead with your market/specialty, not your years of experience
- Tell the story of why you do this work in 2-3 sentences
- End with a clear offer to help and an invitation to connect
- No bullet list of services — keep it conversational
```

---

## AGENT BIO

---

**Agent Bio — Short Version (100-150 words)**
*When to use: Zillow, Realtor.com, website bio box, email signature, marketing materials.*

```
Write a short professional bio for a real estate agent. This version is for Zillow, websites, and marketing collateral — it needs to establish credibility fast and feel human.

Agent details:
- Name: [YOUR NAME]
- Market/area: [CITY/AREA]
- Years of experience: [NUMBER]
- Specialty: [e.g., first-time buyers, luxury, investment, relocation]
- Brokerage: [BROKERAGE NAME]
- Notable achievements (pick 1-2 max): [e.g., top 5% of agents in [AREA], sold $X in volume last year, X transactions]
- Personal touch: [e.g., lifelong [CITY] resident, mother of 3, former [PROFESSION], outdoor enthusiast]
- What clients say about working with you (in your own words): [e.g., "my clients say I make a stressful process feel manageable"]

Requirements:
- Length: 100-150 words
- Written in third person
- Lead with market expertise, not tenure
- One sentence of personality/personal connection at the end
- Do NOT use: "passionate," "dedicated," "hardworking," "goes above and beyond"
- Sound like a trusted expert, not a resume
```

---

**Agent Bio — Long Version (300-400 words)**
*When to use: Website About page, listing presentation, press features, or detailed platform profiles.*

```
Write a full-length professional bio for a real estate agent's website About page. This is where potential clients are making a decision about whether to hire this person.

Agent details:
- Name: [YOUR NAME]
- Market/area: [CITY/AREA]
- Years of experience: [NUMBER]
- Brokerage: [BROKERAGE NAME]
- Specialty/niche: [SPECIALTY]
- Volume or transaction highlights: [e.g., closed $X in sales volume, X+ transactions, consistently ranked top X%]
- Professional background: [BACKGROUND — education, previous career, certifications like ABR, CRS, etc.]
- Community involvement: [e.g., board member of [ORG], volunteers at [CAUSE], coaches youth sports]
- Personal details: [e.g., born and raised in [CITY], married with X kids, loves [HOBBY]]
- Client experience philosophy: [HOW DO YOU WORK WITH CLIENTS — what can they expect from you?]
- Why you love this work: [YOUR GENUINE ANSWER]

Requirements:
- Length: 300-400 words
- Written in third person
- Structure: expertise/background → niche and results → community → personal → philosophy → call to action
- Avoid clichés: no "dream home," "passionate," "dedicated," "hardworking"
- Should feel like a profile of a trusted advisor, not a billboard
- End with a personal invitation to connect
```

---

## EMAIL NEWSLETTER

---

**Monthly Email Newsletter**
*When to use: Sending a monthly email to your database — past clients, prospects, and sphere.*

```
Act as a real estate email newsletter writer. Write a monthly newsletter email that's actually worth reading — not a data dump, not pure promotion.

Newsletter details:
- Month/Season: [MONTH, YEAR]
- Agent name: [YOUR NAME]
- Market area: [CITY/AREA]
- Market update (1-2 key takeaways): [e.g., inventory is up 12% from last year / buyer demand remains strong despite rate increase / median price in [AREA] is $X]
- Feature story or tip: [e.g., "3 small upgrades that added $20K to my listing's sale price" / "Is now a good time to sell in [CITY]?" / "How to buy a home in a competitive market"]
- Local happenings (1-2 items): [e.g., new restaurant opening, upcoming community event, local school news]
- Personal note (optional): [e.g., "I just hit 10 years in real estate" / "my team is growing" / something personal but professional]
- Any listings or recent sales to feature: [DETAILS or N/A]
- CTA: [e.g., book a call, reply to this email, referral ask, free home valuation]

Requirements:
- Subject line: write 3 options
- Length: 400-550 words total (short sections, high readability)
- Format: greeting → market pulse (2 short paragraphs) → feature story/tip (main section) → local life (1 paragraph) → personal note → CTA
- Tone: knowledgeable neighbor, not mass marketer
- Use first person, conversational language
- Every section should give value, not just fill space
```

---

**Email Drip — Educational Sequence (Single Email)**
*When to use: Part of an automated nurture sequence for buyers or sellers who aren't ready yet.*

```
Write one educational email for a [BUYER / SELLER] nurture drip sequence. This person isn't ready to transact yet but is thinking about it. The goal is to educate, build trust, and stay top of mind.

Details:
- Sequence type: [BUYER SEQUENCE / SELLER SEQUENCE]
- Email number in sequence: [e.g., Email 2 of 4]
- Topic for this email: [e.g., "How to read a home inspection report" / "What affects your home's appraised value" / "The difference between pre-qualified and pre-approved" / "How to price your home correctly the first time"]
- Audience: [e.g., first-time buyers / move-up buyers / homeowners thinking of selling in the next 6-12 months]
- Your name: [YOUR NAME]

Requirements:
- Subject line: 3 options (one question, one how-to, one bold statement)
- Length: 300-400 words
- Tone: teacher/advisor — not salesperson
- Open with a relatable scenario or question your reader is probably asking
- Give genuinely useful information — don't tease and withhold
- End with a soft CTA (reply with questions, book a free call, download a resource)
- PS line: a brief, personal one-liner that reinforces the relationship
```

---

## VIDEO SCRIPTS

---

**YouTube/Long-Form Video Script**
*When to use: Recording a 5-10 minute educational or neighborhood video for YouTube or your website.*

```
Act as a real estate video scriptwriter. Write a complete YouTube video script for a [NEIGHBORHOOD TOUR / MARKET UPDATE / HOW-TO / HOME BUYING GUIDE] video.

Video details:
- Video topic: [SPECIFIC TOPIC — e.g., "Is [NEIGHBORHOOD] a good place to live in 2025?" / "How to buy a home with 3% down" / "[CITY] real estate market update — what buyers and sellers need to know"]
- Target viewer: [e.g., people considering moving to [CITY] / first-time buyers / homeowners thinking of selling]
- Key points to cover (3-5): [LIST YOUR MAIN POINTS]
- Your name and market: [NAME, CITY]
- Call to action at end: [e.g., subscribe, comment, book a free consultation, download a guide]

Requirements:
- Format: [HOOK] → [INTRO] → [MAIN CONTENT - 3-5 sections] → [OUTRO + CTA]
- Length: 700-900 words (approximately 5-7 min at normal speaking pace)
- Hook: first 30 seconds must be compelling — tease the payoff before the intro
- Tone: conversational, authoritative, like talking to a friend who happens to be a real estate expert
- Label each section clearly so it's easy to record in segments
- Include pauses, notes for B-roll (footage to show), and any on-screen text suggestions in brackets
```

---

**Educational Instagram/Facebook Reel Script**
*When to use: Short-form educational video for social — "did you know" style content that establishes expertise.*

```
Write a script for a 45-60 second educational real estate video for Instagram Reels or Facebook. This should teach something genuinely useful and position me as the expert.

Details:
- Topic: [e.g., "3 things sellers do that cost them money" / "Why your Zestimate is wrong" / "What earnest money actually means" / "How to win in a multiple offer situation"]
- Target audience: [BUYERS / SELLERS / HOMEOWNERS / ALL]
- Your name: [YOUR NAME]
- CTA at end: [e.g., "Follow for more tips" / "DM me your questions" / "Comment with your question"]

Requirements:
- Format: [HOOK LINE] → [3 quick points or 1 explained point] → [CTA]
- Total length: 80-130 words
- Hook must work as text overlay and voiceover simultaneously
- Every sentence must be short and punchy (max 10 words)
- Format as: [SHOT/ACTION] | SPOKEN WORDS | TEXT OVERLAY
- Suggest a trending audio style (not specific song — just energy/vibe)
- The viewer should learn something actionable in under 60 seconds
```

---

## EDUCATIONAL & AUTHORITY-BUILDING POSTS

---

**FAQ Post — Buyer Question**
*When to use: Answering a common buyer question in a carousel, caption, or video — establish expertise.*

```
Write a social media post answering a common buyer question in a way that's clear, useful, and positions me as the expert to hire.

Details:
- Question: [e.g., "How much do I really need for a down payment?" / "Should I sell before buying?" / "What's the difference between a buyer's agent and a listing agent?" / "Is it a good time to buy right now?"]
- Platform: [INSTAGRAM CAROUSEL / FACEBOOK POST / LINKEDIN / EMAIL]
- My answer/perspective: [YOUR ACTUAL ANSWER — the AI will format it, but give your genuine take]
- Your name: [YOUR NAME]

Requirements:
- If carousel: write 7-8 slides (1 hook slide, 5-6 content slides, 1 CTA slide) — each slide is 15-20 words max
- If post: 150-200 words, conversational tone
- Lead with the question or a surprising truth about the topic
- Give a real, complete answer — not a tease that requires hiring you to get the answer
- End with what THEY should do with this info + a CTA
```

---

**Authority-Building "Myth vs. Reality" Post**
*When to use: Correcting common real estate misconceptions — high engagement, builds trust.*

```
Write a "myth vs. reality" social media post debunking a common real estate misconception.

Details:
- Myth to bust: [e.g., "You need 20% down to buy a home" / "Spring is always the best time to sell" / "You should always price high and come down" / "The listing agent works for both buyer and seller equally"]
- The reality: [YOUR ACCURATE EXPLANATION]
- Why this myth persists: [e.g., it was true decades ago / people hear it from parents / media perpetuates it]
- What buyers/sellers should do instead: [PRACTICAL TAKEAWAY]
- Platform: [INSTAGRAM / FACEBOOK / LINKEDIN]
- Your name: [YOUR NAME]

Requirements:
- Format for carousel: Slide 1: "MYTH: [STATEMENT]" → Slides 2-4: break down the myth → Slide 5: "REALITY: [TRUTH]" → Slide 6: practical takeaway → Slide 7: CTA
- Format for single post: 150-200 words, lead with the myth statement as a question or bold claim
- Tone: confident, educational, not condescending to people who believed the myth
- End with an invitation to ask their most common real estate question in the comments
```

---

*Next: `05-business-operations-prompts.md` → 15 prompts for CMAs, outreach, cold calling & more*
