# 06 — Workflow SOPs
### 5 Complete Step-by-Step Workflows for Using AI in Your Real Estate Business

---

> These workflows tell you exactly which prompts to use, in what order, and what to do with the output. Follow them and you'll have a system, not just a collection of tools.

---

## WORKFLOW 1: New Listing in 30 Minutes
### From Property Features → Live Marketing Content in One Sitting

**When to run this workflow:** Every time you take a new listing and are ready to go live.

**What you'll create:**
- MLS description
- 3 listing headlines
- Coming soon social post (if applicable)
- New listing Instagram caption
- New listing Facebook post
- Email announcement for your database
- Open house announcement (if applicable)

**Total time: 25-35 minutes**

---

### Before You Start — Gather Your Inputs (5 min)

Have the following ready before opening your AI tool:
- [ ] Property fact sheet / MLS input sheet
- [ ] List of 6-10 standout features (be specific — "white oak hardwood floors" not "nice floors")
- [ ] Recent updates and their approximate year
- [ ] Neighborhood highlights (schools, walkability, commute)
- [ ] Asking price
- [ ] Open house date/time (if scheduled)
- [ ] 2-3 target buyer types for this property
- [ ] Your Instagram handle and contact info

---

### Step 1: MLS Description (8 min)

Open a **new chat** in ChatGPT or Claude.

1. Go to `02-listing-prompts.md`
2. Choose the right prompt based on property type:
   - Standard home → **"Standard MLS Description — Single Family Home"**
   - Luxury ($750K+) → **"Luxury Property MLS Description"**
   - Needs work → **"Fixer-Upper / Value-Add MLS Description"**
   - Multi-family → **"Investment / Income Property Description"**
   - Condo/townhome → **"Condo / Townhome MLS Description"**
3. Fill in every bracket with your property details
4. Paste into AI. Read the output.
5. Make edits: add 2-3 hyper-local details the AI couldn't know (specific school name, nearby landmark, neighborhood vibe)
6. Copy the final version to your MLS input sheet or clipboard.

**Output:** Your MLS remarks, ready to input.

---

### Step 2: Headlines (3 min)

In the **same chat window**, paste this follow-up:

```
Based on the property description you just wrote, generate 5 compelling listing headlines for this home — mix of emotional, feature-forward, and location-based. Under 12 words each. No clichés.
```

Review the 5 options. Choose 1 for your Zillow title. Save 2 others for social posts.

**Output:** Listing headline for Zillow/MLS, 2 headlines for social use.

---

### Step 3: Instagram Caption (5 min)

Open a **new chat** (fresh context = better output).

1. Go to `04-marketing-prompts.md`
2. Use **"New Listing Instagram Caption"**
3. Fill in all brackets
4. Run it. Review.
5. Edit: check that the hook is strong (not "Just listed!"), confirm the CTA matches how you want them to contact you.

**Output:** Instagram caption + hashtag block ready to post.

---

### Step 4: Facebook Post (3 min)

In the **same chat**, paste this follow-up:

```
Now write a Facebook version of this listing announcement. Longer and more descriptive — Facebook audiences respond to detail. Include the full address, all the key features, price, and an invitation to schedule a showing or attend the open house on [DATE, TIME].
```

Review and lightly edit. Copy and save.

**Output:** Facebook post ready to schedule or publish.

---

### Step 5: Database Email (7 min)

Open a **new chat**.

Paste this prompt:

```
Write a new listing announcement email to send to my real estate database (past clients, sphere, prospects). 

Property: [QUICK DESCRIPTION — beds, baths, sqft, area]
Key features: [TOP 4-5 FEATURES]
Price: [$PRICE]
Open house: [DATE AND TIME or N/A]
Link or how to get more info: [YOUR LISTING LINK OR CONTACT]
My name: [YOUR NAME]

Requirements:
- Subject line (3 options)
- Length: 180-240 words
- Tone: personal, like you're tipping off a friend to a great home
- Mention who would love this home (target buyer type)
- CTA: schedule a showing or attend the open house
```

Review, edit, and load into your email system (Mailchimp, Constant Contact, kvCORE, etc.)

**Output:** Email blast ready to send.

---

### Step 6 (Optional): Coming Soon Teaser (2 min)

If you have 3-7 days before going live:

1. Go to `02-listing-prompts.md`
2. Use **"Coming Soon Teaser"**
3. Post to Instagram Stories and your database

**Output:** Pre-launch buzz content.

---

### Checklist — Before You Close the Browser

- [ ] MLS description saved ✓
- [ ] Headline selected for Zillow ✓
- [ ] Instagram caption drafted and scheduled (or saved to drafts) ✓
- [ ] Facebook post drafted and scheduled ✓
- [ ] Database email drafted and scheduled ✓
- [ ] Coming Soon posted (if applicable) ✓

---

## WORKFLOW 2: Lead Follow-Up Sequence
### 4-Touch Email Series Over 21 Days

**When to run this workflow:** When a buyer or seller lead comes in and you want to set up an automated drip sequence, or when you're doing manual follow-up for a promising lead.

**What you'll create:**
- 4 emails over 21 days
- Each email has a different angle and value proposition
- The goal: book a consultation or get a response before day 21

**Best tool:** Run each email individually in a fresh Claude or ChatGPT session.

---

### The 4-Touch Framework

| Touch | Day | Purpose | Angle |
|-------|-----|---------|-------|
| Email 1 | Day 0 (same day) | First impression | Personal + value offer |
| Email 2 | Day 4 | Educational value | Teach something useful |
| Email 3 | Day 10 | Social proof | Share a relevant win |
| Email 4 | Day 21 | Permission close | Direct, honest, last touch |

---

### Email 1: Day 0 — First Impression (Same Day as Lead Arrives)

Go to `03-client-communication-prompts.md`:
- Buyer lead → use **"Buyer First Contact — Inbound Lead"**
- Seller lead → use **"Seller First Contact — Inbound Lead"**

Fill in brackets, run it, edit, send **within 5 minutes of the lead arriving.** Speed matters more than perfection on the first touch.

---

### Email 2: Day 4 — Educational Value

Open a new chat. Paste this prompt:

```
Write follow-up email #2 in a lead nurture sequence. This person responded to (or didn't respond to) my first email. Today I want to give them something genuinely useful — no pitch.

Lead type: [BUYER / SELLER]
What they're looking for: [THEIR STATED INTEREST]
Educational topic: [CHOOSE ONE:
  - For buyers: "The real timeline of buying a home in [CITY] right now" / "What you need to know about getting pre-approved" / "3 things buyers overlook in today's market"
  - For sellers: "How homes are priced in [CITY] right now" / "What buyers in your price range are looking for" / "The #1 reason listings sit on the market"]
My name: [YOUR NAME]

Requirements:
- Subject line: curiosity-driven, not salesy
- 200-280 words
- Lead with the educational topic, reference me briefly at the end
- End with a soft CTA: reply with questions or book a 15-min call
- Tone: helpful expert, zero pressure
```

---

### Email 3: Day 10 — Social Proof / Relevant Win

Open a new chat. Paste this prompt:

```
Write follow-up email #3 in a lead nurture sequence. I want to share a relevant recent success story that's similar to what this lead is trying to do.

Lead type: [BUYER / SELLER]
Their situation: [WHAT THEY WANT TO DO]
My relevant success story: [e.g., "I just helped a buyer win a home at asking price when there were 4 other offers" / "I just listed a home in [AREA] and sold it in 5 days above asking"]
One key reason we succeeded: [e.g., "we got a fully underwritten pre-approval" / "we priced it aggressively on day 1"]
My name: [YOUR NAME]

Requirements:
- Subject line: result-focused
- 180-240 words
- Tell the story briefly — setup, challenge, result, lesson
- Bridge to them: "Here's why this matters for you..."
- CTA: book a free 20-minute consultation
- Tone: confident, story-driven, warm
```

---

### Email 4: Day 21 — Permission Close

Go to `03-client-communication-prompts.md` and use **"Follow-Up After No Response — Cold Lead (2-Week)"** — or adapt the prompt below:

```
Write the 4th and final email in a lead nurture sequence. This person has not responded in 21 days. I want to be honest, give them an exit if they need it, and leave the door open.

Lead's name: [NAME]
What they originally inquired about: [CONTEXT]
My name: [YOUR NAME]

Requirements:
- Subject line: direct and honest (e.g., "Should I close your file?" / "Last check-in from me")
- 80-110 words
- Acknowledge they may have moved forward with someone else or changed plans — and that's okay
- Give them explicit permission to opt out
- If they ARE still looking, make it very easy to re-engage
- Confident, not desperate — this should read like it came from someone with a full client roster
```

---

### After the 4-Touch Sequence

If no response after Day 21:
- Move to quarterly "soft touch" using **"Holiday / Seasonal Check-In"** from `03-client-communication-prompts.md`
- Keep them on your monthly newsletter
- Set a CRM reminder to personally check in in 90 days

If they respond at any point: pause the sequence, have a real conversation, and move them into your active client workflow.

---

## WORKFLOW 3: Monthly Marketing Batch Session
### One 90-Minute Session = One Full Month of Content

**When to run this workflow:** First Monday of each month (or the last Friday of the previous month)

**What you'll create in one sitting:**
- 4 Instagram posts (1 per week)
- 2 Facebook posts
- 1 LinkedIn post
- 1 monthly email newsletter
- 1 educational Reel script

**Total time: 75-90 minutes**

---

### Prep Work (10 min)

Before your session, make a list:
1. **Recent transactions** to feature (sold, listed, pending)
2. **Market stat** you want to share this month (pull from your MLS or local association)
3. **Educational topic** you want to teach this month
4. **Local news or community item** happening in your area
5. **Personal story** or behind-the-scenes moment from the past 30 days

---

### Session Plan

**Block 1: Instagram Content (25 min)**

Run these 4 prompts from `04-marketing-prompts.md` in separate chat windows:

1. **Week 1** → "Just Sold Instagram Caption" (recent transaction)
2. **Week 2** → "Market Update Instagram Caption" (your market stat)
3. **Week 3** → "Educational FAQ Post — Buyer Question" or "Myth vs. Reality Post"
4. **Week 4** → "Personal Brand / Behind the Scenes Instagram Caption"

After generating all 4, schedule them in your scheduling tool (Later, Buffer, Meta Suite, etc.) — one per week.

---

**Block 2: Facebook & LinkedIn (20 min)**

1. **Facebook Post 1** → "Facebook Community Content Post" (local news item)
2. **Facebook Post 2** → If you have a new listing or recent sale, use **"Facebook Listing Post — Detailed"**. If not, repurpose the market update from Instagram into a longer Facebook version.
3. **LinkedIn Post** → "LinkedIn Market Insight Post" (use the same market stat, reframed for a professional audience)

---

**Block 3: Monthly Newsletter (25 min)**

Go to `04-marketing-prompts.md` and use **"Monthly Email Newsletter."**

Fill in:
- Your market update (from your MLS data)
- The educational topic you chose
- Your local community item
- Any listings or sales to feature

After generating, review carefully — newsletters require a bit more editing since they go to your whole list. Send through your email platform.

---

**Block 4: Reel Script (10 min)**

Go to `04-marketing-prompts.md` and use **"Educational Instagram/Facebook Reel Script."**

Pick a topic that complements your educational post. Film it this week or next — keep the content machine going.

---

### Content Calendar After Your Batch Session

| Week | Instagram | Facebook | LinkedIn | Email |
|------|-----------|----------|----------|-------|
| Week 1 | Just Sold | Community Post | — | Newsletter |
| Week 2 | Market Update | — | Market Insight | — |
| Week 3 | Educational | Listing/Sold | — | — |
| Week 4 | Personal Brand | Repurposed | — | — |

---

## WORKFLOW 4: Open House Follow-Up System
### Same-Day Outreach After Every Open House

**When to run this workflow:** Within 2 hours of your open house ending.

**Goal:** Follow up with every sign-in while the memory is fresh and the emotional response is high.

**What you'll create:**
- 3 different follow-up messages (hot lead, warm lead, cold/browse)
- 1 social post celebrating the open house turnout

---

### Step 1: Sort Your Sign-Ins (10 min)

Before running prompts, categorize every visitor:

- 🔥 **Hot**: showed strong interest, asked specific questions, asked about offers, stayed 20+ minutes
- 🌡️ **Warm**: engaged but non-committal, mentioned "still early in the search," took a card
- 🥶 **Cold**: walked through quickly, minimal conversation, may be neighbors or curious locals

---

### Step 2: Generate the Three Message Templates (15 min)

Open `03-client-communication-prompts.md` — **"After-Showing Follow-Up"** — and run it 3 times with different parameters:

**Hot Lead Version:**
```
Adapt the after-showing follow-up prompt for a hot lead who showed strong interest at our open house today. Include a natural question about their level of interest and a clear next step — scheduling a private showing or starting a conversation about an offer.

Open house property: [ADDRESS]
Their apparent interest: [WHAT THEY SAID OR DID]
Their contact: [NAME]
My name: [YOUR NAME]
```

**Warm Lead Version:**
```
Adapt the after-showing follow-up prompt for a visitor who seemed engaged but non-committal at our open house. Don't push. Just thank them, offer to answer questions, and keep the door open.

Open house property: [ADDRESS]
My name: [YOUR NAME]
```

**Cold/Neighbor Version:**
```
Write a brief, friendly thank-you note to someone who attended our open house but appeared to be a neighbor or early-stage looker. Make them feel welcome, no pressure, and subtly position me as their neighborhood real estate expert if they ever need one.

My name: [YOUR NAME]
Property/neighborhood: [AREA]
```

Personalize each template with the visitor's name and any notes from the day before sending.

---

### Step 3: Send All Follow-Ups (15 min)

Send all messages within 3 hours of the open house. Use text for most (higher open rates); use email for hot leads if they provided an email address.

---

### Step 4: Social Post (5 min)

Post to Instagram and/or Facebook while the open house is still fresh:

```
Write a post-open house Instagram caption. We had a great turnout today and I want to celebrate it while keeping things going for people who missed it.

Property: [BRIEF DESCRIPTION]
Turnout: [e.g., 14 groups came through / over 20 visitors / great energy today]
Still available: [yes — and here's how to schedule a private showing / or: offer deadline is [DATE]]
My name/handle: [@HANDLE]
```

---

### Step 5: Next Day — Hot Lead Follow-Up

For any hot lead who didn't respond within 24 hours, send one brief follow-up:

```
Write a next-day follow-up text to an open house visitor who showed strong interest but hasn't responded to my same-day message. Keep it short — just checking in and offering a next step.
```

---

## WORKFLOW 5: Seller Presentation Prep
### Using AI to Prepare for a Listing Appointment

**When to run this workflow:** 24 hours before a listing appointment.

**Goal:** Walk into the appointment prepared with custom content, a clear pricing story, and confident answers to common objections.

**What you'll create:**
- A personalized pre-listing email
- A CMA summary narrative (once you've run your numbers)
- Objection prep document
- Customized marketing plan description

---

### Step 1: Send a Pre-Listing Email (5 min)

Go to `05-business-operations-prompts.md` — **"Pre-Listing Presentation Email"**

Fill in the seller's name, property address, meeting time, and your one proof point. Send this 24 hours before the appointment. It sets professional expectations before you even walk in.

---

### Step 2: Run Your CMA (20 min, your work)

This is not AI work — this is your MLS expertise. Pull:
- 3 active comparable listings (currently on market)
- 3-5 sold comparables (last 90 days, closest match)
- Average DOM, list-to-sale ratio in their zip/neighborhood

Come to a pricing recommendation you believe in before you ask AI to help you explain it.

---

### Step 3: Write Your CMA Narrative (10 min)

Go to `05-business-operations-prompts.md` — **"CMA Summary for Sellers"**

Fill in all your comps and your recommendation. The AI will write a clear, professional narrative that walks the seller through the data and your recommendation in a way they can follow. Print this or use it in your presentation.

---

### Step 4: Prepare for Objections (10 min)

Open a new chat and run this prompt:

```
I'm going on a listing appointment tomorrow. Help me prepare for these common seller objections by giving me confident, empathetic, factual responses.

My recommended price: [$PRICE]
Their likely price expectation: [$HIGHER PRICE — if you know it]
Market conditions: [e.g., buyer's market / DOM averaging 45 days / prices have softened 3% in last 6 months]

Objections to prepare for:
1. "We want to try a higher price first and come down if needed."
2. "Another agent said they could get us $X more."
3. "We're not in a hurry — we can wait for the right buyer."
4. "We don't think we need professional photos / staging."
5. "We want to try it ourselves for 30 days first." (FSBO concern)

For each, give me: a 2-3 sentence empathetic acknowledgment, then a factual, confident redirect. Don't be aggressive — be the expert who helps them make a better decision.

My name: [YOUR NAME]
My market: [CITY/AREA]
```

Print this. Read it the night before. Know it cold.

---

### Step 5: Write Your Marketing Plan Summary (5 min)

Open a new chat:

```
Write a brief, compelling marketing plan summary I can present verbally and leave behind with a seller. This should show them the scope of what I'll do to market their home — not a bullet list of features, but a narrative that makes them excited about working with me.

My marketing approach includes:
- Professional photography: [YES / specify if you use video, drone, etc.]
- 3D virtual tour: [YES / NO]
- MLS exposure: [YES — including syndication to Zillow, Realtor.com, etc.]
- Social media promotion: [PLATFORMS — Instagram, Facebook, YouTube, etc.]
- Email database: [X number of buyers/sphere on my list]
- Open house: [YES / NO / if yes, typical approach]
- Network and agent outreach: [e.g., I'll email my network of X agents directly]
- Any paid digital advertising: [YES / NO / details]
- Anything unique to your approach: [e.g., staging consultation, neighborhood door-knocking, targeted Facebook ads in buyer demographics]

My name: [YOUR NAME]
My brokerage: [BROKERAGE]

Requirements: 200-260 words, narrative format, make it sound like a premium marketing service, not a checkbox list. The seller should feel like they're getting serious, high-level exposure.
```

---

### Pre-Appointment Checklist

- [ ] Pre-listing email sent ✓
- [ ] CMA completed and narrative written ✓
- [ ] Objection responses reviewed and memorized ✓
- [ ] Marketing plan summary ready ✓
- [ ] Comparable sold homes bookmarked in MLS (to show on tablet) ✓
- [ ] Listing agreement ready to print/e-sign ✓
- [ ] Your track record stats refreshed (days on market, list/sale ratio, recent solds nearby) ✓

---

*Next: `07-cheat-sheet.md` → Top 15 power prompts in quick-reference format*
