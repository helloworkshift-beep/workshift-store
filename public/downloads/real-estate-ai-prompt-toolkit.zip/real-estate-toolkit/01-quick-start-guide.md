# 01 — Quick Start Guide
### How to Use This Toolkit with ChatGPT & Claude (and Get Great Results Every Time)

---

## The 5-Minute Setup

You don't need to be a tech person. You don't need to pay for premium AI subscriptions (though they help). You just need a browser, 5 minutes, and one of these free tools open in a tab.

---

## Recommended AI Tools (All Free to Start)

### 🥇 ChatGPT — Best All-Around
**URL:** [chat.openai.com](https://chat.openai.com)
**Free tier:** GPT-3.5 unlimited, GPT-4o with daily limits
**Best for:** MLS descriptions, emails, social captions, scripts
**Tip:** Use GPT-4o whenever possible. The quality jump over GPT-3.5 is significant for real estate copy.

### 🥈 Claude (by Anthropic) — Best for Long-Form
**URL:** [claude.ai](https://claude.ai)
**Free tier:** Claude 3.5 Sonnet — generous daily limit
**Best for:** Longer emails, seller presentations, newsletters, blog posts
**Tip:** Claude tends to write in a more natural, conversational tone. Great for client-facing content.

### 🥉 Google Gemini — Best for Speed
**URL:** [gemini.google.com](https://gemini.google.com)
**Free tier:** Gemini 1.5 Flash — very fast
**Best for:** Quick captions, short emails, ideas when you're in a rush
**Tip:** Gemini pulls from current Google data, making it good for market-trend content.

### Microsoft Copilot — Best for Office Users
**URL:** [copilot.microsoft.com](https://copilot.microsoft.com)
**Free tier:** Fully free with a Microsoft account
**Best for:** Agents already using Word, Outlook, or Teams
**Tip:** Copilot is built into Windows 11 and Microsoft 365 — use it directly in Word for listing descriptions.

### Perplexity AI — Best for Research
**URL:** [perplexity.ai](https://perplexity.ai)
**Free tier:** Generous daily limit
**Best for:** Neighborhood research, market stats, school information
**Tip:** Use Perplexity to research the neighborhood, then feed those facts into ChatGPT or Claude for the actual copy.

---

## How to Use This Toolkit Step by Step

### Step 1: Find the Right Prompt
Each file is organized by category. Use the README for a quick map. Every prompt has a **"When to use"** line in italics — read that first to make sure it's the right prompt for your situation.

### Step 2: Fill In Every Bracket
Brackets look like this: `[PROPERTY ADDRESS]`, `[BUYER NAME]`, `[NUMBER OF BEDROOMS]`

**Rule: Never leave a bracket empty.** If you skip a bracket, the AI will either fill it in with something generic or produce awkward output. Take 60 seconds to fill them all in before pasting.

**How to fill them in efficiently:**
- Open your MLS sheet or listing notes beside your browser
- Read through the prompt and highlight every bracket
- Fill them top to bottom
- Then paste the whole thing

### Step 3: Paste Into Your AI Tool
Copy the full completed prompt. Open your AI tool. Paste it in the message box. Press Enter or click Send.

### Step 4: Read the Output
The AI will generate content in seconds. Read it fully before using it. Look for:
- Anything factually incorrect (the AI can hallucinate details)
- Anything that doesn't match your voice or market
- Any generic filler phrases that don't add value

### Step 5: Make Light Edits
You should only need to change 10–20% of the output. Real edits to look for:
- Add specific local details (school names, nearby parks, commute routes)
- Adjust the tone if needed (more formal for luxury, more casual for social)
- Fix anything that sounds off for your market

### Step 6: Publish or Send
Copy the edited output and paste it where it needs to go: your MLS, your email client, Instagram, etc.

**Total time: 4–8 minutes per piece of content.**

---

## How to Fill In Brackets Like a Pro

### The Golden Rule
The more specific your bracket fill-in, the more specific the AI output. Compare:

**Bad fill-in:**
> [PROPERTY FEATURES] → "3 bed, 2 bath, nice yard"

**Good fill-in:**
> [PROPERTY FEATURES] → "3 bed, 2 bath, 1,800 sq ft, renovated kitchen with quartz counters, primary suite with walk-in closet, covered patio, fenced backyard with mature oak trees, 2-car garage, solar panels, new HVAC 2023"

The good fill-in produces a description you can publish. The bad one produces generic fluff.

### Common Bracket Types & How to Fill Them

| Bracket | What to Put Here |
|---------|-----------------|
| `[PROPERTY ADDRESS]` | Full address or just city/neighborhood for privacy |
| `[NUMBER OF BEDROOMS/BATHROOMS]` | e.g., "4 bedrooms, 2.5 bathrooms" |
| `[SQUARE FOOTAGE]` | e.g., "2,200 sq ft" |
| `[ASKING PRICE]` | e.g., "$485,000" |
| `[NEIGHBORHOOD NAME]` | e.g., "Riverside Heights" |
| `[KEY FEATURES]` | List 5–8 specific standout features |
| `[SELLER/BUYER NAME]` | First name only is fine |
| `[YOUR NAME]` | Your name as you want it to appear |
| `[YOUR BROKERAGE]` | Your brokerage name |
| `[MARKET CONDITION]` | e.g., "low inventory, multiple offers common" |
| `[CALL TO ACTION]` | e.g., "Schedule your showing today" |
| `[OFFER AMOUNT]` | e.g., "$472,000" |
| `[CLOSING DATE]` | e.g., "March 15th" |
| `[TONE]` | e.g., "warm and professional" or "exciting and urgent" |

---

## Tips for Getting the Best Results

### Tip 1: Start a New Conversation for Each Task
Don't chain a listing description, a follow-up email, and a social post into the same conversation. The AI gets confused by too much context switching. Open a fresh chat for each task.

### Tip 2: Ask for Variations
After getting your first output, type:
> "Give me 3 different versions of the headline, each with a different tone."
or
> "Rewrite this but make it 30% shorter."

AI tools can iterate quickly. Use that.

### Tip 3: Tell It the Platform
Mention where the content will be used. Example additions:
- "This is for an MLS listing — keep it under 500 words."
- "This is for Instagram — use emojis and keep it punchy."
- "This is for a formal email to a high-end buyer."

The AI will automatically adjust tone, length, and format.

### Tip 4: Use the "Act As" Framing
Many prompts in this toolkit already include this, but you can add it to any prompt:
> "Act as an expert real estate copywriter with 15 years of experience in [YOUR MARKET]."

This simple instruction improves output quality noticeably.

### Tip 5: Save a "System Prompt" for Your Voice
If you use ChatGPT regularly, set a custom instruction (Settings → Personalization → Custom Instructions) with something like:
> "I'm a real estate agent in [CITY]. My tone is warm, professional, and direct. I specialize in [NICHE]. Never use clichés like 'cozy' or 'nestled.' Keep descriptions specific and feature-focused."

This improves every output without having to repeat yourself.

### Tip 6: Don't Accept the First Draft for High-Stakes Content
For a luxury listing, a seller presentation email, or a recruiting message — ask for a second draft. Type: "Good start. Now rewrite it to be more compelling and specific. The stakes are high." The second draft is almost always better.

### Tip 7: Use Perplexity for Research, Then ChatGPT for Copy
If you need to write about a neighborhood you're less familiar with, use Perplexity to pull current data (commute times, school ratings, average prices, recent developments), then paste those facts into a ChatGPT prompt to write the copy.

---

## Common Mistakes to Avoid

❌ **Leaving brackets blank** — always fill every bracket
❌ **Publishing without reading** — AI makes factual errors
❌ **Using the same prompt for every listing** — adjust the tone brackets for each property type
❌ **Skipping the "When to use" line** — using the wrong prompt for the situation
❌ **Being too vague in your features list** — specificity is everything
❌ **Not adjusting for your local market** — add local flavor AI can't know

---

## Your First Prompt (Do This Now)

Open `02-listing-prompts.md`. Find **"Standard MLS Description."** Fill in the brackets with a current or recent listing. Paste it into ChatGPT or Claude. Read the output.

That's it. You're using this toolkit.

---

*Next: `02-listing-prompts.md` → 25 prompts for every listing situation*
