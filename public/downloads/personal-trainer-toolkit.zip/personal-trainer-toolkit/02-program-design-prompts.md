# 02 — Program Design Prompts

*25 prompts for building training programs, session plans, and workout progressions*

---

> **How to use:** Replace every `[BRACKET]` with your client's real information. The more specific your inputs, the more ready-to-use the output will be.

---

### 1. Complete Training Program — 12-Week Block
*Use when onboarding a new client or starting a new training phase.*

```
You are an experienced personal trainer and strength coach. Create a complete 12-week training program for the following client:

Client profile:
- Name/alias: [CLIENT_NAME]
- Age: [AGE]
- Sex: [MALE/FEMALE/OTHER]
- Current fitness level: [BEGINNER/INTERMEDIATE/ADVANCED]
- Primary goal: [E.G., FAT LOSS / MUSCLE GAIN / ATHLETIC PERFORMANCE / GENERAL FITNESS]
- Secondary goal: [E.G., IMPROVE CARDIOVASCULAR FITNESS / REDUCE BACK PAIN]
- Training days per week: [NUMBER]
- Session length available: [MINUTES]
- Equipment access: [E.G., FULL GYM / HOME GYM WITH DUMBBELLS / BODYWEIGHT ONLY]
- Injuries or limitations: [LIST OR "NONE"]
- Exercise experience: [DESCRIBE BACKGROUND]

Organize the program into 3 four-week phases (Anatomical Adaptation → Hypertrophy/Base Fitness → Intensification or Sport-Specific). For each week, list:
- Training split
- Sets, reps, tempo, and rest periods
- Key exercises and why they were chosen
- Progression parameters

Include a brief rationale for the overall program design in plain language I can share with the client.
```

---

### 2. Single Session Plan
*Use when planning a specific upcoming session.*

```
Create a detailed single training session plan with the following parameters:

Client: [CLIENT_PROFILE — FITNESS LEVEL, GOAL, LIMITATIONS]
Session goal: [E.G., LOWER BODY STRENGTH / FULL BODY CONDITIONING / UPPER BODY HYPERTROPHY]
Session length: [MINUTES]
Equipment available: [LIST]
Where they are in their program: [E.G., WEEK 3, STRENGTH PHASE]
Any notes from last session: [E.G., "MENTIONED LEFT KNEE DISCOMFORT DURING SQUATS"]

Format:
1. Warm-up (specific exercises, duration, purpose)
2. Activation/mobility (if applicable)
3. Main work (exercise, sets, reps, tempo, rest, coaching cues)
4. Accessory work
5. Cooldown/stretch

Include 1–2 key coaching cues for the most technically demanding exercises.
```

---

### 3. Training Program for Weight Loss
*Use for clients whose primary goal is fat loss.*

```
Design a fat loss training program for the following client:

Client: [AGE, SEX, WEIGHT, HEIGHT]
Current activity level: [SEDENTARY / LIGHTLY ACTIVE / MODERATELY ACTIVE]
Training days available: [NUMBER] per week
Session length: [MINUTES]
Equipment: [GYM / HOME / BODYWEIGHT]
Injuries or limitations: [LIST OR NONE]
Timeline: [WEEKS] to goal date
Target: [WEIGHT/FAT LOSS GOAL IF KNOWN]

Design a program that maximizes caloric burn while preserving lean mass. Include:
- Training split and weekly schedule
- Mix of strength and metabolic conditioning (with rationale)
- Rep ranges and rest periods appropriate for fat loss
- 1 HIIT or cardio protocol
- Progression plan across [X] weeks
- What metrics to track week-over-week
```

---

### 4. Muscle Building Program (Hypertrophy Focus)
*Use for clients whose primary goal is building muscle.*

```
Create a hypertrophy-focused training program:

Client: [AGE, SEX, TRAINING EXPERIENCE — BEGINNER/INTERMEDIATE/ADVANCED]
Days per week: [NUMBER]
Session length: [MINUTES]
Equipment: [FULL GYM / HOME GYM / SPECIFY]
Weak points or areas to prioritize: [E.G., LAGGING CHEST AND ARMS]
Any exercises to avoid: [LIST OR NONE]

Design the program using periodization principles appropriate for their experience level. Include:
- Volume landmarks (weekly sets per muscle group)
- Primary and secondary exercises per session
- Rep ranges, tempo, and rest periods
- Techniques to apply in weeks 3–4 (e.g., drop sets, supersets, mechanical drop sets)
- Deload protocol at end of block
- How to know if they need more or less volume
```

---

### 5. Home Workout Program (Minimal Equipment)
*Use for clients who train at home with limited equipment.*

```
Create a [NUMBER]-week home workout program with minimal equipment.

Client: [FITNESS LEVEL, AGE, PRIMARY GOAL]
Available equipment: [E.G., BODYWEIGHT ONLY / RESISTANCE BANDS / 2 DUMBBELLS AT X LBS / PULL-UP BAR]
Days per week: [NUMBER]
Session length: [MINUTES]
Limitations: [ANY INJURIES OR RESTRICTIONS]

Make the program genuinely challenging and progressive despite equipment limitations. Include:
- Creative use of available equipment
- Tempo manipulation for progressive overload
- Rest-pause, 1.5 reps, or other techniques to increase difficulty without more weight
- How to progress each exercise week-over-week
- At-home substitutions for common gym exercises
```

---

### 6. Athletic Performance Program
*Use for clients with sport-specific training goals.*

```
Design a training program for athletic performance:

Client: [AGE, SEX, FITNESS LEVEL]
Sport: [SPORT OR ACTIVITY]
Position or role: [IF APPLICABLE]
Performance goal: [E.G., INCREASE VERTICAL JUMP / IMPROVE LATERAL SPEED / BUILD SPORT-SPECIFIC ENDURANCE]
Current in-season or off-season: [STATUS]
Competing schedule: [UPCOMING EVENTS OR SEASON DATES]
Days available for strength training: [NUMBER]
Current weaknesses (if known): [LIST]

Design a program that improves sport-specific performance without over-fatiguing for competition. Include:
- Periodization approach (block, undulating, or conjugate — with rationale)
- Speed/power work placement in the weekly schedule
- Strength movements prioritized for sport transfer
- Movement prep and injury prevention work
- In-season vs. off-season adjustments
```

---

### 7. Corrective Exercise Program
*Use for clients with postural issues or movement dysfunction.*

```
Create a corrective exercise program for the following movement issue:

Client: [AGE, GENERAL FITNESS LEVEL]
Issue identified: [E.G., ANTERIOR PELVIC TILT / ROUNDED UPPER BACK / KNEE VALGUS / FORWARD HEAD POSTURE]
Root cause (if assessed): [E.G., TIGHT HIP FLEXORS + WEAK GLUTES / TIGHT PECS + WEAK LOWER TRAPS]
Hours per day sitting: [APPROXIMATE]
Other training they're doing: [BRIEF DESCRIPTION]
Session time available for corrective work: [E.G., 15 MINUTES BEFORE MAIN TRAINING]

Provide:
1. The inhibit/lengthen/activate/integrate sequence
2. Specific exercises for each phase (with sets, reps, and hold times)
3. Daily routine they can do at home (5–10 minutes)
4. What to watch for to know it's working
5. Exercises to AVOID until corrected
```

---

### 8. Senior / Older Adult Program
*Use for clients 60+ or those with age-related considerations.*

```
Design a training program appropriate for an older adult client:

Client: [AGE, SEX]
Current activity level: [SEDENTARY / LIGHTLY ACTIVE / ACTIVE]
Health conditions: [LIST ANY — E.G., OSTEOPOROSIS, HIGH BLOOD PRESSURE, ARTHRITIS, HIP REPLACEMENT]
Medications: [IF RELEVANT TO EXERCISE — E.G., BETA BLOCKERS AFFECTING HEART RATE]
Goals: [E.G., MAINTAIN INDEPENDENCE / IMPROVE BALANCE / BUILD BONE DENSITY / GENERAL HEALTH]
Days per week: [NUMBER]
Equipment: [GYM / HOME / SENIOR CENTER]

Design a safe, effective program that prioritizes:
- Fall prevention and balance training
- Functional movement patterns (squat, hinge, push, pull, carry)
- Bone density (weight-bearing exercises)
- Joint-friendly progressions
- Clear intensity guidelines (RPE-based, not max percentage-based)
- Signs to stop and when to consult a physician
```

---

### 9. Post-Rehabilitation Return-to-Training Program
*Use for clients returning after injury or surgery (always with physician clearance).*

```
Create a return-to-training program outline for a client post-injury or surgery.

IMPORTANT: I have physician clearance for this client to begin supervised exercise.

Client: [AGE, FITNESS LEVEL BEFORE INJURY]
Injury/surgery: [E.G., ACL RECONSTRUCTION, ROTATOR CUFF REPAIR, LOWER BACK DISC]
Time since surgery/injury: [WEEKS/MONTHS]
Cleared for: [WHAT THE PHYSICIAN HAS APPROVED — E.G., "LOWER BODY TRAINING, NO IMPACT, NO LOADING ABOVE BODYWEIGHT YET"]
Previous fitness level: [DESCRIBE]
Goal: [RETURN TO SPORT / GENERAL FITNESS / PAIN-FREE DAILY ACTIVITY]

Design a phased return-to-training protocol with:
- Phase 1: Reactivation (weeks 1–4)
- Phase 2: Rebuilding (weeks 5–8)
- Phase 3: Strengthening (weeks 9–12)
- Red flags to watch for and when to refer back to their medical team
- Exercises to avoid and why
- Progressions based on performance, not just time
```

---

### 10. Workout Progression Plan
*Use when a client has plateaued and needs a new stimulus.*

```
A client has been on the same program and is plateauing. Create a progression plan.

Current program overview: [DESCRIBE WHAT THEY'VE BEEN DOING — EXERCISES, SETS, REPS, FREQUENCY]
Weeks on current program: [NUMBER]
Where they're stuck: [E.G., SQUAT HAS BEEN THE SAME WEIGHT FOR 4 WEEKS / NO VISIBLE BODY COMPOSITION CHANGE / CARDIO FEELS TOO EASY]
Client profile: [FITNESS LEVEL, GOAL, AVAILABLE TIME]

Provide:
1. A diagnosis of why they've plateaued (likely cause)
2. 3 specific adjustments to break the plateau this week
3. A revised 4-week mini-block to create a new adaptation
4. Long-term periodization recommendation to avoid this in the future
5. How to explain the plateau and the plan to the client in encouraging terms
```

---

### 11. Group Fitness Class Plan
*Use when designing a class format for multiple participants.*

```
Create a group fitness class plan:

Class type: [E.G., BOOTCAMP / HIIT / CIRCUIT TRAINING / STRENGTH CLASS]
Class length: [MINUTES]
Number of participants: [APPROXIMATE]
Fitness levels in the group: [MIXED BEGINNERS TO INTERMEDIATE / ADVANCED]
Equipment available per person: [E.G., MAT, PAIR OF DUMBBELLS, RESISTANCE BAND]
Space available: [E.G., SMALL STUDIO / LARGE GYM FLOOR / OUTDOOR FIELD]
Theme or focus: [E.G., FULL BODY / CORE AND CONDITIONING / LOWER BODY BURN]

Format the class with:
- Warm-up (time and exercises)
- Main circuit (station descriptions, time per station, rest, number of rounds)
- Modifications for beginners AND progressions for advanced participants
- Energy/music cues (high-energy moments, recovery moments)
- Cooldown
- Coach's script for transitions between segments
```

---

### 12. Deload Week Protocol
*Use at the end of a training block to manage fatigue.*

```
Design a deload week protocol for a client who has completed [NUMBER] weeks of hard training.

Client training history: [BRIEF — WHAT THEY'VE BEEN DOING, FREQUENCY, INTENSITY]
Accumulated fatigue signs: [E.G., SLEEP DISRUPTION, DECREASED MOTIVATION, STALLED LIFTS, NAGGING ACHES]
Goal of deload: [PHYSICAL RECOVERY / MENTAL RESET / BOTH]
Client's mindset about rest: [E.G., "HATES TAKING IT EASY" / "WELCOMES THE BREAK"]

Design a deload that:
- Reduces volume by 40–60% without eliminating training entirely
- Maintains movement patterns and neural efficiency
- Addresses any mobility or corrective work that gets deprioritized during hard blocks
- Includes guidance for sleep, nutrition, and active recovery (walks, swimming, etc.)
- Includes how to explain the PURPOSE of deloading to a client who thinks rest = losing gains
```

---

### 13. Warm-Up Protocol
*Use to design specific warm-ups for different training styles.*

```
Design a warm-up protocol for the following training session:

Session type: [E.G., HEAVY LOWER BODY STRENGTH / UPPER BODY PUSH / FULL BODY HIIT / OLYMPIC LIFTING]
Client: [FITNESS LEVEL, ANY KNOWN TIGHTNESS OR PROBLEM AREAS]
Total warm-up time available: [MINUTES]
Equipment available for warm-up: [FOAM ROLLER / BANDS / LIGHT WEIGHTS / BODYWEIGHT]

The warm-up should:
1. Raise core temperature (general warm-up)
2. Address mobility for today's movement patterns
3. Activate key muscles needed for the session
4. Include a specific neural activation for the main lifts
5. Take exactly [MINUTES] if done at a normal pace

Include coaching cues for the 2–3 most important warm-up exercises.
```

---

### 14. Cardio Programming
*Use when designing the cardio component of a client's program.*

```
Design a cardio programming plan for the following client:

Client: [GOAL, FITNESS LEVEL, TIME AVAILABLE]
Current cardio capacity: [E.G., CAN RUN 20 MINUTES AT MODERATE PACE / GETS WINDED WALKING UPSTAIRS]
Equipment available: [TREADMILL / BIKE / ROWER / OUTDOORS / NONE]
Weekly strength sessions: [NUMBER AND WHICH DAYS]
Total cardio time available per week: [MINUTES]
Cardio goal: [FAT LOSS / CARDIOVASCULAR HEALTH / ENDURANCE IMPROVEMENT / MENTAL HEALTH]

Design a 4-week cardio plan that:
- Doesn't interfere with strength adaptation
- Uses the right mix of steady-state and interval work for the goal
- Progresses appropriately week-over-week
- Includes specific protocols (time, intensity zones, structure)
- Explains the reasoning in plain language for the client
```

---

### 15. Flexibility & Mobility Routine
*Use to build standalone mobility work or end-of-session routines.*

```
Create a flexibility and mobility routine for the following client:

Client: [AGE, ACTIVITY LEVEL, KNOWN TIGHT AREAS]
Primary complaint: [E.G., "TIGHT HIPS AND HAMSTRINGS FROM SITTING ALL DAY" / "SHOULDER RANGE OF MOTION LIMITED"]
Time available: [10 / 15 / 20 / 30 MINUTES]
Format: [END OF WORKOUT COOLDOWN / STANDALONE SESSION / DAILY MORNING ROUTINE]
Goal: [INJURY PREVENTION / IMPROVE SQUAT DEPTH / REDUCE BACK PAIN / GENERAL FLEXIBILITY]

Include:
- Specific stretches and mobility drills (not just generic recommendations)
- Hold times and repetitions
- Order of exercises (distal to proximal or area-by-area)
- Active vs. passive stretches (and when to use each)
- How long before they'll notice improvement if they're consistent
```

---

### 16. Beginner's First Month Program
*Use for brand-new exercisers who have never trained consistently.*

```
Design a beginner's first-month training program.

Client: [AGE, SEX, STARTING FITNESS LEVEL — DESCRIBE AS HONESTLY AS POSSIBLE]
Primary goal: [LOSE WEIGHT / GET STRONGER / FEEL BETTER / BUILD A HABIT]
Available days per week: [NUMBER — START CONSERVATIVELY FOR A BEGINNER]
Equipment: [GYM / HOME / SPECIFY]
Any health considerations: [LIST OR NONE]
Previous exercise experience: [NONE / SOME YEARS AGO / BRIEFLY TRIED AND STOPPED]

Design a program that:
- Builds the exercise habit before adding difficulty
- Starts with movements they can succeed at immediately
- Teaches the 5 fundamental movement patterns (squat, hinge, push, pull, carry)
- Includes clear, non-intimidating language they can use without a trainer present
- Has built-in "success milestones" to celebrate in weeks 1, 2, 3, and 4
- Sets expectations about soreness, progress rate, and what "normal" looks like

Include a note I can share with the client about what to expect their first month.
```

---

### 17. Training Program Adjustment After Life Disruption
*Use when a client has missed time or had a major life change.*

```
A client has been absent for [NUMBER WEEKS/MONTHS] due to [REASON — ILLNESS / TRAVEL / WORK / INJURY / PERSONAL].

Before absence: [DESCRIBE THEIR PREVIOUS FITNESS LEVEL AND WHAT THEY WERE DOING]
Current state: [DESCRIBE HOW THEY FEEL NOW — DECONDITIONING, EXTRA STRESS, WEIGHT CHANGE, ETC.]
Available time now: [DAYS/WEEK, SESSION LENGTH]
Motivation level: [HIGH / MEDIUM / LOW — BE HONEST]

Design a return-to-training plan that:
1. Meets them where they are right now (not where they were)
2. Rebuilds confidence and habit before intensity
3. Is structured for their current reduced availability
4. Sets realistic expectations for how long it takes to regain lost fitness
5. Includes a message I can use to re-engage them and get them back in the gym
```

---

### 18. VO2 Max / Endurance Training Plan
*Use for clients training for running events or endurance goals.*

```
Create an endurance training plan for:

Client: [CURRENT FITNESS / RUNNING EXPERIENCE]
Goal event: [E.G., 5K / 10K / HALF MARATHON / CYCLING EVENT / GENERAL ENDURANCE]
Current weekly mileage or training volume: [DESCRIBE]
Target event date: [DATE]
Weeks available to prepare: [NUMBER]
Other training: [STRENGTH TRAINING SCHEDULE IF ANY]
Injuries or concerns: [LIST OR NONE]

Include:
- Weekly mileage/volume progression (10% rule or appropriate progression)
- Types of runs/sessions each week (easy, tempo, intervals, long)
- Heart rate zones or pace zones for each session type
- Cross-training recommendations
- Taper strategy in the final 2 weeks
- Race week and race day guidance
```

---

### 19. Supersets and Paired Exercise Combinations
*Use to design efficient time-saving workout structures.*

```
Design a superset-based workout structure for the following session:

Client: [FITNESS LEVEL, GOAL]
Session focus: [E.G., FULL BODY / PUSH-PULL / ANTAGONIST PAIRS]
Session length: [MINUTES — THIS STRUCTURE IS FOR EFFICIENCY]
Key movements to include: [LIST THE EXERCISES YOU WANT TO FEATURE]
Equipment: [AVAILABLE EQUIPMENT]

Pair exercises to minimize rest while maximizing volume. Include:
- Rationale for each pairing (antagonist, non-competing, active rest)
- Sets, reps, rest between supersets
- How to adjust load between exercises (if moving from heavy to light)
- How to explain supersets to a client unfamiliar with them
```

---

### 20. Program Periodization Overview (Annual Plan)
*Use when mapping out a full year of training for a committed client.*

```
Create a high-level annual periodization plan for a committed client:

Client: [PROFILE — FITNESS LEVEL, GOAL, SPORT OR FOCUS]
Key dates/goals in the next 12 months: [LIST ANY EVENTS, VACATIONS, ANTICIPATED BUSY PERIODS]
Training availability: [CURRENT — AND ANY KNOWN CHANGES THROUGHOUT THE YEAR]
Current fitness level: [DESCRIBE]
Long-term goal: [12-MONTH OUTCOME GOAL]

Map out a 12-month plan organized by mesocycles, showing:
- Phase names and goals (e.g., Foundation, Build, Peak, Transition)
- Months in each phase
- Training focus, volume, and intensity in each phase
- Key performance markers to hit at the end of each phase
- Planned deloads
- How to adjust if they get sick or fall behind

Format as a simple table + brief rationale for the annual structure.
```

---

### 21. Exercise Substitution List
*Use when a client can't perform a standard exercise.*

```
Provide exercise substitutions for the following situation:

Exercise they can't do: [E.G., BARBELL BACK SQUAT / CONVENTIONAL DEADLIFT / PULL-UP / BENCH PRESS]
Reason they can't do it: [INJURY / EQUIPMENT UNAVAILABILITY / TECHNICAL SKILL GAP / PAIN]
Their goal: [WHAT THEY'RE TRAINING FOR]
Equipment available: [LIST]

For each substitution, explain:
1. What muscle/movement it trains (and how it compares to the original)
2. Any technique considerations
3. Rep/set recommendations
4. When they might be ready to return to the original movement (if applicable)

Provide at least 3 substitution options ranging from closest to the original to most modified.
```

---

### 22. Foam Rolling / SMR Protocol
*Use to create soft tissue work for specific areas.*

```
Create a foam rolling and self-myofascial release protocol for:

Target area: [E.G., THORACIC SPINE / IT BAND / HIP FLEXORS / CALVES / LATS]
Client complaint: [E.G., "FEELS TIGHT AFTER LEG DAYS" / "UPPER BACK IS ALWAYS STIFF" / "PLANTAR FASCIITIS HISTORY"]
When to perform: [PRE-WORKOUT / POST-WORKOUT / DAILY MAINTENANCE]
Tools available: [FOAM ROLLER / LACROSSE BALL / BOTH / MASSAGE STICK]
Time available: [MINUTES]

Include:
- Specific rolling technique for each area (direction, speed, pausing on tender spots)
- Duration on each area
- Breathing guidance
- What sensations are normal vs. signs to back off
- How to explain to a client what foam rolling is actually doing (and why it helps)
```

---

### 23. Tracking Metrics and Progress Check Protocol
*Use to build a client progress review system.*

```
Design a client progress tracking and review protocol for:

Client goal: [SPECIFIC GOAL — FAT LOSS / STRENGTH GAIN / ATHLETIC PERFORMANCE / GENERAL HEALTH]
Assessment frequency: [EVERY X WEEKS]
Tools available: [SCALE / TAPE MEASURE / CALIPERS / PERFORMANCE TESTS / PHOTOS / NONE]

Create a protocol that includes:
1. Metrics to track (and why each one matters for this goal)
2. Metrics to AVOID tracking (e.g., daily weight for someone with body image concerns)
3. How to conduct the assessment conversation with the client
4. How to present data in an encouraging way even when progress is slow
5. Decision tree: what to adjust if progress stalls for 2+ weeks
6. Template for a monthly progress review summary I can share with the client
```

---

### 24. Tempo and Rest Period Prescription Guide
*Use to explain and implement tempo manipulation for a client.*

```
Explain and design a tempo and rest period scheme for the following training goal:

Goal: [HYPERTROPHY / STRENGTH / POWER / MUSCULAR ENDURANCE / FAT LOSS]
Client experience level: [BEGINNER / INTERMEDIATE / ADVANCED]
Current training they're doing: [BRIEF DESCRIPTION]

Provide:
1. Recommended tempo notation and what each number means (eccentric/pause/concentric/pause)
2. Specific tempo prescriptions for: compound movements, isolation exercises, accessory work
3. Rest period recommendations by exercise type and goal
4. How to explain tempo to a client who's never used it
5. 5 example exercises with specific tempo and rest prescriptions for [GOAL]
6. How to progressively manipulate tempo over an 8-week block
```

---

### 25. Periodization Model Comparison for Client Explanation
*Use when explaining why you chose a particular training structure.*

```
Write a plain-language explanation of my training program design for a client:

Program type I'm using: [LINEAR PERIODIZATION / UNDULATING PERIODIZATION / BLOCK PERIODIZATION / CONJUGATE / DAILY UNDULATING (DUP)]
Client's background: [EXPLAIN THEIR EXPERIENCE LEVEL AND WHAT THEY'VE DONE BEFORE]
Their goal: [GOAL]
Why I chose this model: [YOUR REASONING]

Write a 200-300 word explanation I can share with or say to the client that:
- Explains the structure in plain language (no jargon)
- Explains WHY this approach will work for their goal specifically
- Sets expectations for what weeks 1-4 vs. weeks 9-12 will feel like
- Builds their confidence that there's a plan (not just random workouts)
- Answers the question "why aren't we going harder right away?"
```

---
