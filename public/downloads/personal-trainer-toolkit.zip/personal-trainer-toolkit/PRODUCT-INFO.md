# PRODUCT INFO — The Personal Trainer's AI Prompt Toolkit

---

## Product Details

| Field | Value |
|-------|-------|
| **Product Name** | The Personal Trainer's AI Prompt Toolkit |
| **Version** | 1.0 |
| **Format** | 7 Markdown files (digital download) |
| **Total Prompts** | 90+ ready-to-use AI prompts |
| **Support** | helloworkshift@gmail.com |

---

## Who It's For

Personal trainers and fitness coaches who want to design better programs, communicate more effectively with clients, provide nutrition guidance, and grow their business — without spending hours on admin instead of coaching.

---

## What's Included

| File | Description | Prompt Count |
|------|-------------|--------------|
| `01-quick-start-guide.md` | Setup, system prompt, best practices | — |
| `02-program-design-prompts.md` | Training programs, workout plans, periodization | 23 |
| `03-client-coaching-prompts.md` | Check-ins, motivation, progress reviews | 22 |
| `04-nutrition-lifestyle-prompts.md` | Nutrition guidance, habit coaching | 18 |
| `05-business-marketing-prompts.md` | Social content, client retention, marketing | 17 |
| `06-workflow-sops.md` | 5 complete trainer workflow playbooks | — |
| `07-cheat-sheet.md` | Top 15 prompts + variable quick reference | 15 |

---

*For support: helloworkshift@gmail.com*
*Last updated: 2026*
