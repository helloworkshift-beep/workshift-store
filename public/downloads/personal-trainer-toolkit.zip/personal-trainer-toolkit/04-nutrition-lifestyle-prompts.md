# 04 — Nutrition & Lifestyle Coaching Prompts

*20 prompts for nutrition guidance, habit building, and lifestyle support*

---

> **Important disclaimer to include with all nutrition guidance:**
> *These prompts generate general nutrition education and behavior coaching. I am not a registered dietitian. For clients with medical conditions, eating disorder history, or complex dietary needs, refer to a qualified nutrition professional.*

---

### 1. Basic Nutrition Coaching Plan
*Use to create a starting nutrition framework for a new client.*

```
Create a practical nutrition coaching framework for a personal training client.

Client: [AGE, SEX, WEIGHT, HEIGHT, ACTIVITY LEVEL]
Goal: [FAT LOSS / MUSCLE GAIN / PERFORMANCE / GENERAL HEALTH]
Current eating habits: [DESCRIBE — E.G., "SKIPS BREAKFAST, EATS OUT 5X/WEEK, DRINKS 2 GLASSES OF WINE NIGHTLY"]
Restrictions or preferences: [ALLERGIES, DIETARY RESTRICTIONS, FOODS THEY HATE]
My scope: [GENERAL NUTRITION EDUCATION ONLY — NOT MEDICAL NUTRITION THERAPY]
Cooking ability: [DOESN'T COOK / BASIC / CONFIDENT IN THE KITCHEN]
Time for meal prep: [NONE / 30 MIN/WEEK / HAPPY TO SPEND TIME COOKING]

Create a practical nutrition framework that:
1. Establishes estimated calorie and protein targets (explain how you calculated them)
2. Gives simple portion guidance (hand method or plate method — no obsessive counting)
3. Identifies 2–3 "quick wins" they can implement this week
4. Addresses their specific current eating habits
5. Doesn't require cooking elaborate meals unless they want to
6. Includes a note about when to refer out to a registered dietitian
```

---

### 2. Protein Target and Food Sources Guide
*Use to help a client hit their protein goals without a complicated tracking system.*

```
Write a personalized protein guide for a client who struggles to eat enough protein.

Client: [WEIGHT IN LBS OR KG, GOAL — FAT LOSS/MUSCLE GAIN/GENERAL HEALTH]
Estimated daily protein target: [CALCULATE: 0.7–1G PER LB BODYWEIGHT FOR MOST CLIENTS]
Foods they already eat and like: [LIST]
Foods they dislike or avoid: [LIST]
Eating style: [OMNIVORE / VEGETARIAN / VEGAN / PESCATARIAN]
Cooking ability and time: [BRIEF]

Create a guide that:
- Shows them exactly how to hit [TARGET]g of protein daily
- Lists their top 10 best protein sources with serving sizes and protein content
- Gives 3 sample daily menus that hit the target using foods they like
- Includes 5 easy "protein boosts" they can add to meals they already eat
- Explains why protein matters for their specific goal in simple terms
```

---

### 3. Meal Prep Planning Template
*Use when a client wants to start meal prepping but doesn't know how.*

```
Create a weekly meal prep plan and guide for a client who wants to eat better without thinking about it every day.

Client: [GOAL, DIETARY PREFERENCES, ESTIMATED CALORIE RANGE IF KNOWN]
Schedule: [WHEN THEY CAN PREP — E.G., "SUNDAY AFTERNOONS, 1–2 HOURS MAX"]
Kitchen skills: [BEGINNER / INTERMEDIATE]
Household size: [JUST THEMSELVES / FAMILY OF X]
Budget: [APPROXIMATE WEEKLY FOOD BUDGET]

Create:
1. A Sunday prep plan (exactly what to cook in what order for maximum efficiency)
2. 5 breakfasts for the week (same one or 2–3 rotating options)
3. 5 lunches that can be made from Sunday prep
4. 3 easy weeknight dinners using prepped components
5. A grocery list organized by store section
6. Tips for making prep faster and less boring
7. How to adjust portions based on how hungry/not hungry they are
```

---

### 4. Eating Out Strategy Guide
*Use to help a client navigate restaurants without derailing their progress.*

```
Create an eating-out strategy guide for a client who travels or eats out frequently.

Client: [GOAL, ESTIMATED NUTRITION TARGETS IF APPLICABLE]
How often they eat out: [X TIMES PER WEEK]
Types of restaurants most common for them: [E.G., CASUAL DINING / FAST FOOD / BUSINESS DINNERS / ETHNIC CUISINES]
Current behavior pattern: [E.G., "ORDERS THE BIGGEST MEAL AND HAS DESSERT EVERY TIME" / "ALWAYS GETS DRINKS WITH MEALS"]
Mindset: [WANTS STRATEGIES / DOESN'T WANT TO FEEL DEPRIVED]

Write a guide that:
- Gives a pre-restaurant strategy (mindset, online menu review, pre-eating)
- Lists the best choices at their common restaurant types
- Gives ordering hacks that reduce calories without seeming weird
- Addresses alcohol (if applicable) — how to handle it, not eliminate it
- Covers business dinners and social pressure situations
- Ends with the key rule: "If you don't know, do this..."
```

---

### 5. Habit Stacking Plan for Nutrition
*Use to help a client build better eating habits without willpower.*

```
Create a behavior change plan for a client with poor eating habits.

Client's current habits: [DESCRIBE THE SPECIFIC PATTERNS — E.G., "STRESS EATS AT 3PM / NEVER DRINKS WATER / SKIPS MEALS THEN OVEREATS AT NIGHT"]
Root causes (if identified): [E.G., STRESS / BOREDOM / LACK OF PREP / EMOTIONAL TRIGGERS]
Their goal: [WHAT NUTRITION CHANGE WOULD MOST IMPACT THEIR PROGRESS]
Change readiness: [HIGH / MEDIUM / LOW — WHAT ARE THEY WILLING TO ACTUALLY DO]

Using habit stacking and behavior design principles:
1. Identify the 1 highest-leverage habit change (not 10 — just 1)
2. Design the cue → routine → reward loop for that habit
3. Show how to attach it to an existing behavior
4. Create a "minimum viable habit" version for their lowest motivation days
5. Design a 4-week progression (getting more consistent before getting more complex)
6. Include what to say to themselves when they slip (self-compassion script)
```

---

### 6. Pre and Post Workout Nutrition Guide
*Use to educate a client on fueling their training.*

```
Write a pre and post-workout nutrition guide for a client.

Client: [GOAL, TRAINING SCHEDULE, GENERAL NUTRITION APPROACH]
Training time: [MORNING / MIDDAY / EVENING]
Training type: [STRENGTH TRAINING / CARDIO / SPORT / MIXED]
Training duration: [MINUTES]

Cover:
1. Pre-workout nutrition (timing, macros, what to eat, what to avoid)
2. Intra-workout (water, electrolytes, when carbs during training make sense)
3. Post-workout nutrition (the "window" — what the research actually says, not myths)
4. Specific food examples for each timing
5. Adjustments for morning fasted training vs. afternoon sessions
6. Supplement overview (what the evidence actually supports — be honest)
7. What happens if they miss pre/post nutrition (context, not catastrophizing)
```

---

### 7. Calorie Deficit Explanation for Fat Loss Client
*Use to explain energy balance in a way clients actually understand and accept.*

```
Write a plain-language explanation of caloric deficit and energy balance for a client trying to lose fat.

Client background: [DESCRIBE — E.G., "HAS TRIED EVERY DIET, FRUSTRATED WITH LACK OF RESULTS, DOESN'T BELIEVE CALORIES MATTER"]
Their current belief: [E.G., "I BARELY EAT AND STILL CAN'T LOSE WEIGHT" / "I HEARD CARBS ARE BAD" / "INTERMITTENT FASTING IS WHAT WORKS"]
My goal: [EDUCATE WITHOUT ALIENATING / BUILD UNDERSTANDING SO THEY CAN MAKE BETTER DECISIONS]

Write a 300-word explanation that:
- Explains energy balance simply and accurately
- Addresses their specific belief or misconception head-on (not dismissively)
- Explains why they may not be losing weight even if they "eat nothing" (common mistakes)
- Reframes "diet" as a sustainable approach vs. restriction
- Gives them 1 actionable thing to do this week based on this understanding
- Doesn't lecture — sounds like a conversation with someone who's on their side
```

---

### 8. Sleep and Recovery Coaching Message
*Use to address a client who is underslept or under-recovering.*

```
Write a coaching message for a client whose sleep and recovery is hurting their results.

Client situation: [E.G., "AVERAGES 5 HOURS / NIGHT AND WONDERS WHY THEY'RE NOT LOSING FAT" / "TRAINS 6 DAYS/WEEK AND NEVER RECOVERS FULLY"]
What I've noticed: [PERFORMANCE DECLINING / BODY COMPOSITION STALLED / ALWAYS SORE / MOOD CHANGES]
What I know about their schedule: [E.G., "WORKS LATE, SCROLLS PHONE UNTIL 1AM, WAKES AT 6AM"]

The message should:
- Explain the link between sleep/recovery and their specific goal in plain terms
- Give 3 specific, actionable sleep improvements (not generic "sleep more")
- Address their actual schedule constraints
- Be supportive, not preachy
- Reframe rest as part of training, not a break from it
- Offer 1 immediate change they can make tonight
```

---

### 9. Stress Management for Fat Loss Resistance
*Use when a client is doing everything right but not losing weight due to stress.*

```
Write an explanation and coaching plan for a client who is stress-eating or experiencing stress-related fat loss resistance.

Client situation: [HIGH STRESS JOB / FAMILY SITUATION / RECENT LIFE EVENT]
What's happening physically: [E.G., "TRAINING HARD, EATING WELL, BUT GAINING BODY FAT — ESPECIALLY IN THE MIDSECTION"]
What they've tried: [LIST]

Write:
1. A clear explanation of how chronic stress (cortisol) affects body composition
2. The link between stress and food choices (not a willpower problem)
3. 5 practical stress management strategies that fit in a busy schedule
4. How to adjust training temporarily to reduce the cortisol load (not stop — adjust)
5. What success looks like over the next 4–6 weeks if they address this
6. A script for how I'd explain this in a session without making them feel broken
```

---

### 10. Alcohol and Fat Loss Conversation Guide
*Use when a client's drinking habits are impacting their progress.*

```
Write a coaching conversation guide for addressing a client's alcohol consumption.

Client situation: [E.G., "DRINKS 4–5 NIGHTS/WEEK, USUALLY 2–3 DRINKS EACH TIME, SAYS THEY WON'T GIVE IT UP"]
Their goal: [FAT LOSS GOAL AND TIMELINE]
My relationship with this client: [HOW LONG I'VE KNOWN THEM, HOW DIRECT I CAN BE]

Write:
1. How to raise the topic without making them defensive
2. The actual math on how alcohol impacts their goal (calories, sleep, muscle protein synthesis)
3. A "harm reduction" approach (not elimination) with specific strategies
4. Drink choices that minimize the damage
5. How to handle social situations while reducing intake
6. The script if they say "I'm not giving up drinking" — how to work with that honestly
```

---

### 11. Tracking Without Obsession (Flexible Dieting Intro)
*Use to introduce tracking for a client who needs structure but risks over-fixating.*

```
Write an introduction to flexible dieting and food tracking for a client.

Client: [GOAL, CURRENT RELATIONSHIP WITH FOOD — BE HONEST IF THERE ARE SIGNS OF DISORDERED EATING HISTORY]
Why they need some tracking: [E.G., PROTEIN IS CONSISTENTLY TOO LOW / CALORIE INTAKE IS UNKNOWN]
My concern: [THEY MIGHT BECOME OBSESSIVE / THEY HAVE AN ALL-OR-NOTHING PERSONALITY]

Write:
1. An introduction to tracking (why, how, what app to use)
2. A "minimum viable tracking" approach (just protein first, not everything)
3. Rules for when to stop tracking (red flags that it's becoming unhealthy)
4. How to handle "going over" a target (recovery, not punishment)
5. The difference between tracking as a learning tool vs. tracking as a cage
6. At what point I'd recommend they stop tracking and just eat intuitively
```

---

### 12. Nutritional Supplements: What Actually Works
*Use to give evidence-based supplement guidance.*

```
Write a practical, evidence-based supplement guide for a personal training client.

Client goal: [FAT LOSS / MUSCLE GAIN / PERFORMANCE / GENERAL HEALTH]
Their current supplements: [LIST WHAT THEY TAKE NOW]
Their question or situation: [E.G., "ASKS ABOUT EVERY NEW SUPPLEMENT THEY SEE ON INSTAGRAM" / "SPENDS $200/MONTH ON SUPPLEMENTS AND WONDERS WHY THEY'RE NOT SEEING RESULTS"]

Write a guide that:
- Lists supplements with strong evidence for their goal (be honest — it's a short list)
- Lists supplements that are a waste of their money (be direct)
- Covers dosing and timing for the evidence-based ones
- Addresses the most common fitness supplements by name (creatine, protein powder, pre-workout, fat burners, BCAAs)
- Includes a clear priority order (food first, then this, then maybe that)
- Uses the phrase "the research shows" and means it
```

---

### 13. 7-Day Nutrition Reset Plan
*Use for a client who has gotten off track and needs to restart.*

```
Create a 7-day nutrition reset plan for a client who has been off track.

Client: [GOAL, GENERAL CALORIE RANGE, DIETARY PREFERENCES]
What "off track" looks like for them: [E.G., "BEEN EATING OUT EVERY DAY FOR 3 WEEKS" / "VACATION AND GAINED 8 LBS" / "STRESS EATING NIGHTLY"]
What they want to feel like after 7 days: [E.G., "LESS BLOATED / BACK ON ROUTINE / LIGHTER"]

Design a 7-day plan that:
- Is realistic (not a crash diet or juice cleanse)
- Focuses on whole foods, high protein, reduced alcohol and processed food
- Includes full day-by-day menus with simple preparation
- Addresses cravings and emotional eating moments that will happen
- Includes daily "anchor habits" (3 non-negotiables for 7 days)
- Has a Day 8 reflection protocol to decide what to carry forward
```

---

### 14. Bulking Nutrition Guide (Lean Gaining)
*Use for clients in a muscle-building phase who need nutrition guidance.*

```
Create a lean bulking nutrition guide for a client focused on building muscle.

Client: [CURRENT WEIGHT, ESTIMATED BODY FAT IF KNOWN, TRAINING EXPERIENCE]
Training program: [BRIEF DESCRIPTION — DAYS/WEEK, TYPE]
Calorie surplus recommendation: [CALCULATE — TYPICALLY 200–400 CALORIES ABOVE MAINTENANCE FOR LEAN BULK]
Protein target: [CALCULATE]
Meal frequency preference: [HOW MANY TIMES PER DAY THEY PREFER TO EAT]

Write a guide covering:
1. Calorie and macro targets with rationale
2. Meal timing around training
3. Best foods for lean bulking (high protein, nutrient-dense)
4. How to track progress (weight gain target: 0.25–0.5 lbs/week)
5. Signs you're gaining too fast (and what to do)
6. Signs you're not eating enough (and what to do)
7. Supplement recommendations for this phase
8. A sample day of eating that hits the targets
```

---

### 15. Mindful Eating Guide
*Use for clients with emotional eating patterns or poor hunger awareness.*

```
Create a mindful eating practice guide for a personal training client.

Client situation: [E.G., "EATS IN FRONT OF THE TV EVERY NIGHT AND OVEREATS WITHOUT REALIZING" / "EATS QUICKLY, ALWAYS FEELS STUFFED AFTER MEALS" / "USES FOOD TO COPE WITH STRESS AND EMOTIONS"]
Their goal: [HOW MINDFUL EATING WILL HELP THEM — FAT LOSS / BETTER RELATIONSHIP WITH FOOD / LESS GUT DISCOMFORT]
Their skepticism level: [IF THEY THINK THIS IS "WOO" — ACKNOWLEDGE AND REFRAME]

Write:
1. A brief explanation of mindful eating (the science, not the meditation version)
2. The "hunger scale" (1–10) and how to use it
3. 5 practical mindful eating exercises they can start today
4. How to apply this at a restaurant or social eating situation
5. The difference between hunger, appetite, and cravings (and how to tell them apart)
6. What to do when they catch themselves eating mindlessly (self-compassion approach)
```

---

### 16. Intermittent Fasting Assessment
*Use when a client asks about intermittent fasting.*

```
Write a balanced, evidence-based assessment of intermittent fasting for a specific client.

Client: [GOAL, CURRENT SCHEDULE, TRAINING TIME, ANY HISTORY WITH DISORDERED EATING]
Their interest level: [E.G., "WANTS TO TRY 16:8" / "A FRIEND LOST 30 LBS ON OMAD AND NOW THEY WANT TO DO IT"]
My role: [GIVE THEM HONEST INFORMATION TO MAKE THEIR OWN DECISION]

Cover:
1. What IF actually is (and the different protocols)
2. What the research actually shows (vs. the hype)
3. Who it tends to work well for (and why)
4. Who it tends NOT to work well for (and why)
5. Whether it's appropriate for THIS client specifically (give my honest assessment)
6. If they want to try it: how to implement it with their training schedule
7. Red flags to watch for
8. The honest bottom line: is it magic, or is it just a way to reduce calories?
```

---

### 17. Vegetarian/Vegan Client Nutrition Guide
*Use for clients on plant-based diets.*

```
Create a practical nutrition guide for a [VEGETARIAN/VEGAN] personal training client.

Client: [GOAL, TRAINING SCHEDULE, CALORIE RANGE IF KNOWN]
How strict: [FULLY VEGAN / VEGETARIAN / MOSTLY PLANT-BASED / FLEXITARIAN]
Will they use supplements: [YES / NO / OPEN TO DISCUSSION]
Budget: [CONSTRAINED / FLEXIBLE]

Address:
1. Protein targets and how to hit them on a plant-based diet (specific foods + amounts)
2. The complete protein myth and reality (amino acid profile of plant proteins)
3. Nutrients most likely to be deficient and how to address each:
   - B12, Iron, Zinc, Calcium, Omega-3, Vitamin D, Creatine
4. Best plant-based protein sources for their goal
5. Sample day of eating that hits protein and calorie targets
6. Supplement recommendations (evidence-based, not a shopping list)
7. What to watch for as a performance-focused athlete eating plant-based
```

---

### 18. Hydration Protocol
*Use to help clients optimize water intake.*

```
Write a practical hydration guide for a personal training client.

Client: [WEIGHT, ACTIVITY LEVEL, CLIMATE THEY LIVE/TRAIN IN]
Current hydration habits: [E.G., "DRINKS MAYBE 2 GLASSES OF WATER A DAY AND A LOT OF COFFEE"]
Training schedule: [FREQUENCY AND DURATION]
Goal: [FAT LOSS / PERFORMANCE / GENERAL HEALTH]

Cover:
1. How much water they actually need (individualized estimate, not "8 glasses a day")
2. How to adjust for training intensity, sweat rate, and climate
3. Signs of dehydration (and how it impacts their specific goal)
4. How to build a hydration habit (not just "drink more water")
5. The role of electrolytes and when they actually matter
6. What about coffee, tea, and diet drinks? (honest assessment)
7. A daily hydration schedule mapped to their actual routine
```

---

### 19. Gut Health and Digestion for Athletes
*Use for clients experiencing digestive issues that impact training.*

```
Write a coaching guide on gut health for an active client experiencing digestive issues.

Client situation: [E.G., "BLOATED AFTER EATING / GAS DURING WORKOUTS / CONSTIPATED / DIARRHEA BEFORE COMPETITIONS"]
Their training: [TYPE AND FREQUENCY]
Current diet: [BRIEF DESCRIPTION]
Severity: [MILD INCONVENIENCE / IMPACTING TRAINING AND DAILY LIFE]

NOTE: Severe or persistent GI symptoms should be evaluated by a doctor. This guide is for general education.

Cover:
1. How exercise affects gut motility and digestion
2. Foods most commonly causing issues in active people
3. Pre-workout meal timing to reduce GI distress
4. Probiotic and prebiotic foods (vs. supplements)
5. Fiber intake — how much is right for their activity level
6. When to refer to a doctor or registered dietitian
7. A "sensitive gut" meal template for training days
```

---

### 20. Nutrition Q&A Response Templates
*Use to answer common nutrition questions from clients quickly and accurately.*

```
Write professional responses to these common client nutrition questions:

Client question: [CHOOSE ONE OR MORE]:
A. "Should I do a detox or cleanse?"
B. "Are carbs bad for fat loss?"
C. "Do I need to eat breakfast?"
D. "Is [SPECIFIC FOOD] bad for me?"
E. "Why am I not losing weight even though I'm eating healthy?"
F. "Do I need to count macros?"
G. "Is protein powder good or bad?"
H. "Should I eat before or after my workout?"

For each response:
- Lead with the evidence-based answer
- Acknowledge why people believe the myth (if applicable)
- Give them the practical takeaway
- Keep it under 150 words per response
- Sound like a knowledgeable coach, not a textbook
- Include "as always, check with your doctor if you have specific health concerns" where appropriate
```

---
