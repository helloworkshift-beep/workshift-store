# 01 — Quick Start Guide

*How to get maximum value from this toolkit in the first 10 minutes*

---

## The 3-Minute Setup

### Step 1: Pick Your AI Tool
These prompts work with any modern LLM:
- **ChatGPT (GPT-4o)** — Great for client messages and social content
- **Claude (Sonnet or Opus)** — Best for detailed training programs and coaching documents
- **Gemini Advanced** — Works well for nutrition and research-heavy prompts

### Step 2: Set a System Prompt
Paste this at the start of any new conversation:

```
You are an experienced certified personal trainer and fitness coach with 10+ years training clients. You understand exercise science, behavior change, and the psychology of fitness motivation. You design programs that are practical, progressive, and appropriate for the individual client's fitness level, goals, and schedule. You write client communications that are encouraging, clear, and specific — never preachy or generic. When I give you a prompt, produce clean, professional output I can send to a client or post online today.
```

### Step 3: Fill In the Brackets
Every prompt uses `[BRACKET_VARIABLES]` in ALL_CAPS. Replace every bracket with your real client details before pasting.

---

## How to Fill In Variables Like a Pro

**Bad:**
```
[CLIENT] = my client
[GOAL] = lose weight
```

**Good:**
```
[CLIENT] = Mark, 42-year-old male, office worker, trains 3x per week, goal is to lose 20 lbs in 5 months while building functional strength
[GOAL] = lose 20 lbs in 5 months, improve energy for workday, reduce lower back pain from desk job
```

The more specific your client profile, the better the program or message.

---

## Power Techniques

### Build a Client Profile Library
For each client, keep a short profile you can paste into prompts:
- Name, age, fitness level
- Current program and phase
- Goal and timeline
- Any injuries or limitations
- Motivational style (accountability-driven vs. autonomy-driven)

### Stack Prompts for Full Programs
1. Use **Training Program Generator** (Program #1) for the framework
2. Use **Weekly Workout Plan** (Program #4) to fill in the daily details
3. Use **Client Progress Review** (Coaching #5) to evaluate after 4 weeks

### Personalize Coaching Messages
Paste a client message or voice memo summary into the prompt context. AI will help you respond with the right coaching language for their specific situation.

---

## Common Mistakes to Avoid

❌ **Generic programs** — Filling in `[GOAL] = get fit` produces generic output. Be specific about the client's actual situation and constraints.

❌ **Medical advice** — These prompts produce fitness and general wellness guidance, not medical prescriptions. Always remind clients to consult their doctor for medical concerns.

❌ **Sending without your voice** — Add your coaching personality, your phrases, your encouragement style. AI writes the structure; you provide the relationship.

---

## Recommended Use by Situation

| Situation | Go-To Prompts |
|-----------|--------------|
| Designing a new client program | Program Design #1, #2 |
| Client hit a plateau | Coaching #6, #7 |
| Client missed multiple sessions | Coaching #4 |
| Nutrition question | Nutrition #1, #3, #5 |
| Writing a social media post | Business #1, #2 |
| Client retention email | Business #8 |
| Asking for a referral | Business #11 |
| Writing a client welcome packet | Coaching #1 |
| Preparing for a free consultation | Business #4 |

---

## File Navigation

- **Program Design** → [02-program-design-prompts.md](02-program-design-prompts.md)
- **Client Coaching** → [03-client-coaching-prompts.md](03-client-coaching-prompts.md)
- **Nutrition & Lifestyle** → [04-nutrition-lifestyle-prompts.md](04-nutrition-lifestyle-prompts.md)
- **Business & Marketing** → [05-business-marketing-prompts.md](05-business-marketing-prompts.md)
- **Full Workflow Playbooks** → [06-workflow-sops.md](06-workflow-sops.md)
- **Quick Reference** → [07-cheat-sheet.md](07-cheat-sheet.md)

---

*Start with the cheat sheet, or jump to program design if you have a new client starting this week.*
