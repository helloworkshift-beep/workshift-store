# 06 — Workflow SOPs

*5 complete systems for your most time-intensive personal training tasks — powered by AI*

---

## SOP A: Onboard a New Client in 60 Minutes

**What this produces:** A fully programmed, ready-to-train new client with professional documentation
**When to run it:** After a new client signs their agreement and pays
**Time commitment:** 60 minutes total (vs. 3–4 hours of scattered prep)

---

**Before the session (20 min):**

1. Review their intake questionnaire
2. Note health history red flags and injury limitations
3. Use **Prompt: New Client Welcome Email** from `03-client-coaching-prompts.md` → send immediately
4. Use **Prompt: Initial Fitness Assessment Script** to prepare your assessment protocol

**During the first session (40 min):**

1. Movement screen (15 min) — document findings in real time
2. Basic fitness tests (10 min)
3. Goal-setting conversation using **Prompt: Goal-Setting Session Guide** (15 min)

**After the session (same day):**

1. Use **Prompt: Complete Training Program** from `02-program-design-prompts.md` with all intake data
2. Use **Prompt: Session Recap Template** from `03-client-coaching-prompts.md` to document session 1
3. Prepare week 1 schedule and send to client

---

## SOP B: Quarterly Program Refresh

**What this produces:** A fresh training block that prevents plateaus and keeps clients engaged
**When to run it:** Every 8–12 weeks per client

---

**Step 1 — Review current block results (15 min)**

Pull session notes for the past 8–12 weeks. Document:
- Strength progression on key lifts
- Body composition changes (if measured)
- Client-reported energy, soreness, motivation
- Exercises they loved / hated

**Step 2 — Assess and diagnose (10 min)**

Use **Prompt: Workout Progression Plan** from `02-program-design-prompts.md` if they've plateaued.

Identify: What phase are they in? What stimulus haven't they had? What's the gap between where they are and their goal?

**Step 3 — Design the next block (20 min)**

Use **Prompt: Complete Training Program** or a phase-specific prompt from `02-program-design-prompts.md`.

**Step 4 — Write the monthly progress report (10 min)**

Use **Prompt: Monthly Progress Report** from `03-client-coaching-prompts.md`. Send before presenting the new program.

**Step 5 — Present the new block**

Frame it as exciting, not routine. Explain WHY the new stimulus will work using the plain-language periodization explanation from `02-program-design-prompts.md`.

---

## SOP C: Re-engage a Ghost Client

**What this produces:** A client who went quiet back in the gym and paying
**When to run it:** When a client misses 2+ sessions without explanation

---

**Day 1 of silence:** Do nothing. Life happens.

**Day 3:** Quick, casual check-in text. Use **Prompt: Motivational Message for Struggling Client** from `03-client-coaching-prompts.md` — lighter version.

**Day 7:** More direct outreach. Reference specific things you know about them. Offer a lower-barrier re-entry point (a lighter session, a phone call, dropping from 3x to 2x/week).

**Day 14:** Final check-in. Use **Prompt: Handling a Client Who Wants to Cancel** from `03-client-coaching-prompts.md`. Give them an easy, graceful path — either back in or a proper goodbye.

**If they re-engage:**
- Don't shame the absence
- Use **Prompt: Training Program Adjustment After Life Disruption** to build a realistic re-entry program
- Set a new 4-week milestone to rebuild momentum

---

## SOP D: Handle a Client Who Isn't Seeing Results

**What this produces:** A clear diagnosis, an adjusted plan, and a motivated client
**When to run it:** When a client has trained 8+ weeks without meaningful progress

---

**Step 1 — Audit before the conversation (20 min)**

Review their last 8 weeks honestly:
- Training adherence (sessions completed vs. scheduled)
- Session notes (were they actually working hard?)
- Nutrition check-ins (were they consistent?)
- Sleep and stress (any major life disruptions?)
- Program design (has the stimulus changed?)

**Step 2 — Prepare your diagnosis**

Use **Prompt: Workout Progression Plan** from `02-program-design-prompts.md` to generate a plateau analysis.

Identify the most likely 1–2 causes. Don't blame the client — find the system failure.

**Step 3 — Have the conversation**

Use **Prompt: Handling Client Plateau Conversation** from `03-client-coaching-prompts.md`.

Lead with what IS working. Present your diagnosis as a hypothesis, not an accusation. Co-create the solution.

**Step 4 — Reset with a 4-week mini-block**

Design a specific 4-week intervention using the appropriate program design prompt from `02-program-design-prompts.md`.

Set a clear, measurable milestone for week 4 that they can realistically hit.

---

## SOP E: Launch Your Online Coaching Business

**What this produces:** A fully operational online coaching business ready to take clients
**When to run it:** When moving from in-person to online or adding online clients

---

**Phase 1 — Foundation (1 week)**

1. Write your bio using **Prompt: Personal Trainer Bio** from `05-business-marketing-prompts.md`
2. Write your pricing page using **Prompt: Personal Training Pricing Page**
3. Write your online coaching sales page using **Prompt: Online Coaching Package Sales Page**
4. Create your onboarding questionnaire using **Prompt: Onboarding Questionnaire** from `03-client-coaching-prompts.md`
5. Draft your client agreement using **Prompt: Training Contract/Agreement Language**

**Phase 2 — Visibility (weeks 2–3)**

1. Plan your first month of Instagram content using **Prompt: Instagram Content Calendar**
2. Write your Google Business Profile content using **Prompt: Google Business Profile Optimization**
3. Write 2 local SEO blog posts using **Prompt: Local SEO Blog Post**
4. Set up your email list and write your first newsletter using **Prompt: Email Newsletter**

**Phase 3 — Acquisition (week 4+)**

1. Write your Facebook/Instagram ad using **Prompt: Facebook/Instagram Ad**
2. Pitch 3 local podcasts using **Prompt: Podcast Pitch/Guest Appearance Outreach**
3. Ask current clients for testimonials using **Prompt: Client Testimonial Request**
4. Launch your referral program using **Prompt: Referral Program Announcement**

---
