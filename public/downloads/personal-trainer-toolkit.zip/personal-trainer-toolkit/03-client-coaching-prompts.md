# 03 — Client Coaching & Communication Prompts

*22 prompts for onboarding, check-ins, motivation, and client management*

---

### 1. New Client Welcome Email
*Use immediately after a new client signs up.*

```
Write a warm, professional welcome email for a new personal training client.

Client name: [CLIENT_NAME]
Training start date: [DATE]
Training format: [IN-PERSON / ONLINE / HYBRID]
Location (if in-person): [GYM / STUDIO / CLIENT'S HOME]
What they signed up for: [E.G., 3X/WEEK PERSONAL TRAINING / 12-WEEK TRANSFORMATION PROGRAM / MONTHLY ONLINE COACHING]
Their primary goal: [GOAL]
Anything I know about their situation: [E.G., "HASN'T TRAINED IN 5 YEARS" / "PREPARING FOR A WEDDING"]

The email should:
- Make them feel excited and confident they made the right decision
- Tell them exactly what to expect before their first session
- List what to bring / wear / do beforehand
- Include my contact info for questions
- Set the tone for a professional, results-driven relationship
```

---

### 2. Initial Fitness Assessment Script
*Use to conduct or document a new client assessment.*

```
Create a new client fitness assessment protocol and script for:

Client: [AGE, SEX, GOAL, ANY HEALTH CONDITIONS DISCLOSED]
Assessment type: [IN-PERSON / PHONE INTAKE / ONLINE QUESTIONNAIRE]
Time available: [MINUTES]
Testing equipment available: [LIST — E.G., TAPE MEASURE, SCALE, STOPWATCH, RESISTANCE BANDS]

Include:
1. Intake questions (health history, lifestyle, goals, previous training)
2. Movement screen (which screens, what to look for, red flags)
3. Basic fitness tests appropriate for their level (with norms for comparison)
4. Body composition measurements (if applicable and agreed to by client)
5. Script for how to review findings with the client in an encouraging way
6. Template for documenting findings for your records
```

---

### 3. Weekly Check-In Template
*Use for regular client progress conversations.*

```
Create a weekly check-in structure for my online/hybrid coaching clients.

Delivery method: [EMAIL / TEXT / APP / VOICE MEMO]
Check-in day: [DAY OF WEEK]
Client profile: [GOAL, CURRENT PROGRAM WEEK]

Design a check-in that covers:
1. Workout completion (adherence questions)
2. Energy and recovery (sleep, stress, soreness)
3. Nutrition adherence (if I'm coaching nutrition)
4. Wins from the week (always capture these)
5. Anything that got in the way
6. Questions or concerns
7. Focus for next week

Keep it to 5 minutes or less to answer. Provide a template in [FORM / BULLET LIST / PARAGRAPH] format that feels personal, not like a corporate survey. Also write my response template for typical scenarios (great week / missed workouts / plateau).
```

---

### 4. Motivational Message for Struggling Client
*Use when a client is losing motivation or considering quitting.*

```
Write a motivational message for a client who is struggling.

Client name: [CLIENT_NAME]
What's going on: [E.G., "MISSED 3 SESSIONS IN A ROW AND HASN'T RESPONDED TO MY TEXTS" / "SAYS THEY FEEL LIKE THEY'RE NOT MAKING PROGRESS" / "DEALING WITH HIGH STRESS AT WORK"]
Where they started: [BRIEF DESCRIPTION OF STARTING POINT]
Progress they've actually made (even if they can't see it): [LIST REAL EVIDENCE]
Their original "why": [WHAT MOTIVATED THEM TO START]

The message should:
- Be genuine, not generic
- Acknowledge the difficulty without dismissing it
- Remind them of specific progress (not vague encouragement)
- Reconnect them with their original goal
- Give them one tiny action to take today (not "just get back to it")
- Sound like it came from a person who actually knows them, not a template
```

---

### 5. Goal-Setting Session Guide
*Use when helping a client set meaningful, achievable goals.*

```
Create a structured goal-setting session guide for a new or re-evaluating client.

Client situation: [NEW CLIENT / RETURNING CLIENT AFTER A BREAK / CLIENT WHOSE GOAL HAS CHANGED]
Time available: [MINUTES]
Their stated goal (vague version): [E.G., "I WANT TO LOSE WEIGHT" / "I WANT TO GET FIT" / "I WANT TO RUN A MARATHON"]

Design a goal-setting conversation that:
1. Uncovers the real "why" behind the surface goal (3-level why exercise)
2. Transforms the vague goal into a SMART goal with my input
3. Identifies potential obstacles proactively
4. Creates 1 "process goal" (behavior) alongside the outcome goal
5. Gets the client to articulate what success looks, feels, and sounds like
6. Establishes check-in milestones
7. Gets verbal (and ideally written) commitment

Include the actual conversation questions and my script for moving between sections.
```

---

### 6. Non-Scale Victory Celebration Message
*Use to acknowledge client progress beyond weight loss.*

```
Write a celebration message for a client who has achieved a non-scale victory.

Client name: [CLIENT_NAME]
The achievement: [E.G., "DID THEIR FIRST FULL PUSH-UP" / "RAN THEIR FIRST MILE WITHOUT STOPPING" / "WENT 30 DAYS WITHOUT MISSING A SESSION" / "FIT INTO OLD JEANS"]
Their overall goal: [WHAT THEY'RE WORKING TOWARD]
How long they've been training with me: [TIMEFRAME]

The message should:
- Be genuinely enthusiastic (this matters more than the scale)
- Connect this achievement to their larger goal
- Reinforce that THIS is what progress looks like
- Motivate continued effort without pressure
- Feel personal and specific — not like a form letter
```

---

### 7. Session No-Show / Cancellation Response
*Use when a client misses a session or cancels last-minute.*

```
Write a message to a client who no-showed (or late-cancelled) a training session.

Client name: [CLIENT_NAME]
Situation: [FIRST TIME / PATTERN OF MISSING / GENUINE EMERGENCY]
My cancellation policy: [E.G., 24-HOUR NOTICE REQUIRED / FIRST MISS FREE / FULL SESSION CHARGED]
My goal with this message: [ENFORCE THE POLICY / CHECK IN WARMLY / RESCHEDULE WITHOUT DRAMA]

The message should:
- Be warm but clear
- State the policy if applicable (without sounding punitive)
- Open the door to reschedule easily
- Not make them feel so bad they avoid coming back entirely
- Protect the business while preserving the relationship

Write two versions: one for a first-time no-show, one for a pattern.
```

---

### 8. Client Progress Report (Monthly)
*Use to send formal monthly summaries to clients.*

```
Write a monthly progress report for a client.

Client: [CLIENT_NAME]
Month: [MONTH/YEAR]
Program they're on: [BRIEF DESCRIPTION]
Workouts completed: [NUMBER OUT OF PLANNED]

Stats (include what's applicable):
- Starting weight / current weight: [DATA]
- Body measurements changes: [DATA]
- Performance benchmarks: [E.G., "SQUAT WENT FROM 95 LBS TO 135 LBS"]
- Endurance improvements: [DATA]
- Notable non-scale victories: [LIST]

Upcoming focus for next month: [BRIEF]

Write this as a professional yet warm 1-page summary that:
- Leads with wins (always)
- Presents data in context (e.g., why a 2 lb loss is actually significant)
- Sets the tone for the next month
- Reminds them why the investment is worth it
```

---

### 9. Handling Client Plateau Conversation
*Use when a client is frustrated by a lack of progress.*

```
Script a conversation for when a client feels stuck or isn't seeing results.

Client situation: [DESCRIBE — E.G., "BEEN TRAINING 8 WEEKS, SCALE HASN'T MOVED, GETTING FRUSTRATED"]
Actual progress they have made: [LIST — EVEN SMALL THINGS]
Likely causes of the plateau: [E.G., NUTRITION INCONSISTENCY / SLEEP / STRESS / PROGRAM ADAPTATION]
What I want to adjust: [DESCRIBE THE PROGRAM OR LIFESTYLE CHANGES I'M CONSIDERING]

Write:
1. How to open the conversation (validate frustration, don't dismiss)
2. How to reframe what "progress" means for their goal
3. How to walk through what might be causing the plateau without being accusatory
4. How to present the changes as exciting, not as "you've been doing it wrong"
5. How to re-establish momentum with a clear 4-week plan
```

---

### 10. Client Testimonial Request
*Use when asking a satisfied client for a review or referral.*

```
Write a message asking a satisfied client for a testimonial and/or referral.

Client name: [CLIENT_NAME]
Their results: [SPECIFIC — E.G., "LOST 18 LBS AND RAN HER FIRST 5K"]
How long they've trained with me: [TIMEFRAME]
Where I want the testimonial: [GOOGLE / INSTAGRAM / YELP / JUST A QUOTE I CAN USE]
Am I offering anything in return: [DISCOUNT ON NEXT PACKAGE / REFERRAL CREDIT / NOTHING — JUST ASKING]

The message should:
- Be genuine and reference their specific results
- Make it easy (tell them exactly what to say or give them prompts)
- Not feel transactional or pushy
- Include a clear next step and link

Also write 3 alternative testimonial "prompts" I can give them if they say "I don't know what to write."
```

---

### 11. Training Contract / Agreement Language
*Use to draft the key terms for a client agreement.*

```
Write professional terms and conditions language for a personal training client agreement.

Business name: [YOUR_BUSINESS_NAME]
Services offered: [IN-PERSON / ONLINE / SEMI-PRIVATE]
Payment terms: [E.G., MONTHLY AUTO-CHARGE / PAY-PER-SESSION / PACKAGE UPFRONT]
Cancellation policy: [YOUR POLICY]
Refund policy: [YOUR POLICY]
Liability waiver: [YES — INCLUDE STANDARD LANGUAGE]
Health disclaimer: [YES — INCLUDE STANDARD LANGUAGE]
State: [YOUR STATE — NOTE: THIS IS A STARTING POINT, NOT LEGAL ADVICE]

Draft the key clauses for: (1) Services Provided, (2) Payment Terms, (3) Cancellation Policy, (4) Refund Policy, (5) Assumption of Risk and Liability Waiver, (6) Health Representation, (7) Intellectual Property (if providing programming), (8) Termination.

Disclaimer: I'll have a lawyer review this before using it.
```

---

### 12. Difficult Conversation: Recommending a Client Pause Training
*Use when a client needs to stop or reduce training for health, financial, or personal reasons.*

```
Help me script a sensitive conversation where I recommend a client pause or reduce training.

Situation: [E.G., "CLIENT IS SHOWING SIGNS OF OVERTRAINING AND IGNORING RECOVERY" / "CLIENT IS CLEARLY STRESSED ABOUT THE COST BUT WON'T BRING IT UP" / "CLIENT HAS A HEALTH ISSUE THEY HAVEN'T ADDRESSED WITH A DOCTOR"]
My concern: [DESCRIBE SPECIFICALLY]
Desired outcome: [E.G., "THEY TAKE 2 WEEKS OFF AND COME BACK REFRESHED" / "THEY TALK TO THEIR DOCTOR BEFORE CONTINUING" / "WE REDUCE FROM 3X TO 2X WITHOUT THEM FEELING LIKE I'M PUSHING THEM OUT"]

Script the conversation so that:
- I lead with care for their wellbeing, not the business impact
- I'm direct without being harsh
- I give them an easy path to the outcome I'm recommending
- I leave the door open for when they're ready to return or escalate
- They feel supported, not fired
```

---

### 13. Offboarding / Graduation Message
*Use when a client completes their program or ends training.*

```
Write an offboarding message for a client who is completing their program or ending training.

Client: [CLIENT_NAME]
Reason for ending: [COMPLETED PROGRAM GOAL / MOVING / FINANCIAL / SCHEDULE CHANGE / NATURAL END POINT]
Their transformation: [WHAT THEY ACHIEVED — BE SPECIFIC]
Time trained together: [DURATION]

Write:
1. A personal farewell message celebrating their journey
2. A maintenance plan or next steps recommendation (even if they're not continuing with me)
3. An invitation to return
4. A referral ask (if appropriate)

Tone: Warm, genuine pride, no guilt-tripping about leaving. Make them feel like they won.
```

---

### 14. Onboarding Questionnaire
*Use to create a comprehensive intake form for new clients.*

```
Create a new client onboarding questionnaire for my personal training business.

My services: [IN-PERSON / ONLINE / HYBRID]
Client type I typically work with: [E.G., BUSY PROFESSIONALS / WOMEN OVER 40 / ATHLETES / GENERAL POPULATION]
Training focus: [STRENGTH / FAT LOSS / PERFORMANCE / GENERAL FITNESS]

Design a questionnaire covering:
1. Personal information (name, age, contact)
2. Health history (conditions, medications, injuries, surgeries)
3. Lifestyle (sleep, stress, job type, activity level)
4. Nutrition basics (eating habits, restrictions, diet history)
5. Training history (what they've done, what worked, what didn't)
6. Goals (primary, secondary, timeline, what success looks like)
7. Logistics (schedule, equipment access, budget if appropriate)
8. Mindset (motivation style, how they handle setbacks, accountability preferences)

Keep each section concise. The whole questionnaire should take under 15 minutes to complete.
```

---

### 15. Email Nurture Sequence for Prospects
*Use to follow up with leads who haven't converted yet.*

```
Write a 4-email nurture sequence for a prospect who inquired about personal training but hasn't signed up.

Prospect situation: [WHAT THEY TOLD ME WHEN THEY REACHED OUT — E.G., "WANTS TO LOSE WEIGHT, HASN'T TRAINED IN YEARS, SAID SHE'D THINK ABOUT IT"]
My offer: [DESCRIBE YOUR SERVICES AND PRICE RANGE]
Their likely objection: [E.G., COST / TIME / FEAR OF THE GYM / "DO I REALLY NEED A TRAINER?"]

Email 1 (Day 1 after inquiry): Re-engage with value, not pressure
Email 2 (Day 4): Address their likely objection with social proof or logic
Email 3 (Day 8): Share a transformation story or result relevant to their situation
Email 4 (Day 14): Soft close — last chance to take advantage of [OFFER/AVAILABILITY]

Each email: Under 200 words. Personal tone, not corporate. Clear single CTA.
```

---

### 16. Instagram / Social DM Response Templates
*Use to handle common DMs from potential clients professionally.*

```
Write response templates for the following common social media DM scenarios for my personal training business:

My niche/focus: [E.G., FAT LOSS FOR WOMEN / STRENGTH TRAINING OVER 50 / ONLINE COACHING]
My typical offer: [DESCRIBE BRIEFLY]

Write templates for:
1. "How much do you charge?"
2. "Do you do online training?"
3. "I'm a complete beginner, is that okay?"
4. "I've tried everything and nothing works"
5. "I'm interested but I need to talk to my spouse first"
6. "Can I see some results/testimonials?"

Each response should:
- Be conversational, not robotic
- Move toward booking a free call or consultation
- Not give away too much free advice (preserve the consultation)
- Sound like me, not a sales script
```

---

### 17. Session Recap / Notes Template
*Use to document each session for your own records and client communication.*

```
Create a session recap template I can fill in after each training session.

Client: [CLIENT_NAME]
Session date: [DATE]
Session number: [NUMBER IN THEIR PROGRAM]
Session goal: [WHAT TODAY WAS FOCUSED ON]

Exercises, loads, sets, reps: [I'LL FILL IN]
Performance vs. last session: [I'LL FILL IN — BETTER / SAME / WORSE AND WHY]
Technique observations: [WHAT I NOTICED — GOOD AND NEEDS WORK]
Energy/recovery today: [CLIENT'S REPORTED AND OBSERVED ENERGY]
Conversation notes: [ANYTHING PERSONAL THEY SHARED — STRESS, SLEEP, ETC.]
Next session focus: [BASED ON TODAY]
Cues to revisit: [COACHING CUES TO REMEMBER FOR THIS CLIENT]

Format this as a clean, one-page template I can fill in quickly after every session and keep in [GOOGLE DOCS / NOTION / PAPER]. Make it fast to complete — under 5 minutes.
```

---

### 18. Handling a Client Who Wants to Cancel
*Use when a client is thinking about stopping their training.*

```
Script a retention conversation for a client who says they want to cancel or pause their training.

Client: [CLIENT_NAME]
Stated reason: [E.G., "TOO EXPENSIVE RIGHT NOW" / "I DON'T HAVE TIME" / "I CAN DO IT ON MY OWN NOW" / "NOT SEEING RESULTS"]
How long they've been training with me: [DURATION]
Real progress they've made: [LIST ACTUAL RESULTS]
What I suspect is really going on: [IF I HAVE A SENSE — E.G., STRESS, CONFIDENCE, FINANCIAL]

Write:
1. My immediate verbal response (calm, curious, not defensive)
2. Questions to ask to understand the real objection
3. A tailored retention offer based on their reason (adjust package / pause vs. cancel / bridge option)
4. What to say if they still want to cancel (graceful, keep the door open, ask for a referral)

I want to save this client if possible, but I don't want to beg — I want to find a genuine win-win.
```

---

### 19. Referral Program Announcement
*Use to launch or communicate a referral program to existing clients.*

```
Write a message announcing a referral program to my existing training clients.

Referral offer: [E.G., "REFER A FRIEND WHO SIGNS UP AND YOU BOTH GET ONE FREE SESSION" / "$50 CREDIT FOR EVERY CLIENT YOU REFER WHO STAYS FOR 30 DAYS"]
Who I'm sending this to: [ALL CLIENTS / MY LONGEST-TERM CLIENTS / MY MOST RESULTS-DRIVEN CLIENTS]
My business context: [E.G., "I HAVE 3 OPEN SPOTS" / "OPENING A NEW LOCATION" / "LAUNCHING ONLINE COACHING"]

The message should:
- Make them feel special (they're getting early access or insider info)
- Explain the offer clearly and simply
- Make it easy to refer (give them talking points or a referral link/code)
- Not feel like a corporate marketing email — should feel like it's from their trainer
```

---

### 20. Fitness Challenge Invitation
*Use to create engagement and excitement with a short group challenge.*

```
Write an invitation for a [NUMBER]-day fitness challenge for my clients and audience.

Challenge type: [E.G., 30-DAY PUSH-UP CHALLENGE / 21-DAY FAT LOSS CHALLENGE / 6-WEEK TRANSFORMATION]
Who it's for: [EXISTING CLIENTS / EMAIL LIST / SOCIAL MEDIA FOLLOWERS / ALL]
What participants do: [BRIEFLY DESCRIBE THE DAILY/WEEKLY COMMITMENT]
What they get: [COMMUNITY SUPPORT / PROGRAMMING / ACCOUNTABILITY / PRIZE]
Cost: [FREE / PAID — AMOUNT]
Start date: [DATE]

Write:
1. The social media announcement (150 words)
2. The email invitation (250 words)
3. The welcome message for participants who sign up
4. The challenge rules/structure document (brief)
```

---

### 21. Post-Session Feedback Request
*Use to gather structured feedback from clients about their experience.*

```
Write a post-session or post-program feedback request for my personal training clients.

Context: [AFTER FIRST SESSION / AFTER 1 MONTH / AFTER COMPLETING A PROGRAM]
Format: [EMAIL / TEXT / SHORT SURVEY]
What I want to know: [WHAT'S WORKING / WHAT ISN'T / WOULD THEY RECOMMEND ME / NET PROMOTER SCORE]

Create:
1. A brief message framing the request (make it feel valued, not like a chore)
2. 5–7 feedback questions (mix of rating scale and open-ended)
3. A follow-up thank-you message

Make the questions specific enough to give me actionable data, not just "how was your experience?"
```

---

### 22. Client Success Story (For Marketing Use)
*Use to document and share client results with permission.*

```
Write a client success story for marketing purposes.

IMPORTANT: Client has given explicit written permission to share their story.

Client: [FIRST NAME OR ALIAS ONLY UNLESS THEY'VE AGREED TO FULL NAME]
Their situation when they started: [DESCRIBE — BE SPECIFIC ABOUT THE CHALLENGE]
What program they did: [BRIEF DESCRIPTION]
Timeline: [DURATION OF TRAINING]
Measurable results: [SPECIFIC NUMBERS — WEIGHT, MEASUREMENTS, PERFORMANCE BENCHMARKS]
Non-scale victories: [HOW THEIR LIFE CHANGED]
Their own words about the experience: [QUOTE FROM THEIR TESTIMONIAL IF AVAILABLE]

Write:
1. A long-form story (400–500 words) for my website
2. A short version (150 words) for email or social
3. A 3-sentence Instagram caption version
4. A headline option for each version

Keep it inspiring and specific — generic "she lost weight and feels great" stories convert nobody.
```

---
