# 07 — The Personal Trainer's AI Cheat Sheet

*The 12 most powerful prompts in this toolkit — ready to copy, paste, and use right now*

---

> **How to use:** Fill in every `[BRACKET]` with your real context before pasting. The quality of your output is directly proportional to the specificity of your inputs.

---

### 🏆 Prompt 1: The Complete 12-Week Program
*Source: 02-program-design-prompts.md*
*Why it's here: Your highest-leverage use of AI — a full program in 20 minutes instead of 3 hours.*

```
You are an experienced personal trainer and strength coach. Create a complete 12-week training program for the following client:

Client profile:
- Age: [AGE] | Sex: [SEX] | Fitness level: [BEGINNER/INTERMEDIATE/ADVANCED]
- Primary goal: [FAT LOSS / MUSCLE GAIN / ATHLETIC PERFORMANCE / GENERAL FITNESS]
- Training days per week: [NUMBER] | Session length: [MINUTES]
- Equipment: [FULL GYM / HOME GYM / BODYWEIGHT ONLY]
- Injuries or limitations: [LIST OR NONE]

Organize into 3 four-week phases. For each week include training split, sets/reps/tempo/rest, key exercises with rationale, and progression parameters. Include a client-facing rationale paragraph.
```

---

### 🏆 Prompt 2: Single Session Plan
*Source: 02-program-design-prompts.md*
*Why it's here: Use it the night before every session. 10 minutes of prep = a significantly better training hour.*

```
Create a detailed single training session:

Client: [FITNESS LEVEL, GOAL, LIMITATIONS]
Session goal: [LOWER BODY STRENGTH / UPPER BODY HYPERTROPHY / FULL BODY CONDITIONING]
Session length: [MINUTES] | Equipment: [LIST]
Program context: [WEEK X, PHASE]
Notes from last session: [ANYTHING RELEVANT]

Format: Warm-up → Activation → Main work (exercise/sets/reps/tempo/rest/coaching cues) → Accessory → Cooldown
```

---

### 🏆 Prompt 3: New Client Welcome Email
*Source: 03-client-coaching-prompts.md*
*Why it's here: First impressions matter. A great welcome email reduces no-shows and sets the relationship tone.*

```
Write a warm, professional welcome email for a new personal training client.

Client: [CLIENT_NAME] | Start date: [DATE] | Format: [IN-PERSON / ONLINE]
What they signed up for: [DESCRIBE PACKAGE]
Their primary goal: [GOAL]
Additional context: [ANYTHING PERSONAL YOU KNOW]

The email should make them excited and confident, tell them exactly what to expect, list what to bring/do before session 1, and set a professional tone.
```

---

### 🏆 Prompt 4: Protein Guide for Non-Trackers
*Source: 04-nutrition-lifestyle-prompts.md*
*Why it's here: Most clients under-eat protein. This gives them a simple, personalized system without obsessive tracking.*

```
Write a personalized protein guide for a client who doesn't want to count calories.

Client: [WEIGHT, GOAL — FAT LOSS/MUSCLE GAIN/GENERAL HEALTH]
Target: [CALCULATE: 0.7–1G PER LB BODYWEIGHT]
Foods they like: [LIST] | Foods they avoid: [LIST]
Diet: [OMNIVORE / VEGETARIAN / VEGAN]

Include: top 10 protein sources with amounts, 3 sample daily menus hitting the target, and 5 "protein boosts" they can add to existing meals.
```

---

### 🏆 Prompt 5: Motivational Re-Engagement Message
*Source: 03-client-coaching-prompts.md*
*Why it's here: Every trainer has ghost clients. This is how you bring them back.*

```
Write a motivational message for a client who has been absent and isn't responding.

Client: [CLIENT_NAME]
Situation: [HOW LONG THEY'VE BEEN MISSING, WHAT YOU KNOW ABOUT WHAT'S HAPPENING]
Real progress they made before going quiet: [LIST SPECIFICS]
Their original motivation for starting: [WHAT BROUGHT THEM IN]

The message should be genuine, reference their specific progress, reconnect with their original why, and give them one small action to take today. Sound personal, not templated.
```

---

### 🏆 Prompt 6: Monthly Progress Report
*Source: 03-client-coaching-prompts.md*
*Why it's here: Clients who see their progress in writing stay longer. This takes 10 minutes and dramatically improves retention.*

```
Write a monthly progress report for a client.

Client: [NAME] | Month: [MONTH/YEAR] | Program: [BRIEF DESCRIPTION]
Workouts completed: [X out of Y planned]
Stats: [WEIGHT CHANGE, MEASUREMENTS, STRENGTH BENCHMARKS, ENDURANCE IMPROVEMENTS]
Non-scale victories: [LIST]
Next month focus: [BRIEF]

Lead with wins. Present data in context. Set tone for next month. Remind them the investment is worth it.
```

---

### 🏆 Prompt 7: Plateau Diagnosis and Conversation Script
*Source: 03-client-coaching-prompts.md + 02-program-design-prompts.md*
*Why it's here: Plateaus are the #1 reason clients quit. This turns a crisis into a coaching moment.*

```
A client has trained for [X] weeks without meaningful progress toward their [GOAL] goal.

Training history: [DESCRIBE WHAT THEY'VE BEEN DOING]
Nutrition adherence: [HONEST ASSESSMENT]
Sleep/stress: [RELEVANT FACTORS]
Real wins they have made (even if they can't see them): [LIST]

1. Diagnose the most likely cause of the plateau
2. Suggest 3 program adjustments to break it
3. Write the conversation script: how to open it, validate frustration, present the diagnosis, co-create the solution
4. Design a 4-week reset mini-block
```

---

### 🏆 Prompt 8: Corrective Exercise Program
*Source: 02-program-design-prompts.md*
*Why it's here: Pain and dysfunction lose clients. Fix the pattern and they stay for years.*

```
Create a corrective exercise program for:

Client: [AGE, FITNESS LEVEL]
Issue: [ANTERIOR PELVIC TILT / ROUNDED UPPER BACK / KNEE VALGUS / FORWARD HEAD / OTHER]
Root cause (if assessed): [TIGHT + WEAK MUSCLES INVOLVED]
Time available for corrective work: [15 MIN BEFORE MAIN TRAINING / STANDALONE]

Provide the inhibit → lengthen → activate → integrate sequence with specific exercises, sets/reps/holds, a daily home routine, and what to watch for to know it's working.
```

---

### 🏆 Prompt 9: Instagram Caption (Transformation Post)
*Source: 05-business-marketing-prompts.md*
*Why it's here: Client results are your best marketing. This prompt turns a before/after into a story that sells.*

```
Write an Instagram caption for a client transformation. [Client has given written permission.]

Client: [FIRST NAME OR ALIAS]
Starting situation: [SPECIFIC — NOT VAGUE]
Results: [SPECIFIC NUMBERS AND LIFE CHANGES]
Timeframe: [HOW LONG]
What made the difference: [YOUR APPROACH]
CTA: [DM ME / LINK IN BIO / BOOK A FREE CALL]

Write: full caption (200–300 words), short version (50 words), hook-only version (scroll-stopper first line), and 15 targeted hashtags.
```

---

### 🏆 Prompt 10: Handling a Cancellation Attempt
*Source: 03-client-coaching-prompts.md*
*Why it's here: Retention is more profitable than acquisition. This script saves clients without desperation.*

```
Script a retention conversation for a client who says they want to cancel.

Client: [CLIENT_NAME]
Stated reason: [TOO EXPENSIVE / NO TIME / "CAN DO IT ALONE" / NOT SEEING RESULTS]
Real progress they've made: [LIST ACTUAL RESULTS]
What I suspect is really going on: [YOUR HONEST READ]

Write: my immediate verbal response, questions to uncover the real objection, a tailored retention offer for their specific reason, and what to say if they still want to cancel (graceful, no guilt, keep the door open).
```

---

### 🏆 Prompt 11: Weekly Check-In Response Templates
*Source: 03-client-coaching-prompts.md*
*Why it's here: Online coaches who respond fast and well retain clients. These save 30+ min/week.*

```
Write weekly check-in response templates for my online coaching clients.

Create response templates for these scenarios:
1. Great week — hit all workouts, feeling strong
2. Missed 2–3 workouts due to busy week
3. Completed workouts but scale didn't move / feeling discouraged
4. Dealing with injury or pain during a movement
5. Asking to change a specific exercise they don't like
6. Saying they want to quit / are frustrated

Each response: warm but direct, addresses the specific situation, gives a clear next step, under 100 words.
```

---

### 🏆 Prompt 12: Pre-Workout Nutrition Q&A
*Source: 04-nutrition-lifestyle-prompts.md*
*Why it's here: You get this question weekly. Have a great answer ready.*

```
Write a personalized pre and post-workout nutrition guide for a client.

Client: [GOAL, TRAINING SCHEDULE]
Training time: [MORNING / MIDDAY / EVENING]
Training type: [STRENGTH / CARDIO / MIXED] | Duration: [MINUTES]

Cover: pre-workout timing and food choices, intra-workout hydration, post-workout nutrition (what research actually says vs. myths), specific food examples, adjustments for fasted morning training, and supplement evidence summary. Keep it practical and myth-free.
```

---

## QUICK VARIABLE CHEAT SHEET

| Variable | What to put |
|----------|-------------|
| [CLIENT_NAME] | Their first name (or alias for social posts) |
| [FITNESS_LEVEL] | Beginner / Intermediate / Advanced |
| [GOAL] | Fat loss / Muscle gain / Performance / General health |
| [TRAINING_DAYS] | Number of days/week they can train |
| [SESSION_LENGTH] | In minutes (be realistic) |
| [EQUIPMENT] | Full gym / Home gym with X / Bodyweight only |
| [LIMITATIONS] | Injuries, health conditions, exercises to avoid |
| [PROGRAM_WEEK] | Which week they're on (for session plans) |

---

*Full prompt libraries in files 02–05. These 12 cover the most common daily needs.*
