# 💪 The Personal Trainer's AI Prompt Toolkit

**90+ AI prompts for personal trainers, fitness coaches, and gym owners**

---

## What's Inside

This toolkit gives personal trainers and fitness coaches instant access to professional-grade prompts for every part of running a training business — from writing training programs to coaching clients through plateaus to marketing your services and keeping clients for the long haul.

Every prompt is:
- **Fitness-specific** — Built for real training and coaching scenarios
- **Structured** — Uses `[BRACKET VARIABLES]` so you can customize for each client
- **Immediately usable** — Designed to produce programs, messages, and content you can use today

---

## File Guide

| File | Contents | Prompts |
|------|----------|---------|
| [01-quick-start-guide.md](01-quick-start-guide.md) | How to use this toolkit effectively | — |
| [02-program-design-prompts.md](02-program-design-prompts.md) | Training programs, workout plans, periodization | 23 |
| [03-client-coaching-prompts.md](03-client-coaching-prompts.md) | Check-ins, motivation, mindset, progress reviews | 22 |
| [04-nutrition-lifestyle-prompts.md](04-nutrition-lifestyle-prompts.md) | Nutrition guidance, habit coaching, lifestyle tips | 18 |
| [05-business-marketing-prompts.md](05-business-marketing-prompts.md) | Social content, client retention, referrals, ads | 17 |
| [06-workflow-sops.md](06-workflow-sops.md) | 5 complete trainer workflow playbooks | — |
| [07-cheat-sheet.md](07-cheat-sheet.md) | Top 15 power prompts + quick reference | 15 |

**Total: 90+ prompts**

---

## Who This Is For

- **Personal trainers** with 1-on-1 or small group clients
- **Online fitness coaches** managing clients remotely
- **Gym owners** who also train clients
- **Bootcamp and group fitness coaches** scaling their programs

---

*Built for trainers who change lives.*
