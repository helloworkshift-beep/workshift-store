# 05 — Business & Marketing Prompts

*18 prompts for growing your training business, building your brand, and attracting clients*

---

### 1. Personal Trainer Bio (Website/Instagram)
*Use to write your professional bio for your website or social profiles.*

```
Write a compelling personal trainer bio for my website and Instagram.

My name: [YOUR_NAME]
My certifications: [LIST — E.G., NASM-CPT, CSCS, PRECISION NUTRITION L1]
My specialties: [E.G., STRENGTH TRAINING FOR WOMEN / FAT LOSS / ATHLETIC PERFORMANCE / OLDER ADULTS]
My own fitness story: [BRIEF — WHAT BROUGHT YOU TO THIS PROFESSION]
My results (choose 1–2 client stats): [E.G., "HELPED 50+ CLIENTS LOSE THEIR FIRST 20 LBS" / "TRAINED COLLEGIATE ATHLETES"]
My approach in one sentence: [E.G., "I BUILD PROGRAMS THAT FIT YOUR LIFE, NOT THE OTHER WAY AROUND"]
My ideal client: [WHO DO YOU BEST SERVE]
Location/format: [CITY / ONLINE / BOTH]

Write:
1. A 200-word website "About" page bio (professional, first-person)
2. A 150-character Instagram bio (with emoji)
3. A 100-word "credibility paragraph" I can use in proposals or emails
```

---

### 2. Instagram Content Calendar (Monthly)
*Use to plan a month of social media content.*

```
Create a 30-day Instagram content calendar for a personal trainer.

My niche: [E.G., FAT LOSS / STRENGTH TRAINING / ONLINE COACHING / [TARGET AUDIENCE]]
My posting frequency: [X TIMES PER WEEK]
Content pillars I want to cover: [E.G., TIPS / CLIENT RESULTS / PERSONAL STORY / EDUCATION / PROMOTION]
Platforms: [INSTAGRAM FEED / REELS / STORIES / TIKTOK / ALL]
My personality/tone: [E.G., DIRECT AND NO-BS / WARM AND ENCOURAGING / SCIENCE-FORWARD / FUN]

For each post include:
- Day and format (Reel / Carousel / Static / Story)
- Topic and angle
- 1-sentence caption hook
- 3 relevant hashtags

Create a mix of educational, entertaining, and promotional content. No more than 20% promotional. Include at least 4 "story" ideas for behind-the-scenes or daily engagement.
```

---

### 3. Instagram Caption (Transformation Post)
*Use when sharing a client transformation result.*

```
Write an Instagram caption for a client transformation post.

IMPORTANT: Client has given written permission to share their story and photos.

Client first name (or alias): [NAME]
Their starting situation: [DESCRIBE — SPECIFIC, NOT VAGUE]
Their results: [SPECIFIC — WEIGHT LOST, STRENGTH GAINED, HOW THEIR LIFE CHANGED]
Timeframe: [HOW LONG IT TOOK]
What made the difference: [THE APPROACH, NOT JUST "HARD WORK"]
My call to action: [DM ME / LINK IN BIO / BOOK A FREE CALL]

Write:
1. A full caption (200–300 words) that tells the story and sells the result
2. A short version (50 words) for when I want the image to do the work
3. The first line / hook only (needs to stop the scroll)
4. 15 targeted hashtags

Focus on the transformation journey, not just the before/after. People buy outcomes, not processes.
```

---

### 4. YouTube / Podcast Intro Script
*Use when launching or improving your content presence.*

```
Write an intro script for my [YOUTUBE CHANNEL / PODCAST].

Show/channel name: [NAME]
My focus: [WHAT TOPICS YOU COVER]
Target audience: [WHO YOU'RE SPEAKING TO]
My unique angle: [WHAT MAKES YOUR CONTENT DIFFERENT FROM THE OTHER 10,000 FITNESS CHANNELS]
My background: [BRIEF]
What viewers/listeners will get: [THE VALUE THEY RECEIVE]
My call to subscribe/follow: [YOUR ASK]

Write:
1. A 60-second intro script I say at the beginning of each video/episode
2. A 30-second "channel trailer" hook script
3. A 200-word YouTube channel description
4. An Instagram bio that drives people to the channel
```

---

### 5. Email Newsletter (Weekly)
*Use to create weekly value-driven email content for your list.*

```
Write a weekly email newsletter for personal training subscribers.

My list: [TYPE OF SUBSCRIBERS — CURRENT CLIENTS / PROSPECTS / GENERAL FITNESS AUDIENCE]
This week's topic: [E.G., "WHY YOU'RE NOT BUILDING MUSCLE" / "THE REAL REASON DIETS FAIL" / "HOW I FIXED MY CLIENT'S PLATEAU"]
My goal for this email: [EDUCATE / PROMOTE A SERVICE / DRIVE ENGAGEMENT / BUILD RELATIONSHIP]
If promoting something: [DESCRIBE THE OFFER]

Write a 400-500 word email that:
- Opens with a personal hook (not "in today's newsletter...")
- Teaches something useful in the body
- Uses my voice (not corporate speak)
- Has one clear call to action at the end
- Includes a subject line (write 3 options)
- Includes a preview text line (under 90 characters)
```

---

### 6. Google Business Profile Optimization
*Use to write your Google listing content.*

```
Write Google Business Profile content for my personal training business.

Business name: [BUSINESS_NAME]
Location: [CITY, STATE] (or "Online coaching")
Services: [LIST YOUR MAIN SERVICES]
Specialties: [WHO YOU SERVE BEST]
Credentials: [CERTIFICATIONS, YEARS EXPERIENCE]
Unique value: [WHAT MAKES YOU DIFFERENT]

Write:
1. Business description (750 characters — the Google character limit)
2. 5 Google post ideas (text only, 150–300 words each) on different topics
3. Suggested service categories and how to describe each (50–100 words per service)
4. FAQ answers for the 5 most common questions potential clients ask (for the FAQ section)
```

---

### 7. Personal Training Pricing Page
*Use to write clear, conversion-optimized pricing for your website.*

```
Write website pricing page copy for my personal training business.

My services and prices:
- [SERVICE 1]: $[PRICE] (describe what's included)
- [SERVICE 2]: $[PRICE] (describe what's included)
- [SERVICE 3]: $[PRICE] (describe what's included)

My ideal client: [DESCRIBE]
The main objection to buying: [E.G., PRICE IS TOO HIGH / NOT SURE IF THEY NEED A TRAINER / HAD A BAD EXPERIENCE BEFORE]
My guarantee (if any): [DESCRIBE OR "NONE"]

Write a pricing page that:
- Opens with a value statement (not just a price list)
- Makes each package clearly distinct (who it's for)
- Addresses the price objection preemptively
- Uses social proof / results within the pricing context
- Ends with an easy call to action
- Doesn't apologize for the price
```

---

### 8. Facebook / Instagram Ad (Lead Generation)
*Use to create paid social ads for client acquisition.*

```
Write a Facebook/Instagram ad for my personal training services.

Target audience: [AGE RANGE, GENDER IF TARGETED, INTERESTS, LOCATION]
Offer: [E.G., FREE CONSULTATION / $97 30-DAY TRIAL / FREE TRAINING PLAN]
The one transformation I deliver: [SPECIFIC — E.G., "BUSY MOMS LOSE 20 LBS IN 12 WEEKS WITHOUT GIVING UP THEIR SOCIAL LIFE"]
The main pain point: [WHAT KEEPS THEM UP AT NIGHT]
Ad format: [SINGLE IMAGE / VIDEO / CAROUSEL]
Budget (optional): [DAILY BUDGET — AFFECTS COPY LENGTH AND URGENCY]

Write:
1. Primary text (2–3 short paragraphs, hook → problem → solution → CTA)
2. Headline (under 40 characters — this gets cut off)
3. Description (under 30 characters)
4. 3 alternative headline options to A/B test
5. The image/video creative concept (describe what visual would work best)
```

---

### 9. Client Referral Card / Leave-Behind
*Use to create printed material clients can share.*

```
Write copy for a referral card for my personal training business.

My name and business: [NAME / BUSINESS_NAME]
Card size: [BUSINESS CARD / POSTCARD / FLYER]
Referral offer: [E.G., "GIVE A FRIEND 1 FREE SESSION / BOTH GET $25 OFF"]
Tagline (or I'll write one): [YOUR TAGLINE OR "WRITE ONE FOR ME"]
Contact / booking info: [PHONE / WEBSITE / INSTAGRAM]
My specialty: [BRIEF — E.G., "STRENGTH TRAINING FOR PEOPLE OVER 40"]

Write the front and back of the card:
- Front: Hook, tagline, offer
- Back: Credibility, contact, QR code placeholder text, referral instructions

Make it feel premium — not like a coupon. People carry cards that feel worth carrying.
```

---

### 10. Podcast Pitch / Guest Appearance Outreach
*Use to pitch yourself as a guest on fitness or lifestyle podcasts.*

```
Write a podcast guest pitch email for my personal training business.

Podcast I'm pitching: [PODCAST_NAME]
The host: [HOST_NAME]
Their audience: [DESCRIBE — E.G., "BUSY PROFESSIONALS / WOMEN IN THEIR 40S / ENTREPRENEURS"]
My expertise: [WHAT I'D TALK ABOUT — BE SPECIFIC, NOT GENERIC "FITNESS"]
My angle: [WHAT MAKES MY TAKE FRESH OR CONTRARIAN]
My credentials: [BRIEF — RELEVANT CERTIFICATIONS, CLIENTS, RESULTS]
My own platform (if any): [INSTAGRAM FOLLOWING / PODCAST / YOUTUBE]
What I want from this: [NEW CLIENTS / BRAND AWARENESS / INDUSTRY CREDIBILITY]

Write a pitch email that:
- Opens with 1–2 sentences about why I specifically like their show
- Proposes 3 specific episode topics with working titles
- Briefly establishes my credibility without being self-congratulatory
- Makes it easy to say yes (no asks, no requirements, just value)
- Is under 200 words — podcasters are busy
```

---

### 11. Workshop or Webinar Promotional Copy
*Use to promote a fitness workshop or free webinar.*

```
Write promotional copy for a fitness workshop or webinar I'm hosting.

Event: [WORKSHOP / WEBINAR / LIVE CLASS / CHALLENGE KICKOFF]
Title: [YOUR TITLE OR "HELP ME CREATE ONE"]
Date and time: [DATE, TIME, TIMEZONE]
Format: [IN-PERSON / ONLINE / HYBRID]
Topic: [WHAT YOU'RE TEACHING]
Who it's for: [SPECIFIC AUDIENCE]
Cost: [FREE / $X]
Main outcome: [WHAT THEY'LL LEAVE WITH]
Limit: [NUMBER OF SPOTS, IF ANY]

Write:
1. Registration page headline and description (300 words)
2. Email announcement to my list (250 words)
3. 3 Instagram posts to promote it (different angles each)
4. Day-of reminder text message
5. Post-event email follow-up to attendees
```

---

### 12. LinkedIn Profile for Personal Trainer
*Use to build your professional presence on LinkedIn.*

```
Write LinkedIn profile content for a personal trainer.

Name: [YOUR_NAME]
Credentials: [CERTIFICATIONS, DEGREES IF ANY]
Current work: [YOUR BUSINESS NAME AND TYPE]
Previous experience: [ANY RELEVANT WORK HISTORY — SPORTS, HEALTHCARE, COACHING]
Target audience on LinkedIn: [E.G., CORPORATE WELLNESS / EXECUTIVE CLIENTS / B2B FITNESS PARTNERSHIPS / GENERAL]
Professional goal: [E.G., ATTRACT CORPORATE WELLNESS CLIENTS / BUILD PROFESSIONAL CREDIBILITY / FIND BRAND PARTNERSHIPS]

Write:
1. LinkedIn headline (220 character limit — make it more than just "Personal Trainer")
2. About section (2,600 character limit — use it well)
3. Featured section blurb (for a post or article to pin)
4. 3 LinkedIn post ideas that would perform well for my target audience
```

---

### 13. Business Plan One-Pager
*Use when you need to articulate your business model to a partner, investor, or yourself.*

```
Write a one-page business plan for my personal training business.

Business name: [NAME]
Services: [LIST]
Target market: [DESCRIBE YOUR IDEAL CLIENT PRECISELY]
Pricing: [YOUR RATES AND PACKAGES]
Revenue goal: [MONTHLY OR ANNUAL TARGET]
Current client count: [NUMBER]
Clients needed to hit goal: [CALCULATE]
Acquisition channels: [HOW YOU GET CLIENTS NOW AND HOW YOU PLAN TO GROW]
Competitive advantage: [WHY CLIENTS CHOOSE YOU]
Key expenses: [LIST MAJOR COSTS — RENT, INSURANCE, SOFTWARE, MARKETING]
12-month goal: [WHERE YOU WANT TO BE]

Organize this as a clean one-pager with sections: Business Overview, Target Market, Services & Pricing, Revenue Model, Marketing Strategy, 12-Month Goals. Make it something I'd be proud to show a potential business partner.
```

---

### 14. Text Marketing Message Templates
*Use for SMS marketing to your prospect and client list.*

```
Write text message marketing templates for my personal training business.

My offer: [CURRENT PROMOTION OR SERVICE]
Compliance note: These will only be sent to opted-in subscribers.

Write templates for:
1. New offer announcement (under 160 characters)
2. Spot availability notification ("I have 2 open slots this month")
3. Re-engagement for a cold prospect (last contacted 30+ days ago)
4. Appointment reminder (24-hour notice)
5. Class or workshop announcement
6. Follow-up after a free consultation (didn't convert yet)

Each text should:
- Identify who you are immediately
- Be under 160 characters (1 SMS)
- Have a single clear action
- Not feel spammy or mass-marketed
- Include opt-out instructions where required by law
```

---

### 15. Local SEO Blog Post
*Use to create local search-optimized content for your website.*

```
Write a blog post optimized for local search for my personal training website.

My location: [CITY, NEIGHBORHOOD, OR REGION]
My specialty: [E.G., PERSONAL TRAINER FOR WOMEN / STRENGTH COACHING / WEIGHT LOSS TRAINING]
Target keyword: [E.G., "PERSONAL TRAINER IN [CITY]" / "WEIGHT LOSS COACH [CITY]" / "ONLINE PERSONAL TRAINER [SPECIALTY]"]
Target audience: [WHO IS SEARCHING THIS]
Word count: [800–1200 WORDS]

Write a post that:
- Includes the target keyword naturally (not stuffed)
- Provides genuine value (answers a question real people search for)
- Includes a local angle (mentions the city/area authentically)
- Has headers (H2 and H3) organized logically
- Ends with a clear call to action (free consultation, contact form, etc.)
- Includes 3 internal link suggestions and 2 external link suggestions
```

---

### 16. Corporate Wellness Pitch
*Use to pitch your services to companies for their employee wellness programs.*

```
Write a corporate wellness program pitch for my personal training business.

Company I'm pitching: [COMPANY NAME AND INDUSTRY]
Decision maker: [TITLE — E.G., HR DIRECTOR / OFFICE MANAGER / CEO]
Company size: [APPROXIMATE EMPLOYEE COUNT]
What I'm offering: [E.G., LUNCH BREAK FITNESS CLASSES / ONLINE WELLNESS PROGRAM / QUARTERLY WORKSHOPS / ERGONOMIC ASSESSMENTS]
Pricing model: [PER EMPLOYEE / FLAT MONTHLY / WORKSHOP FEE]
Why corporate wellness matters: [THE BUSINESS CASE]
My credentials: [RELEVANT]

Write:
1. A cold outreach email (under 200 words)
2. A one-page program proposal outline
3. The key talking points for a follow-up call
4. An FAQ for common corporate objections (cost, liability, participation rates)
```

---

### 17. End-of-Year Business Review Template
*Use to reflect on your business performance and set goals for the coming year.*

```
Create a structured end-of-year business review template for my personal training business.

My services this year: [LIST]
Revenue (if comfortable including): [APPROXIMATE OR PERCENTAGE CHANGE]
Client stats: [CLIENTS STARTED / CLIENTS RETAINED / CLIENTS LOST]
Top marketing channels this year: [WHAT WORKED]
What didn't work: [HONEST ASSESSMENT]
Personal goals I hit: [LIST]
Personal goals I missed: [LIST]

Build a review template covering:
1. Revenue and client metrics analysis
2. Service and delivery review (what did clients love? what needed improvement?)
3. Marketing and acquisition analysis
4. Personal skills and education review
5. 3 lessons learned this year
6. 3 goals for next year (with specific metrics)
7. 1 thing I'm stopping, 1 thing I'm starting, 1 thing I'm continuing

Format as a reflection document I can spend 2 hours on once a year.
```

---

### 18. Online Coaching Package Sales Page
*Use to write a high-converting sales page for your online coaching offer.*

```
Write a sales page for my online personal training / coaching package.

Package name: [E.G., "THE 12-WEEK TRANSFORMATION" / "ONLINE COACHING MEMBERSHIP"]
Price: $[AMOUNT]
What's included: [LIST EVERYTHING]
Who it's for: [EXACT TARGET CLIENT — BE SPECIFIC]
The transformation they'll experience: [OUTCOME-FOCUSED]
Proof / social proof: [CLIENT RESULTS, TESTIMONIALS — EVEN BRIEF PARAPHRASES]
Guarantee (if any): [DESCRIBE OR NONE]
My credentials: [BRIEF]

Write a full sales page including:
1. Headline + subheadline (outcome-focused, specific)
2. Problem section (pain they're feeling right now)
3. Solution introduction (why this program)
4. What's included (features → benefits)
5. Who this is for (and who it's NOT for)
6. Social proof section
7. FAQ section (5 questions)
8. Pricing and CTA section
9. Guarantee section (if applicable)

Length: 600–900 words. Tone: confident, direct, warm — not hype.
```

---
