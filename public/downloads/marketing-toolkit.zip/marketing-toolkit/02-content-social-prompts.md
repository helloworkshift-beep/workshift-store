# 02 — Content & Social Media Prompts

> 25 prompts for LinkedIn, Twitter/X, Instagram, YouTube, Blog, and Content Calendars.

---

## LinkedIn Posts

---

### **Prompt 01 — The Contrarian LinkedIn Post**

*When to use: You want to challenge an industry assumption, spark debate, and drive high engagement on LinkedIn.*

```
You are a B2B content strategist and LinkedIn ghostwriter who specializes in thought leadership for [INDUSTRY] executives.

Write a LinkedIn post for [AUTHOR NAME/TITLE] at [COMPANY NAME] that challenges a common belief in [INDUSTRY].

Details:
- Contrarian take: [THE BELIEF YOU'RE CHALLENGING]
- Your actual position: [WHAT YOU BELIEVE INSTEAD]
- Supporting evidence or experience: [PROOF POINT OR STORY]
- Audience: [TARGET AUDIENCE — e.g., "VPs of Marketing at mid-market SaaS companies"]
- Tone: [TONE — e.g., "Direct, confident, slightly provocative but not arrogant"]
- Length: 150–200 words
- Format: Open with a bold statement. Use short paragraphs (1–2 sentences max). End with a question that invites comments.

Do NOT start with "I" or a generic opener like "Hot take:" — find a more original hook.
Do NOT use hashtags in the body — add 3 relevant hashtags at the very end.
```

---

### **Prompt 02 — The Personal Story LinkedIn Post**

*When to use: You want to humanize your brand, build trust, and share a lesson from a real experience.*

```
You are an expert LinkedIn copywriter who specializes in narrative-driven thought leadership.

Write a personal story LinkedIn post for [AUTHOR NAME], [TITLE] at [COMPANY NAME].

Story details:
- The situation: [WHAT HAPPENED — be specific, e.g., "We almost lost our biggest client in 2022"]
- The turning point: [WHAT CHANGED OR WHAT YOU REALIZED]
- The lesson: [KEY TAKEAWAY RELEVANT TO YOUR AUDIENCE]
- Connection to business/product: [HOW THIS RELATES TO WHAT YOU DO — keep this subtle, 1 sentence max]
- Audience: [TARGET AUDIENCE]
- Tone: [TONE — e.g., "Vulnerable, honest, self-deprecating but ultimately confident"]
- Length: 200–250 words

Format:
- Hook: A single line that creates curiosity or tension
- Build: 3–4 short paragraphs telling the story
- Lesson: 2–3 clear takeaways
- CTA: Soft — ask the audience a reflective question

No corporate speak. Write like a real human talking to another human.
```

---

### **Prompt 03 — The Data-Driven LinkedIn Post**

*When to use: You have a stat, case study result, or research finding and want to turn it into a high-value post.*

```
You are a B2B content strategist with deep expertise in [INDUSTRY].

Write a data-driven LinkedIn post for [COMPANY NAME] using the following:

Data/stat: [YOUR STAT OR FINDING — e.g., "Companies that post on LinkedIn 3x/week get 5x more profile views"]
Source: [SOURCE OR "our internal data"]
What this means for the audience: [THE SO-WHAT]
Recommended action: [WHAT THEY SHOULD DO WITH THIS INFORMATION]
Audience: [TARGET AUDIENCE]
Tone: [TONE — e.g., "Authoritative, educational, slightly urgent"]
Length: 150–200 words

Format:
- Open with the surprising stat (make it impossible to scroll past)
- Explain why it matters to this specific audience
- Give them 3 actionable implications or takeaways
- Close with a CTA: [CTA — e.g., "Comment your thoughts" or "DM us for the full report"]

Include 3–5 hashtags at the end, relevant to [INDUSTRY] and [TOPIC].
```

---

### **Prompt 04 — The LinkedIn Carousel Script**

*When to use: You want to create a swipeable carousel post that educates and drives saves/shares.*

```
You are a LinkedIn carousel expert and B2B educator.

Create a 10-slide LinkedIn carousel script for [COMPANY NAME] on the topic: [TOPIC/TITLE]

Audience: [TARGET AUDIENCE]
Goal: [GOAL — e.g., educate, generate leads, build authority]
Tone: [TONE]

For each slide, provide:
- Slide number
- Headline (max 8 words, punchy)
- Body copy (max 30 words per slide)
- Visual direction note (what image/graphic/icon works here)

Slide structure:
1. Cover slide: Bold hook/title that stops the scroll
2–3. Set up the problem or context
4–7. Core content (tips, steps, frameworks, or insights)
8–9. Advanced insight or the "so what"
10. CTA slide with [CTA] and company handle/logo note

Make each slide feel like it could stand alone. Tease the next slide at the end of key slides to drive swipes.

Topic details: [ANY ADDITIONAL CONTEXT, DATA, OR TALKING POINTS]
```

---

### **Prompt 05 — The LinkedIn Poll Post**

*When to use: You want to generate quick engagement, gather market research, and spark conversation.*

```
You are a LinkedIn engagement strategist.

Create a LinkedIn poll post for [COMPANY NAME] designed to get maximum engagement from [TARGET AUDIENCE] in [INDUSTRY].

Topic/Theme: [TOPIC]
Business goal of the poll: [GOAL — e.g., "understand our audience's biggest pain point around [X]"]
Tone: [TONE]

Deliver:
1. The poll question (clear, specific, debate-worthy)
2. 4 poll answer options (distinct, no obvious "right" answer — make people think)
3. A 50–80 word intro post that:
   - Explains why you're asking
   - Gives a teaser of what you'll share after results
   - Invites people to comment with their "real" answer if it's not one of the options

Make it feel like genuine curiosity, not a sales tactic.
```

---

## Twitter/X Threads

---

### **Prompt 06 — The Educational Twitter/X Thread**

*When to use: You want to share expertise, build a following, and establish authority on a specific topic.*

```
You are a viral Twitter/X thread writer specializing in [INDUSTRY/NICHE] content.

Write a 10-tweet educational thread for [BRAND/AUTHOR NAME] on: [TOPIC]

Audience: [TARGET AUDIENCE]
Core thesis (what will they know after reading?): [THESIS]
Tone: [TONE — e.g., "Smart, direct, no fluff — like a friend who knows their stuff"]

Thread structure:
- Tweet 1: The hook — a bold claim, counterintuitive fact, or compelling question. Must make people want to click "Show more."
- Tweets 2–4: Set up the problem or context (why this matters)
- Tweets 5–8: The core content — tips, steps, or insights. One idea per tweet. Short sentences. 
- Tweet 9: The "advanced" insight most people miss
- Tweet 10: Summary + CTA ([CTA]) + Note to RT tweet 1 if they found value

Rules:
- Each tweet max 280 characters
- No filler phrases ("In this thread I'll cover...")
- Use numbers where possible ("3 things", "87% of...")
- End tweets 2–9 with a micro-cliffhanger to keep readers scrolling
```

---

### **Prompt 07 — The Contrarian Thread**

*When to use: You want to challenge conventional wisdom in your industry and drive retweets and debate.*

```
You are a thought leadership content strategist for [INDUSTRY].

Write a contrarian Twitter/X thread for [AUTHOR/BRAND] that challenges the mainstream view on [TOPIC].

Mainstream belief: [WHAT MOST PEOPLE THINK]
Your contrarian position: [WHAT YOU ACTUALLY BELIEVE]
Evidence/reasoning: [WHY YOU'RE RIGHT]
Audience: [TARGET AUDIENCE]
Tone: [TONE — e.g., "Confident, a little provocative, backed by evidence — not just an opinion"]

Structure:
- Tweet 1: The hot take hook (state your contrarian position boldly)
- Tweets 2–3: Acknowledge the mainstream view fairly (show you understand it)
- Tweets 4–7: Break down your argument with specifics, data, or examples
- Tweet 8: Address the strongest counterargument and rebut it
- Tweet 9: The nuanced "here's when the mainstream view IS right"
- Tweet 10: Summary + discussion CTA ("What do you think? Reply below.")

Max 280 characters per tweet. Use line breaks to improve readability.
```

---

### **Prompt 08 — The Brand Announcement Thread**

*When to use: You're launching a product, feature, campaign, or major company news.*

```
You are a startup and brand communications expert.

Write a Twitter/X announcement thread for [COMPANY NAME] announcing [WHAT YOU'RE ANNOUNCING].

Details about the announcement:
- What it is: [DESCRIPTION]
- Why it exists (the problem it solves): [PROBLEM]
- Who it's for: [TARGET AUDIENCE]
- Key features or benefits: [FEATURES/BENEFITS — list 3–5]
- Availability: [LAUNCH DATE / HOW TO GET IT]
- CTA: [CTA]

Tone: [TONE — e.g., "Excited but not hypey, human, clear"]

Thread format (8–12 tweets):
- Tweet 1: The big reveal — hook + announcement
- Tweets 2–3: The problem you're solving (make people feel it)
- Tweets 4–6: What you built and why it's different
- Tweet 7: Social proof or early results if available: [PROOF]
- Tweet 8: How to get it / next steps
- Tweet 9: Thank the team, community, early users
- Final tweet: Link + CTA

Make it feel momentous without being cringe. Real excitement, not marketing speak.
```

---

## Instagram Captions

---

### **Prompt 09 — The B2C Product Feature Caption**

*When to use: You're showcasing a product and want to drive clicks, saves, or purchases.*

```
You are an Instagram copywriter specializing in B2C [INDUSTRY/PRODUCT CATEGORY] brands.

Write 3 versions of an Instagram caption for [BRAND NAME] showcasing [PRODUCT/FEATURE].

Product details:
- Product name: [PRODUCT NAME]
- Key benefit: [KEY BENEFIT]
- Target customer: [TARGET CUSTOMER — demographics, lifestyle, pain point]
- Visual description (what's in the photo/video): [VISUAL DESCRIPTION]
- Tone: [TONE — e.g., "Warm, aspirational, inclusive"]
- CTA: [CTA — e.g., "Link in bio to shop"]

For each version, provide:
- Version A: Storytelling-first (lead with an emotion or scenario, end with product)
- Version B: Benefit-first (lead with what they get, make it tangible)
- Version C: Social proof / community angle (lead with how others love it or use it)

Each caption: 100–150 words + 10–15 relevant hashtags grouped at the end.
Use line breaks for readability. Include 1–2 relevant emojis (not excessive).
```

---

### **Prompt 10 — The B2B Brand Authority Caption**

*When to use: A B2B brand wants to build credibility and thought leadership on Instagram.*

```
You are a B2B Instagram strategist who helps professional services and SaaS brands build authority.

Write an Instagram caption for [COMPANY NAME] on the topic: [TOPIC]

Context:
- What we want to convey: [KEY MESSAGE OR INSIGHT]
- Supporting proof: [STAT, CASE STUDY RESULT, OR EXAMPLE]
- Audience: [TARGET AUDIENCE on Instagram]
- Visual description: [WHAT'S IN THE IMAGE — e.g., infographic, team photo, product screenshot]
- Tone: [TONE — e.g., "Authoritative but approachable, like a smart mentor not a corporate brand"]
- CTA: [CTA — e.g., "Save this post" or "Comment your biggest challenge with [X]"]

Write one caption (100–150 words) that:
- Opens with a bold statement or surprising insight
- Delivers genuine value (teach something)
- Ends with an engagement CTA
- Uses 5–8 strategic hashtags (mix of niche and broad)
```

---

### **Prompt 11 — The Reel / Short Video Caption**

*When to use: Pairing a caption with a Reel, TikTok, or YouTube Short.*

```
You are a short-form video content strategist.

Write an Instagram Reel caption for [BRAND NAME] to accompany a video about [VIDEO TOPIC/CONTENT].

Video details:
- What happens in the video: [VIDEO DESCRIPTION]
- Key message or hook: [WHAT VIEWERS TAKE AWAY]
- Audience: [TARGET AUDIENCE]
- Tone: [TONE]
- CTA: [CTA]

Caption requirements:
- First line must be so compelling that people tap "more" (max 125 characters before the fold)
- Total length: 80–120 words
- Use 2–4 emojis naturally woven in (not clustered at the end)
- 8–12 hashtags at the end
- Optional: tag any relevant accounts ([ACCOUNTS TO TAG if applicable])

Also give me 3 alternative first-line options for A/B testing.
```

---

## YouTube Scripts

---

### **Prompt 12 — The YouTube Video Script (Educational)**

*When to use: Creating a 5–10 minute educational YouTube video to build authority and drive organic traffic.*

```
You are an expert YouTube scriptwriter specializing in [INDUSTRY] educational content.

Write a complete YouTube video script for [CHANNEL NAME / COMPANY NAME] on the topic: [VIDEO TITLE/TOPIC]

Details:
- Target audience: [AUDIENCE]
- Video goal: [GOAL — e.g., rank for "[KEYWORD]", drive traffic to [URL], build subscribers]
- Target length: [LENGTH — e.g., "7–9 minutes, approximately 1,100–1,400 words"]
- Tone: [TONE — e.g., "Conversational, energetic, clear — like a smart friend explaining something"]
- Key points to cover: [LIST 3–5 KEY POINTS]
- CTA at end: [CTA]

Script format:
[HOOK] — First 30 seconds: Start with a question, bold claim, or surprising stat. Do NOT start with "Hey guys, welcome back to my channel."
[INTRO] — 60 seconds: What they'll learn + why it matters to them specifically
[MAIN CONTENT] — Divided into [NUMBER] sections with clear transitions
[RECAP] — 30 seconds: Summarize the key takeaways
[CTA] — 30 seconds: Subscribe, comment, link in description

Include: speaker notes in (parentheses) for tone/emphasis. Mark B-roll suggestions in [SQUARE BRACKETS].
```

---

### **Prompt 13 — The YouTube Ad Script (15 or 30 seconds)**

*When to use: Creating a YouTube pre-roll ad that hooks viewers before they skip.*

```
You are a direct-response video ad writer with expertise in YouTube advertising for [INDUSTRY].

Write [TWO VERSIONS: 15-second and 30-second] YouTube ad scripts for [COMPANY NAME] promoting [PRODUCT/SERVICE].

Ad details:
- Product/Service: [PRODUCT/SERVICE]
- Key benefit: [KEY BENEFIT — the single most compelling thing]
- Target audience: [AUDIENCE]
- Pain point addressed: [PAIN POINT]
- Unique selling proposition: [USP]
- CTA: [CTA + URL]
- Tone: [TONE]

For both versions:
- The first 5 seconds must be designed to survive the "skip" decision
- Use pattern interrupts (unexpected opener, bold visual direction note, direct question)
- Include on-screen text suggestions in [BRACKETS]
- End with a clear, urgent CTA

Also provide: 3 alternative opening hooks for split testing.
```

---

## Blog Posts

---

### **Prompt 14 — The SEO Blog Post (Long-Form)**

*When to use: Writing a comprehensive blog post designed to rank on Google and generate organic leads.*

```
You are an expert B2B/B2C SEO content strategist and long-form writer.

Write a complete, SEO-optimized blog post for [COMPANY NAME] on the topic: [BLOG POST TITLE/TOPIC]

SEO details:
- Primary keyword: [PRIMARY KEYWORD]
- Secondary keywords: [2–3 SECONDARY KEYWORDS]
- Search intent: [INFORMATIONAL / COMMERCIAL / TRANSACTIONAL]
- Target word count: [WORD COUNT — e.g., 1,500–2,000 words]

Audience details:
- Who they are: [TARGET AUDIENCE]
- What they're trying to solve: [PROBLEM/QUESTION]
- Where they are in the funnel: [AWARENESS / CONSIDERATION / DECISION]

Post structure:
- Title: H1 with primary keyword (give 3 options)
- Meta description: 155 characters max with primary keyword
- Introduction: Hook + preview of what they'll learn (150 words)
- [3–5 H2 sections with H3 subsections as needed]
- Conclusion: Summarize + CTA ([CTA])
- Internal link suggestions: Note where to link to [RELEVANT PAGES/PRODUCTS]

Tone: [TONE]
Brand context: [COMPANY NAME] is a [DESCRIPTION] company. [KEY DIFFERENTIATOR].

Include: A "Key Takeaways" box at the top (5 bullet points).
```

---

### **Prompt 15 — The Thought Leadership Blog Post**

*When to use: Publishing a POV piece on your company blog or a publication like Forbes, HBR, or Medium.*

```
You are a ghostwriter specializing in executive thought leadership for [INDUSTRY] leaders.

Write a thought leadership article for [AUTHOR NAME], [TITLE] at [COMPANY NAME], to be published on [PUBLICATION — e.g., "LinkedIn Articles" or "our company blog"].

Article details:
- Core argument: [WHAT ARE YOU ARGUING OR CLAIMING?]
- Why this matters now: [WHAT'S CHANGED OR HAPPENING IN THE MARKET?]
- Supporting evidence: [DATA POINTS, EXAMPLES, CASE STUDIES]
- Target reader: [TARGET AUDIENCE]
- Tone: [TONE — e.g., "Visionary but grounded, backed by evidence, not overly academic"]
- Word count: [WORD COUNT — e.g., 900–1,200 words]

Structure:
- Headline: Give 4 options (include the author's name-worthy phrasing)
- Opening: Establish stakes — why should anyone care about this?
- Argument: Build the case with evidence and examples
- Implications: What does this mean for the industry / the reader?
- Call to action: What should readers think, do, or discuss?

Avoid buzzwords: [LIST ANY WORDS/PHRASES TO AVOID]. 
Use the author's voice characteristics: [VOICE NOTES if available].
```

---

### **Prompt 16 — The Product-Led Blog Post**

*When to use: Writing content that naturally showcases your product while providing genuine value to readers.*

```
You are a product-led content strategist who writes blog posts that educate readers AND naturally demonstrate product value.

Write a product-led blog post for [COMPANY NAME] about [TOPIC].

Details:
- Product/feature to showcase: [PRODUCT/FEATURE]
- How the product connects to the topic: [CONNECTION — be subtle, not salesy]
- Primary keyword: [KEYWORD]
- Target audience: [AUDIENCE]
- Pain point: [PAIN POINT]
- Word count: [WORD COUNT]
- Tone: [TONE]

Requirements:
- 70% educational value, 30% product integration
- Mention the product naturally in the context of solving the problem (not as a sales pitch)
- Include a "How [COMPANY NAME] helps with this" section (max 150 words — factual, not hype)
- End with a soft CTA: [CTA — e.g., "Try [PRODUCT] free for 14 days"]
- Include 3 internal link placeholders: [INTERNAL LINK: description]
```

---

## Content Calendars

---

### **Prompt 17 — The Monthly Social Media Content Calendar**

*When to use: Planning an entire month of social media content in one session.*

```
You are a social media strategist and content calendar expert.

Create a 4-week social media content calendar for [COMPANY NAME] for the month of [MONTH/YEAR].

Brand context:
- Company: [COMPANY NAME]
- Industry: [INDUSTRY]
- Products/services: [PRODUCTS/SERVICES]
- Target audience: [TARGET AUDIENCE]
- Brand tone: [TONE]
- Platforms: [PLATFORMS — e.g., LinkedIn, Instagram, Twitter/X]
- Posting frequency per platform: [FREQUENCY — e.g., LinkedIn 3x/week, Instagram 5x/week]

Content pillars (themes to rotate through):
1. [PILLAR 1 — e.g., Educational/How-To]
2. [PILLAR 2 — e.g., Social Proof/Case Studies]
3. [PILLAR 3 — e.g., Behind the Scenes/Culture]
4. [PILLAR 4 — e.g., Product/Service Spotlights]
5. [PILLAR 5 — e.g., Industry News/Commentary]

Upcoming campaigns or events to incorporate: [EVENTS/CAMPAIGNS]

Deliver a table with: Date | Platform | Content Pillar | Post Type | Topic/Hook | CTA

After the table, write 5 full post drafts for the highest-priority pieces.
```

---

### **Prompt 18 — The Campaign Content Calendar**

*When to use: Mapping out all content touchpoints for a specific campaign across all channels.*

```
You are a multi-channel campaign strategist.

Create a campaign content calendar for [COMPANY NAME]'s upcoming [CAMPAIGN NAME] campaign.

Campaign details:
- Campaign goal: [GOAL — e.g., generate 500 leads, drive $X in revenue]
- Campaign duration: [START DATE] to [END DATE]
- Target audience: [AUDIENCE]
- Core message: [CORE MESSAGE]
- Offer/CTA: [OFFER + CTA]
- Channels: [CHANNELS — e.g., Email, LinkedIn, Instagram, Google Ads, Blog]
- Budget note: [BUDGET CONTEXT if relevant]

Deliver:
1. A week-by-week content calendar showing what goes live on each channel and when
2. A "Content Themes by Week" section (Week 1: Awareness, Week 2: Consideration, etc.)
3. For each piece of content: Channel | Date | Content Type | Topic/Copy Direction | CTA
4. A pre-launch checklist (5 items)
5. A post-campaign content wrap-up suggestion

Flag any dependencies or sequencing requirements.
```

---

### **Prompt 19 — The Blog Editorial Calendar (Quarterly)**

*When to use: Planning a quarter of blog content aligned to SEO, campaigns, and business goals.*

```
You are an SEO content strategist and editorial planner.

Create a 90-day blog editorial calendar for [COMPANY NAME].

Context:
- Industry: [INDUSTRY]
- Primary business goal this quarter: [GOAL — e.g., generate leads for [PRODUCT], rank for [KEYWORD CLUSTER]]
- Target audience: [AUDIENCE]
- Current top-performing topics (if known): [TOPICS]
- Campaigns or product launches this quarter: [CAMPAIGNS/LAUNCHES]
- Publishing cadence: [FREQUENCY — e.g., 2 posts/week]

Deliver:
1. A list of 12–24 blog post titles with:
   - Proposed publish date (approximate)
   - Primary keyword target
   - Content type (educational, product-led, thought leadership, case study)
   - Funnel stage (TOFU / MOFU / BOFU)
   - Campaign alignment (if applicable)
   - Estimated traffic potential (high/medium/low based on your knowledge)
2. 3 "cornerstone" posts to prioritize for the quarter
3. Content repurposing suggestions for top 5 posts (what to turn them into)
```

---

### **Prompt 20 — The Content Repurposing Plan**

*When to use: You have a high-performing piece of content and want to extract maximum value from it.*

```
You are a content repurposing strategist who helps brands multiply the value of every piece of content they create.

I have a [CONTENT TYPE — e.g., blog post / webinar / podcast episode / case study] titled: "[TITLE]"

Content summary: [BRIEF SUMMARY OF WHAT IT COVERS]
Original format: [FORMAT]
Original platform: [WHERE IT LIVES]
Audience: [AUDIENCE]
Top-performing elements (if known): [WHAT RESONATED MOST]

Create a complete repurposing plan that includes:
1. LinkedIn: 2 post ideas (one data/insight-driven, one story-driven)
2. Twitter/X: 1 thread outline (8–10 tweets)
3. Instagram: 1 carousel concept + caption direction
4. Email newsletter: 1 section or standalone email concept
5. YouTube/Video: 1 short-form video concept (60–90 seconds)
6. Blog: 1 spin-off blog post angle (different keyword, different audience angle)
7. Sales enablement: 1 way this can be used by the sales team

For each, specify: Format | Platform | Core angle | Key message | CTA
```

---

### **Prompt 21 — The Content Pillar Framework**

*When to use: Defining your brand's core content themes before building a calendar.*

```
You are a brand content strategist who builds content pillars for B2B and B2C companies.

Build a content pillar framework for [COMPANY NAME].

Brand context:
- Company: [COMPANY NAME]
- What we sell: [PRODUCTS/SERVICES]
- Who we sell to: [TARGET AUDIENCE — be specific]
- Our mission: [MISSION — in 1 sentence]
- Top 3 brand values: [VALUES]
- Main competitors: [COMPETITORS]
- What makes us different: [DIFFERENTIATOR]
- Platforms we're on: [PLATFORMS]

Deliver:
1. 5 content pillars with:
   - Pillar name
   - Description (what this pillar is about and why it matters to our audience)
   - Example topics (5 per pillar)
   - Formats that work best for this pillar
   - How often to post this type of content
   - KPI to track success

2. A "content mix" recommendation (% split across pillars per week)

3. 3 "hero content" ideas per pillar (big, high-effort pieces that anchor the pillar)
```

---

### **Prompt 22 — The Video Content Strategy**

*When to use: Building a YouTube channel or video content strategy from scratch.*

```
You are a YouTube and video content strategist specializing in [INDUSTRY].

Build a video content strategy for [COMPANY NAME / CHANNEL NAME].

Context:
- Brand: [COMPANY NAME]
- Products/Services: [PRODUCTS/SERVICES]
- Target audience: [AUDIENCE]
- Business goal for video: [GOAL — e.g., build brand awareness, generate leads, support sales]
- Current situation: [E.g., "Starting from zero" or "We have X subscribers and Y avg. views"]
- Competitors on YouTube: [COMPETITORS — or "unknown"]
- Tone: [TONE]
- Resources: [RESOURCES — e.g., "One person, 1 day/week for video"]

Deliver:
1. Channel positioning statement (1–2 sentences)
2. 5 video series ideas (each with a series name, premise, and 5 episode ideas)
3. A "first 10 videos" roadmap with titles and keyword targets
4. Video format recommendations (long-form, Shorts, live, etc.) with rationale
5. SEO keywords to target (10 keywords with difficulty estimate)
6. CTA strategy (what to ask viewers to do and when)
```

---

### **Prompt 23 — The Podcast Episode Outline**

*When to use: Preparing a podcast episode, webinar, or video interview.*

```
You are a podcast producer and interviewer specializing in [INDUSTRY] business content.

Create a complete episode outline for [PODCAST NAME] for an episode about: [EPISODE TOPIC]

Episode details:
- Guest (if applicable): [GUEST NAME, TITLE, COMPANY]
- Target length: [LENGTH — e.g., 35–45 minutes]
- Audience: [AUDIENCE]
- Key takeaway (what listeners leave with): [KEY TAKEAWAY]
- Tone: [TONE — e.g., "Conversational, curious, smart — not overly formal"]

Deliver:
1. Episode title: 3 options (punchy, SEO-aware)
2. Episode description for podcast platforms (150 words)
3. Full outline:
   - Cold open / hook (30 seconds — what will hook listeners immediately?)
   - Intro segment ([HOST NAME] intro + guest intro — 3 minutes)
   - Segment 1: Context setting (10 minutes — 5 questions)
   - Segment 2: Core insight / main topic (15 minutes — 5 questions)
   - Segment 3: Practical takeaways (10 minutes — 3 questions)
   - Closing: Rapid fire + where to find guest + CTA
4. 5 "pull quote" moments to clip for social media
5. Show notes template
```

---

### **Prompt 24 — The Newsletter Issue**

*When to use: Writing a weekly or bi-weekly email newsletter issue.*

```
You are a newsletter writer who creates engaging, high-value email newsletters for [INDUSTRY] professionals.

Write a complete newsletter issue for [NEWSLETTER NAME] by [COMPANY/AUTHOR NAME].

Issue details:
- Theme or focus this week: [THEME]
- Target audience: [AUDIENCE]
- Tone: [TONE — e.g., "Smart, warm, opinionated — like a weekly email from a well-read friend in the industry"]
- Sections to include: [SECTIONS — e.g., "intro, 3 insights, 1 tool rec, 1 quote, quick CTA"]
- Main CTA: [CTA]
- Any timely news or hooks to work in: [CURRENT EVENTS/NEWS if relevant]

Structure:
1. Subject line: 3 options (max 50 characters, curiosity/benefit-driven)
2. Preview text: 3 options (max 85 characters)
3. Opening (100 words): Personal, conversational, sets up the theme
4. [SECTION 1]: [CONTENT]
5. [SECTION 2]: [CONTENT]
6. [SECTION 3]: [CONTENT]
7. Closing (50 words): Warm sign-off + CTA
8. P.S. line: One surprising or delightful thought

Write the full draft. Word count: approximately [WORD COUNT — e.g., 500–700 words].
```

---

### **Prompt 25 — The User-Generated Content Campaign**

*When to use: Launching a UGC campaign to collect customer content and social proof.*

```
You are a community and UGC (user-generated content) strategist.

Design a UGC campaign for [COMPANY NAME] to collect authentic customer content.

Campaign context:
- Product/Service: [PRODUCT/SERVICE]
- Campaign goal: [GOAL — e.g., collect 100 pieces of UGC, increase social proof, launch a new product]
- Target participants: [WHO YOU WANT TO CREATE CONTENT — existing customers, new buyers, followers]
- Incentive (if any): [INCENTIVE — e.g., feature on our page, discount, prize]
- Campaign duration: [DURATION]
- Platforms: [PLATFORMS]
- Hashtag (if using one): [HASHTAG]

Deliver:
1. Campaign name and concept (2–3 sentences)
2. The UGC brief for participants (what to create, how to submit, rules — max 150 words)
3. Launch post for each platform ([PLATFORMS])
4. 3 email templates to invite existing customers to participate
5. A moderation framework (how to select, respond to, and repurpose submissions)
6. Metrics to track success
```

---

*End of Section 02 — 25 prompts total.*
