# PRODUCT-INFO.md — The Marketer's AI Prompt Toolkit

---

## Product Details

- **Product Name:** The Marketer's AI Prompt Toolkit
- **Price:** $67
- **Purchase Link:** [https://buy.stripe.com/7sY3cx0N3eJPdA5aUEgEg03](https://buy.stripe.com/7sY3cx0N3eJPdA5aUEgEg03)
- **Format:** Instant digital download — 7 Markdown/PDF files
- **Category:** Marketing Tools / AI Productivity

---

## Sales Description (200 words)

Most marketers are using AI wrong. They type a vague request, get a mediocre result, decide "AI doesn't work for marketing," and go back to doing everything manually. The Marketer's AI Prompt Toolkit fixes that.

This is a complete library of 100+ professional-grade prompts, frameworks, and SOPs built specifically for marketers — covering everything from social media and campaign copy to brand strategy, reporting, and quarterly planning.

Every prompt is engineered with the RACE framework (Role, Action, Context, Examples) so you get agency-quality output, not generic filler. Every bracket is deliberate. Every instruction is tested. You fill in your brand details, and AI does the heavy lifting.

Inside you'll find prompts for LinkedIn thought leadership, high-converting landing pages, email nurture sequences, Google and Meta ad copy, SEO blog posts, competitive analysis, board presentations, monthly marketing reports, OKR planning, and more.

You also get five complete workflow SOPs — step-by-step systems for campaign launches, monthly content batching, product launches, competitive sprints, and quarterly reviews. Plus a cheat sheet with the 15 most powerful prompts and the 10 Golden Rules of AI Prompting.

Stop starting from scratch. Start shipping better marketing, faster.

---

## Headlines (for sales page, email, or social)

1. **"100+ AI Prompts That Write Your Marketing For You — Without the Generic Garbage"**

2. **"The Prompt Library That Turns 4-Hour Marketing Projects into 40-Minute Wins"**

3. **"Finally: AI Marketing Prompts Built by Marketers, for Marketers — Not by a Chatbot"**

4. **"Stop Prompting Like an Amateur. Ship Better Marketing in Half the Time."**

5. **"Your Entire Marketing Stack in 7 Files: Prompts, Frameworks, SOPs, and a Cheat Sheet for $67"**

---

## Target Audience

### Primary Audience

**Solo marketers and marketing managers at startups and SMBs** who are responsible for a wide range of marketing tasks — content, campaigns, reporting, strategy — but don't have a large team or agency budget to support them. They've tried AI but get inconsistent results. They know AI should be saving them time but it isn't yet.

**Freelance marketers and marketing consultants** who want to deliver better, faster work to clients without increasing hours. They need repeatable systems and professional-quality outputs across content, copy, strategy, and reporting.

### Secondary Audience

**Marketing directors and CMOs at growth-stage companies** who want to systematize their team's AI usage, reduce the gap between "we're using AI" and "AI is actually improving our output," and ensure consistent brand voice across channels.

**Marketing agency owners and their teams** who want to productize AI-assisted services, increase margins on deliverables, and give junior team members frameworks that produce senior-quality work.

### Psychographic Profile

- Feels overwhelmed by the volume of marketing work required
- Has experimented with AI but been disappointed by vague, generic outputs
- Cares about quality — doesn't want to publish mediocre content with their name on it
- Time-constrained — looking for systems, not just tools
- Skeptical of "AI hype" but open to practical, proven approaches
- Would pay $67 easily if it saves them even 5 hours of work in the first month

---

## File List

| # | File | Contents |
|---|------|----------|
| 01 | `01-quick-start-guide.md` | The RACE Framework, how to use brackets, how to build a brand brief, quick-start checklist |
| 02 | `02-content-social-prompts.md` | 25 prompts for LinkedIn, Twitter/X, Instagram, YouTube, blog posts, and content calendars |
| 03 | `03-campaign-copy-prompts.md` | 20 prompts for ads, landing pages, email campaigns, product launches, and promotional copy |
| 04 | `04-brand-strategy-prompts.md` | 15 prompts for positioning, messaging, personas, competitive analysis, and brand strategy |
| 05 | `05-reporting-analysis-prompts.md` | 15 prompts for monthly reports, channel analysis, post-mortems, board updates, OKR reviews, and budget justification |
| 06 | `06-workflow-sops.md` | 5 complete SOPs: campaign launch, monthly content batch, product launch, competitive sprint, quarterly planning |
| 07 | `07-cheat-sheet.md` | Top 15 most powerful prompts (full text) + 10 Golden Rules of Prompting for Marketers |

**Total:** 90+ prompts · 5 workflow SOPs · 7 frameworks · 10 golden rules

---

## FAQ

**Q: What AI tools do these prompts work with?**
A: All of them — ChatGPT, Claude, Gemini, Copilot, or any LLM-based tool. The prompts are model-agnostic.

**Q: Do I need to be a marketer to use this?**
A: You should have a basic understanding of marketing (campaigns, channels, KPIs). This isn't a marketing 101 course — it's a productivity system for people who already do marketing.

**Q: How long until I see results?**
A: Most buyers use at least one prompt on the day they purchase. The campaign launch SOP has been used to produce a full campaign brief in under 90 minutes.

**Q: Is this a subscription?**
A: No. One-time payment, instant download. Files are yours to keep and use forever.

**Q: Can I use these prompts for client work?**
A: Yes. No restrictions on commercial use.

---

## Suggested Use Cases for Marketing

- **Email subject line:** "I spent $67 on an AI toolkit and it saved me 10 hours in the first week."
- **LinkedIn launch post:** Behind-the-scenes of how this toolkit was built and why I priced it at $67
- **Twitter/X:** "Hot take: most people use AI prompts wrong. Here are the 3 mistakes ruining your outputs — [LINK]"
- **Pinterest/visual:** Cheat sheet graphic with the 10 Golden Rules
- **Podcast pitch:** "I'll walk your audience through the 5 most common AI prompting mistakes marketers make"
