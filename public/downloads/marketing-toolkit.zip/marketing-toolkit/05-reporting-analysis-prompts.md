# 05 — Reporting & Analysis Prompts

> 15 prompts for turning raw data into compelling narratives — for reports, post-mortems, board decks, and strategic reviews.

---

## Monthly Marketing Reports

---

### **Prompt 01 — Monthly Marketing Performance Report**

*When to use: You need to write a clear, professional monthly marketing report for your team, leadership, or stakeholders — turning raw metrics into a coherent story.*

```
You are a senior marketing analyst and communications expert. Your job is to transform raw performance data into a clear, insightful monthly report that tells a story, not just lists numbers.

Write a monthly marketing performance report for [COMPANY NAME] covering [MONTH, YEAR].

Include the following sections:
1. Executive Summary (3–4 sentences: what happened, what mattered, what's next)
2. Highlights & Wins (top 3 positive results with context)
3. Channel Performance Overview (brief summary for each active channel)
4. Metrics Snapshot (format as a table or structured list)
5. What Underperformed & Why (honest, solution-oriented)
6. Key Learnings
7. Priorities for Next Month

Here is the raw data to work with:
- Total leads generated: [NUMBER]
- Lead sources: [BREAKDOWN BY CHANNEL]
- Website traffic: [TOTAL SESSIONS, % CHANGE MOM]
- Top traffic sources: [LIST]
- Email metrics: [OPEN RATE, CTR, UNSUBSCRIBES]
- Paid ad spend: [TOTAL SPEND, ROAS, CPA]
- Social media: [FOLLOWER GROWTH, ENGAGEMENT RATE, TOP POST]
- Revenue attributed to marketing: [AMOUNT OR PIPELINE VALUE]
- MQLs generated: [NUMBER]
- Conversion rate (lead to MQL): [%]
- Notable campaigns: [CAMPAIGN NAMES AND RESULTS]
- Anomalies or surprises: [ANYTHING UNEXPECTED]

Company context:
- Industry: [INDUSTRY]
- Business model: [B2B/B2C/D2C]
- Marketing team size: [NUMBER]
- Monthly marketing budget: [$AMOUNT]
- Key business goal this month: [GOAL]

Tone: Professional but direct. Write for a [AUDIENCE — e.g., "VP-level internal audience" or "cross-functional leadership team"]. Avoid jargon. Be honest about failures without being dramatic.
```

---

### **Prompt 02 — Marketing Dashboard Narrative**

*When to use: Your data dashboard is ready but you need a written narrative that explains the numbers — for a weekly or monthly internal update.*

```
You are an expert marketing analyst who specializes in making data approachable and actionable.

Write a dashboard narrative for our [WEEKLY/MONTHLY] marketing update. This is NOT a report — it's a 300–500 word written commentary that brings the numbers to life for non-analytical readers.

Dashboard data:
- Date range: [DATE RANGE]
- Sessions: [NUMBER] ([+/- %] vs. prior period)
- New users: [NUMBER]
- Bounce rate: [%]
- Goal completions / conversions: [NUMBER]
- Top performing page or content: [PAGE/CONTENT + METRIC]
- Worst performing area: [AREA + METRIC]
- Email sent this period: [NUMBER SENT, OPEN RATE, CTR]
- Social reach: [TOTAL REACH]
- Ad performance: [IMPRESSIONS, CLICKS, CONVERSIONS, SPEND]
- Pipeline influenced: [$AMOUNT]

Write the narrative in three parts:
1. The headline story (1 paragraph — what's the most important thing that happened?)
2. What's working and why (2–3 observations with context, not just data)
3. What needs attention and what we're doing about it (2–3 items with planned actions)

Audience: [INTERNAL TEAM / EXECUTIVE TEAM / BOARD]
Tone: [CONVERSATIONAL / FORMAL / DIRECT]
```

---

## Channel Performance Analysis

---

### **Prompt 03 — Channel Performance Deep Dive**

*When to use: You want to analyze a single channel (SEO, paid, email, social, etc.) in depth — to understand what's working, what isn't, and what to do next.*

```
You are a senior digital marketing strategist with deep expertise in [CHANNEL — e.g., "paid search," "organic social," "email marketing"].

Conduct a performance analysis for our [CHANNEL] program over the past [TIME PERIOD — e.g., "90 days"].

Performance data:
[PASTE OR LIST YOUR KEY METRICS HERE]

Business context:
- Goal for this channel: [PRIMARY GOAL — e.g., "generate MQLs," "drive brand awareness," "support revenue pipeline"]
- Target audience: [DESCRIPTION]
- Budget allocated: [$AMOUNT/PERIOD]
- Team managing it: [INTERNAL/AGENCY/FREELANCER]
- Key campaigns or initiatives run: [LIST]

Structure your analysis as follows:
1. Performance Summary (how did this channel perform overall vs. goals?)
2. What's Working (specific tactics, content types, or segments performing above expectation — explain WHY)
3. What's Underperforming (specific issues — explain the likely root causes, not just the symptoms)
4. Benchmarks (how do our numbers compare to industry benchmarks for [INDUSTRY]?)
5. Opportunity Areas (where is there unrealized potential in this channel?)
6. Recommended Actions (3–5 specific, prioritized next steps with expected impact)

Be analytical and specific. Avoid vague suggestions like "post more consistently" — provide actionable recommendations with reasoning.
```

---

### **Prompt 04 — Multi-Channel Comparison Report**

*When to use: You need to compare performance across channels to decide where to shift budget, attention, or resources.*

```
You are a marketing strategist who specializes in cross-channel analysis and budget optimization.

Analyze the comparative performance of our marketing channels for [TIME PERIOD] and provide strategic recommendations.

Channel data:
[For each channel, provide: spend, reach/impressions, leads/conversions, revenue attributed, CPA/CAC, ROI]

- Organic Search (SEO): [DATA]
- Paid Search (SEM): [DATA]
- Paid Social: [DATA]
- Organic Social: [DATA]
- Email Marketing: [DATA]
- Content Marketing: [DATA]
- Events/Webinars: [DATA]
- Partnerships/Affiliates: [DATA]
- [OTHER CHANNEL]: [DATA]

Business context:
- Total marketing budget: [$AMOUNT]
- Primary business goal: [GOAL]
- Revenue target: [$TARGET]
- Current CAC target: [$TARGET]
- LTV of a customer: [$LTV]

Deliver:
1. Channel performance ranking (by efficiency and volume — explain your scoring)
2. Top 3 channels to double down on (with rationale)
3. Channels to reduce investment in (with rationale and risk assessment)
4. Channel synergy opportunities (where do channels reinforce each other?)
5. Recommended budget reallocation (provide a suggested % breakdown)
6. 30/60/90-day action plan

Format with clear headers and be direct about tradeoffs.
```

---

## Campaign Post-Mortems

---

### **Prompt 05 — Campaign Post-Mortem Analysis**

*When to use: A campaign has ended and you need to document what happened, extract learnings, and share insights with the team.*

```
You are a marketing director who runs rigorous, blameless campaign post-mortems — the goal is learning, not finger-pointing.

Write a comprehensive campaign post-mortem for the following campaign:

Campaign details:
- Campaign name: [CAMPAIGN NAME]
- Campaign type: [e.g., product launch, lead gen, brand awareness, seasonal]
- Channels used: [LIST]
- Duration: [START DATE — END DATE]
- Total budget: [$AMOUNT]
- Team involved: [ROLES/NAMES]
- Primary KPIs: [METRICS AND TARGETS]

Results:
- Target vs. actual for each KPI: [DATA]
- Total spend vs. budget: [$ACTUAL vs. $BUDGET]
- Revenue or pipeline generated: [$AMOUNT]
- ROI: [%]
- Other notable outcomes: [ANYTHING ELSE]

What happened (provide a brief timeline or narrative): [WHAT WENT DOWN]

Structure the post-mortem as:
1. Campaign Overview (1 paragraph)
2. Results Scorecard (table: KPI | Target | Actual | % to Goal)
3. What Went Well (be specific — which elements drove results?)
4. What Didn't Work (be honest — what failed and why?)
5. Surprises (things you didn't expect, positive or negative)
6. Root Cause Analysis (for the biggest failure, do a 5-Why analysis)
7. Key Learnings (3–5 principles to carry forward)
8. Recommendations for Future Campaigns
9. What We'd Do Differently

Tone: Professional, honest, constructive. This document will be shared with [AUDIENCE — e.g., "the marketing team," "leadership," "the full company"].
```

---

### **Prompt 06 — Failed Campaign Analysis**

*When to use: A campaign significantly underperformed and you need to diagnose why — and present the findings without losing credibility.*

```
You are a marketing consultant called in to diagnose a campaign that significantly underperformed expectations.

Conduct an objective, evidence-based analysis of why this campaign fell short, and provide a recovery or improvement plan.

Campaign context:
- Campaign: [NAME AND BRIEF DESCRIPTION]
- Expected results: [WHAT WAS PROMISED OR PROJECTED]
- Actual results: [WHAT ACTUALLY HAPPENED]
- Gap: [HOW FAR OFF WERE YOU?]
- Duration: [DATES]
- Budget spent: [$AMOUNT]
- Channels: [LIST]

Available context about what happened:
[SHARE ANYTHING YOU KNOW — audience response, team observations, competitive activity, timing issues, creative performance, etc.]

Your analysis should:
1. Rule out or confirm each potential cause (be systematic, not assumptive)
   - Strategy failure (wrong audience, wrong message, wrong timing)
   - Execution failure (poor creative, technical issues, low budget)
   - External factors (market conditions, competition, seasonality)
   - Measurement failure (wrong KPIs, tracking issues)
2. Identify the primary root cause (what was the #1 reason?)
3. Identify contributing factors
4. Assess what was salvageable and what was wasted
5. Provide a specific 3-step recovery plan
6. Recommend how to present these findings to [STAKEHOLDER — e.g., "the CMO," "the board," "the client"]

Be direct. Don't soften the diagnosis. The goal is to learn fast and not repeat the mistake.
```

---

## Attribution Narratives

---

### **Prompt 07 — Marketing Attribution Story**

*When to use: You need to explain to leadership or finance how marketing contributed to revenue — especially when your attribution model is complex or imperfect.*

```
You are a marketing analytics lead who excels at translating complex attribution models into clear business narratives.

Write an attribution narrative for [TIME PERIOD] that explains how marketing contributed to revenue and pipeline.

Attribution data:
- Total revenue in period: [$AMOUNT]
- Marketing-sourced revenue (first-touch): [$AMOUNT / %]
- Marketing-influenced revenue (multi-touch): [$AMOUNT / %]
- Pipeline created by marketing: [$AMOUNT]
- Pipeline influenced by marketing: [$AMOUNT]
- Average deal influenced by [NUMBER] marketing touchpoints
- Top converting content/campaigns: [LIST]
- Attribution model used: [FIRST-TOUCH / LAST-TOUCH / LINEAR / DATA-DRIVEN / OTHER]

Context:
- Sales cycle length: [AVERAGE DAYS]
- Average deal size: [$AMOUNT]
- Total closed-won deals this period: [NUMBER]
- Deals with zero marketing touches: [NUMBER / %]
- Marketing team headcount: [NUMBER]
- Total marketing spend: [$AMOUNT]

Write a 400–600 word narrative that:
1. Opens with the headline impact number
2. Explains the attribution methodology in plain language (no jargon)
3. Highlights the most impactful marketing programs
4. Addresses the "dark funnel" or untracked influence honestly
5. Translates marketing activity into business outcomes (don't just report metrics)
6. Closes with a forward-looking statement about marketing's role in the next period

Audience: [CFO / CEO / BOARD / SALES LEADERSHIP]
Tone: Confident, evidence-based, business-focused — not defensive.
```

---

## Board Marketing Updates

---

### **Prompt 08 — Board-Level Marketing Update**

*When to use: You're presenting marketing results to a board, investors, or C-suite — and you need to be concise, strategic, and focused on business impact.*

```
You are a CMO preparing a board-level marketing update. Boards care about one thing: business outcomes. They don't want to hear about impressions. They want to know how marketing is contributing to growth, efficiency, and competitive position.

Write a board marketing update for [COMPANY NAME] for [QUARTER/PERIOD].

Input data:
- Revenue target vs. actual: [$TARGET vs. $ACTUAL]
- Marketing-sourced pipeline: [$AMOUNT]
- CAC this period: [$AMOUNT] vs. [$BENCHMARK/TARGET]
- LTV:CAC ratio: [RATIO]
- Total marketing spend: [$AMOUNT]
- Marketing ROI: [%]
- Key campaign results: [LIST TOP 2–3]
- Brand metrics (if available): [AWARENESS %, NPS, SHARE OF VOICE]
- Headcount and budget vs. plan: [DETAILS]
- Big strategic bets / experiments: [LIST]
- Competitive landscape update: [KEY CHANGES]

Structure the update as:
1. Headline (one sentence: how did marketing perform?)
2. Business Impact (3 numbers that matter most — pipeline, CAC, ROI)
3. What We Did (brief — 3 most important activities)
4. Market & Competitive Context
5. What's Working / What We're Doubling Down On
6. What We're Watching / Risks
7. Ask or Outlook (what do you need from the board, or what's coming next quarter?)

Format: Use headers and bullets. Keep the full update under 500 words. This is meant to accompany slides, not replace them — write it as a companion narrative.

Tone: Executive. Direct. Strategic. No fluffy marketing language.
```

---

## Budget Justification

---

### **Prompt 09 — Marketing Budget Justification**

*When to use: You're requesting a budget increase, defending current spend, or building the business case for a new marketing investment.*

```
You are a CMO or VP of Marketing building a business case for [a marketing budget increase / a new marketing investment / maintaining current marketing spend].

Write a compelling, data-driven budget justification for [COMPANY NAME].

Current situation:
- Current marketing budget: [$AMOUNT/YEAR]
- Budget requested: [$AMOUNT/YEAR]
- Increase requested: [$AMOUNT / %]
- What the additional budget will fund: [CHANNELS, HEADCOUNT, TOOLS, CAMPAIGNS]

Performance context:
- Current marketing-sourced revenue: [$AMOUNT]
- Current marketing ROI: [X:1 or %]
- Current CAC: [$AMOUNT]
- Revenue target for next [PERIOD]: [$AMOUNT]
- Gap between current trajectory and target: [$AMOUNT]

Competitive context:
- Competitors' estimated marketing investment: [DATA IF AVAILABLE]
- Market opportunity size: [$TAM or growth rate]
- What happens if we don't invest: [RISK DESCRIPTION]

Structure the justification as:
1. The Ask (clear and upfront — how much, for what, by when)
2. The Business Case (why this investment, why now — connect to company goals)
3. Expected ROI (model out the return — conservative, base, optimistic scenarios)
4. What We'll Do With It (specific allocation with rationale)
5. What Happens If We Don't (honest risk analysis)
6. Success Metrics (how will we measure the investment?)
7. Timeline to Results (when should leadership expect to see impact?)

Audience: [CEO / CFO / BOARD / INVESTORS]
Tone: Business-case oriented. Treat marketing as an investment, not a cost center. Be specific with numbers — avoid vague claims.
```

---

### **Prompt 10 — Marketing Budget Reallocation Request**

*When to use: You want to shift budget from one area to another and need to build the internal case with data and reasoning.*

```
You are a marketing director requesting approval to reallocate budget between channels or programs.

Write a budget reallocation memo for [COMPANY NAME] recommending shifting [$AMOUNT] from [FROM CHANNEL/PROGRAM] to [TO CHANNEL/PROGRAM].

Current allocation:
- [FROM CHANNEL]: [$CURRENT SPEND] — [CURRENT RESULTS]
- [TO CHANNEL]: [$CURRENT SPEND] — [CURRENT RESULTS/POTENTIAL]

Rationale for the shift:
- Why reduce [FROM CHANNEL]: [EVIDENCE OF UNDERPERFORMANCE OR DIMINISHING RETURNS]
- Why increase [TO CHANNEL]: [EVIDENCE OF OPPORTUNITY OR EFFICIENCY]
- Data supporting the decision: [KEY METRICS]
- Risk of reducing [FROM CHANNEL]: [HONEST ASSESSMENT]

Expected impact:
- Conservative: [PROJECTED RESULT]
- Base case: [PROJECTED RESULT]
- Optimistic: [PROJECTED RESULT]

Write the memo in 300–400 words. Include:
1. The recommendation (clear and specific)
2. The evidence (data-driven, not opinion)
3. The tradeoffs (acknowledge what we're giving up)
4. The success criteria (how will we know if this was the right call?)
5. A review checkpoint (propose a date to reassess)

Audience: [CMO / CFO / CEO]
Tone: Analytical, confident, and concise.
```

---

## SEO Performance Summaries

---

### **Prompt 11 — SEO Performance Summary**

*When to use: You need to report on organic search performance — for a monthly summary, quarterly review, or to justify continued SEO investment.*

```
You are an SEO strategist and analytics expert writing a performance summary for [COMPANY NAME]'s organic search program.

Write an SEO performance summary for [TIME PERIOD].

SEO data:
- Organic sessions: [NUMBER] ([+/- %] vs. prior period)
- Organic new users: [NUMBER]
- Organic conversions / goal completions: [NUMBER]
- Organic revenue attributed: [$AMOUNT] (if e-commerce or trackable)
- Total keywords ranking: [NUMBER]
- Keywords in top 3: [NUMBER]
- Keywords in top 10: [NUMBER]
- New keywords entered top 10: [LIST TOP 5]
- Keywords lost from top 10: [LIST]
- Average ranking position: [NUMBER]
- Click-through rate (CTR): [%]
- Impressions: [NUMBER]
- Top performing pages: [LIST TOP 5 BY TRAFFIC OR CONVERSIONS]
- Pages that dropped: [LIST]
- Backlinks acquired this period: [NUMBER]
- Domain authority / domain rating: [NUMBER, CHANGE]
- Core Web Vitals status: [PASS/FAIL, NOTES]
- Technical issues identified: [LIST ANY MAJOR ISSUES]
- Content published this period: [NUMBER OF PIECES, TYPES]

Business context:
- SEO goal: [WHAT IS SEO TRYING TO ACHIEVE? — traffic, leads, revenue, brand visibility]
- Target audience: [WHO ARE YOU TRYING TO REACH?]
- Top competitors in search: [LIST]

Structure the summary as:
1. Performance Snapshot (the headline numbers with context)
2. What Moved the Needle (key wins and their causes)
3. Areas of Concern (what dropped and why)
4. Competitive Landscape (any notable changes in SERP landscape)
5. Technical Health Update (brief status on site health)
6. Content Performance (which pieces drove the most value)
7. Priorities for Next Period (top 3–5 actions)

Audience: [MARKETING TEAM / LEADERSHIP / CLIENT]
```

---

## Email Marketing Reports

---

### **Prompt 12 — Email Marketing Performance Report**

*When to use: You're reporting on email channel performance — for a monthly review, a specific campaign, or a list health assessment.*

```
You are an email marketing analyst writing a performance report for [COMPANY NAME]'s email program.

Write an email marketing report for [TIME PERIOD / CAMPAIGN NAME].

Email data:
- Emails sent: [NUMBER]
- List size: [NUMBER] | List growth this period: [+/- NUMBER]
- Deliverability rate: [%]
- Open rate: [%] (vs. industry benchmark: [BENCHMARK %])
- Click-to-open rate (CTOR): [%]
- Click-through rate (CTR): [%]
- Conversion rate: [%]
- Unsubscribe rate: [%]
- Spam complaint rate: [%]
- Revenue generated: [$AMOUNT] (if trackable)
- Top performing email: [SUBJECT LINE + KEY METRICS]
- Worst performing email: [SUBJECT LINE + KEY METRICS]
- Automated sequences performance: [NAME + OPEN RATE + CTR + CONVERSIONS]
- A/B tests run: [WHAT WAS TESTED, WHAT WON]
- Segment performance highlights: [ANY SEGMENT STANDOUTS]

Write the report with:
1. Executive Summary (3–4 sentence overview of email health and performance)
2. Deliverability Health (are we reaching inboxes? any issues?)
3. Engagement Metrics (opens, clicks — what's trending?)
4. Conversion Performance (are emails driving the desired action?)
5. List Health (growth, churn, segment quality)
6. Campaign Highlights (best and worst — with reasons)
7. A/B Testing Results
8. Recommendations (3–5 actions to improve performance)

Audience: [MARKETING DIRECTOR / TEAM / CLIENT]
Tone: Data-driven and constructive. Highlight opportunities, not just problems.
```

---

## Paid Ads Analysis

---

### **Prompt 13 — Paid Advertising Performance Analysis**

*When to use: You need to analyze and report on paid ad performance across one or multiple platforms — for internal review, client reporting, or budget decisions.*

```
You are a paid media strategist and analyst writing a performance analysis for [COMPANY NAME]'s paid advertising program.

Analyze paid ad performance for [TIME PERIOD] and provide strategic recommendations.

Paid media data:
- Total ad spend: [$AMOUNT]
- Total impressions: [NUMBER]
- Total clicks: [NUMBER]
- Average CTR: [%]
- Average CPC: [$AMOUNT]
- Total conversions: [NUMBER]
- Conversion rate: [%]
- CPA (cost per acquisition): [$AMOUNT]
- ROAS (return on ad spend): [X:1]
- Revenue attributed: [$AMOUNT]
- MQLs or leads generated: [NUMBER]
- Cost per lead: [$AMOUNT]

Platform breakdown:
- Google Search: [SPEND, ROAS, CPA, TOP CAMPAIGNS]
- Google Display: [SPEND, ROAS, CPA]
- Meta (Facebook/Instagram): [SPEND, ROAS, CPA, TOP ADS]
- LinkedIn: [SPEND, CPL, MQLs]
- YouTube: [SPEND, VIEWS, VTR, CONVERSIONS]
- [OTHER PLATFORM]: [DATA]

Top performing ads/campaigns: [LIST WITH KEY METRICS]
Underperforming ads/campaigns: [LIST WITH KEY METRICS]
Audience performance highlights: [WHICH SEGMENTS/AUDIENCES PERFORMED BEST]
Budget pacing: [ON TRACK / OVER / UNDER — and by how much]

Deliver:
1. Performance Overview (how did paid media perform vs. goals?)
2. Platform-by-Platform Breakdown (what worked and didn't on each platform)
3. Creative Performance (what ad formats/creative types performed best?)
4. Audience Insights (what did we learn about who responds to our ads?)
5. Budget Efficiency Analysis (where is the best ROAS? where is money being wasted?)
6. Recommendations (5 specific actions — include budget changes, creative tests, audience adjustments)
7. Forecast for Next Period (if we implement these changes, what should we expect?)

Audience: [INTERNAL MARKETING TEAM / CMO / CLIENT]
```

---

## Marketing OKR Reviews

---

### **Prompt 14 — Quarterly Marketing OKR Review**

*When to use: You're reviewing your marketing team's OKR progress at the end of a quarter — to assess what was achieved, what wasn't, and why.*

```
You are a marketing operations leader facilitating a quarterly OKR review for [COMPANY NAME]'s marketing team.

Write a Q[QUARTER] OKR review for [YEAR].

OKR data:
[For each Objective and Key Result, provide:]

Objective 1: [OBJECTIVE STATEMENT]
- KR 1.1: [KEY RESULT] | Target: [NUMBER] | Actual: [NUMBER] | Score: [0.0–1.0]
- KR 1.2: [KEY RESULT] | Target: [NUMBER] | Actual: [NUMBER] | Score: [0.0–1.0]
- KR 1.3: [KEY RESULT] | Target: [NUMBER] | Actual: [NUMBER] | Score: [0.0–1.0]

Objective 2: [OBJECTIVE STATEMENT]
- KR 2.1: [KEY RESULT] | Target: [NUMBER] | Actual: [NUMBER] | Score: [0.0–1.0]
[Continue for all OKRs]

Context:
- What major initiatives drove results? [LIST]
- What blocked progress? [LIST]
- What changed externally (market, competition, company strategy)? [LIST]
- Initiatives deprioritized mid-quarter: [LIST]
- Team size and any capacity issues: [NOTES]

Write the OKR review with:
1. Scorecard Overview (table: Objective | Avg Score | Status — Green/Yellow/Red)
2. Narrative by Objective (1–2 paragraphs each: what happened, why, what it means)
3. Quarter's Biggest Wins (celebrate what worked)
4. Quarter's Biggest Misses (honest, blameless analysis)
5. External Factors That Impacted Performance
6. What We Learned (3–5 key learnings)
7. Implications for Q[NEXT QUARTER] Planning

Format: Clear structure with headers. Score each KR and provide a brief reason for the score.
Tone: Honest and constructive. OKRs should be stretch goals — a score of 0.7 is often success.
```

---

### **Prompt 15 — Marketing Strategy Mid-Year Review**

*When to use: You're six months into your annual marketing plan and need to assess whether your strategy is still on track — and where to course-correct.*

```
You are a CMO conducting a rigorous mid-year review of the annual marketing strategy for [COMPANY NAME].

Write a mid-year marketing strategy review for [YEAR].

Annual plan context:
- Annual revenue target: [$AMOUNT]
- Revenue at mid-year: [$AMOUNT] ([%] of annual target)
- Marketing's pipeline contribution target: [$AMOUNT]
- Pipeline contributed at mid-year: [$AMOUNT]
- Annual marketing budget: [$AMOUNT]
- Budget spent at mid-year: [$AMOUNT] ([%] of annual)
- Top 3 strategic priorities set at start of year: [LIST]
- Progress on each priority: [STATUS + NOTES]

Performance vs. plan:
- Which channels are ahead of plan: [LIST + WHY]
- Which channels are behind plan: [LIST + WHY]
- Key campaigns completed: [RESULTS]
- Major pivots made in H1: [DESCRIPTION]

Market context:
- Significant market or competitive changes in H1: [LIST]
- Changes in buyer behavior or demand: [OBSERVATIONS]
- Company strategy shifts that affect marketing: [IF ANY]

Write the mid-year review with:
1. H1 Performance Scorecard (traffic light: Red/Yellow/Green for each strategic priority)
2. The Headline Story (in 1–2 paragraphs: how did H1 actually go?)
3. Strategy Validation Check (which assumptions from the annual plan held? which didn't?)
4. H2 Recommendations (what should stay the same, what should change?)
5. Revised H2 Priorities (given what you know now, what are the top 3?)
6. Resource Reallocation (any budget or headcount shifts recommended?)
7. Risks & Opportunities for H2 (what to watch, what to accelerate)
8. Success Metrics for H2 (how will you declare H2 a success?)

Audience: [CEO / BOARD / LEADERSHIP TEAM]
Tone: Strategic, candid, and forward-looking. This is a leadership document.
```

---

*Next: [06 — Workflow SOPs →](06-workflow-sops.md)*
