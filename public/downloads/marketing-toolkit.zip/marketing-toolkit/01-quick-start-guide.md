# 01 — Quick Start Guide

> Get up and running in under 10 minutes.

---

## The Golden Rule of AI Prompting

**Garbage in, garbage out. Brilliance in, brilliance out.**

AI is not magic — it's a mirror. It reflects the quality of your thinking back at you. The prompts in this toolkit are built to help you give the AI exactly what it needs to produce professional, on-brand, conversion-ready output.

---

## The RACE Prompt Framework

Every great marketing prompt follows four elements:

### **R — Role**
Tell the AI who it is. A senior copywriter thinks differently than a brand strategist.

> *"You are an expert B2B content strategist with 15 years of experience..."*

### **A — Action**
Be specific about what you want. "Write a LinkedIn post" is weak. "Write a 150-word LinkedIn post that opens with a contrarian hook..." is strong.

### **C — Context**
Provide the details that make the output yours — your brand, audience, product, tone, and any data or constraints.

### **E — Examples / End Goal**
Tell it what success looks like. Share an example of good output, or describe the final goal (e.g., "The reader should feel urgency and click the CTA").

---

## How to Fill In the Brackets

Every prompt uses `[BRACKETS]` for the variables you need to fill in. Here's how to do it well:

| Bracket | What to Put There |
|---|---|
| `[COMPANY NAME]` | Your actual company name |
| `[PRODUCT/SERVICE]` | Be specific — don't just say "software" |
| `[TARGET AUDIENCE]` | Job title, industry, pain point, demographic |
| `[TONE]` | Professional, conversational, witty, bold, empathetic |
| `[KEY BENEFIT]` | The #1 thing your customer gets |
| `[PAIN POINT]` | The problem that keeps them up at night |
| `[COMPETITOR]` | A real competitor, or "our main competitor" |
| `[CTA]` | Book a demo, start a trial, download the guide, etc. |
| `[DATA/STATS]` | Real numbers if you have them — AI can use them |

---

## Power Moves

### 🔁 Chain Prompts
Use one prompt's output as input for the next. Example:
1. Use the **Brand Voice Guide prompt** (Section 04) to define your voice
2. Paste that output into the **LinkedIn Post prompt** (Section 02)
3. Now every piece of content sounds like you

### 🎯 Set the Scene First
Before copying a prompt, paste this setup message into your AI chat:

```
Before I give you a task, here is the context for our brand:

Company: [COMPANY NAME]
Product/Service: [PRODUCT/SERVICE]
Target Audience: [TARGET AUDIENCE]
Tone of Voice: [TONE]
Key Differentiator: [KEY DIFFERENTIATOR]
Typical CTA: [CTA]

Please keep this context in mind for all prompts I share in this conversation.
```

### 🔄 Ask for Alternatives
After any prompt output, follow up with:
- *"Give me 3 alternative versions with different hooks."*
- *"Make version 2 more aggressive/emotional/data-driven."*
- *"Rewrite this for a CFO audience instead of a CMO audience."*

### ✂️ Edit, Don't Accept
AI output is a first draft, not a final draft. The best marketers use AI to get to 70% in 2 minutes, then spend 10 minutes pushing it to 100%.

---

## Choosing the Right AI Tool

| Task | Best Tool |
|---|---|
| Long-form strategy, nuanced brand work | Claude |
| Punchy copy, headlines, ad variants | ChatGPT |
| Research-heavy reports, data synthesis | Gemini |
| Code/integrations for marketing ops | ChatGPT / Claude |

---

## Your First 3 Prompts

Start here before anything else:

1. **Brand Voice Guide** → `04-brand-strategy-prompts.md` — Prompt #1
   *Set the foundation. Everything else builds on this.*

2. **Content Pillar Framework** → `02-content-social-prompts.md` — Prompt #24
   *Map out your content strategy before you start writing.*

3. **Campaign Brief** → `03-campaign-copy-prompts.md` — Prompt #1
   *Get your next campaign structured and ready to execute.*

---

## Troubleshooting Weak Output

| Problem | Fix |
|---|---|
| Output feels generic | Add more specific context in `[BRACKETS]` |
| Tone is off | Add a sample of your own writing and say "match this tone" |
| Too long / too short | Add explicit length requirements to the prompt |
| Missing your differentiator | Explicitly state what makes you different in the Context section |
| Sounds like every other brand | Run it through the Brand Voice Check prompt (Section 04, Prompt #8) |

---

## Let's Go

You have everything you need. Start with Section 02 for content, Section 03 for campaigns, Section 04 for brand strategy, or jump straight to the Cheat Sheet (`07-cheat-sheet.md`) for the 15 most powerful prompts in the whole toolkit.

*Good marketing is thinking made visible. AI just helps you think faster.*
