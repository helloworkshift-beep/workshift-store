# 06 — Workflow SOPs

> Five complete Standard Operating Procedures for the most important marketing workflows. Each SOP tells you exactly what to do, when, how long it takes, and which prompts to use.

---

## How to Use These SOPs

These are **repeatable systems**, not one-time recipes. Run them on a schedule. Over time, you'll build a library of outputs, learnings, and brand assets that compound in value.

**Before you start any SOP:**
1. Open the relevant prompt files alongside this one
2. Fill in your [BRAND BRIEF] or keep it in a doc to paste quickly
3. Use a single AI chat session per SOP — context carries over and improves outputs
4. Save all outputs in your preferred content management system

---

## SOP A — Full Campaign Launch System

> **Purpose:** Launch a complete marketing campaign — from strategy through execution — using AI to accelerate every stage.
> **Total time:** 3–5 hours (spread across 2–3 sessions)
> **Cadence:** Per campaign (typically monthly or quarterly)

---

### Phase 1: Campaign Strategy (60–90 minutes)

**Step 1 — Define the campaign objective**
- Time: 10 minutes
- Tool: Notepad or doc (human thinking, no AI yet)
- Write down in one sentence: *"This campaign will [ACTION] for [AUDIENCE] to achieve [GOAL] by [DATE]."*
- Define your primary KPI and secondary KPIs before touching AI
- **Why:** AI can't set your business goals. You can.

**Step 2 — Build the campaign brief with AI**
- Time: 20 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 01 (Campaign Strategy Framework)** or **Prompt 08 (Go-to-Market Launch Plan)**
- Input: Your one-sentence objective + product/service details + target audience + budget
- Output: Full campaign brief with messaging pillars, channel strategy, and KPIs
- Save this output — it becomes your brief for all downstream work

**Step 3 — Develop your messaging hierarchy**
- Time: 20 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 04 (Messaging Hierarchy)**
- Input: Campaign brief from Step 2
- Output: Primary message, supporting messages, proof points, CTAs

**Step 4 — Map the customer journey**
- Time: 20 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 03 (Customer Journey Map)**
- Output: Awareness → Consideration → Decision content plan for this campaign

---

### Phase 2: Content & Copy Production (90–120 minutes)

**Step 5 — Write ad copy variants**
- Time: 30 minutes
- Prompt to use: **03 — Campaign Copy Prompts → Prompt 01 (Google Search Ads)** and **Prompt 05 (Facebook/Instagram Ads)**
- Run 3–5 variants of each ad type (headline + body copy + CTA)
- Note: Use your campaign brief as context at the start of the session

**Step 6 — Write landing page copy**
- Time: 30 minutes
- Prompt to use: **03 — Campaign Copy Prompts → Prompt 10 (Landing Page Copy)**
- Input: Campaign brief + target keyword (if SEO component) + conversion goal
- Output: Full landing page: hero, subheadline, benefits, social proof, FAQ, CTA

**Step 7 — Create email sequence**
- Time: 30 minutes
- Prompt to use: **03 — Campaign Copy Prompts → Prompt 13 (Email Nurture Sequence)**
- Minimum: 3-email sequence (awareness → education → conversion)
- Optional: Add a re-engagement email for non-openers

**Step 8 — Generate social media content**
- Time: 30 minutes
- Prompt to use: **02 — Content & Social Prompts → Prompt 01 (LinkedIn)**, **Prompt 08 (Instagram)**, **Prompt 12 (Twitter/X)**
- Create at least 2 posts per active channel, plus a launch-day version

---

### Phase 3: Supporting Assets (30–60 minutes)

**Step 9 — Write blog or content piece (if content component)**
- Time: 30 minutes
- Prompt to use: **02 — Content & Social Prompts → Prompt 17 (Blog Post)** or **Prompt 19 (Pillar Page)**
- Use the campaign's messaging hierarchy as the content spine

**Step 10 — Prepare campaign tracking plan**
- Time: 15 minutes
- No prompt needed — use this checklist:
  - [ ] UTM parameters defined for all links
  - [ ] Conversion events confirmed in analytics
  - [ ] CRM campaign tags set up
  - [ ] Reporting dashboard or template ready

---

### Phase 4: Post-Launch Analysis (30–60 minutes — run after campaign ends)

**Step 11 — Write campaign post-mortem**
- Time: 30 minutes
- Prompt to use: **05 — Reporting Prompts → Prompt 05 (Campaign Post-Mortem)**
- Input: Your actual results vs. KPI targets
- Output: Full post-mortem to share with the team

**Step 12 — Extract reusable insights**
- Time: 15 minutes
- Add to your brand brief: what messaging worked, what audiences responded, what channels delivered
- Update your prompt templates with new [BRAND] context

---

### Campaign Launch Checklist

Before going live, confirm:
- [ ] Campaign brief approved
- [ ] All copy reviewed and approved
- [ ] Landing page live and tested
- [ ] UTM tracking in place
- [ ] Ads loaded in platform and reviewed
- [ ] Email sequence activated
- [ ] Social posts scheduled
- [ ] Team notified of launch
- [ ] Reporting dashboard ready

---

## SOP B — Monthly Content Batch (All Channels in One Session)

> **Purpose:** Produce a full month of content for all channels in a single focused work session — using AI to batch-create efficiently.
> **Total time:** 3–4 hours (one sitting or two 2-hour blocks)
> **Cadence:** Monthly (run the first week of each month for the upcoming month)

---

### Before You Start: Monthly Content Brief

**Step 1 — Define the month's content theme**
- Time: 15 minutes (before opening AI)
- Decide: What is the overarching theme or campaign for this month?
- Example: "November = end-of-year urgency + customer success stories"
- Write down: 1 theme, 3 content pillars, 2–3 key messages
- Identify any dates: product launches, holidays, events, promotions

**Step 2 — Set your content targets**
- How many LinkedIn posts: [NUMBER — typical: 12–20]
- How many Instagram posts: [NUMBER]
- How many X/Twitter posts: [NUMBER]
- How many emails: [NUMBER — typical: 4–8]
- How many blog posts: [NUMBER]
- How many YouTube videos or scripts: [NUMBER]

---

### Session 1: Social Media Batch (90 minutes)

**Step 3 — Generate LinkedIn content for the month**
- Time: 30 minutes
- Prompt to use: **02 — Content & Social Prompts → Prompt 24 (Content Calendar Generator)**
- Input: Monthly theme, content pillars, posting frequency
- Output: LinkedIn calendar with 15–20 post ideas + outlines
- Follow-up: Use **Prompt 01–06** to write the full posts for your top 8–10 posts

**Step 4 — Generate Instagram content for the month**
- Time: 20 minutes
- Prompt to use: **02 — Content & Social Prompts → Prompt 08 (Instagram Caption)** + **Prompt 09 (Reels Script)**
- Tip: In the same chat, paste your monthly theme and ask AI to maintain consistency

**Step 5 — Generate Twitter/X content for the month**
- Time: 20 minutes
- Prompt to use: **02 — Content & Social Prompts → Prompt 12 (Twitter/X Thread)** and **Prompt 13 (Single Tweets)**
- Aim for: 1 thread per week + 5–7 standalone tweets per week

**Step 6 — Create a visual content brief**
- Time: 10 minutes
- No prompt needed — list the posts that need designed graphics
- Include: dimensions, copy overlay text, brand colors/style notes
- Hand off to designer or use a Canva template

---

### Session 2: Long-Form & Email Content (90 minutes)

**Step 7 — Write the month's email campaigns**
- Time: 30 minutes
- Prompt to use: **03 — Campaign Copy Prompts → Prompt 12 (Newsletter)** and **Prompt 13 (Promotional Email)**
- Write all emails in sequence: weekly newsletter + any promotional sends
- Note: Keep the AI chat open — reference prior emails to maintain voice consistency

**Step 8 — Write blog posts or content pieces**
- Time: 40 minutes
- Prompt to use: **02 — Content & Social Prompts → Prompt 17 (Blog Post — SEO Optimized)** or **Prompt 18 (Thought Leadership Article)**
- Aim for at least 1 substantial piece per month (1,500+ words)
- Use the outline first, then generate section by section

**Step 9 — Write YouTube or video scripts (if applicable)**
- Time: 20 minutes
- Prompt to use: **02 — Content & Social Prompts → Prompt 21 (YouTube Script)**

---

### Session 3: Review, Refine & Schedule (30–45 minutes)

**Step 10 — Review all AI-generated content**
- Read everything. Edit for:
  - Brand voice accuracy
  - Factual accuracy (AI can hallucinate stats — verify any data)
  - Freshness (remove anything generic or timeless-sounding if current events matter)
  - Personal touches (add real anecdotes, customer quotes, internal data)

**Step 11 — Schedule all content**
- Load posts into your scheduling tool (Buffer, Hootsuite, Later, etc.)
- Schedule emails in your ESP
- Set blog posts to publish with final review reminder

**Step 12 — Create a content tracker**
- Document: post dates, platforms, topics, goals, UTM links
- At month end: review performance data for the next batch session

---

## SOP C — Product Launch Marketing Sequence

> **Purpose:** Execute a complete go-to-market marketing sequence for a product or feature launch.
> **Total time:** 6–10 hours across 2–4 weeks
> **Cadence:** Per product or major feature launch

---

### Pre-Launch Phase (3–4 weeks before launch)

**Step 1 — Develop launch positioning and messaging**
- Time: 60 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 02 (Positioning Statement)** and **Prompt 04 (Messaging Hierarchy)**
- Output: Clear positioning statement, key differentiators, messaging for each audience segment

**Step 2 — Create the launch campaign brief**
- Time: 30 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 08 (Go-to-Market Launch Plan)**
- Input: Product details, target audience, launch date, budget, channels
- Output: Full launch campaign brief with timeline and channel strategy

**Step 3 — Write the foundational launch copy**
- Time: 90 minutes
- Prompt to use: **03 — Campaign Copy Prompts → Prompt 10 (Landing Page)**, **Prompt 01 (Google Ads)**, **Prompt 05 (Facebook/Instagram Ads)**
- Create: Product landing page, ad copy, product description
- Also write: Internal sales enablement copy (one-pager, battlecard bullet points)

**Step 4 — Build pre-launch email sequence**
- Time: 30 minutes
- Prompt to use: **03 — Campaign Copy Prompts → Prompt 13 (Email Sequence)**
- Sequence:
  - Email 1 (2 weeks out): Teaser / "something's coming"
  - Email 2 (1 week out): Problem + hint at the solution
  - Email 3 (2 days out): Last chance to join waitlist / early access
  - Email 4 (launch day): It's here — full reveal

---

### Launch Week

**Step 5 — Write launch day content**
- Time: 45 minutes
- Prompts to use: **02 — Content & Social Prompts → Prompt 01 (LinkedIn)**, **Prompt 08 (Instagram)**, **Prompt 12 (Twitter/X)**
- Create a full day of coordinated posts across all channels
- Timing: Stagger posts throughout the day (morning announcement → midday social proof → evening recap)

**Step 6 — Launch day email**
- Time: 20 minutes
- Prompt to use: **03 — Campaign Copy Prompts → Prompt 11 (Launch/Announcement Email)**
- Subject line: Test 3 variants. Pick the strongest.

**Step 7 — Write PR and partnership outreach**
- Time: 30 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 09 (PR Pitch)** or **Prompt 10 (Partnership Outreach)**
- Target: 5–10 relevant publications, influencers, or partners

---

### Post-Launch Phase (2–4 weeks after)

**Step 8 — Create follow-up content**
- Time: 45 minutes
- Prompts to use: **02 — Content & Social Prompts → Prompt 14 (Customer Story)**, **Prompt 18 (Thought Leadership)**
- Create: 3 posts using early customer reactions or results

**Step 9 — Write post-launch email sequence**
- Time: 30 minutes
- Emails:
  - Week 1 post-launch: Social proof + early results
  - Week 2: "Here's what customers are saying"
  - Week 3: Address objections / FAQ
  - Week 4: Last call for launch pricing or offer

**Step 10 — Conduct launch post-mortem**
- Time: 45 minutes
- Prompt to use: **05 — Reporting Prompts → Prompt 05 (Campaign Post-Mortem)**
- Capture: what messaging resonated, which channels drove the most signups, what you'd do differently

---

## SOP D — Competitive Analysis Sprint

> **Purpose:** Conduct a thorough competitive analysis and translate it into actionable strategy — in a single focused sprint.
> **Total time:** 3–4 hours
> **Cadence:** Quarterly (or when a major competitor moves)

---

### Phase 1: Research & Data Gathering (60–90 minutes — human-led)

**Step 1 — Identify your competitive set**
- List 3–5 direct competitors
- List 2–3 indirect competitors (alternative solutions)
- Note any new entrants in the past 6 months

**Step 2 — Gather competitive intelligence**
- Time: 60 minutes
- For each competitor, collect:
  - [ ] Homepage and key landing pages (screenshot + notes)
  - [ ] Pricing page (structure, tiers, positioning)
  - [ ] Recent ads (use Facebook Ad Library, Google Transparency Center)
  - [ ] Social media: tone, content types, posting frequency, top posts
  - [ ] Blog and content strategy: topics, format, SEO focus
  - [ ] Email (subscribe to their list — save welcome email and recent campaigns)
  - [ ] G2/Capterra/Trustpilot reviews: what do customers love/hate?
  - [ ] Recent news, funding, hires, product launches

---

### Phase 2: AI-Powered Analysis (60–90 minutes)

**Step 3 — Competitive positioning analysis**
- Time: 30 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 05 (Competitive Positioning Analysis)**
- Input: Your research from Phase 1 (paste key findings)
- Output: Positioning map, differentiation gaps, where competitors are vulnerable

**Step 4 — Messaging and copy analysis**
- Time: 20 minutes
- Ask AI to analyze:
  - "Here are headlines from 5 competitors. Identify patterns in how they position themselves and find gaps we could own."
  - Paste homepages, ad copy, and email subject lines into the prompt
- Output: Messaging patterns, overused language to avoid, unique angles you could own

**Step 5 — Content and SEO competitive gaps**
- Time: 20 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 06 (Content Strategy Development)**
- Input: List of topics competitors rank for or publish frequently
- Ask AI: "What content gaps exist? What topics are underserved that align with our positioning?"

**Step 6 — SWOT synthesis**
- Time: 20 minutes
- Prompt:
  ```
  Based on this competitive intelligence, write a concise competitive SWOT analysis for [COMPANY NAME].
  
  Focus on:
  - Strengths we have that competitors lack
  - Weaknesses where competitors outperform us
  - Market opportunities that are underserved
  - Competitive threats we should take seriously in the next 6–12 months
  
  Competitive intelligence: [PASTE YOUR NOTES]
  
  Be specific — avoid generic SWOT entries. Each point should be actionable.
  ```

---

### Phase 3: Strategy & Action Plan (30–45 minutes)

**Step 7 — Develop counter-positioning strategy**
- Time: 20 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 02 (Positioning Statement)**
- Focus: How do you position relative to what you've just learned?

**Step 8 — Create the competitive battlecard**
- Time: 20 minutes
- Prompt:
  ```
  Create a one-page competitive battlecard for our sales team comparing [COMPANY NAME] vs. [COMPETITOR].
  
  Format:
  - Header: "Why [COMPANY NAME] vs. [COMPETITOR]?"
  - Quick win reasons (3 bullet points, one sentence each)
  - Head-to-head comparison table: 8 key dimensions
  - How to handle the 3 most common objections ("The competitor told us...")
  - When [COMPANY NAME] wins and why
  - When [COMPETITOR] wins (be honest — builds credibility with sales)
  - Our differentiating proof points
  
  Company details: [YOUR PRODUCT/FEATURES]
  Competitor details: [WHAT YOU KNOW ABOUT THEM]
  ```

**Step 9 — Write competitive analysis summary report**
- Time: 15 minutes
- Prompt to use: **05 — Reporting Prompts → Prompt 03 (Channel Performance Deep Dive)** (adapt for competitive context)
- Share with leadership and product team

---

## SOP E — Quarterly Marketing Review and Planning

> **Purpose:** Close out the quarter with a rigorous performance review, then build your next-quarter marketing plan — using AI to accelerate analysis and planning.
> **Total time:** 4–6 hours (ideally over 2 days)
> **Cadence:** Quarterly (run in the last 2 weeks of each quarter)

---

### Day 1: Quarterly Review (2–3 hours)

**Step 1 — Gather all performance data**
- Time: 45 minutes (human-led data collection)
- Pull from: Google Analytics, CRM, email platform, ad platforms, social analytics
- Organize in a spreadsheet: one row per channel, columns for all key metrics
- Compare to: Q targets, prior quarter, prior year same quarter

**Step 2 — Write the quarterly OKR review**
- Time: 30 minutes
- Prompt to use: **05 — Reporting Prompts → Prompt 14 (Quarterly OKR Review)**
- Input: Your OKR scores and context from the data gathered
- Output: Full OKR review document

**Step 3 — Conduct channel performance analysis**
- Time: 30 minutes
- Prompt to use: **05 — Reporting Prompts → Prompt 04 (Multi-Channel Comparison Report)**
- Input: Your full-quarter channel data
- Output: Performance ranking, efficiency analysis, budget reallocation recommendations

**Step 4 — Write executive summary**
- Time: 20 minutes
- Prompt to use: **05 — Reporting Prompts → Prompt 08 (Board-Level Marketing Update)**
- Tailor to your audience: leadership team, board, or investors
- Keep it to 1 page or 5 slides maximum

**Step 5 — Team retrospective (async or in person)**
- Time: 45 minutes
- Human activity — facilitate a blameless retro with your team
- Questions to ask:
  - What are we most proud of this quarter?
  - What would we do differently?
  - What should we stop doing?
  - What should we start doing?
  - What assumptions were proven wrong?

---

### Day 2: Quarterly Planning (2–3 hours)

**Step 6 — Review company priorities for next quarter**
- Time: 20 minutes (human activity — meeting with CEO/leadership)
- Confirm: revenue targets, product roadmap, hiring plans, strategic priorities
- Note: Any major changes from this quarter that affect marketing strategy

**Step 7 — Build next quarter's marketing strategy**
- Time: 45 minutes
- Prompt to use: **04 — Brand & Strategy Prompts → Prompt 01 (Campaign Strategy Framework)** adapted for quarterly planning
- Prompt addition:
  ```
  Based on these Q[LAST QUARTER] results and Q[NEXT QUARTER] company priorities, develop a quarterly marketing strategy including:
  1. Top 3 marketing priorities for the quarter
  2. Campaign calendar (one campaign per month, brief description)
  3. Channel investment recommendations (where to increase, decrease, hold)
  4. Headcount or resource needs
  5. 5 OKRs for the quarter (1 objective, 3–5 KRs each)
  
  Last quarter performance: [SUMMARY]
  Company priorities: [FROM STEP 6]
  Budget: [$AMOUNT]
  Team size: [NUMBER]
  ```

**Step 8 — Set quarterly OKRs**
- Time: 30 minutes
- Use AI output from Step 7 as a draft
- Refine with your team for alignment and buy-in
- Confirm: Are these ambitious enough? Are they measurable? Do they connect to company goals?

**Step 9 — Build the quarter's content calendar**
- Time: 30 minutes
- Prompt to use: **02 — Content & Social Prompts → Prompt 24 (Content Calendar Generator)**
- Input: Quarterly themes, campaigns, and any key dates
- Output: 13-week content roadmap with themes by week

**Step 10 — Campaign kickoffs**
- Time: 30 minutes
- For each planned campaign, run **SOP A (Campaign Launch System)** Phase 1
- Create a brief for each campaign so your team can execute asynchronously

**Step 11 — Budget allocation**
- Time: 20 minutes
- Prompt to use: **05 — Reporting Prompts → Prompt 09 (Marketing Budget Justification)** or **Prompt 10 (Budget Reallocation Request)**
- Finalize channel-by-channel budget based on Q analysis

**Step 12 — Communicate the plan**
- Time: 20 minutes
- Write a one-page "Q[NEXT] Marketing Plan" summary for your team
- Include: priorities, campaigns, OKRs, budget summary, team responsibilities

---

### Quarterly Planning Checklist

- [ ] Q performance data collected and organized
- [ ] OKR review written and shared
- [ ] Channel performance analyzed and ranked
- [ ] Executive summary prepared
- [ ] Team retrospective completed
- [ ] Company priorities for next quarter confirmed
- [ ] Next quarter marketing strategy drafted
- [ ] OKRs set and aligned with leadership
- [ ] Content calendar built for 13 weeks
- [ ] Campaign briefs created for each initiative
- [ ] Budget allocated by channel
- [ ] Plan communicated to team

---

*Next: [07 — Cheat Sheet →](07-cheat-sheet.md)*
