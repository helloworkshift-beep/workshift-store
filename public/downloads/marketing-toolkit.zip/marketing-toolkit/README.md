# 🚀 The Marketer's AI Prompt Toolkit

> **200+ hours of marketing expertise, distilled into 80+ battle-tested AI prompts.**

---

## What's Inside

This toolkit gives B2B and B2C marketers everything they need to use AI like a seasoned pro — not a beginner guessing at prompts. Every prompt is structured, tested, and ready to drop into ChatGPT, Claude, Gemini, or any other AI assistant.

| File | Contents | Prompts |
|------|----------|---------|
| `01-quick-start-guide.md` | Setup, mindset, and how to use this toolkit | — |
| `02-content-social-prompts.md` | LinkedIn, Twitter/X, Instagram, YouTube, Blog, Calendars | 25 |
| `03-campaign-copy-prompts.md` | Campaign briefs, ad copy, landing pages, email sequences | 20 |
| `04-brand-strategy-prompts.md` | Brand voice, positioning, messaging, taglines | 20 |
| `05-reporting-analysis-prompts.md` | Reports, reviews, attribution, board updates, budgets | 15 |
| `06-workflow-sops.md` | 5 complete end-to-end marketing workflows | — |
| `07-cheat-sheet.md` | Top 15 power prompts for instant use | 15 |

**Total: 80+ prompts across all files.**

---

## How to Use This Toolkit

1. **Start with `01-quick-start-guide.md`** — understand the prompt framework
2. **Find your use case** — navigate to the relevant section
3. **Copy the prompt** — paste directly into your AI tool of choice
4. **Fill in the `[BRACKETS]`** — replace with your specific details
5. **Iterate** — use the follow-up suggestions to refine outputs

---

## AI Tools This Works With

- ✅ Claude (Anthropic) — *Recommended for long-form and strategy*
- ✅ ChatGPT (OpenAI) — *Recommended for copy and ideation*
- ✅ Gemini (Google) — *Recommended for research-heavy tasks*
- ✅ Copilot (Microsoft)
- ✅ Any instruction-following LLM

---

## Who This Is For

- **Content Marketers** — produce more content, faster, without burning out
- **Brand Strategists** — build sharper positioning with AI as your thinking partner
- **Performance Marketers** — write better ad copy and landing pages in minutes
- **Marketing Directors** — generate executive-ready reports and board updates
- **Founders & Solopreneurs** — do the work of a full marketing team

---

## Quick Tips

> 💡 **The more context you give, the better the output.** Always fill in every `[BRACKET]` thoughtfully.

> 💡 **Chain prompts together.** Use the output from one prompt as input to the next.

> 💡 **Save your filled-in prompts.** Build a library of prompts customized to your brand.

> 💡 **Treat AI as a thinking partner, not a vending machine.** Push back, ask for alternatives, and iterate.

---

## Version

**v1.0** | Built for marketers who want to move faster without sacrificing quality.

---

*© The Marketer's AI Prompt Toolkit. For personal and commercial use by the license holder.*
