# 03 — Campaign Copy Prompts

> 20 prompts for campaign briefs, ad copy, landing pages, email sequences, and A/B test variants.

---

## Campaign Briefs

---

### **Prompt 01 — The Full Campaign Brief**

*When to use: Kicking off a new marketing campaign and aligning your team (or briefing an agency) on goals, strategy, and execution.*

```
You are a senior marketing strategist with deep experience building integrated campaigns for [INDUSTRY] companies.

Create a comprehensive campaign brief for [COMPANY NAME].

Campaign context:
- Campaign name: [CAMPAIGN NAME]
- Campaign type: [TYPE — e.g., product launch, seasonal, lead gen, brand awareness, retention]
- Campaign goal: [SPECIFIC GOAL — e.g., "Generate 300 MQLs in 6 weeks" or "Drive $150K in revenue"]
- Target audience: [PRIMARY AUDIENCE — include demographics, psychographics, job titles if B2B]
- Secondary audience (if any): [SECONDARY AUDIENCE]
- Campaign dates: [START DATE] to [END DATE]
- Budget: [$BUDGET or "TBD"]
- Channels: [CHANNELS]

Brand context:
- Product/Service being promoted: [PRODUCT/SERVICE]
- Key benefit: [KEY BENEFIT]
- USP: [UNIQUE SELLING PROPOSITION]
- Key competitors: [COMPETITORS]
- Tone of voice: [TONE]

Deliver a full brief including:
1. Executive Summary (3–4 sentences)
2. Campaign Objectives (SMART goals)
3. Target Audience Profile (including pain points, motivations, objections)
4. Campaign Strategy (core narrative, key messages, value proposition)
5. Channel Plan (each channel, role it plays, content types, KPIs)
6. Creative Direction (tone, visual direction notes, key messages per channel)
7. Offer & CTA Strategy
8. Timeline (week-by-week milestones)
9. Success Metrics (primary KPIs + secondary indicators)
10. Risks & Mitigation
```

---

### **Prompt 02 — The Campaign Messaging Matrix**

*When to use: You need to ensure consistent messaging across multiple channels and audiences.*

```
You are a campaign messaging strategist who ensures brand consistency across all touchpoints.

Build a campaign messaging matrix for [COMPANY NAME]'s [CAMPAIGN NAME] campaign.

Campaign context:
- Product/Service: [PRODUCT/SERVICE]
- Core value proposition: [VALUE PROPOSITION]
- Campaign theme/tagline: [THEME/TAGLINE]
- Audiences: [LIST 2–3 AUDIENCE SEGMENTS]
- Channels: [LIST ALL CHANNELS]
- Tone: [TONE]

For each audience segment × channel combination, provide:
- Primary message (1 sentence — what's the #1 thing we want them to hear?)
- Key benefit (most relevant to this audience)
- Proof point (stat, testimonial, or feature that backs the claim)
- CTA (specific to this audience/channel)
- Tone adjustment (how tone shifts for this audience)

Format as a table: Audience | Channel | Primary Message | Key Benefit | Proof Point | CTA | Tone Note

After the table, write the "campaign north star" — one paragraph that defines the single unifying idea behind all messages.
```

---

### **Prompt 03 — The A/B Test Plan**

*When to use: Planning structured A/B tests for your campaigns before launch.*

```
You are a conversion optimization and testing strategist for [INDUSTRY] marketing campaigns.

Build an A/B test plan for [COMPANY NAME]'s [CAMPAIGN/CHANNEL].

Test context:
- What we're testing: [ELEMENT — e.g., email subject lines, landing page headline, ad creative, CTA button]
- Campaign goal: [GOAL]
- Current baseline (if known): [CURRENT PERFORMANCE METRIC]
- Target improvement: [WHAT IMPROVEMENT WOULD BE MEANINGFUL — e.g., "10% lift in CTR"]
- Audience: [AUDIENCE]
- Traffic/volume available for testing: [VOLUME]

For each test, provide:
1. Hypothesis (If we change [X], we expect [Y] because [reason])
2. Control (Version A — current/baseline)
3. Variant (Version B — what we're testing)
4. Metric to measure (primary + secondary)
5. Minimum sample size needed for statistical significance
6. Test duration recommendation
7. Success criteria (what result means we should implement the variant)

Design 5 separate A/B tests for [CHANNEL], prioritized by potential impact.

End with: A "testing roadmap" showing which tests to run sequentially vs. simultaneously.
```

---

## Ad Copy

---

### **Prompt 04 — Google Search Ads**

*When to use: Writing high-converting Google search ad copy for PPC campaigns.*

```
You are a Google Ads copywriter and PPC specialist with expertise in [INDUSTRY].

Write Google Search ad copy for [COMPANY NAME] targeting the keyword: [TARGET KEYWORD]

Ad details:
- Product/Service: [PRODUCT/SERVICE]
- Landing page URL: [URL]
- Key benefit: [KEY BENEFIT]
- USP: [USP]
- Offer (if any): [OFFER — e.g., "Free trial", "30% off", "Free consultation"]
- CTA: [CTA]
- Audience intent: [INTENT — e.g., "High intent — they're searching to buy now" or "Informational — researching options"]
- Top competitor running ads: [COMPETITOR]
- Tone: [TONE]

Deliver:
- 3 complete Responsive Search Ads (RSA), each with:
  - 15 headline options (max 30 characters each) — labeled H1–H15
  - 4 description options (max 90 characters each) — labeled D1–D4
  - Pinning recommendation (which headline goes in position 1)

- 5 standalone ad extension options:
  - 3 Sitelink extensions (headline + 2 lines of description)
  - 2 Callout extensions (max 25 characters each)

Prioritize: clarity > cleverness. Lead with the strongest benefit or offer.
```

---

### **Prompt 05 — Meta (Facebook/Instagram) Ad Copy**

*When to use: Writing ad copy for Facebook and Instagram campaigns (awareness, traffic, conversion).*

```
You are a Meta Ads copywriter who specializes in [INDUSTRY] direct-response and brand campaigns.

Write Meta ad copy for [COMPANY NAME] for the following campaign:

Campaign details:
- Objective: [OBJECTIVE — Awareness / Traffic / Leads / Conversions / Retargeting]
- Product/Service: [PRODUCT/SERVICE]
- Target audience: [AUDIENCE — demographics, interests, behaviors]
- Key benefit: [KEY BENEFIT]
- Pain point addressed: [PAIN POINT]
- Offer: [OFFER]
- CTA button: [CTA — e.g., "Shop Now", "Learn More", "Get Quote"]
- Landing page: [URL or description]
- Tone: [TONE]
- Visual description (what the ad image/video will show): [VISUAL]

Write 3 complete ad variants:

Variant A — Problem/Solution format
Variant B — Social proof / testimonial format  
Variant C — Direct offer / urgency format

For each variant:
- Primary text (125 characters — shown before "See More" on mobile)
- Extended primary text (up to 500 characters for full context)
- Headline (40 characters max)
- Description (30 characters max)

Also write: 5 standalone headline options for split testing.
```

---

### **Prompt 06 — LinkedIn Sponsored Content Ad**

*When to use: Running paid campaigns on LinkedIn targeting professionals by title, company, or industry.*

```
You are a LinkedIn Ads specialist and B2B copywriter with deep expertise in [INDUSTRY].

Write LinkedIn Sponsored Content ad copy for [COMPANY NAME].

Campaign details:
- Campaign objective: [OBJECTIVE — Brand awareness / Website visits / Lead gen / Engagement]
- Product/Service: [PRODUCT/SERVICE]
- Target audience: [JOB TITLE + COMPANY SIZE + INDUSTRY — be specific]
- Key message: [KEY MESSAGE]
- Pain point: [PAIN POINT]
- Proof point: [STAT OR CASE STUDY RESULT]
- Offer/CTA: [OFFER + CTA]
- Landing page or Lead Gen Form topic: [DESTINATION]
- Tone: [TONE — professional but not stiff]

Deliver 3 complete ad variants:

Variant A — Insight-led (open with a surprising stat or industry insight)
Variant B — Pain point-led (open by naming their challenge)
Variant C — Results-led (open with a customer outcome or proof)

For each:
- Introductory text (150 characters — shown above the image)
- Full text (max 600 characters)
- Headline (70 characters max)
- Description (100 characters max)

Format as clearly labeled blocks. Flag which variant you'd recommend testing first and why.
```

---

### **Prompt 07 — Display / Banner Ad Copy**

*When to use: Writing copy for display ads, retargeting banners, or programmatic ad units.*

```
You are a display advertising copywriter specializing in retargeting and awareness campaigns.

Write display ad copy for [COMPANY NAME] for the following sizes: [SIZES — e.g., 300x250, 728x90, 160x600]

Ad details:
- Product/Service: [PRODUCT/SERVICE]
- Campaign type: [COLD AWARENESS / RETARGETING / LOOKALIKE]
- Audience: [AUDIENCE]
- Key message: [ONE MESSAGE — display ads must be singular in focus]
- Offer: [OFFER]
- CTA: [CTA]
- Tone: [TONE]
- Brand colors/visual direction: [VISUAL DIRECTION]

For each ad size, provide:
- Headline (max 30 characters)
- Body copy (max 50–75 characters depending on size)
- CTA button text (max 20 characters)
- Design note (what the visual should communicate)

Also provide:
- 5 retargeting-specific variants for people who visited [PAGE] but didn't convert
- 3 urgency/scarcity variants (for use when there's a deadline or limited availability)
```

---

## Landing Page Copy

---

### **Prompt 08 — The Lead Generation Landing Page**

*When to use: Building a landing page designed to capture leads (email, phone, consultation request).*

```
You are a conversion copywriter and landing page strategist with a track record in [INDUSTRY].

Write complete landing page copy for [COMPANY NAME]'s lead generation page.

Page details:
- Goal: [GOAL — e.g., "Get visitors to book a free strategy call"]
- Offer: [OFFER — what they're getting in exchange for their info]
- Target audience: [AUDIENCE]
- Traffic source (where they're coming from): [SOURCE — Google Ads / LinkedIn / organic / email]
- Key benefit: [KEY BENEFIT]
- Pain point: [PAIN POINT]
- Proof: [SOCIAL PROOF — testimonials, logos, stats available]
- CTA: [CTA]
- Tone: [TONE]

Page copy structure:
1. Hero Section
   - H1 headline: 3 options (benefit-focused, max 10 words)
   - Subheadline: 1–2 sentences expanding on the H1
   - Hero CTA button: 3 options (action-oriented, first-person)
   - Trust indicators (logos, stats, or short testimonial to show under hero)

2. Problem section (50–75 words — make them feel understood)

3. Solution section (100 words — your offer as the answer)

4. Benefits section (3–5 bullet points with bold headers + 1-sentence descriptions)

5. Social proof section (3 testimonial prompts — the structure/sentiment to capture if you gather real quotes)

6. How It Works section (3 steps, max 20 words per step)

7. Final CTA section (headline + 1 sentence + button)

8. FAQ section (5 questions with answers)
```

---

### **Prompt 09 — The Product / Sales Landing Page**

*When to use: Building a direct-to-purchase or "buy now" page for a product or service.*

```
You are a direct-response copywriter specializing in high-converting sales pages for [INDUSTRY].

Write a complete sales landing page for [COMPANY NAME]'s product: [PRODUCT NAME]

Product details:
- What it is: [DESCRIPTION]
- Price: [$PRICE / pricing model]
- Key benefits: [3–5 BENEFITS]
- Features: [3–5 FEATURES]
- USP: [USP — what makes this different from everything else]
- Target buyer: [BUYER — pain points, motivations, objections]
- Social proof available: [TESTIMONIALS / CASE STUDIES / LOGOS / RATINGS]
- Guarantee (if any): [GUARANTEE]
- Urgency/Scarcity (if any): [URGENCY]
- CTA: [CTA]
- Tone: [TONE]

Write the full page with:
1. Above-the-fold: H1, subheadline, CTA (3 H1 options)
2. Pain agitation section (100 words — make the problem visceral)
3. "Imagine if..." dream state section (75 words)
4. Product reveal and key benefits (3–5 sections)
5. Feature breakdown with benefit translation (features → what it means for them)
6. Social proof section (3 testimonial frameworks)
7. Objection handling section (top 3 objections + responses)
8. Pricing section (present price with value stacking)
9. Guarantee section
10. Final CTA (create urgency without being gimmicky)
11. Post-CTA trust statement
```

---

### **Prompt 10 — The Event / Webinar Registration Page**

*When to use: Creating a landing page to drive registrations for a webinar, workshop, or live event.*

```
You are a webinar and event marketing copywriter.

Write a registration landing page for [COMPANY NAME]'s upcoming [EVENT TYPE — webinar/workshop/summit/conference].

Event details:
- Event name: [EVENT NAME]
- Date and time: [DATE/TIME/TIMEZONE]
- Format: [FORMAT — live / recorded / hybrid]
- Topic: [TOPIC]
- Key takeaways (what attendees will learn): [3–5 TAKEAWAYS]
- Speakers: [SPEAKER NAMES, TITLES, COMPANIES]
- Audience: [TARGET AUDIENCE]
- Why attend now (timeliness): [WHY THIS MATTERS NOW]
- CTA: [CTA — "Reserve Your Seat", "Register Free", etc.]
- Tone: [TONE]

Page sections:
1. H1 headline: 3 options (outcome-focused)
2. Subheadline: What they'll learn + who it's for
3. Event overview (75 words — make it sound unmissable)
4. "What you'll discover" — 4–6 bullet points
5. Speaker bios (write 1 compelling sentence per speaker)
6. Who this is for (3 audience bullets)
7. Why [COMPANY NAME] on this topic (credibility paragraph, 50 words)
8. Registration form intro (above the form — 2 sentences max)
9. FAQ (5 registration/logistics questions)
```

---

## Email Sequences

---

### **Prompt 11 — The Lead Nurture Email Sequence**

*When to use: Building an automated email sequence to nurture new leads until they're sales-ready.*

```
You are an email marketing strategist and copywriter specializing in B2B lead nurture for [INDUSTRY].

Write a 7-email lead nurture sequence for [COMPANY NAME] for new leads who downloaded [LEAD MAGNET / OPT-IN OFFER].

Context:
- Lead magnet/how they opted in: [LEAD MAGNET]
- Product/Service to ultimately sell: [PRODUCT/SERVICE]
- Target audience: [AUDIENCE]
- Sales cycle length: [SALES CYCLE — e.g., "typically 30–90 days"]
- Tone: [TONE — e.g., "Educational and helpful — we build trust before we sell"]
- CTA at end of sequence: [FINAL CTA — e.g., "Book a demo"]

For each email, write:
- Subject line (2 options: curiosity + benefit)
- Preview text (1 option, max 85 characters)
- Full email body (with natural sign-off)
- CTA (primary + optional secondary)
- Send timing from opt-in (Day X)

Email sequence:
- Email 1 (Day 0): Welcome + deliver the lead magnet + set expectations
- Email 2 (Day 2): Biggest insight / quick win related to [TOPIC]
- Email 3 (Day 5): Address the #1 pain point — educational content
- Email 4 (Day 8): Case study or social proof email
- Email 5 (Day 12): Objection-handling email (address the #1 reason they haven't moved forward)
- Email 6 (Day 16): The product/service introduction (soft sell)
- Email 7 (Day 20): The ask — clear CTA with urgency
```

---

### **Prompt 12 — The Product Launch Email Sequence**

*When to use: Launching a new product, feature, or offer to your email list.*

```
You are a product launch email strategist who has driven millions in revenue through email.

Write a 6-email product launch sequence for [COMPANY NAME] launching [PRODUCT/FEATURE NAME].

Launch details:
- Product: [PRODUCT NAME + DESCRIPTION]
- Key benefits: [3–5 BENEFITS]
- Price: [$PRICE]
- Launch date: [LAUNCH DATE]
- Pre-launch window: [X days before launch date]
- Cart close / offer end (if applicable): [END DATE]
- Audience: [AUDIENCE — existing customers / email list / segment]
- Tone: [TONE]
- Special launch offer (if any): [OFFER — e.g., early bird discount, bonus]

For each email:
- Subject line (3 options)
- Preview text
- Full email body
- CTA
- Timing

Sequence:
- Email 1 ([X] days before launch): Teaser — create anticipation without revealing everything
- Email 2 ([X-2] days before): The problem email — deepen the pain
- Email 3 (Launch day AM): The big reveal — product launch announcement
- Email 4 (Launch day PM): FAQ / objection handling
- Email 5 (2 days after launch): Social proof / early results / testimonials
- Email 6 (Final day / cart close): Urgency email — last chance

Include: Re-engagement subject lines for subscribers who didn't open Email 3.
```

---

### **Prompt 13 — The Abandoned Cart / Abandoned Inquiry Email Sequence**

*When to use: Re-engaging potential buyers who started but didn't complete a purchase or inquiry.*

```
You are a conversion email copywriter specializing in cart abandonment and re-engagement for [INDUSTRY].

Write a 3-email abandoned cart/inquiry recovery sequence for [COMPANY NAME].

Context:
- What they abandoned: [CART / DEMO REQUEST / SIGN-UP / QUOTE REQUEST]
- Product/Service: [PRODUCT/SERVICE]
- Price (if relevant): [$PRICE]
- Audience: [AUDIENCE]
- Possible reasons they didn't complete: [REASONS — e.g., "price objection, distraction, uncertainty about fit"]
- Incentive to offer (if any): [INCENTIVE]
- Tone: [TONE — warm and helpful, not guilt-tripping]
- CTA: [CTA]

For each email:
- Subject line (2 options)
- Preview text
- Full email body
- CTA
- Timing from abandonment

Email 1 (1 hour after): Gentle reminder — did something come up?
Email 2 (24 hours after): Address the #1 hesitation with proof/reassurance
Email 3 (72 hours after): Final nudge — create light urgency or offer incentive

Write each email to feel like it was written by a real human, not an automation. Short, direct, warm.
```

---

### **Prompt 14 — The Re-Engagement Email Campaign**

*When to use: Winning back inactive subscribers or churned customers.*

```
You are an email re-engagement specialist who writes campaigns that reignite dormant relationships.

Write a 4-email re-engagement campaign for [COMPANY NAME] targeting [SEGMENT — e.g., "subscribers who haven't opened in 90+ days" or "customers who haven't purchased in 6 months"].

Context:
- Who we're targeting: [SEGMENT + DESCRIPTION]
- What we want them to do: [DESIRED ACTION]
- What's new since they last engaged: [NEW PRODUCTS / FEATURES / CONTENT / OFFERS]
- Incentive (if any): [INCENTIVE]
- What happens if they don't re-engage: [E.g., "We'll remove them from the list"]
- Tone: [TONE — honest, human, a little self-aware about the awkwardness]

For each email:
- Subject line (2 options — be creative, avoid "We miss you")
- Preview text
- Full email body (keep it SHORT — 100–150 words max)
- CTA
- Timing

Email 1: The "check in" — honest, low pressure, curious
Email 2: The value reminder — what's new, what they've missed
Email 3: The offer — give them a reason to come back
Email 4: The "last chance" — clean, honest, respectful opt-out option

Include a "sunset" subject line and body for the final removal email.
```

---

### **Prompt 15 — The Onboarding Email Sequence**

*When to use: Welcoming and onboarding new customers or users after sign-up or purchase.*

```
You are a customer success and email onboarding strategist for [INDUSTRY] companies.

Write a 5-email onboarding sequence for [COMPANY NAME] for new [CUSTOMERS / USERS] of [PRODUCT/SERVICE].

Context:
- What they signed up for / purchased: [PRODUCT/SERVICE]
- The #1 outcome they want: [DESIRED OUTCOME]
- The #1 thing that causes churn early on: [EARLY CHURN REASON]
- 3 key features/steps they must complete: [FEATURES/STEPS]
- Resources available to them: [RESOURCES — help center, tutorials, support, community]
- Tone: [TONE — e.g., "Warm, encouraging, clear — like a great customer success manager"]
- CTA in final email: [CTA — upsell / referral / review / upgrade]

For each email:
- Subject line
- Preview text
- Full email body
- CTA
- Timing from sign-up

Email 1 (Day 0): Welcome + first action to take (make it feel achievable)
Email 2 (Day 2): Quick win — guide them to their first success moment
Email 3 (Day 5): Feature spotlight — show the feature most correlated with retention
Email 4 (Day 10): Social proof + community — you're in good company
Email 5 (Day 20): Check-in + expand — are they getting value? nudge toward the next level
```

---

## A/B Test Copy Variants

---

### **Prompt 16 — Email Subject Line Variants**

*When to use: Generating multiple subject line options to test for any email campaign.*

```
You are a direct-response email copywriter and split-testing specialist.

Generate A/B test subject line variants for the following email:

Email context:
- Email type: [TYPE — e.g., newsletter, product announcement, promotional, nurture]
- Email topic: [TOPIC]
- Audience: [AUDIENCE]
- Primary goal: [GOAL — open rate / click rate / conversion]
- Tone: [TONE]
- Key message inside: [KEY MESSAGE]
- Any offer or urgency: [OFFER/URGENCY]

Write 20 subject line options across these 6 categories (3–4 per category):

1. Curiosity / Open loop (make them wonder what's inside)
2. Benefit-led (lead with what they get)
3. Social proof / Authority (others are doing it, you should too)
4. Urgency / Scarcity (time or availability pressure)
5. Personal / Direct (feels like a human wrote it)
6. Contrarian / Unexpected (challenge their assumption)

For each subject line, also write:
- A matching preview text (max 85 characters)
- A 1-sentence rationale for why it could perform well

Mark your top 3 picks with ⭐ and explain your testing recommendation.
```

---

### **Prompt 17 — Landing Page Headline Variants**

*When to use: Testing different headline angles on a landing page to improve conversion rate.*

```
You are a conversion rate optimization specialist and copywriter.

Write A/B test headline variants for [COMPANY NAME]'s landing page for [PRODUCT/SERVICE].

Context:
- Page goal: [GOAL — leads / sales / registrations]
- Current headline (if any): [CURRENT HEADLINE]
- Key benefit: [KEY BENEFIT]
- Target audience: [AUDIENCE]
- Pain point: [PAIN POINT]
- USP: [USP]
- Tone: [TONE]

Write 15 headline variants across these angles:

Outcome-focused (3): Lead with the result they get
Problem-focused (3): Name the pain they want to eliminate
How-to / Method (2): Promise a process or approach
Speed/Ease (2): Make it sound fast or simple
Social proof (2): Other people's results
Contrarian (2): Challenge what they think they know
Question (1): Engage them with the right question

For each headline:
- H1 headline (max 12 words)
- Matching subheadline (1–2 sentences that expand on the H1)
- Notes on which audience segment this angle will resonate with most

⭐ Mark your top 3 recommendations for testing first.
```

---

### **Prompt 18 — CTA Button Copy Variants**

*When to use: Testing call-to-action button text to improve click-through and conversion rates.*

```
You are a UX copywriter and conversion optimization specialist.

Write CTA button copy variants for [COMPANY NAME]'s [PAGE TYPE — landing page / email / ad].

Context:
- What we want them to do: [DESIRED ACTION]
- What happens after they click: [NEXT STEP — e.g., "They fill out a form", "They go to checkout", "They schedule a call"]
- What they get: [VALUE — what's the benefit of clicking]
- Audience: [AUDIENCE]
- Tone: [TONE]
- Current CTA text (if any): [CURRENT CTA]

Write 20 CTA button options across these types:

Action + Benefit (5): Verb + what they get [e.g., "Get My Free Report"]
First-person (5): Written from the user's POV [e.g., "Yes, I Want This"]
Urgency (4): Time or scarcity [e.g., "Claim Your Spot Now"]
Low-friction (3): Reduce perceived commitment [e.g., "Start Free — No Credit Card"]
Curiosity (3): Intrigue without giving it all away

For each CTA, note:
- Expected friction level (Low / Medium / High)
- Best use case (where it performs best)

⭐ Top 3 recommendations with rationale.
```

---

### **Prompt 19 — Ad Creative Concept Variants**

*When to use: Briefing designers or content creators on multiple ad creative concepts to test.*

```
You are a creative strategist for [INDUSTRY] paid media campaigns.

Develop 6 ad creative concept briefs for [COMPANY NAME]'s upcoming [CAMPAIGN NAME] campaign.

Campaign details:
- Platform(s): [PLATFORMS]
- Product/Service: [PRODUCT/SERVICE]
- Target audience: [AUDIENCE]
- Campaign objective: [OBJECTIVE]
- Key message: [KEY MESSAGE]
- Offer: [OFFER]
- Budget context: [BUDGET — e.g., "We'll test all 6 with equal budget in week 1"]

For each creative concept:
1. Concept name (2–3 words)
2. Format (static image / video / carousel / GIF)
3. Visual direction (what does the viewer see? describe the scene in detail)
4. Headline
5. Ad copy (primary text)
6. CTA
7. Emotional hook (what emotion are we triggering?)
8. Hypothesis (why we think this will work)
9. Best-fit audience segment (which part of our target is this most likely to resonate with)

Cover these creative angles across the 6 concepts:
- Concept 1: Product demo / in-use visual
- Concept 2: Before/After or Problem/Solution
- Concept 3: Social proof / testimonial
- Concept 4: Data / statistics visual
- Concept 5: Culture / people / human story
- Concept 6: Bold text-only / direct offer
```

---

### **Prompt 20 — The Full-Funnel Copy Audit**

*When to use: Reviewing and improving all copy across a campaign funnel for consistency and conversion.*

```
You are a senior conversion copywriter conducting a funnel copy audit for [COMPANY NAME].

Audit the copy across the following funnel:

Ad → Landing Page → Email Sequence → CTA

Paste the existing copy here:
[AD COPY — paste your current ad text]
[LANDING PAGE COPY — paste key sections]
[EMAIL 1 COPY — paste subject line + body]
[CTA — paste the CTA text and context]

Audience: [AUDIENCE]
Product/Service: [PRODUCT/SERVICE]
Conversion goal: [GOAL]
Tone: [DESIRED TONE]

For each piece of copy, provide:
1. Current score (1–10) with rationale
2. Biggest weakness (be specific)
3. Biggest strength (what's working)
4. Rewritten version (improved copy)
5. 1 A/B test recommendation

Then provide:
- An overall funnel assessment: Is the message consistent from ad to landing page to email?
- 3 quick wins (changes with highest ROI potential)
- 1 "big bet" change that could significantly move the needle
```

---

*End of Section 03 — 20 prompts total.*
