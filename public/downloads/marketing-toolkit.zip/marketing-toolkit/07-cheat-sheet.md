# 07 — Cheat Sheet

> Your quick-reference companion. The 15 most powerful prompts from the entire toolkit — plus the 10 Golden Rules of Prompting for Marketers.

---

## The 15 Most Powerful Prompts

*These are the prompts that deliver the highest ROI on your time. Master these first.*

---

### **#1 — The Campaign Strategy Builder**

*The single highest-leverage prompt in the toolkit. Turns a vague idea into a complete campaign brief in 10 minutes.*

```
You are a senior marketing strategist with 20 years of experience building high-converting campaigns for [B2B/B2C] companies in [INDUSTRY].

Develop a complete campaign strategy for [COMPANY NAME].

Campaign details:
- Product/service: [WHAT WE'RE PROMOTING]
- Primary goal: [e.g., generate 500 MQLs, drive 10,000 trial signups, achieve $200K in revenue]
- Target audience: [DETAILED DESCRIPTION — demographics, role, pain points, buying stage]
- Budget: [$AMOUNT over TIMEFRAME]
- Timeline: [START DATE → END DATE]
- Channels available: [LIST]

Develop a full campaign strategy including:
1. Campaign concept and big idea (one compelling theme that ties everything together)
2. Audience segmentation (primary and secondary audiences, with tailored messaging for each)
3. Messaging hierarchy (hero message → supporting messages → proof points → CTAs)
4. Channel strategy (which channels, in what order, with what role — awareness, nurture, conversion)
5. Content plan (what content types to create, for which stage of the funnel)
6. Campaign timeline with milestones
7. Budget allocation recommendation by channel (%)
8. KPIs and success metrics (primary, secondary, guardrail metrics)
9. Risk factors and contingency plans
10. What "great" looks like for this campaign

Be specific. I should be able to hand this to a team of five and have them execute it without asking clarifying questions.
```

---

### **#2 — The Conversion-Optimized Landing Page**

*One strong landing page can generate ROI for months. This prompt writes the whole thing — hero to footer.*

```
You are a conversion rate optimization expert and direct-response copywriter. You've written landing pages that have converted at 2–5x the industry average.

Write high-converting landing page copy for [COMPANY NAME]'s [OFFER/PRODUCT/SERVICE].

Offer details:
- What we're offering: [PRODUCT/SERVICE/LEAD MAGNET/TRIAL/DEMO]
- Unique value proposition: [THE ONE THING ONLY WE CAN SAY]
- Price or commitment level: [PRICE / FREE / FREEMIUM / DEMO REQUEST]
- Primary audience: [WHO IS THIS PAGE FOR?]
- Their biggest pain point: [THE PROBLEM WE SOLVE]
- Their primary objection: [BIGGEST REASON THEY WOULDN'T CONVERT]
- Proof we have: [TESTIMONIALS / CASE STUDIES / DATA / LOGOS]
- Competitor alternatives: [WHAT ELSE THEY MIGHT CONSIDER]

Write the full landing page in this order:
1. Hero headline (primary value proposition, 8–12 words max)
2. Sub-headline (expand the hero, add urgency or specificity)
3. Hero CTA button text (action-oriented, outcome-focused — NOT "Submit")
4. Social proof bar (logos or stat: "[NUMBER] teams use [PRODUCT]")
5. Problem section (agitate the pain — make them feel it before you solve it)
6. Solution section (introduce your product as the answer)
7. Feature/benefit breakdown (3–5 key points: feature → "which means" → benefit)
8. How it works (3 steps, simple)
9. Social proof / testimonials (write 3 credible, specific testimonial templates)
10. FAQ (answer the top 5 objections as questions)
11. Final CTA section (restate value, create urgency, button text)

Tone: [TONE — e.g., "Professional and trustworthy," "Energetic and bold," "Warm and conversational"]
```

---

### **#3 — The LinkedIn Thought Leadership Post**

*The highest-engagement content format for B2B. Consistently outperforms everything else on LinkedIn.*

```
You are an expert LinkedIn ghostwriter who has written viral thought leadership content for [INDUSTRY] executives.

Write a thought leadership LinkedIn post for [AUTHOR NAME], [TITLE] at [COMPANY NAME].

Post brief:
- Insight or lesson to share: [THE CORE IDEA]
- Story or experience that illustrates it: [THE SPECIFIC MOMENT OR EXAMPLE]
- Who needs to hear this: [TARGET READER — be specific]
- Contrarian angle (optional): [BELIEF THIS CHALLENGES, IF ANY]
- Action or takeaway: [WHAT SHOULD THE READER DO OR THINK DIFFERENTLY?]
- Tone: [TONE — e.g., "Authoritative and direct," "Honest and vulnerable," "Data-driven and practical"]

Format requirements:
- Open with a hook that makes people stop scrolling (NOT "I" as the first word)
- Use short paragraphs (1–3 sentences max) — no walls of text
- Include one specific, surprising, or counterintuitive point
- End with a question that invites genuine responses
- Length: 150–250 words
- Do NOT use hashtags in the body — add 3 targeted hashtags at the very end

Write 3 variations with different hooks, and mark the strongest one.
```

---

### **#4 — The Email Sequence That Converts**

*A well-structured email sequence is your highest-ROI content asset. This prompt writes all 5 emails in one go.*

```
You are a direct-response email copywriter who specializes in B2B SaaS and [INDUSTRY] email sequences.

Write a 5-email nurture sequence for [COMPANY NAME] targeting [TARGET AUDIENCE].

Sequence goal: Move [AUDIENCE] from [STARTING STATE — e.g., "just downloaded our guide"] to [DESIRED ACTION — e.g., "book a demo"].

Audience details:
- Role: [JOB TITLE / DESCRIPTION]
- Company type: [INDUSTRY / SIZE]
- Main challenge: [PROBLEM THEY FACE]
- What they want: [DESIRED OUTCOME]
- Main hesitation about buying: [BIGGEST OBJECTION]

Product/service context:
- What we sell: [PRODUCT/SERVICE]
- Key differentiator: [WHY WE'RE DIFFERENT]
- Price point / commitment level: [PRICING / FREE TRIAL / DEMO]
- Proof points available: [CASE STUDIES / DATA / TESTIMONIALS]

Email sequence:
- Email 1 (Send immediately): Welcome + deliver on the promise. Subject line options: [3 VARIANTS]
- Email 2 (Day 3): The problem framed as a story. No selling.
- Email 3 (Day 6): Introduce the solution. Light CTA.
- Email 4 (Day 10): Social proof — a customer story or data point.
- Email 5 (Day 14): Direct ask. Clear CTA. Urgency if appropriate.

For each email write:
- 3 subject line options (A/B/C test)
- Preview text (40–50 characters)
- Full email body (150–250 words)
- Primary CTA (button text + destination)

Brand voice: [VOICE — e.g., "Conversational and warm, no corporate-speak"]
```

---

### **#5 — The Ad Copy Generator (5 Formats at Once)**

*Stop writing one ad at a time. This prompt gives you Google, Meta, LinkedIn, and display ads in a single session.*

```
You are a performance marketing copywriter who specializes in writing ads that generate clicks and conversions — not just impressions.

Write ad copy for [COMPANY NAME] promoting [PRODUCT/SERVICE/OFFER].

Target audience: [DESCRIPTION]
Core value proposition: [ONE SENTENCE]
Primary pain point addressed: [THE PROBLEM]
Desired action: [CTA — e.g., "Start free trial," "Book a demo," "Download the guide"]
Key proof point: [A STAT, TESTIMONIAL, OR SOCIAL PROOF ELEMENT]

Create ad copy for each format:

1. Google Search Ads (3 complete ads)
   - Each ad: Headline 1 (30 chars) | Headline 2 (30 chars) | Headline 3 (30 chars) | Description 1 (90 chars) | Description 2 (90 chars)

2. Facebook/Instagram Ads (3 variations)
   - Each: Primary text (125 chars for feed) | Headline (40 chars) | Description (30 chars) | CTA button

3. LinkedIn Sponsored Content (2 variations)
   - Each: Intro text (150 chars) | Headline (200 chars) | CTA

4. Display/Banner Ad Copy (3 sizes)
   - 728x90 (leaderboard): Headline | CTA
   - 300x250 (medium rectangle): Headline | Sub-copy | CTA
   - 160x600 (skyscraper): Headline | 2-line benefit | CTA

5. YouTube Pre-Roll (5-second hook + 30-second script)
   - First 5 seconds: [HOOK TO PREVENT SKIP]
   - Full 30-second script

Flag your top-recommended variant for each format.
```

---

### **#6 — The SEO Blog Post**

*Writes a complete, search-optimized, human-sounding article — not the robotic SEO content everyone skips.*

```
You are an SEO content strategist and expert writer in [INDUSTRY]. You write content that ranks AND that humans actually want to read.

Write a comprehensive, SEO-optimized blog post for [COMPANY NAME].

Post details:
- Primary keyword: [TARGET KEYWORD]
- Secondary keywords: [2–3 RELATED TERMS]
- Target audience: [WHO WILL READ THIS]
- Search intent: [INFORMATIONAL / COMMERCIAL / NAVIGATIONAL]
- Word count target: [1,200 / 1,800 / 2,500 words]
- Content angle: [UNIQUE TAKE — e.g., "The definitive guide," "A contrarian take on X," "What everyone gets wrong about X"]

Structure:
1. Title (include primary keyword, under 60 characters, compelling — write 5 options)
2. Meta description (155 characters, include keyword + reason to click — write 3 options)
3. Introduction (hook → problem → promise → preview of what's in the post, 100–150 words)
4. [H2] Sections (5–8 main sections based on outline — write the full content for each)
5. Include at least 3 data points, statistics, or expert references (use placeholders if exact data isn't provided)
6. [H3] Subsections where appropriate
7. Include a practical example or case study
8. Conclusion with a clear takeaway
9. CTA (what should the reader do next?)

Voice: [BRAND VOICE — e.g., "Authoritative but approachable, no jargon"]
Avoid: Overuse of transition words ("Furthermore," "Additionally"), generic openings, listicle padding without substance.
```

---

### **#7 — The Brand Positioning Statement**

*The foundation for everything. If your positioning is fuzzy, every campaign underperforms. This prompt sharpens it.*

```
You are a brand strategist who has repositioned dozens of companies in competitive markets.

Develop a complete positioning framework for [COMPANY NAME].

Company details:
- What we do: [ONE SENTENCE]
- Who we serve: [PRIMARY CUSTOMER — role, industry, company size]
- The problem we solve: [THE REAL PAIN — not the surface symptom]
- How we solve it: [YOUR APPROACH — what's unique about how you do it]
- Why now: [WHY IS THIS PROBLEM URGENT OR IMPORTANT RIGHT NOW?]
- Key differentiators: [3–5 THINGS ONLY WE CAN SAY]
- Proof points: [DATA, CUSTOMER RESULTS, AWARDS, RECOGNITION]
- Competitors: [LIST 3–5]
- Why customers choose us over them: [HONEST ANSWER]
- Customers who are NOT a good fit: [WHO SHOULD NOT BUY FROM US?]

Develop:
1. Positioning statement (classic format: "For [target], [brand] is the [category] that [key benefit] because [reason to believe]")
2. Tagline options (5 variations — from functional to emotional)
3. Elevator pitch (30-second spoken version)
4. One-liner for email signatures / social bios (under 15 words)
5. "We're not X, we're Y" statements (3 contrasting pairs that clarify your positioning)
6. Category creation opportunity (should you define a new category? If yes, name it and make the case)
7. Messages to avoid (what language dilutes your positioning?)
```

---

### **#8 — The Campaign Post-Mortem**

*Most teams skip this. The teams that don't skip this get significantly better every quarter.*

```
You are a marketing director who runs rigorous, blameless campaign post-mortems — the goal is learning, not finger-pointing.

Write a comprehensive campaign post-mortem for the following campaign:

Campaign details:
- Campaign name: [CAMPAIGN NAME]
- Campaign type: [e.g., product launch, lead gen, brand awareness, seasonal]
- Channels used: [LIST]
- Duration: [START DATE — END DATE]
- Total budget: [$AMOUNT]
- Team involved: [ROLES/NAMES]
- Primary KPIs: [METRICS AND TARGETS]

Results:
- Target vs. actual for each KPI: [DATA]
- Total spend vs. budget: [$ACTUAL vs. $BUDGET]
- Revenue or pipeline generated: [$AMOUNT]
- ROI: [%]
- Other notable outcomes: [ANYTHING ELSE]

What happened (provide a brief timeline or narrative): [WHAT WENT DOWN]

Structure the post-mortem as:
1. Campaign Overview (1 paragraph)
2. Results Scorecard (table: KPI | Target | Actual | % to Goal)
3. What Went Well (be specific — which elements drove results?)
4. What Didn't Work (be honest — what failed and why?)
5. Surprises (things you didn't expect, positive or negative)
6. Root Cause Analysis (for the biggest failure, do a 5-Why analysis)
7. Key Learnings (3–5 principles to carry forward)
8. Recommendations for Future Campaigns
9. What We'd Do Differently

Tone: Professional, honest, constructive. Shared with [AUDIENCE].
```

---

### **#9 — The Competitive Positioning Analysis**

*Know exactly where you stand — and where competitors are vulnerable — in 30 minutes.*

```
You are a competitive intelligence analyst and positioning strategist.

Conduct a comprehensive competitive positioning analysis for [COMPANY NAME] in the [INDUSTRY/MARKET] space.

Our position:
- Company: [COMPANY NAME]
- Product/service: [DESCRIPTION]
- Target audience: [DESCRIPTION]
- Current positioning: [HOW WE CURRENTLY DESCRIBE OURSELVES]
- Key strengths: [LIST]
- Acknowledged weaknesses: [LIST]

Competitor landscape:
[For each competitor, provide whatever you know:]
- Competitor 1: [NAME] — [POSITIONING/TAGLINE] — [KEY MESSAGES] — [PRICE POINT] — [PERCEIVED STRENGTHS/WEAKNESSES]
- Competitor 2: [NAME] — [DATA]
- Competitor 3: [NAME] — [DATA]
[Add more as needed]

Analyze:
1. Positioning Map (place each player on a 2x2 matrix — define the axes that matter most for this market)
2. Messaging Patterns (what language is everyone using? what's oversaturated?)
3. White Space (what positioning territory is unclaimed?)
4. Our Differentiation Assessment (how well does our current positioning differentiate us? score 1–10 with reasoning)
5. Recommended Positioning Territory (where should we play to win?)
6. Messages to Own (3 claims only WE can credibly make)
7. Competitive Vulnerabilities (where are our competitors weakest? how can we exploit those gaps?)
8. Risk Assessment (what could a competitor do that would threaten our position in 12 months?)
```

---

### **#10 — The Monthly Marketing Report**

*Turn raw data into a stakeholder-ready narrative in 20 minutes flat.*

```
You are a senior marketing analyst and communications expert. Your job is to transform raw performance data into a clear, insightful monthly report that tells a story, not just lists numbers.

Write a monthly marketing performance report for [COMPANY NAME] covering [MONTH, YEAR].

Include the following sections:
1. Executive Summary (3–4 sentences: what happened, what mattered, what's next)
2. Highlights & Wins (top 3 positive results with context)
3. Channel Performance Overview (brief summary for each active channel)
4. Metrics Snapshot (format as a table or structured list)
5. What Underperformed & Why (honest, solution-oriented)
6. Key Learnings
7. Priorities for Next Month

Here is the raw data to work with:
- Total leads generated: [NUMBER]
- Lead sources: [BREAKDOWN BY CHANNEL]
- Website traffic: [TOTAL SESSIONS, % CHANGE MOM]
- Top traffic sources: [LIST]
- Email metrics: [OPEN RATE, CTR, UNSUBSCRIBES]
- Paid ad spend: [TOTAL SPEND, ROAS, CPA]
- Social media: [FOLLOWER GROWTH, ENGAGEMENT RATE, TOP POST]
- Revenue attributed to marketing: [AMOUNT OR PIPELINE VALUE]
- MQLs generated: [NUMBER]
- Conversion rate (lead to MQL): [%]
- Notable campaigns: [CAMPAIGN NAMES AND RESULTS]
- Anomalies or surprises: [ANYTHING UNEXPECTED]

Company context:
- Industry: [INDUSTRY]
- Business model: [B2B/B2C/D2C]
- Marketing team size: [NUMBER]
- Monthly marketing budget: [$AMOUNT]
- Key business goal this month: [GOAL]

Tone: Professional but direct. For [AUDIENCE — e.g., "VP-level" or "cross-functional leadership"]. Honest about failures without being dramatic.
```

---

### **#11 — The Customer Persona Deep Dive**

*You can't write for someone you don't understand. This prompt builds a persona that actually informs your copy.*

```
You are a consumer psychologist and market researcher specializing in B2B buyer psychology for [INDUSTRY].

Build a detailed buyer persona for [COMPANY NAME]'s primary customer.

Known information about this customer:
- Job title/role: [TITLE]
- Industry: [INDUSTRY]
- Company size: [SIZE]
- Geography: [LOCATION]
- Demographics: [AGE, GENDER IF RELEVANT, EDUCATION]
- What they buy from us: [PRODUCT/SERVICE]
- Why they buy: [WHAT WE KNOW]

Build a full persona that includes:
1. Day-in-the-life narrative (a typical Tuesday — what challenges do they face before our product enters the picture?)
2. Goals (professional and personal goals for this year)
3. Frustrations (what keeps them up at night? what's their biggest professional failure they're trying to avoid?)
4. Trigger events (what specific moment or event would make them go searching for our solution?)
5. Buying process (how do they research, who do they consult, how long does it take, who else is involved?)
6. Information sources (what do they read, watch, attend, trust?)
7. Decision criteria (what are the top 5 things they evaluate when choosing a solution like ours?)
8. Objections (top 3 reasons they might not buy — and the real reason behind each objection)
9. Language patterns (exact phrases they use to describe their problem and desired outcome — this is gold for copy)
10. What "good" looks like (how do they define success 6 months after buying our product?)

Name the persona, give them a photo description, and make them feel like a real person.
```

---

### **#12 — The Webinar/Event Promotion Sequence**

*Events live or die by their promotion. This prompt writes the entire sequence so no one misses the memo.*

```
You are an event marketing specialist who fills virtual and in-person events for B2B companies.

Write a complete promotional sequence for [COMPANY NAME]'s [WEBINAR/EVENT NAME].

Event details:
- Event name: [NAME]
- Date and time: [DATE, TIME, TIMEZONE]
- Format: [WEBINAR / LIVE EVENT / WORKSHOP / CONFERENCE]
- Topic: [WHAT IT'S ABOUT]
- Key speaker(s): [NAME, TITLE, CREDIBILITY]
- What attendees will learn: [3 KEY TAKEAWAYS]
- Who should attend: [TARGET AUDIENCE]
- Registration link: [URL]
- Expected duration: [LENGTH]

Write:

1. SAVE THE DATE EMAIL (4 weeks out)
   - Subject: [3 options]
   - Body: 100 words, announce the event, drive early registrations

2. REGISTRATION EMAIL (2 weeks out)
   - Subject: [3 options]
   - Body: 150–200 words, full details, clear CTA

3. REMINDER EMAIL (3 days out)
   - Subject: [3 options]
   - Body: 100–150 words, urgency, social proof (registrant count if available)

4. DAY-OF EMAIL (morning of event)
   - Subject: [3 options]
   - Body: 75–100 words, link, time, what to expect

5. POST-EVENT EMAIL (next day)
   - Subject: [3 options]
   - Body: 150 words, replay link, key takeaway, next CTA

6. SOCIAL PROMOTION (for each email above, write 1 LinkedIn post and 1 X/Twitter post)

Tone: [TONE — professional, conversational, or energetic]
```

---

### **#13 — The B2B Lead Nurture Sequence**

*The difference between a lead and a customer is often just 5 well-timed emails. This prompt writes them all.*

```
You are a B2B demand generation specialist who writes nurture sequences that move prospects through long sales cycles without being annoying.

Write a lead nurture sequence for [COMPANY NAME] for prospects who [TRIGGER — e.g., "downloaded our ROI calculator" / "attended our webinar" / "visited our pricing page 3 times"].

Prospect profile:
- Role: [JOB TITLE]
- Company type: [INDUSTRY, SIZE]
- Where they are in the buying journey: [AWARENESS / CONSIDERATION / DECISION]
- Main challenge: [PROBLEM]
- Likely objections: [TOP 2–3]
- What they want: [GOAL/DESIRED OUTCOME]

Product/service:
- What we offer: [DESCRIPTION]
- Differentiator: [WHY US]
- Ideal customer result: [BEST OUTCOME A CUSTOMER HAS ACHIEVED]
- Price/commitment: [CONTEXT]

Write a 6-email sequence:
- Email 1 (Day 0): Immediate follow-up — deliver value, acknowledge the trigger, no hard sell
- Email 2 (Day 3): Educate — address a specific pain point, position our solution indirectly
- Email 3 (Day 7): Social proof — a specific customer story (write a realistic example if I don't have one)
- Email 4 (Day 12): Overcome objection — address the #1 reason they haven't acted yet
- Email 5 (Day 18): Case study or data point — make the business case
- Email 6 (Day 25): Direct ask — soft CTA (discovery call, demo, free trial)

For each email:
- 3 subject line options
- Preview text (45 chars)
- Full email body (150–250 words)
- CTA (button text)
- P.S. line (optional — P.S. lines get read)
```

---

### **#14 — The Board Marketing Presentation**

*Walk into that board meeting with confidence. This prompt writes the narrative behind your numbers.*

```
You are a CMO preparing a board-level marketing update. Boards care about one thing: business outcomes. They don't want to hear about impressions. They want to know how marketing is contributing to growth, efficiency, and competitive position.

Write a board marketing update for [COMPANY NAME] for [QUARTER/PERIOD].

Input data:
- Revenue target vs. actual: [$TARGET vs. $ACTUAL]
- Marketing-sourced pipeline: [$AMOUNT]
- CAC this period: [$AMOUNT] vs. [$BENCHMARK/TARGET]
- LTV:CAC ratio: [RATIO]
- Total marketing spend: [$AMOUNT]
- Marketing ROI: [%]
- Key campaign results: [LIST TOP 2–3]
- Brand metrics (if available): [AWARENESS %, NPS, SHARE OF VOICE]
- Headcount and budget vs. plan: [DETAILS]
- Big strategic bets / experiments: [LIST]
- Competitive landscape update: [KEY CHANGES]

Structure the update as:
1. Headline (one sentence: how did marketing perform?)
2. Business Impact (3 numbers that matter most — pipeline, CAC, ROI)
3. What We Did (brief — 3 most important activities)
4. Market & Competitive Context
5. What's Working / What We're Doubling Down On
6. What We're Watching / Risks
7. Ask or Outlook (what do you need from the board, or what's coming next quarter?)

Format: Headers and bullets. Under 500 words. Accompanies slides.
Tone: Executive. Direct. Strategic. No fluffy marketing language.
```

---

### **#15 — The Quarterly OKR Planning Prompt**

*Don't let OKR season be a copy-paste from last quarter. This prompt builds ambitious, connected objectives.*

```
You are a marketing operations leader and OKR coach who has helped marketing teams set ambitious, measurable, and strategically connected objectives.

Help [COMPANY NAME]'s marketing team build Q[QUARTER] OKRs.

Business context:
- Company revenue target this quarter: [$AMOUNT]
- Company top priorities this quarter: [LIST 2–3]
- Marketing's primary role in achieving these: [DESCRIPTION]
- Last quarter's biggest wins: [LIST]
- Last quarter's biggest gaps: [LIST]
- Marketing team size: [NUMBER]
- Budget: [$AMOUNT]

Marketing channels/programs in play: [LIST]

For each of 3 objectives, develop:
- A compelling, ambitious Objective statement (verb + outcome + timeframe — NOT a task or metric)
- 3–4 Key Results (measurable, time-bound, outcome-based — NOT activities)
- One "health metric" guardrail per objective (a metric that shouldn't degrade while pursuing the objective)
- Confidence level on each KR (1–10: 10 = already happening, 1 = moonshot)

Good OKR principles to follow:
- Objectives should be inspiring, not mechanical
- Key Results should be measurable outcomes, not tasks ("launch X" is not a KR)
- Aim for confidence of 6–7 out of 10 (too confident = not ambitious enough)
- Fewer, better OKRs beat a long list of mediocre ones

Also provide:
- One "canary metric" — the early indicator that will tell you if you're on track by mid-quarter
- Any dependencies on other teams (product, sales, engineering) to flag upfront
```

---

## The 10 Golden Rules of Prompting for Marketers

---

### Rule 1: Assign a Role Before Asking Anything

Never start a marketing prompt without telling the AI who it is.

**Weak:** *"Write a LinkedIn post about our new product launch."*

**Strong:** *"You are a B2B content strategist with 15 years of experience writing for SaaS executives. Write a LinkedIn post..."*

The role shapes everything: tone, depth, vocabulary, assumptions. A copywriter writes differently than a strategist. A CMO writes differently than a content manager. Be specific.

---

### Rule 2: Context Is Not Optional — It's the Whole Game

The quality of your output is directly proportional to the quality of your context. AI can't read your mind. It doesn't know your brand, your audience, your competitors, or your business goals unless you tell it.

**The minimum context every marketing prompt needs:**
- Who is the audience? (specific, not "everyone")
- What do you want them to feel or do?
- What's the tone/voice?
- What's the one thing you want them to remember?

Build a **Brand Brief** doc with your standard context and paste it at the start of every session. 5 minutes of context = 10x better output.

---

### Rule 3: Specify Format Explicitly

Don't say "write a post." Say:
- "Write a 150-word LinkedIn post"
- "Use short paragraphs — maximum 2 sentences each"
- "End with a question"
- "Do not use bullet points"
- "Start with a hook — NOT with 'I'"

Format instructions don't constrain creativity. They direct it. Professional content has structure. Tell AI what that structure is.

---

### Rule 4: Always Ask for Variants

Never accept one option. Always ask for at least 3.

Add to any prompt: *"Write 3 variations. Label them A, B, and C. Mark which one you think is strongest and why."*

Variants reveal the range of possibilities. You'll often combine the best elements of all three into something better than any single option.

---

### Rule 5: Use "Which Means" to Force Benefits Over Features

AI defaults to describing features. You need benefits.

Train it by adding this instruction: *"For every feature you mention, use the phrase 'which means' to connect it to a customer benefit."*

*"Real-time analytics → which means you know what's working before the campaign ends, not after."*

This single habit transforms generic product descriptions into persuasive copy.

---

### Rule 6: Reference the Enemy — Your Audience's Pain

The most persuasive copy doesn't start with the product. It starts with the problem. Deeply. Specifically. In the reader's own words.

Add to your prompts: *"Before introducing the solution, spend at least one paragraph vividly describing the problem — use the language my target audience uses to describe their pain, not the language I use to describe what I sell."*

Readers think: *"That's exactly how I feel. These people understand me."* Then they buy.

---

### Rule 7: Tell It What NOT to Do

Constraints are as powerful as instructions. Great prompts include explicit "don'ts."

Examples:
- "Do NOT use the phrase 'game-changing' or 'revolutionary'"
- "Do NOT start with 'In today's fast-paced world'"
- "Do NOT use passive voice"
- "Do NOT add hashtags in the body of the post"
- "Do NOT mention our competitors by name"

This eliminates the lazy, generic patterns that make AI-generated content obvious and forgettable.

---

### Rule 8: Iterate in the Same Session — Don't Start Over

One of the most common mistakes: starting a new chat for every request. When you stay in the same session, the AI retains context, learns your preferences, and builds on prior output.

Iteration workflow:
1. Generate the first draft
2. Ask for specific changes: *"The second paragraph is too formal. Rewrite it to sound more conversational while keeping the data point."*
3. Ask for a refined version: *"Now tighten the whole thing by 30% without losing the core message."*
4. Ask it to evaluate: *"What's the weakest sentence in this and why? Rewrite it."*

The 4th draft is almost always significantly better than the 1st.

---

### Rule 9: Ask for the Brief Before the Output

For complex projects, ask AI to write the brief first — then execute it.

*"Before you write the campaign copy, write a creative brief for this campaign. I'll review it and give you feedback before you start writing."*

This catches strategic misalignments early, when they're cheap to fix, instead of after you've spent time on copy that's built on wrong assumptions.

It also forces you to articulate what you actually want — which makes the final output far better.

---

### Rule 10: Always Inject Real Proof — Then Polish

AI cannot know:
- Your specific customer success stories
- Your actual product data and metrics
- Your real customer quotes and reviews
- Your company's authentic origin story

These are the elements that make copy convert. AI gives you the structure and the polish. You provide the truth.

Workflow: Generate with AI → inject real specifics → ask AI to polish the combined version.

*"Here's the AI draft. Here are the real customer quotes and data I want included: [PASTE]. Rewrite the draft to naturally incorporate these proof points."*

The result: AI efficiency + human authenticity = copy that actually works.

---

*That's the full toolkit. Good luck, and go build something.*

---

*[← Back to 06 — Workflow SOPs](06-workflow-sops.md)*
