# 04 — Brand Strategy Prompts

> 20 prompts for brand voice guides, positioning statements, messaging frameworks, competitive differentiation, taglines, and elevator pitches.

---

## Brand Voice & Tone

---

### **Prompt 01 — The Brand Voice Guide**

*When to use: Defining your brand's voice and tone for the first time, or refreshing an existing guide.*

```
You are a senior brand strategist and verbal identity expert.

Build a comprehensive brand voice guide for [COMPANY NAME].

Brand context:
- Company: [COMPANY NAME]
- What we do: [PRODUCT/SERVICE]
- Who we serve: [TARGET AUDIENCE]
- Our mission: [MISSION]
- Our values: [3–5 VALUES]
- Current tone (if any): [HOW YOU CURRENTLY SOUND — or "no consistent voice yet"]
- What we admire in other brands' voices: [BRANDS + WHAT YOU LIKE — e.g., "Basecamp's directness, Patagonia's conviction, Mailchimp's wit"]
- What we never want to sound like: [ANTI-EXAMPLES]

Deliver a complete brand voice guide including:

1. Voice overview (3–4 sentences describing the brand's personality)
2. 4 voice dimensions (e.g., Bold but not Arrogant, Witty but not Silly):
   - Dimension name
   - What it means in practice
   - Example: What we say vs. What we don't say (3 pairs each)
3. Tone variations by context:
   - Social media
   - Long-form content
   - Customer support
   - Sales/conversion copy
   - Executive/PR communications
4. Power words (15–20 words that feel on-brand)
5. Words to avoid (10–15 words that feel off-brand)
6. Writing rules (5–7 specific do's and don'ts)
7. Quick reference card (1-page summary version)
```

---

### **Prompt 02 — The Tone of Voice Calibration**

*When to use: Calibrating your tone for a specific audience, platform, or campaign — without losing brand voice.*

```
You are a verbal identity specialist who helps brands adapt their voice without losing their identity.

Calibrate [COMPANY NAME]'s brand voice for the following specific context:

Core brand voice: [DESCRIBE YOUR BRAND VOICE — or paste your existing voice guide]
New context: [E.g., "LinkedIn posts targeting CFOs" / "Instagram for Gen Z consumers" / "Email to churned enterprise customers"]
Audience shift: [HOW THIS AUDIENCE DIFFERS from your primary audience]

Deliver:
1. Tone profile for this context (3–4 sentences — how does voice shift while staying on-brand?)
2. What stays the same (2–3 non-negotiable voice elements)
3. What changes (2–3 adjustments for this context)
4. Before/After examples: Rewrite these 3 sample messages in the calibrated tone:
   [MESSAGE 1 — paste your current copy]
   [MESSAGE 2 — paste your current copy]
   [MESSAGE 3 — paste your current copy]
5. 10 power words for this specific context
6. A one-paragraph brief a writer could use to nail this voice immediately
```

---

### **Prompt 03 — The Brand Voice Consistency Check**

*When to use: Auditing existing content to ensure brand voice consistency across assets.*

```
You are a brand voice auditor who evaluates content consistency for professional brands.

Audit the following content pieces from [COMPANY NAME] for brand voice consistency.

Target brand voice: [DESCRIBE YOUR BRAND VOICE — or paste key sections of your voice guide]
Audience: [AUDIENCE]

Content to audit:
[Piece 1 — paste the content and label it "Website Homepage"]
[Piece 2 — paste the content and label it "LinkedIn Post"]
[Piece 3 — paste the content and label it "Email Campaign"]
[Piece 4 — paste the content and label it "Ad Copy"]
[Piece 5 — paste the content and label it "Sales Page"]

For each piece:
1. Voice consistency score (1–10)
2. On-brand elements (what's working)
3. Off-brand elements (what's not)
4. Specific words or phrases that don't fit
5. Rewritten version of the first 3 sentences in the correct voice

Overall audit summary:
- Consistency score across all pieces (1–10)
- Top 3 voice issues to fix
- Recommendations for alignment
```

---

## Positioning

---

### **Prompt 04 — The Brand Positioning Statement**

*When to use: Defining your brand's unique position in the market — the strategic north star for all marketing.*

```
You are a brand positioning strategist with expertise in [INDUSTRY].

Develop a brand positioning statement for [COMPANY NAME].

Context:
- Company: [COMPANY NAME]
- Category (what market are you in?): [CATEGORY — e.g., "project management software", "premium skincare", "B2B cybersecurity"]
- Target customer: [SPECIFIC TARGET — be narrow, not broad]
- Customer's primary job to be done: [JTBD — what are they trying to accomplish?]
- Current alternatives (how do they solve this today?): [ALTERNATIVES]
- Your key differentiator: [WHAT MAKES YOU GENUINELY DIFFERENT]
- Proof / reason to believe: [EVIDENCE — data, technology, methodology, team, track record]
- Brand aspiration (what do you want to be known for?): [ASPIRATION]

Deliver:
1. Classic positioning statement: "For [TARGET CUSTOMER] who [NEED/PAIN], [COMPANY] is the [CATEGORY] that [KEY BENEFIT] because [REASON TO BELIEVE]."
   — Give 3 versions

2. Strategic positioning narrative (2–3 paragraphs for internal use — the full strategic story)

3. Positioning map: Place [COMPANY NAME] vs. [3 COMPETITORS] on two axes: [AXIS 1] vs. [AXIS 2]. Describe the map and why this position is defensible.

4. The "white space" — what unmet need does this positioning own?

5. Test: 3 questions to pressure-test whether this positioning is real and defensible
```

---

### **Prompt 05 — The Category Design Brief**

*When to use: You want to create a new category rather than compete in an existing one.*

```
You are a category design strategist inspired by the discipline of creating and owning new market categories.

Build a category design brief for [COMPANY NAME].

Context:
- Current category (what you're typically compared to): [CURRENT CATEGORY]
- Why the current category is limiting: [THE PROBLEM WITH BEING IN THIS CATEGORY]
- The new problem you want to define for the market: [THE PROBLEM ONLY YOU CAN SEE]
- The new category you want to create: [PROPOSED CATEGORY NAME — or "help me name it"]
- Why you are the only logical "category king": [YOUR UNIQUE QUALIFICATION]
- Proof you can deliver: [PROOF]
- Target audience for this category: [AUDIENCE]

Deliver:
1. The "Point of View" (POV) document: 3–4 paragraphs that define the problem, why old solutions fail, and what the new category represents. This should be publishable.
2. Category name options: 5 options with rationale
3. Category narrative (2–3 sentences that define what the category IS and what it stands against)
4. "If you don't have X, you have Y" — the old/new contrast statement (3 versions)
5. 3 pieces of "lightning strike" content to introduce this category to the market
```

---

### **Prompt 06 — The Competitive Differentiation Framework**

*When to use: Building a clear case for why buyers should choose you over the competition.*

```
You are a competitive strategy and positioning expert for [INDUSTRY] companies.

Build a competitive differentiation framework for [COMPANY NAME] vs. [COMPETITOR(S)].

Context:
- Your company: [COMPANY NAME]
- Product/Service: [PRODUCT/SERVICE]
- Your key strengths: [STRENGTHS — 5–7 specific, factual differentiators]
- Competitors to compare: [COMPETITORS — list 2–4]
- Target buyer making the comparison: [BUYER — job title, company size, industry]
- What matters most to this buyer: [TOP 3 BUYER CRITERIA]

Deliver:
1. Competitive positioning grid: Compare [COMPANY] vs. [COMPETITORS] across the top [5–7] buyer criteria. Use: ✅ Strong | ⚡ Partial | ❌ Weak

2. "We win when..." statement: The specific scenarios where you consistently beat the competition

3. "We don't win when..." statement: Honest assessment of where competitors have the edge (and how to respond)

4. Battle card (1-page format):
   - Why customers choose us
   - Common competitor objections + our responses (5 objections)
   - Trap questions to ask in sales conversations that highlight competitor weaknesses
   - Proof points and statistics

5. The "unfair advantage" statement: In 2 sentences, what can you do or say that no competitor can?
```

---

## Messaging Frameworks

---

### **Prompt 07 — The Brand Messaging Framework**

*When to use: Creating the master messaging document that aligns sales, marketing, and leadership.*

```
You are a messaging strategist who builds brand messaging frameworks for [INDUSTRY] companies.

Build a comprehensive brand messaging framework for [COMPANY NAME].

Context:
- Company: [COMPANY NAME]
- Product/Service: [PRODUCT/SERVICE]
- Core mission: [MISSION]
- Target audiences: [LIST 2–3 AUDIENCE SEGMENTS]
- Primary differentiators: [3–5 DIFFERENTIATORS]
- Brand proof points: [DATA, AWARDS, CASE STUDIES, MILESTONES]
- Competitive context: [WHO YOU COMPETE WITH]
- Tone: [TONE]

Framework structure:

1. Brand Promise (1 sentence — the ultimate commitment to the customer)
2. Brand Tagline options (5 options — see Prompt 14 for detail)
3. Core Value Proposition (2–3 sentences for external use)
4. Proof Points (3–5 data-backed statements that make the value prop credible)
5. Audience-Specific Messaging (for each audience):
   - Primary pain point
   - Primary message (1 sentence)
   - Key benefits (3 bullet points)
   - Proof point most relevant to them
   - CTA most relevant to them
6. Boilerplate (3 versions: 25 words / 75 words / 150 words — for press releases, bios, partnerships)
7. Key messages for common scenarios (5 scenarios: sales call opener, investor pitch, recruiting, PR quote, social intro)
```

---

### **Prompt 08 — The Story Brand (StoryBrand-Style) Framework**

*When to use: Building a customer-centric narrative where the customer is the hero.*

```
You are a brand narrative strategist trained in the StoryBrand framework and customer-centric storytelling.

Apply the 7-element brand story framework to [COMPANY NAME].

Brand context:
- Company: [COMPANY NAME]
- Product/Service: [PRODUCT/SERVICE]
- Target customer: [CUSTOMER]
- What the customer wants: [DESIRE — the goal your customer has before they found you]
- The villain (the problem/obstacle): [VILLAIN — the external problem, internal frustration, or philosophical wrong]
- How you help: [YOUR ROLE AS THE GUIDE]
- The plan you offer: [YOUR PROCESS — 3 steps to working with you]
- What happens if they don't act (failure): [STAKES]
- The transformation (success): [WHAT THEIR LIFE LOOKS LIKE AFTER]

Write the complete brand story across 7 elements:
1. A Character — who the hero is and what they want
2. Has a Problem — external, internal, and philosophical problems
3. And Meets a Guide — your brand's empathy + authority
4. Who Gives Them a Plan — your 3-step process
5. And Calls Them to Action — primary CTA + transitional CTA
6. That Helps Them Avoid Failure — the stakes if they don't act
7. And Ends in Success — the transformation they achieve

Also: Write the one-liner for [COMPANY NAME] using this formula: "We help [CUSTOMER] do [THING] so they can [OUTCOME]." Give 5 options.
```

---

### **Prompt 09 — The Audience Persona Deep Dive**

*When to use: Building a detailed buyer persona to inform all messaging and content decisions.*

```
You are a market research strategist and customer empathy expert for [INDUSTRY].

Build a detailed buyer persona for [COMPANY NAME]'s primary customer.

Known information:
- Industry/company type: [INDUSTRY/COMPANY SIZE]
- Job title/role: [JOB TITLE]
- Demographics (if B2C): [AGE, LOCATION, LIFESTYLE — if relevant]
- Known pain points: [WHAT YOU KNOW ABOUT THEIR PAIN]
- Why they buy from you: [KNOWN REASONS]
- How they typically find you: [CHANNELS]
- Common objections: [OBJECTIONS YOU HEAR]

Using this information and your knowledge of [INDUSTRY], build a complete persona:

1. Persona name and role title
2. Day in the life (100-word narrative)
3. Goals (professional + personal, 3 each)
4. Frustrations/Pain points (5 specific, granular pain points — not generic)
5. Information sources (where they read, who they follow, what they search)
6. How they evaluate solutions (their buying criteria, ranked)
7. What they fear most (what keeps them from making decisions)
8. What makes them look good at work (their "win" criteria)
9. Messaging that resonates (5 statements that would make them nod)
10. Messaging that turns them off (3 things that would make them disengage)
11. Preferred content formats and channels
12. A direct quote (the 1 thing they would say about their biggest problem)
```

---

### **Prompt 10 — The Value Proposition Builder**

*When to use: Crafting or refining your core value proposition for a product, service, or feature.*

```
You are a value proposition strategist using the Value Proposition Canvas methodology.

Build a value proposition for [COMPANY NAME]'s [PRODUCT/SERVICE].

Customer profile:
- Target customer: [CUSTOMER — job title, industry, or demographic]
- Customer jobs (what they're trying to accomplish): [FUNCTIONAL JOBS + SOCIAL JOBS + EMOTIONAL JOBS]
- Customer pains (what frustrates them, risks they fear, obstacles they face): [PAINS — list 5–8]
- Customer gains (outcomes and benefits they want, desires they have): [GAINS — list 5–8]

Your product/service:
- Products and services: [LIST YOUR OFFERINGS]
- Pain relievers (how you eliminate pains): [PAIN RELIEVERS — match to their pains]
- Gain creators (how you produce gains they desire): [GAIN CREATORS — match to their gains]

Deliver:
1. Value Proposition Canvas (visual description — map pain relievers and gain creators to customer jobs, pains, gains)
2. Value proposition statement: 5 versions ranging from 1 sentence to 1 paragraph
3. Ranked: Which pains are you best at relieving? Which gains are you best at creating?
4. Gap analysis: Where is your product weakest vs. customer needs?
5. The "magic moment": In 1 sentence, when does the customer first realize your product is worth it?
```

---

## Taglines & Elevator Pitches

---

### **Prompt 11 — The Brand Tagline Generator**

*When to use: Creating tagline options for a brand, campaign, product, or rebrand.*

```
You are an award-winning advertising creative director and copywriter specializing in brand taglines.

Generate brand tagline options for [COMPANY NAME].

Brand context:
- Company: [COMPANY NAME]
- What we do: [PRODUCT/SERVICE — in plain language]
- Who we serve: [TARGET AUDIENCE]
- Brand personality: [3–5 ADJECTIVES]
- The emotion we want people to feel: [EMOTION]
- Our core positioning: [POSITIONING — 1 sentence]
- What we never want to sound like: [ANTI-EXAMPLES]
- Current tagline (if any): [CURRENT TAGLINE — or "none"]

Generate 30 tagline options organized by approach:

Benefit-driven (5): Lead with the outcome
Purpose-driven (5): Lead with why you exist
Emotion-driven (5): Lead with how you make people feel
Action-driven (5): A verb that defines the brand
Contrast-driven (5): What you're not / what changes with you
Unexpected/Poetic (5): Creative, memorable, conversation-starting

For each, note:
- The core idea it communicates
- Who it resonates with most
- Risk level (safe / moderate / bold)

⭐ Top 5 recommendations with rationale. Flag any that are legally riskable (generic, similar to competitors).
```

---

### **Prompt 12 — The Elevator Pitch (Multiple Formats)**

*When to use: Preparing a clear, compelling pitch for any context — investor, sales, networking, recruiting.*

```
You are an executive communications coach who specializes in high-stakes pitches and presentations.

Write elevator pitch scripts for [COMPANY NAME] across multiple formats and contexts.

Company context:
- Company: [COMPANY NAME]
- What we do: [DESCRIPTION — plain language]
- Who we help: [TARGET CUSTOMER]
- The problem we solve: [PROBLEM]
- How we solve it (uniquely): [SOLUTION + DIFFERENTIATOR]
- Proof (traction, results, social proof): [PROOF POINTS]
- Ask or CTA: [WHAT YOU WANT FROM THIS CONVERSATION]

Write 5 versions:
1. The 10-second hook (one sentence — for when someone asks "what do you do?")
2. The 30-second elevator pitch (for networking events — clear, confident, conversational)
3. The 60-second investor pitch (for fundraising conversations)
4. The 2-minute sales pitch (for a first call or demo intro)
5. The recruiting pitch (for attracting top talent — why work here?)

For each version:
- Full script
- Tone direction
- What to watch out for (the mistake most people make with this version)
- Follow-up question to ask after your pitch
```

---

### **Prompt 13 — The Investor / Pitch Deck Narrative**

*When to use: Crafting the narrative arc and key messages for a fundraising or board presentation.*

```
You are a startup narrative strategist who has helped companies raise hundreds of millions through compelling pitch decks.

Build the narrative framework for [COMPANY NAME]'s investor pitch deck.

Company context:
- Company: [COMPANY NAME]
- Stage: [SEED / SERIES A / SERIES B / etc.]
- Amount raising: [$AMOUNT]
- What we do: [DESCRIPTION]
- Target customer: [CUSTOMER]
- Problem: [PROBLEM — size, urgency, why now]
- Solution: [YOUR SOLUTION]
- Market size: [TAM/SAM/SOM if known]
- Business model: [HOW YOU MAKE MONEY]
- Traction: [KEY METRICS — revenue, users, growth rate, logos]
- Team: [KEY TEAM MEMBERS + WHY THEY'RE RIGHT]
- Competition: [COMPETITIVE LANDSCAPE]
- Use of funds: [HOW THE MONEY IS USED]

Deliver:
1. The deck narrative arc (the story investors should feel, slide by slide)
2. Slide-by-slide messaging guide (for each slide: title + 3 key points + the emotional beat)
3. The opening hook (how to start the meeting before the first slide)
4. The ask slide (how to frame the raise)
5. 10 anticipated investor questions + strong answers
6. The "why us, why now" paragraph (the most important 150 words in any pitch)
```

---

### **Prompt 14 — The Brand Manifesto**

*When to use: Writing a rallying cry document that defines what your brand stands for.*

```
You are a brand manifesto writer. Your work sits between strategy and poetry — grounded in truth but written to inspire.

Write a brand manifesto for [COMPANY NAME].

Brand context:
- Company: [COMPANY NAME]
- Mission: [MISSION]
- Values: [VALUES]
- Who you're for: [AUDIENCE — the people you fight for]
- What you believe about the world: [WORLDVIEW — what's wrong with the status quo?]
- What you're building toward: [VISION — the world you're trying to create]
- The enemy / what you stand against: [ANTI-EXAMPLES — an attitude, approach, or norm you reject]
- Tone: [TONE — e.g., "Bold, poetic, fired up — like a great TED Talk opening"]

Write a 300–500 word manifesto that:
- Starts with a bold declaration about the world or your customer
- Calls out the problem without naming competitors
- Articulates your belief system (we believe... statements)
- Speaks directly to your customer ("you" language)
- Names what you stand for and against
- Ends with an inspiring call to action or rallying line

Also deliver:
- A shortened 100-word version
- A 3-sentence "mission moment" for use on the About page
```

---

### **Prompt 15 — The "About Us" Page**

*When to use: Writing or rewriting your website's About page to connect emotionally and convert.*

```
You are a brand copywriter specializing in About pages that feel human, compelling, and conversion-ready.

Write an About page for [COMPANY NAME]'s website.

Context:
- Company: [COMPANY NAME]
- Founded: [YEAR + FOUNDING STORY — briefly]
- What we do: [PRODUCT/SERVICE]
- Why we exist (the real "why"): [WHY — the problem that frustrated you into starting]
- Who we serve: [TARGET AUDIENCE]
- What makes us different: [DIFFERENTIATORS]
- Team highlights: [KEY PEOPLE — names, roles, and 1 interesting fact each]
- Milestones or social proof: [STATS, AWARDS, NOTABLE CUSTOMERS]
- Brand personality: [TONE + ADJECTIVES]
- Page goal (what we want readers to do): [CTA — e.g., "Contact us", "Meet the team", "See how it works"]

Page structure:
1. Opening hook: 1–2 sentences that make readers feel something (not "We were founded in...")
2. Our story: The founding narrative (150 words — why this company exists)
3. Our mission: 1–2 sentences (not a corporate mission statement — a human one)
4. What we believe: 3–4 "We believe..." statements
5. Who we serve: A warm paragraph about the customer
6. Meet the team: Brief, humanizing intros for key people
7. Social proof: Work in stats, customers, or milestones naturally
8. CTA: Warm, direct invite to take the next step

Avoid: "We're passionate about...", "We're disrupting...", "We're a team of experts..."
```

---

### **Prompt 16 — The Rebrand Messaging Strategy**

*When to use: Planning a rebrand or brand refresh and need to manage the narrative.*

```
You are a rebrand communications strategist who specializes in managing brand transitions.

Create a rebrand messaging strategy for [COMPANY NAME].

Rebrand context:
- Old brand name (if changing): [OLD NAME]
- New brand name: [NEW NAME]
- Why rebranding: [REASON — e.g., expansion, acquisition, pivoting market, reputation reset]
- What's staying the same: [WHAT'S NOT CHANGING — values, mission, team, product]
- What's changing: [WHAT IS CHANGING — name, logo, positioning, focus]
- Audiences to communicate to: [AUDIENCES — customers, employees, partners, investors, press]
- Timeline: [REBRAND DATE]
- Tone for the announcement: [TONE]

Deliver:
1. The core narrative (why we're rebranding — 3 versions: 1 sentence / 1 paragraph / full explanation)
2. Audience-specific messaging guide:
   - Customers: What to say + how to reassure
   - Employees: Internal messaging first (they should hear it before the public)
   - Partners/Vendors: Brief, clear, practical
   - Press/Media: Newsworthy angle and key quote
3. FAQ document (10 questions your audiences will ask + strong answers)
4. Announcement email templates (customers + employees)
5. Social media announcement posts (3 platforms)
6. Timeline: Pre-announcement → Day of → Week after
```

---

### **Prompt 17 — The Product Naming Framework**

*When to use: Naming a new product, service, feature, or sub-brand.*

```
You are a naming strategist and verbal branding expert.

Generate name options and a naming framework for [COMPANY NAME]'s new [PRODUCT / FEATURE / SERVICE / INITIATIVE].

Context:
- What it is: [DESCRIPTION]
- What it does: [FUNCTION]
- Who it's for: [TARGET AUDIENCE]
- The feeling it should evoke: [EMOTION / PERSONALITY]
- What it should signal: [POSITIONING — e.g., premium, accessible, innovative, serious]
- Names to avoid / naming conventions to avoid: [AVOID]
- Existing product family (if naming to fit a family): [PRODUCT FAMILY]
- Will it be trademarked? [YES / NO / POSSIBLY]

Deliver:

1. Naming criteria (5 principles this name must meet)

2. Name options across 6 categories (5 names per category = 30 total):
   - Descriptive: Names that describe what it does
   - Suggestive: Names that hint at the benefit without stating it
   - Coined/Invented: New words with strong sound/feel
   - Metaphor/Association: Names borrowed from other domains
   - Founder/Person: Named after a person or persona
   - Acronym/Abbreviation: If applicable

3. For top 10 names, provide:
   - Pronunciation guide
   - Domain availability check suggestion
   - Trademark risk assessment (easy/moderate/high)
   - Brand story potential (how would you explain this name?)

4. ⭐ Top 3 recommendations with full rationale
```

---

### **Prompt 18 — The Competitive Positioning Response**

*When to use: A competitor has made a move (new product, price cut, campaign) and you need to respond strategically.*

```
You are a competitive marketing strategist and crisis communications advisor.

[COMPETITOR NAME] just [DESCRIBE WHAT THEY DID — e.g., "launched a competing product at half our price" / "ran a campaign directly targeting our customers" / "published a report claiming they outperform us"].

I need a strategic response plan for [COMPANY NAME].

Context:
- Our company: [COMPANY NAME]
- The competitive move: [DESCRIBE IN DETAIL]
- Our current positioning: [HOW WE'RE POSITIONED]
- Our strengths vs. this competitor: [OUR ADVANTAGES]
- Our weaknesses vs. this competitor: [HONEST ASSESSMENT]
- Audiences who need to hear from us: [AUDIENCES]
- Timeline: [HOW URGENT IS THIS]
- Tone: [TONE — e.g., "Confident, not defensive. We acknowledge but don't react"]

Deliver:
1. Strategic assessment: Is this a real threat or noise? (Be honest)
2. Response strategy: Ignore / Acknowledge / Counter-attack / Differentiate (recommend one with rationale)
3. Internal communication (what to tell your team — settle nerves, align response)
4. Customer communication (what to proactively say to existing customers)
5. Sales enablement (how to equip sales reps to handle "what about X?" questions)
6. Public/marketing response (if warranted — blog post, social, PR)
7. The trap to avoid (the reactive mistake most companies make in this situation)
```

---

### **Prompt 19 — The Brand Audit**

*When to use: Getting an objective assessment of where your brand is strong, weak, and inconsistent.*

```
You are a senior brand strategist conducting a brand audit for [COMPANY NAME].

Please audit [COMPANY NAME]'s brand based on the following materials (paste or describe each):

1. Website: [PASTE KEY COPY — homepage, about, product pages]
2. Social profiles: [PASTE BIOS + 3 RECENT POSTS per platform]
3. Current tagline/positioning: [CURRENT TAGLINE AND HOW YOU DESCRIBE YOURSELF]
4. Competitors: [LIST 3 KEY COMPETITORS]
5. Target audience: [TARGET AUDIENCE DESCRIPTION]

Conduct a full brand audit covering:

1. Clarity: Is it immediately clear who you are, what you do, and who you serve?
2. Differentiation: What makes you stand out from [COMPETITORS]? Is it compelling?
3. Consistency: Does the brand feel the same across all touchpoints?
4. Resonance: Does the messaging speak to the real pains and desires of [TARGET AUDIENCE]?
5. Credibility: Do you provide enough proof to be believed?
6. Voice: Is there a consistent, recognizable brand voice?
7. Visual-verbal alignment: Does how you look match how you sound?

For each area: Score (1–10) + specific observations + top recommendation

Close with:
- Top 3 priorities (highest impact, fix first)
- 1 "quick win" you can implement this week
- 1 "big bet" that could transform brand perception
```

---

### **Prompt 20 — The Partnership Co-Marketing Brief**

*When to use: Planning a co-marketing campaign with a partner, sponsor, or collaborator.*

```
You are a partnership marketing strategist with experience building co-marketing campaigns between brands.

Build a co-marketing brief for [COMPANY A] partnering with [COMPANY B].

Context:
- Company A: [COMPANY A — what you do, audience, goals]
- Company B: [COMPANY B — what they do, audience, goals]
- Partnership goal: [GOAL — e.g., reach new audiences, co-create content, drive shared leads]
- Shared audience: [THE AUDIENCE BOTH BRANDS REACH]
- Campaign type: [TYPE — webinar, co-authored content, joint offer, event, etc.]
- Budget split: [HOW COSTS/RESOURCES ARE SHARED]
- Timeline: [CAMPAIGN DATES]

Deliver:
1. Shared value proposition (what's in it for the audience — 2 sentences)
2. Messaging framework:
   - Company A's role and message
   - Company B's role and message
   - Unified campaign message
3. Content plan (what content is created, who creates it, where it lives)
4. Promotion plan (each company's promotion commitments by channel)
5. Lead ownership framework (how leads are split)
6. Success metrics (KPIs for each partner)
7. Legal/brand protection considerations (brief checklist)
8. Campaign name + announcement copy (1 version per company's channels)
```

---

*End of Section 04 — 20 prompts total.*
