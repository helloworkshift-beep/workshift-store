# 03 — Customer Experience Prompts

*20 prompts for review management, guest communication, and building loyalty*

---

### 1. Response to a 5-Star Review
*Use when thanking a guest who left a glowing review.*

```
Write a response to a 5-star Google/Yelp review for my restaurant.

Review text: [PASTE THE REVIEW]
Restaurant name: [NAME]
The reviewer's name (if shown): [NAME OR "A GUEST"]
Something specific they mentioned: [PICK OUT 1–2 DETAILS FROM THEIR REVIEW TO REFERENCE]
Any upcoming thing to invite them back for: [NEW MENU / UPCOMING EVENT / SEASONAL SPECIAL]

The response should:
- Be personal, not copy-paste (mention specifics from their review)
- Thank them warmly but not over-the-top
- Be under 75 words
- Invite them back with a specific reason
- Sound like a person, not a corporate PR team

Note: This response is public and read by future customers. Make it work as marketing too.
```

---

### 2. Response to a 1–2 Star Review
*Use when responding to a negative review professionally.*

```
Write a professional response to a negative review of my restaurant.

Review text: [PASTE THE REVIEW]
Restaurant name: [NAME]
The facts from our side: [WHAT ACTUALLY HAPPENED — FOR YOUR CONTEXT ONLY, DON'T NECESSARILY INCLUDE ALL OF THIS]
Our preferred resolution: [OFFER A RETURN VISIT / ALREADY RESOLVED / DISPUTED BUT PROFESSIONAL]

The response should:
- Acknowledge their experience without admitting liability
- Be under 100 words (shorter is often better)
- Take the conversation offline (include email or phone)
- Be professional, calm, and solution-focused
- Not argue with their version of events publicly
- Make future readers think "wow, this place handles feedback well"

Remember: your response is marketing to the thousands of people who will read it.
```

---

### 3. Response to a 3-Star Review (Mixed Feedback)
*Use for neutral reviews that have both positives and negatives.*

```
Write a response to a mixed/neutral review (2–4 stars) of my restaurant.

Review text: [PASTE THE REVIEW]
Restaurant name: [NAME]
What they liked: [IDENTIFY FROM REVIEW]
What they criticized: [IDENTIFY FROM REVIEW]
Whether the criticism is fair: [YES / PARTIALLY / NO — THIS IS FOR YOUR FRAMING ONLY]

The response should:
- Thank them for the specific positive feedback
- Acknowledge the concern professionally (don't dismiss it)
- Briefly explain any context that matters (without sounding defensive)
- Invite them back to show they'll have a better experience
- Be under 100 words
```

---

### 4. Complaint Resolution Email
*Use when a guest contacts you directly about a bad experience.*

```
Write a guest complaint resolution email for my restaurant.

Guest situation: [DESCRIBE THE COMPLAINT — BE SPECIFIC]
What we did right or wrong: [YOUR HONEST INTERNAL ASSESSMENT]
What resolution I'm offering: [REFUND / COMP NEXT VISIT / DISCOUNT / APOLOGY ONLY / INVESTIGATION]
My tone goal: [RETAIN THE GUEST / SIMPLY RESOLVE PROFESSIONALLY / BOTH]

The email should:
- Open by acknowledging the specific experience (not a generic apology)
- Take responsibility where appropriate without admitting legal liability
- State clearly what you're doing about it
- Offer the resolution naturally (not as a bribe to remove the review)
- End with a genuine invitation to return
- Be under 200 words
```

---

### 5. Server Training Guide (Service Standards)
*Use to document your service expectations for front-of-house staff.*

```
Write a guest service standards guide for my restaurant's front-of-house team.

Restaurant type: [CASUAL / FINE DINING / FAST CASUAL / FAMILY]
Our service philosophy: [E.G., "WARM AND UNPRETENTIOUS" / "PRECISE AND ATTENTIVE" / "FUN AND ENERGETIC"]
Table turn goal: [APPROXIMATE — E.G., 75 MINUTES FOR DINNER SERVICE]
Current service issues: [E.G., "SLOW DRINK REFILLS / SERVERS DON'T UPSELL / GUESTS WAIT TOO LONG AFTER EATING"]

Create a guide covering:
1. The greeting (exact script)
2. Menu presentation and specials explanation
3. Drink refill and check-back timing
4. How to upsell naturally (not push)
5. Handling complaints at the table (before they leave)
6. The check drop and farewell
7. What to do when things go wrong

Include exact scripts for key moments. Something a new hire can read on day 1 and follow.
```

---

### 6. Reservation Confirmation Email
*Use to confirm bookings and set expectations.*

```
Write a reservation confirmation email for my restaurant.

Restaurant name: [NAME]
Reservation details: [DATE, TIME, PARTY SIZE]
Guest name: [GUEST_NAME]
Any special occasion noted: [BIRTHDAY / ANNIVERSARY / NONE]
Our parking or arrival notes: [BRIEF]
Cancellation policy: [YOUR POLICY]
Contact for questions: [PHONE / EMAIL]

The email should:
- Confirm all details clearly
- Build anticipation (a line about what to expect)
- Acknowledge the special occasion if applicable
- State the cancellation policy without making it feel punitive
- Be warm and welcoming
- Under 150 words
```

---

### 7. Waitlist / Table-Ready Text
*Use to communicate with guests who are waiting for a table.*

```
Write SMS templates for table waitlist management.

Restaurant name: [NAME]
Estimated wait time: [X MINUTES]

Write templates for:
1. Initial waitlist confirmation ("You're on our list...")
2. 10-minute heads-up ("Your table is almost ready...")
3. Table-ready notification ("Your table is ready! Please check in at...")
4. Waitlist expired (they didn't respond): ("We held your table but had to release it...")
5. Apology for longer-than-expected wait with offer

Each under 160 characters. Warm, professional, not robotic.
```

---

### 8. Catering / Private Event Follow-Up
*Use after a private event or catering job.*

```
Write a post-event follow-up message to a private dining or catering client.

Event type: [CORPORATE DINNER / BIRTHDAY PARTY / WEDDING REHEARSAL / OTHER]
Event date: [DATE]
Client name: [NAME]
How the event went: [GREAT / MOSTLY GOOD WITH A MINOR HICCUP / OUTSTANDING]
My goal: [THANK THEM AND ASK FOR REFERRALS / GATHER FEEDBACK / BOOK A REPEAT]

Write:
1. Thank-you email (150 words)
2. Review/testimonial request (add after a few days — 75 words)
3. Follow-up for next booking (1 month later — 100 words)
```

---

### 9. VIP / Regular Guest Acknowledgment
*Use to recognize and reward your most loyal customers.*

```
Write a personalized outreach message to a regular or VIP guest.

Guest situation: [E.G., "COMES IN EVERY FRIDAY NIGHT" / "HAS BROUGHT 5 GROUPS IN THE LAST YEAR" / "CELEBRATING THEIR ANNIVERSARY WITH US FOR THE 3RD YEAR"]
What I want to do: [SURPRISE THEM WITH A COMP / INVITE THEM TO A SPECIAL EVENT / SIMPLY ACKNOWLEDGE THEIR LOYALTY]
My offer (if any): [DESCRIBE]
Delivery method: [HANDWRITTEN NOTE / EMAIL / TEXT / VERBAL IN RESTAURANT]

The message should feel genuinely personal — like it came from someone who actually knows and values them. Short. Warm. Specific to them.
```

---

### 10. Food Allergy / Dietary Accommodation Response
*Use to respond to allergy or dietary inquiries.*

```
Write a response to a guest inquiry about food allergies or dietary restrictions.

Guest question: [DESCRIBE — E.G., "DO YOU HAVE GLUTEN-FREE OPTIONS?" / "MY PARTNER HAS A TREE NUT ALLERGY — IS IT SAFE TO DINE WITH YOU?" / "ARE YOUR SAUCES DAIRY-FREE?"]
Our actual situation: [BE SPECIFIC — WHAT WE CAN AND CANNOT ACCOMMODATE]
Kitchen protocol: [E.G., "WE HAVE A SHARED KITCHEN / WE HAVE DEDICATED PREP AREAS / WE ALERT CHEF FOR ALL ALLERGY REQUESTS"]

The response should:
- Be completely honest (this is a safety issue, not a marketing message)
- Tell them exactly what we can and can't accommodate
- Explain the kitchen protocol so they can make an informed decision
- Invite them to call ahead so we can prepare
- Never promise something you can't guarantee
```

---

### 11. No-Show / Reservation Abandonment Message
*Use when a guest no-shows for a reservation.*

```
Write a follow-up message to a guest who didn't show for their reservation.

Restaurant name: [NAME]
Reservation that was missed: [DATE, TIME, PARTY SIZE]
Guest name: [NAME]
My no-show policy: [YOUR POLICY — FEE / NO FEE / FIRST OFFENSE FREE]
My goal: [UNDERSTAND WHAT HAPPENED / ENFORCE POLICY / INVITE THEM TO REBOOK / ALL THREE]

Write a message that:
- Doesn't assume the worst (genuine emergencies happen)
- States the policy clearly if there's a charge
- Invites them to reschedule
- Is professional and non-accusatory
- Is under 100 words
```

---

### 12. Private Event Inquiry Response
*Use to respond to incoming event booking inquiries.*

```
Write a response to a private event inquiry.

Inquiry details: [WHAT THE GUEST ASKED — EVENT TYPE, DATE, PARTY SIZE, ANY SPECIFICS]
Our event options: [DESCRIBE WHAT WE OFFER — SPACE, CATERING, MINIMUMS]
Availability: [IF YOU KNOW IT — OR USE A PLACEHOLDER]
Price range: [ROUGH ESTIMATE OR "STARTING FROM $X"]
Next step: [CALL TO DISCUSS / FILL OUT FORM / SCHEDULE A SITE VISIT]

The response should:
- Confirm receipt of their inquiry warmly
- Show genuine enthusiasm for their event
- Give them enough info to stay interested
- Move them toward the next step
- Be under 200 words

Include a brief question to gather more info (budget, catering style preference, etc.) so the next conversation is productive.
```

---

### 13. Apology for Service Failure (In-Restaurant)
*Use to train staff on how to handle guest complaints at the table.*

```
Write scripts for handling guest complaints at the table during service.

Restaurant type: [CASUAL / FINE DINING / FAMILY]
Common complaint scenarios to script:
1. Wrong order delivered
2. Food arrived cold or poorly prepared
3. Long wait time for food
4. Rude or inattentive service complaint
5. Billing error

For each scenario, write:
- The opening acknowledgment (what to say first)
- The fix (what action to take)
- The recovery offer (what to comp or offer)
- The close (how to leave them feeling good)

Scripts should be under 50 words per scenario. Easy to memorize. Professional but human.
```

---

### 14. Gift Card Promotional Campaign
*Use to promote gift cards as a revenue tool.*

```
Write a gift card promotional campaign for my restaurant.

Restaurant name: [NAME]
Occasion: [HOLIDAY SEASON / MOTHER'S DAY / GENERAL / BIRTHDAY MONTH]
Gift card offer: [E.G., BUY $50, GET A $10 BONUS CARD / STANDARD WITH NO BONUS]
How to purchase: [IN RESTAURANT / ONLINE AT URL / BOTH]
Campaign duration: [DATE RANGE]

Write:
1. Email announcement (200 words) with subject line
2. Instagram post (100 words + hook)
3. In-restaurant table card (50 words)
4. SMS text (under 160 characters)
5. 3 reasons to give this restaurant's gift card (for social media stories)
```

---

### 15. Birthday / Anniversary Recognition Program
*Use to create an automated guest birthday campaign.*

```
Write the email sequence for a restaurant birthday and anniversary recognition program.

Restaurant name: [NAME]
Offer: [E.G., FREE DESSERT / 15% OFF / FREE APPETIZER ON THEIR BIRTHDAY]
Timing: [1 WEEK BEFORE / ON THE DAY / BOTH]

Write:
1. Birthday email (sent 1 week before): announce the offer, invite them to celebrate with us
2. Birthday reminder (sent day-of): shorter, urgent, warm
3. Anniversary email (for couple celebrating their anniversary with us)
4. Post-birthday follow-up (sent 2 days after): "How was your birthday? Hope we made it special"

Tone: Genuinely warm. These should feel like a message from a place that actually remembers them.
```

---

### 16. Thank-You for Large Group / Party
*Use after hosting a large party or group reservation.*

```
Write a thank-you message to a guest who organized a large group reservation.

Organizer name: [NAME]
Event: [BIRTHDAY / WORK DINNER / REUNION / OTHER]
Date: [DATE]
Group size: [NUMBER]
How it went: [GREAT / SMOOTH / WE HAD A SMALL ISSUE THAT WAS RESOLVED]

Write:
1. Email thank-you (within 24 hours)
2. Personal handwritten note (for pickup/mail — if appropriate for your restaurant)
3. Follow-up for next booking (2 weeks later)

Include: an invitation to reach out directly for their next event, and a natural referral ask.
```

---

### 17. Handling a Social Media Complaint
*Use when a guest complains publicly on Instagram, Facebook, or Twitter.*

```
Write a response to a public social media complaint about my restaurant.

Platform: [INSTAGRAM / FACEBOOK / TWITTER / GOOGLE]
The complaint: [DESCRIBE OR PASTE]
The facts: [YOUR INTERNAL ASSESSMENT]
My goal: [RESOLVE PUBLICLY THEN MOVE TO DIRECT MESSAGE / PROTECT BRAND REPUTATION / ACKNOWLEDGE AND INVITE THEM BACK]

Write:
1. Public response (under 75 words — acknowledge, don't argue, move to DM)
2. Direct message follow-up (after they respond or DM you — 150 words, more detail)
3. Resolution close (after issue is resolved — 50 words, thank them for giving you the chance to make it right)

Principle: The public response is for everyone watching. The DM is for fixing the actual problem.
```

---

### 18. Customer Survey / Feedback Request
*Use to gather actionable feedback from dining guests.*

```
Create a customer satisfaction survey for my restaurant.

Restaurant name: [NAME]
Survey method: [EMAIL / QR CODE AT TABLE / PAPER CARD / SMS LINK]
My main concerns I want feedback on: [E.G., WAIT TIMES / FOOD QUALITY / SERVICE / AMBIANCE / VALUE]
How long it should take: [2 MINUTES MAX]

Write:
1. A 7-question survey (mix of rating scale and 1–2 open-ended)
2. The intro message explaining why you're asking (under 50 words)
3. The thank-you message after completion (with incentive if applicable)
4. Email subject line for distribution

Make the questions specific enough to be actionable. "How was your experience?" tells you nothing. "How long did you wait for your entrée?" tells you something.
```

---

### 19. Group Dining Landing Page Copy
*Use to convert large party inquiries from your website.*

```
Write website landing page copy for group dining and private events.

Restaurant name: [NAME]
Private space capacity: [NUMBER OF GUESTS]
Cuisine/menu options for groups: [DESCRIBE — PRIX FIXE / FAMILY STYLE / CUSTOM MENUS]
Event types you host: [CORPORATE / BIRTHDAY / REHEARSAL DINNER / HOLIDAY PARTIES / ALL]
Minimum spend or room fee: [IF APPLICABLE]
What makes your group experience special: [DIFFERENTIATOR]
Booking contact: [EMAIL OR PHONE]

Write a 300-word landing page that:
- Opens with an emotional hook (the experience they'll create, not the logistics)
- Describes what the space and experience are like
- Lists event types (don't assume they know you do this)
- Includes your menu/package options briefly
- Has a clear inquiry CTA (email, phone, or form)
```

---

### 20. Post-Dining Experience Survey Follow-Up
*Use to follow up with guests who completed a satisfaction survey.*

```
Write follow-up messages based on survey responses from restaurant guests.

Write responses for:
1. Guest who gave all 5s and said "perfect experience" — thank them and ask for a public review
2. Guest who gave 3s across the board — understand what happened, invite them back
3. Guest who specifically praised a team member — let them know you'll pass it on, invite back
4. Guest who flagged a specific problem (slow service / wrong order) — address it directly
5. Guest who gave 1s and said they'll never return — a genuine attempt at recovery

Each response: personal, under 150 words, with a specific next step.
```

---
