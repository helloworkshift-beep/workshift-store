# PRODUCT INFO — The Restaurant Owner's AI Prompt Toolkit

---

## Product Details

| Field | Value |
|-------|-------|
| **Product Name** | The Restaurant Owner's AI Prompt Toolkit |
| **Version** | 1.0 |
| **Format** | 7 Markdown files (digital download) |
| **Total Prompts** | 90+ ready-to-use AI prompts |
| **Support** | helloworkshift@gmail.com |

---

## Who It's For

Restaurant owners and operators who want to write compelling menu copy, respond professionally to reviews, manage staff more effectively, and grow their restaurant's reputation online — without hiring a PR or marketing firm.

---

## What's Included

| File | Description | Prompt Count |
|------|-------------|--------------|
| `01-quick-start-guide.md` | Setup, system prompt, best practices | — |
| `02-menu-marketing-prompts.md` | Menu descriptions, specials, promotional copy | 23 |
| `03-customer-experience-prompts.md` | Review responses, complaint handling, loyalty | 22 |
| `04-operations-staff-prompts.md` | Staff communications, training, vendor management | 18 |
| `05-social-reputation-prompts.md` | Social media, review strategy, community | 17 |
| `06-workflow-sops.md` | 5 complete restaurant workflow playbooks | — |
| `07-cheat-sheet.md` | Top 15 prompts + variable quick reference | 15 |

---

*For support: helloworkshift@gmail.com*
*Last updated: 2026*
