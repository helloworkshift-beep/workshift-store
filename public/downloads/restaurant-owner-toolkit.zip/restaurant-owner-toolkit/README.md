# 🍽️ The Restaurant Owner's AI Prompt Toolkit

**90+ AI prompts for restaurant owners, operators, and managers**

---

## What's Inside

This toolkit gives restaurant owners and operators instant access to professional-grade prompts for every part of running a restaurant — from writing menu descriptions that sell to responding to reviews to managing staff and marketing your specials.

Every prompt is:
- **Restaurant-specific** — Built for real hospitality scenarios and daily operations
- **Structured** — Uses `[BRACKET VARIABLES]` so you can customize in minutes
- **Immediately usable** — Designed to produce copy, messages, and posts you can use today

---

## File Guide

| File | Contents | Prompts |
|------|----------|---------|
| [01-quick-start-guide.md](01-quick-start-guide.md) | How to use this toolkit effectively | — |
| [02-menu-marketing-prompts.md](02-menu-marketing-prompts.md) | Menu descriptions, specials copy, promotional content | 23 |
| [03-customer-experience-prompts.md](03-customer-experience-prompts.md) | Review responses, complaint handling, loyalty programs | 22 |
| [04-operations-staff-prompts.md](04-operations-staff-prompts.md) | Staff communication, training docs, vendor management | 18 |
| [05-social-reputation-prompts.md](05-social-reputation-prompts.md) | Social media, review strategy, community building | 17 |
| [06-workflow-sops.md](06-workflow-sops.md) | 5 complete restaurant workflow playbooks | — |
| [07-cheat-sheet.md](07-cheat-sheet.md) | Top 15 power prompts + quick reference | 15 |

**Total: 90+ prompts**

---

## Who This Is For

- **Independent restaurant owners** running 1-5 locations
- **Restaurant managers** responsible for operations and staff
- **Food truck owners** building their brand
- **Café and bar owners** who wear multiple hats every day

---

*Built for restaurant owners who serve something special.*
