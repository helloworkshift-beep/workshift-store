# 06 — Workflow SOPs

*5 complete systems for your most time-intensive restaurant tasks — powered by AI*

---

## SOP A: Launch a Seasonal Menu in 2 Hours (Not 2 Weeks)

**What this produces:** New menu copy, marketing materials, and staff training ready to go
**When to run it:** 2 weeks before each seasonal menu change
**Time commitment:** 2 hours (vs. scattered effort over weeks)

---

**Step 1 — Finalize the dishes (before this session)**

Have your chef confirm: new items, retiring items, price changes. You need this before writing anything.

**Step 2 — Write all menu descriptions (30 min)**

Use **Prompt: Full Menu Section Rewrite** from `02-menu-marketing-prompts.md`.

Paste all new dishes. Get all descriptions in one session. Edit for accuracy — AI won't know your exact preparation.

**Step 3 — Write the announcements (30 min)**

Use **Prompt: Seasonal Menu Announcement** from `02-menu-marketing-prompts.md`.

This generates your email, Instagram caption, and in-restaurant signage in one prompt.

**Step 4 — Write the staff training materials (20 min)**

Use **Prompt: Staff Training Guide** section from `04-operations-staff-prompts.md`.

Specifically: how to describe the new items to guests. Have staff taste every new item before service.

**Step 5 — Schedule the content (20 min)**

Use the generated assets to:
- Schedule the email (send 5 days before launch)
- Queue 3 Instagram posts (teaser → launch day → week 2 feature)
- Print and laminate the updated menu

**Step 6 — First week review**

After 7 days: check which new items are selling and which aren't. Use **Prompt: Menu Pricing Psychology Review** to evaluate positioning if something underperforms.

---

## SOP B: Turn a Bad Review into a Business Asset

**What this produces:** A professional public response that impresses future customers
**When to run it:** Within 24 hours of every negative review

---

**Step 1 — Read it twice before responding**

First read: emotional (your gut reaction). Second read: what a future customer will see. Write from the second perspective.

**Step 2 — Gather the facts**

Talk to the manager on duty that night. What actually happened? Be honest with yourself.

**Step 3 — Write the response**

Use **Prompt: Response to a 1–2 Star Review** from `03-customer-experience-prompts.md`.

Key rules:
- Under 100 words in the final response
- No arguing with their facts publicly
- Take the conversation offline

**Step 4 — Post it, then move on**

Don't obsess. Every restaurant gets bad reviews. Your response-to-bad-review ratio is what potential customers actually notice.

**Step 5 — Use it internally**

Did the review reveal a real service gap? If 3 different reviews mention the same thing, it's not the customers — it's the operation. Use the feedback for a staff meeting discussion.

---

## SOP C: Build Your Social Media Presence in 1 Day Per Month

**What this produces:** 30 days of Instagram content, ready to post
**When to run it:** First Sunday of every month

---

**Step 1 — Plan your content (30 min)**

Use **Prompt: Instagram Content Calendar** from `05-social-reputation-prompts.md`.

Get 30 days of planned posts in one session. Adjust for any upcoming events or promotions.

**Step 2 — Shoot your content (2 hours)**

Batch your photography session:
- Take photos of your top 8–10 dishes during prep (controlled lighting, clean plating)
- Get 2–3 behind-the-scenes kitchen shots
- Capture 1 team moment

You don't need a professional photographer. A phone with good lighting (natural light or a ring light) is enough to start.

**Step 3 — Write all your captions (45 min)**

Use **Prompt: Food Photography Caption Pack** from `02-menu-marketing-prompts.md`.

Write captions for all photos at once while you're in the mindset.

**Step 4 — Schedule everything**

Use Meta Business Suite (free), Later, or Buffer to schedule all 30 days.

**Step 5 — Engage daily (5 min/day)**

Scheduling is not enough. Each day: respond to comments, answer DMs, and like/comment on posts from local community pages. This takes 5 minutes and significantly improves reach.

---

## SOP D: Handle a Service Crisis Night

**What this produces:** A controlled response to a bad service night, before it becomes a bad week of reviews
**When to run it:** Anytime a service goes significantly wrong (kitchen backup, major customer incident, staffing failure)

---

**Immediate (during or immediately after service):**

1. Manager acknowledges the issue to affected tables personally — not a server, the manager
2. Comp strategically (not reflexively — comping a $200 check because someone waited 20 minutes is overkill)
3. Document everything: table numbers, times, what went wrong, what was comped

**Same night (after close):**

1. Write the shift report using **Prompt: Manager Shift Report Template** from `04-operations-staff-prompts.md`
2. Note all tables that had a poor experience — follow up within 24 hours

**Next morning:**

1. Check Google and Yelp for new reviews from last night
2. Respond to any negative reviews using **Prompt: Response to a 1–2 Star Review**
3. For guests whose contact info you have (reservations): use **Prompt: Complaint Resolution Email** to reach out proactively

**Following week:**

1. Use **Prompt: Staff Meeting Agenda** to conduct a root cause debrief
2. Fix the operational gap — equipment, staffing, training, or systems
3. Follow up with staff who were involved

---

## SOP E: Hire and Onboard a New Server in 7 Days

**What this produces:** A fully trained, confident new server ready for solo tables by day 7
**When to run it:** Every new FOH hire

---

**Before Day 1:**

1. Write and post the job listing using **Prompt: Job Posting — Front of House**
2. Conduct 20-minute phone screens (energy, experience, availability)
3. In-person interview: ask them to sell you a menu item cold. Servers who can sell under pressure will do the same for your guests.

**Day 1:**

1. Tour: walk every area they'll work in (kitchen, service areas, POS, side work stations)
2. Menu deep-dive: every item, every modifier, every allergen note
3. POS training: place a test order, run a test check, split a test check
4. Shadow a senior server for a full dinner service

**Day 2:**

1. Food tasting: they should taste everything on the menu before recommending it to guests
2. Shadow again — different server, different style, notice what works
3. Study the wine/beer/cocktail list

**Day 3:**

1. First solo tables with manager within earshot
2. Debrief after each table: what went well, what to improve
3. Practice the upsell conversation

**Day 4–7:**

1. Increasing independence, decreasing check-ins
2. Daily 5-minute feedback session with the manager
3. Day 7: formal check-in — are they ready for the floor independently?

Use **Prompt: New Server Onboarding Guide** from `04-operations-staff-prompts.md` to generate the full written training materials.

---
