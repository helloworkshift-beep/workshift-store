# 02 — Menu & Marketing Prompts

*22 prompts for menu descriptions, promotions, and attracting new customers*

---

### 1. Menu Item Description (Enticing)
*Use to rewrite flat menu copy into descriptions that make people hungry.*

```
You are a professional menu copywriter with experience in restaurant marketing. Write an enticing menu description for the following dish:

Dish name: [DISH_NAME]
Key ingredients: [LIST MAIN INGREDIENTS]
Cooking method: [E.G., WOOD-FIRED / PAN-SEARED / SLOW-BRAISED / HOUSE-SMOKED]
Flavor profile: [E.G., RICH AND SAVORY / BRIGHT AND ACIDIC / SWEET AND SMOKY]
Any unique sourcing: [E.G., LOCAL FARM / HOUSE-MADE / SEASONAL]
Price point context: [BUDGET / MID-RANGE / UPSCALE]
Cuisine style: [E.G., ITALIAN / AMERICAN COMFORT / MODERN ASIAN / BBQ]

Write a 2–3 sentence menu description that:
- Leads with the most crave-worthy element
- Uses sensory words (texture, aroma, temperature, flavor)
- Mentions sourcing or technique if it differentiates the dish
- Fits the restaurant's price point and tone
- Ends naturally — no "enjoy!" or "delight your senses"

Avoid clichés: "mouth-watering," "delicious," "amazing," "to die for."
```

---

### 2. Full Menu Section Rewrite
*Use when your menu section copy needs a full refresh.*

```
Rewrite the following menu section for a [RESTAURANT_STYLE] restaurant.

Section: [E.G., APPETIZERS / SMALL PLATES / DESSERTS / BRUNCH SPECIALS]
Current dishes and their bland descriptions:
[PASTE YOUR CURRENT MENU ITEMS AND DESCRIPTIONS HERE]

Our restaurant tone: [CASUAL AND FUN / SOPHISTICATED AND REFINED / RUSTIC AND WARM / BOLD AND EDGY]
Our cuisine identity: [BRIEF DESCRIPTION]
What we want guests to feel: [EXCITED AND HUNGRY / COMFORTABLE AND AT HOME / CURIOUS AND ADVENTUROUS]

Rewrite each description to be more evocative, consistent in tone, and appropriate for our brand. Maintain the dish names. Keep each under 30 words.
```

---

### 3. Seasonal Menu Announcement
*Use when launching a new seasonal menu.*

```
Write a seasonal menu announcement for [SEASON/OCCASION].

Restaurant name: [NAME]
New dishes being added: [LIST 3–5 HIGHLIGHTS]
What's leaving: [LIST IF RELEVANT — E.G., "LAST CHANCE FOR OUR SUMMER CEVICHE"]
What makes this menu special: [THE STORY — E.G., LOCAL FARM PARTNERSHIP / CHEF'S INSPIRATION / HERITAGE RECIPE]
Target audience for this message: [EMAIL LIST / SOCIAL MEDIA / IN-RESTAURANT SIGNAGE / ALL]

Write:
1. Email announcement (250 words) with subject line
2. Instagram caption (150 words) + caption hook
3. In-restaurant table tent or chalkboard copy (50 words)
```

---

### 4. Weekly Specials Copy
*Use to write recurring specials announcements quickly.*

```
Write promotional copy for this week's restaurant specials.

Restaurant: [NAME] | Cuisine: [TYPE] | Tone: [CASUAL / UPSCALE / FUN]
This week's specials:
- [DISH 1]: [BRIEF DESCRIPTION AND PRICE]
- [DISH 2]: [BRIEF DESCRIPTION AND PRICE]
- [DRINK SPECIAL]: [BRIEF DESCRIPTION AND PRICE]
Days available: [E.G., THURSDAY–SUNDAY / EVERY NIGHT]

Write:
1. Instagram/Facebook post (100–150 words + caption hook)
2. Email subject line (for weekly newsletter)
3. SMS text message (under 160 characters)
4. Chalkboard copy (20 words max per item)
```

---

### 5. Restaurant Brand Story
*Use to write the "About Us" copy for your website.*

```
Write an "About Us" brand story for my restaurant.

Restaurant name: [NAME]
Cuisine type: [DESCRIBE]
Location: [CITY/NEIGHBORHOOD]
Founding story: [HOW AND WHY IT STARTED — BE HONEST AND HUMAN]
What makes us different: [YOUR REAL DIFFERENTIATOR — NOT "GREAT FOOD AND SERVICE"]
Who we serve: [DESCRIBE YOUR TYPICAL CUSTOMER]
The feeling we create: [WHAT PEOPLE FEEL WHEN THEY DINE WITH US]
Chef or owner name: [IF FEATURED]

Write a 300-word brand story that:
- Opens with a scene or moment, not "We are a restaurant that..."
- Captures the soul of the restaurant
- Makes a potential first-timer feel like they already know the place
- Ends with an invitation to visit
```

---

### 6. Google Ads Copy for Local Restaurant
*Use to create search ads targeting local diners.*

```
Write Google Search ad copy for my restaurant.

Restaurant name: [NAME]
Location: [CITY/NEIGHBORHOOD]
Cuisine: [TYPE]
Best selling points: [LIST 3 — E.G., "HAPPY HOUR 3–6PM" / "KIDS EAT FREE TUESDAY" / "AWARD-WINNING RIBS"]
Target search terms: [E.G., "ITALIAN RESTAURANT NEAR ME" / "BEST BRUNCH [CITY]" / "DATE NIGHT RESTAURANTS"]

Write:
- 5 headline options (30 characters each — hard limit)
- 3 description options (90 characters each)
- 2 sitelink extensions (25 character title + 35 character description)

Focus on location, offer, or what makes you worth choosing over the restaurant next door.
```

---

### 7. New Restaurant Opening Announcement
*Use when launching a new location or opening for the first time.*

```
Write an opening announcement for my new restaurant.

Restaurant name: [NAME]
Location: [FULL ADDRESS AND NEIGHBORHOOD]
Opening date: [DATE OR "SOFT OPENING DATE" AND "GRAND OPENING DATE"]
Cuisine and concept: [BRIEF DESCRIPTION]
Hours: [OPERATING HOURS]
Reservations: [YES — HOW TO BOOK / WALK-IN ONLY]
What makes this opening worth attending: [OPENING SPECIALS / UNIQUE CONCEPT / LOCAL CHEF]

Write:
1. Press release (400 words) — for local media
2. Email announcement (200 words) — for existing customers or subscribers
3. Instagram announcement post + caption hook
4. Facebook event description (150 words)
5. Google Business Profile post (200 words)
```

---

### 8. Happy Hour / Promotion Copy
*Use to promote recurring or limited-time deals.*

```
Write promotional copy for the following restaurant deal or promotion.

Promotion: [E.G., HAPPY HOUR / KIDS EAT FREE / TACO TUESDAY / DATE NIGHT SPECIAL / LUNCH SPECIAL]
Details: [EXACT OFFER — TIMES, DAYS, PRICES, WHAT'S INCLUDED]
Restaurant name: [NAME] | Tone: [CASUAL / PLAYFUL / SOPHISTICATED]
Who this targets: [FAMILIES / AFTER-WORK CROWD / COUPLES / LUNCH CROWD]

Write:
1. Instagram/Facebook post (100 words)
2. Email subject line + email body (150 words)
3. SMS announcement (under 160 characters)
4. In-restaurant table card (40 words)
5. Window/exterior signage text (15 words max)
```

---

### 9. Email Marketing — Monthly Newsletter
*Use to keep regulars engaged and bring lapsed customers back.*

```
Write a monthly restaurant email newsletter.

Restaurant name: [NAME]
Month: [MONTH]
This month's highlights:
- New menu items: [LIST]
- Upcoming events: [LIST]
- Special offers: [LIST]
- Community involvement / story: [E.G., NEW LOCAL FARM PARTNERSHIP / CHEF AWARD / CHARITY INVOLVEMENT]
Subscriber type: [REGULARS / MIXED LIST / MOSTLY NEW SUBSCRIBERS]

Write:
- Subject line (under 50 characters)
- Preview text (under 90 characters)
- Newsletter body (300–400 words)
- Clear call to action (reserve a table / try the new menu / share with a friend)

Tone: warm, personal, like an update from someone they like — not a corporate blast.
```

---

### 10. Influencer / Media Outreach
*Use to invite food bloggers, influencers, or journalists to your restaurant.*

```
Write an outreach email inviting a food influencer or local journalist to my restaurant.

Their name: [NAME]
Their platform: [INSTAGRAM / FOOD BLOG / LOCAL NEWSPAPER / TV]
Their audience: [DESCRIBE]
My restaurant: [NAME] | Cuisine: [TYPE] | Location: [CITY]
What I'm inviting them to: [PRESS PREVIEW / TASTING MENU EXPERIENCE / NEW MENU LAUNCH]
What I'm offering: [COMPLIMENTARY MEAL FOR TWO / FULL TASTING / INTERVIEW WITH CHEF]
What's newsworthy: [THE HOOK — WHY NOW, WHY THIS RESTAURANT]

The email should:
- Reference something specific about their work (show you've done your homework)
- Lead with the newsworthiness, not the free meal
- Be under 200 words
- Make it easy to say yes (specific date options, no requirements on coverage)
```

---

### 11. Grand Opening / Anniversary Event Copy
*Use to promote milestone restaurant events.*

```
Write event promotional copy for my restaurant's [GRAND OPENING / ANNIVERSARY / REBRAND LAUNCH].

Event details:
- What: [EVENT NAME]
- When: [DATE, TIME]
- Where: [ADDRESS]
- What's happening: [SPECIALS, ENTERTAINMENT, GIVEAWAYS, GUEST CHEFS]
- Tickets/reservations: [FREE / TICKETED AT $X / RESERVATION REQUIRED]
- Why it's a big deal: [THE STORY]

Write:
1. Facebook event description (250 words)
2. Instagram countdown posts (3 posts — 1 week out, 3 days out, day-of)
3. Local event listing copy (150 words, no restaurant jargon)
4. Email invitation to your list (200 words)
```

---

### 12. Takeout / Delivery Menu Optimization
*Use to optimize your third-party delivery profile listings.*

```
Rewrite my restaurant's takeout/delivery menu listings for [DOORDASH / UBER EATS / GRUBHUB / ALL].

My restaurant: [NAME] | Cuisine: [TYPE]
Current top sellers: [LIST 5–8 DISHES WITH CURRENT DESCRIPTIONS]
What I want to improve: [E.G., "DESCRIPTIONS ARE TOO SHORT" / "CUSTOMERS KEEP ORDERING WRONG MODIFIERS" / "PHOTOS DON'T MATCH DESCRIPTIONS"]
Competition on the platform: [E.G., "LOTS OF SIMILAR CUISINE OPTIONS IN MY AREA"]

Rewrite each description to:
- Accurately describe what they'll receive (set expectations)
- Lead with the most appealing element
- Be clear about portion size and main protein
- Use consistent language that matches how I'd describe it in-restaurant
- Be under 25 words per item

Also write: restaurant banner headline (the short bio shown at the top of your listing, 100 characters max).
```

---

### 13. Local Partnership Pitch
*Use to propose cross-promotion deals with nearby businesses.*

```
Write a partnership pitch to a local business about a cross-promotion.

My restaurant: [NAME, CUISINE, NEIGHBORHOOD]
The business I'm pitching: [BUSINESS NAME AND TYPE]
The partnership idea: [E.G., "THEIR YOGA STUDIO STUDENTS GET 15% OFF OUR HEALTHY BOWLS / WE FEATURE THEIR WINE AT OUR EVENTS / JOINT GIFT CARD PROMOTION"]
What they get: [SPECIFIC BENEFIT]
What I get: [SPECIFIC BENEFIT]
Why this makes sense: [THE LOGICAL CONNECTION BETWEEN OUR BUSINESSES]

Write a 3-paragraph pitch email that:
- Opens with something genuine about their business
- Proposes the partnership clearly with specifics
- Explains the mutual benefit
- Suggests a low-commitment first step (coffee meeting, a trial run)
- Is under 200 words and easy to respond to
```

---

### 14. Restaurant Website Homepage Copy
*Use to write or refresh your restaurant's website.*

```
Write homepage copy for my restaurant website.

Restaurant name: [NAME]
Cuisine: [DESCRIBE]
Location: [ADDRESS OR NEIGHBORHOOD]
Vibe/atmosphere: [E.G., LIVELY NEIGHBORHOOD BISTRO / QUIET DATE NIGHT SPOT / FAMILY-FRIENDLY DINER]
Signature dish or most famous for: [DESCRIBE]
Hours: [HOURS]
Reservation/ordering options: [WALK-IN / RESY / OPENTABLE / ONLINE ORDER]
What you want visitors to do: [MAKE A RESERVATION / ORDER ONLINE / FIND US / ALL THREE]

Write:
1. Hero section (headline + 2-sentence description)
2. "Our Story" blurb (100 words)
3. Signature dishes section (3 dishes × 30-word descriptions)
4. Location and hours section copy
5. Reservation/order CTA section

Tone: [MATCH THE RESTAURANT VIBE]
```

---

### 15. Food Photography Caption Pack
*Use to write a month of Instagram captions in one session.*

```
Write 10 Instagram captions for food photography posts.

My restaurant: [NAME] | Cuisine: [TYPE] | Tone: [CASUAL / PLAYFUL / ELEVATED / WARM]
My typical audience: [LOCAL FOODIES / FAMILIES / DATE NIGHT CROWD / TOURISTS]

Dishes/moments to caption:
1. [DISH OR SCENE — E.G., "OUR WOOD-FIRED MARGHERITA PIZZA"]
2. [DISH OR SCENE]
3. [DISH OR SCENE]
... (list up to 10)

For each caption:
- Scroll-stopping first line (the hook)
- 2–3 sentences body
- CTA (reserve a table / tag a friend / visit this weekend)
- 5 targeted hashtags

Avoid: "😍 YOU NEED TO TRY THIS!" energy. Write like a place with genuine confidence in its food.
```

---

### 16. Yelp / TripAdvisor Business Description
*Use to optimize your profiles on review platforms.*

```
Write an optimized Yelp and TripAdvisor business description for my restaurant.

Restaurant name: [NAME]
Cuisine: [TYPE]
Location: [CITY AND NEIGHBORHOOD]
Atmosphere: [DESCRIBE — SEATING CAPACITY, INDOOR/OUTDOOR, AMBIANCE]
Best for: [E.G., FAMILIES / DATE NIGHT / BUSINESS LUNCH / GROUPS / ALL]
Price range: [$, $$, $$$, $$$$]
Must-try dishes: [LIST 3–5]
Parking and accessibility: [BRIEF]
Reservations: [YES/NO/RECOMMENDED]

Write:
1. Yelp business description (1,500 character limit — use it fully)
2. TripAdvisor description (same content, slightly adjusted tone)
3. "Categories" and "Specialties" section suggestions
4. Suggested response to the question "What makes this place special?" (200 words)
```

---

### 17. Menu Pricing Psychology Review
*Use when redesigning your menu layout and pricing.*

```
Review my menu pricing and layout from a menu engineering and psychology perspective.

My current menu layout: [DESCRIBE OR PASTE KEY ITEMS WITH PRICES]
My food cost target: [E.G., 28–32%]
Current highest-margin items: [LIST IF KNOWN]
Current bestsellers: [LIST IF KNOWN]
Price range of my average check: [$X PER PERSON]
My customer type: [DESCRIBE]

Provide recommendations on:
1. Pricing anchoring (where to place high-margin items)
2. Decoy pricing (how to make target items feel like better value)
3. How to describe prices (remove dollar signs, use .95 vs .00, etc.)
4. Menu category ordering (what to lead with)
5. Which items to feature / spotlight based on what I've told you
6. What to remove (overcrowded menus reduce sales)
7. How to use design to guide eyes to high-margin items
```

---

### 18. Loyalty Program Announcement
*Use to launch or promote a customer loyalty program.*

```
Write copy for my restaurant's loyalty program launch.

Program name: [OR ASK ME TO CREATE ONE]
How it works: [E.G., "EARN 1 POINT PER $1 SPENT, REDEEM 100 POINTS FOR $10 OFF" / "$5 REWARD FOR EVERY 5 VISITS"]
Sign-up method: [APP / PHONE NUMBER / EMAIL / PUNCH CARD]
Launch offer: [E.G., "SIGN UP AND GET A FREE APPETIZER"]
Platform: [SQUARE / TOAST / CUSTOM APP / SIMPLE PUNCH CARD]

Write:
1. In-restaurant table card (75 words)
2. Server script for explaining the program to guests (50 words — easy to memorize)
3. Email announcement to existing customers (200 words)
4. Instagram post announcing the launch (100 words)
5. Follow-up message for members who haven't visited in 30 days
```

---

### 19. Catering / Private Events Page
*Use to promote private dining and catering services.*

```
Write promotional copy for my restaurant's catering and private events services.

Restaurant name: [NAME]
Private event space: [CAPACITY, DESCRIPTION — E.G., "PRIVATE DINING ROOM FOR 20, FULL AV SETUP"]
Catering services offered: [E.G., FULL-SERVICE CATERING / DROP-OFF ONLY / CORPORATE LUNCH DELIVERY]
Types of events served: [CORPORATE / WEDDINGS / BIRTHDAYS / HOLIDAY PARTIES / ALL]
Geographic range: [LOCAL / WIDER RADIUS]
Signature catering dishes: [LIST 3–5]
Minimum order or rental fee: [IF APPLICABLE]
Contact for booking: [EMAIL / PHONE]

Write:
1. Website page copy for private events (400 words)
2. Email pitch to corporate HR / event planners (250 words)
3. Instagram post targeting party planners (100 words)
4. One-page catering menu intro (100 words) to attach to a PDF proposal
```

---

### 20. Reactivation Campaign for Lapsed Customers
*Use to bring back customers who haven't visited in 60+ days.*

```
Write a reactivation campaign for lapsed restaurant customers.

My restaurant: [NAME] | Cuisine: [TYPE]
How long since their last visit: [60 DAYS / 90 DAYS / 6 MONTHS]
What I know about them: [JUST EMAIL / ALSO KNOW THEIR ORDER HISTORY / MINIMAL DATA]
Incentive I'm willing to offer: [E.G., 20% OFF NEXT VISIT / FREE APPETIZER / $10 CREDIT]
New since they last visited: [E.G., NEW MENU / NEW HOURS / NEW SPACE]

Write a 3-touch reactivation sequence:
1. Email 1 — "We miss you" (personal, no hard sell)
2. Email 2 — Show what's new (curiosity hook)
3. Email 3 — Final offer with urgency (last chance, specific expiry date)

Each email: under 150 words, one clear CTA, subject line included.
```

---

### 21. Chef's Spotlight / Feature Story
*Use to humanize your restaurant and build brand connection.*

```
Write a chef or team member spotlight story for social media or the website.

Subject: [CHEF NAME / SERVER NAME / TEAM MEMBER]
Their role: [HEAD CHEF / LINE COOK / GENERAL MANAGER / FRONT OF HOUSE]
Their story: [HOW THEY GOT INTO THIS / WHAT THEY LOVE ABOUT IT]
Something surprising about them: [E.G., "PLAYED IN A ROCK BAND" / "GREW UP ON A FARM" / "SELF-TAUGHT BAKER"]
Their favorite dish on the menu: [DISH AND WHY]
What they want guests to know: [ANY MESSAGE]

Write:
1. Long-form Instagram or Facebook post (250–300 words)
2. Short version for a story caption (75 words)
3. Website "Meet the Team" bio (150 words)

Tone: warm and human. People eat at restaurants they connect with, not just ones with good food.
```

---

### 22. SMS Marketing Templates (Existing Customers)
*Use for text message marketing to opted-in customers.*

```
Write SMS marketing templates for my restaurant.

Note: These will only be sent to opted-in subscribers.

My restaurant: [NAME] | Tone: [FUN / WARM / DIRECT]

Write templates (under 160 characters each) for:
1. Weekly specials announcement
2. Happy hour reminder (same-day, sent at 2 PM)
3. New menu item launch
4. Slow night fill — "Come in tonight" (with incentive)
5. Holiday promotion
6. Birthday message (for loyalty program members)
7. Re-engagement for customers who haven't visited in 60 days

Each text must include: who it's from, the offer/message, one CTA, and opt-out instructions ("Reply STOP to opt out").
```

---
