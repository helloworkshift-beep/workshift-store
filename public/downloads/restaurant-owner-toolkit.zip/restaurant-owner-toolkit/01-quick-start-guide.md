# 01 — Quick Start Guide

*How to get maximum value from this toolkit in the first 10 minutes*

---

## The 3-Minute Setup

### Step 1: Pick Your AI Tool
These prompts work with any modern LLM:
- **ChatGPT (GPT-4o)** — Great for social posts and quick communications
- **Claude (Sonnet or Opus)** — Best for review responses and longer documents
- **Gemini Advanced** — Works well on mobile during service

### Step 2: Set a System Prompt
Paste this at the start of any new conversation:

```
You are an experienced independent restaurant owner and hospitality professional with 15+ years in the food and beverage industry. You understand how to write menu copy that sells, respond to reviews that protect your reputation, communicate with staff professionally, and market a restaurant on a tight budget. You write in a voice that's warm, professional, and specific to the food and dining experience. When I give you a prompt, produce clean, usable output I can post, send, or print today.
```

### Step 3: Fill In the Brackets
Every prompt uses `[BRACKET_VARIABLES]` in ALL_CAPS. Replace every bracket with your restaurant's real information before pasting.

---

## How to Fill In Variables Like a Pro

**Bad:**
```
[RESTAURANT_NAME] = my restaurant
[DISH] = the pasta
```

**Good:**
```
[RESTAURANT_NAME] = The Blue Anchor — a New England seafood bistro in Portland, Maine
[DISH] = Pan-seared halibut with roasted fingerling potatoes, charred lemon, and herb butter — sourced from local day boats
```

Specific, evocative details produce menu copy and social posts people actually engage with.

---

## Power Techniques

### Build a Voice Guide
After generating a few menu descriptions or social posts, save the ones you love. Use them as examples when you want AI to match your restaurant's tone:
- *"Match the voice and style of this example: [paste your saved example]"*

### Batch Your Marketing Content
Once a week, spend 30 minutes generating:
- 3-5 social media posts
- 1 email for your list
- Any review responses from the previous week

### Use Review Responses as Templates
Once you have a strong response for a 1-star review about wait times, save it. Edit 20% for each new similar review. Your response time goes from 30 minutes to 5.

---

## Common Mistakes to Avoid

❌ **Generic menu descriptions** — "Delicious pasta with sauce" produces bad copy. Give the AI the actual ingredients, sourcing story, and cooking technique.

❌ **Responding to reviews while emotional** — If you just got a 1-star review that made you angry, use the AI prompts to draft a response. The templates are specifically designed to de-escalate.

❌ **Posting without your restaurant's voice** — Add your specific specials, seasonal details, and your name/personality before publishing.

---

## Recommended Use by Situation

| Situation | Go-To Prompts |
|-----------|--------------|
| Writing new menu descriptions | Menu #1, #2 |
| Promoting a special or event | Menu #8, #9 |
| Responding to a 1-star review | Customer Experience #6, #7 |
| Writing a loyalty email | Customer Experience #10 |
| Staff policy or training doc | Operations #1, #3 |
| Posting on Instagram | Social #1, #2 |
| Running a promotional campaign | Social #9 |
| Dealing with a vendor issue | Operations #10 |
| Asking happy customers for reviews | Social #6, #7 |

---

## File Navigation

- **Menu & Marketing Copy** → [02-menu-marketing-prompts.md](02-menu-marketing-prompts.md)
- **Customer Experience** → [03-customer-experience-prompts.md](03-customer-experience-prompts.md)
- **Operations & Staff** → [04-operations-staff-prompts.md](04-operations-staff-prompts.md)
- **Social & Reputation** → [05-social-reputation-prompts.md](05-social-reputation-prompts.md)
- **Full Workflow Playbooks** → [06-workflow-sops.md](06-workflow-sops.md)
- **Quick Reference** → [07-cheat-sheet.md](07-cheat-sheet.md)

---

*Start with the cheat sheet, or jump to menu copy if you have a new dish to describe right now.*
