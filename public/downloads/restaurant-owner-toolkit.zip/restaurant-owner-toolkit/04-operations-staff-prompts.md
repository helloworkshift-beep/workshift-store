# 04 — Operations & Staff Prompts

*20 prompts for managing your team, running efficient operations, and handling HR tasks*

---

### 1. Job Posting — Front of House
*Use when hiring servers, hosts, or bartenders.*

```
Write a job posting for a front-of-house position at my restaurant.

Position: [SERVER / HOST / BARTENDER / FOOD RUNNER / BARBACK]
Restaurant name: [NAME] | Cuisine: [TYPE] | Location: [CITY]
Hours: [FULL-TIME / PART-TIME — APPROXIMATE SCHEDULE]
Pay: [HOURLY RATE / TIP ELIGIBLE / DESCRIBE COMP STRUCTURE]
Experience required: [LEVEL — E.G., "1+ YEAR IN FULL-SERVICE RESTAURANT PREFERRED"]
What makes working here great: [CULTURE / TEAM / GROWTH / MEAL PERKS / FLEXIBLE SCHEDULE]
Key responsibilities: [LIST 3–5 MAIN DUTIES]

Write a job posting that:
- Leads with what makes this a great place to work (candidates scan for this)
- Lists responsibilities clearly but not exhaustively
- States requirements honestly
- Has a personality that matches the restaurant
- Includes a clear application instruction
- Is not corporate/generic — sounds like a real place with real culture
```

---

### 2. Job Posting — Back of House
*Use when hiring line cooks, prep cooks, or dishwashers.*

```
Write a job posting for a back-of-house position.

Position: [LINE COOK / PREP COOK / DISHWASHER / SOUS CHEF / PASTRY CHEF]
Restaurant name: [NAME] | Cuisine: [TYPE]
Shifts available: [DESCRIBE — E.G., TUESDAY–SATURDAY DINNER SERVICE]
Pay range: [$X–$X/HOUR OR SALARY]
Experience required: [LEVEL AND SPECIFIC SKILLS — E.G., "KNIFE SKILLS / EXPERIENCE ON GRILL STATION / SCRATCH COOKING"]
Kitchen culture: [DESCRIBE IN 1–2 SENTENCES — E.G., "FAST-PACED BUT COLLABORATIVE" / "SMALL TEAM, HIGH STANDARDS"]
Physical requirements: [E.G., ABLE TO STAND FOR 8+ HOURS / LIFT 50 LBS]
Perks: [MEALS / SCHEDULE / GROWTH / OTHER]

Write a posting that attracts experienced, professional kitchen workers. Be specific about the type of cooking and service. Vague postings attract vague candidates.
```

---

### 3. Staff Schedule Communication Template
*Use to distribute weekly schedules clearly.*

```
Write a staff schedule communication template for my restaurant team.

My scheduling method: [TEXT / EMAIL / SCHEDULING APP (HOMEBASE, 7SHIFTS, ETC.)]
Team size: [NUMBER OF STAFF]
Current challenge: [E.G., "STAFF DON'T RESPOND TO CONFIRM SHIFTS" / "TOO MANY LAST-MINUTE CALLOUTS" / "NO ONE READS THE SCHEDULE"]

Write:
1. The weekly schedule announcement message (sets expectations, asks for confirmation)
2. A shift reminder (sent 24 hours before each shift)
3. A response template for when someone requests a schedule change
4. A policy statement about how far in advance schedule changes must be requested
5. A callout protocol message (what to do if they can't come in)

Keep each communication short and clear. Staff on their phones at 11pm don't read paragraphs.
```

---

### 4. Employee Handbook Section (Key Policies)
*Use to draft or update essential policy documents.*

```
Write key employee handbook sections for my restaurant.

Restaurant name: [NAME]
Restaurant type: [CASUAL / FINE DINING / FAST CASUAL]
Team size: [APPROXIMATE]
State: [YOUR STATE — POLICIES VARY BY JURISDICTION]

Write sections for:
1. Attendance and punctuality policy
2. Callout and no-show procedure
3. Tip reporting and tip pooling policy (if applicable)
4. Dress code and grooming standards
5. Cell phone policy during service
6. Conduct and guest interaction standards
7. Sexual harassment policy statement
8. Discipline and termination procedure

Note: Have a labor attorney review before distributing. State laws vary significantly.
```

---

### 5. Performance Review Template
*Use to conduct fair, documented staff performance reviews.*

```
Create a staff performance review template for a restaurant employee.

Position being reviewed: [SERVER / COOK / MANAGER / BARTENDER / OTHER]
Review frequency: [90-DAY / ANNUAL / SEMI-ANNUAL]
Restaurant type: [CASUAL / FINE DINING]

Design a review template covering:
1. Attendance and reliability (rating scale + comments)
2. Job performance (role-specific — different for FOH vs BOH)
3. Guest/team interaction
4. Initiative and growth
5. Goals from last review (did they meet them?)
6. Goals for next review period
7. Overall rating
8. Space for employee self-assessment
9. Employee signature and manager signature

Also write: the manager script for how to open and close the review conversation professionally.
```

---

### 6. Staff Training Guide — New Server Onboarding
*Use to create structured onboarding for new front-of-house hires.*

```
Write a new server onboarding guide for my restaurant.

Restaurant name: [NAME]
Cuisine: [TYPE] | Service style: [CASUAL / FORMAL]
Onboarding length: [E.G., 3 SHADOW SHIFTS / 1 WEEK / BRIEF TRIAL]
POS system: [E.G., TOAST / SQUARE / ALOHA / OTHER]
Key menu items to know on day 1: [LIST 5–10]
Common guest questions: [LIST WHAT NEW SERVERS GET ASKED MOST]

Create a Day 1–3 onboarding plan:
Day 1: Restaurant tour, culture introduction, menu review, POS basics
Day 2: Shadow a senior server, practice table greeting and ordering
Day 3: First solo tables with manager oversight

Include: the 5 things every server must know before touching a table, the 3 things we never say to a guest, and our opening and closing side work checklist.
```

---

### 7. Disciplinary Warning Letter
*Use to document performance or conduct issues formally.*

```
Write a disciplinary warning letter for a restaurant employee.

Employee name: [NAME] | Position: [ROLE]
Issue: [DESCRIBE — E.G., REPEATED TARDINESS / NO-CALL NO-SHOW / VIOLATION OF GUEST SERVICE STANDARDS / CONDUCT ISSUE]
Previous conversations about this: [YES / NO — IF YES, DESCRIBE BRIEFLY]
Warning level: [VERBAL WARNING / WRITTEN WARNING / FINAL WARNING BEFORE TERMINATION]
Improvement required: [WHAT SPECIFICALLY NEEDS TO CHANGE AND BY WHEN]
Consequence if not improved: [STATE CLEARLY]

Write a professional letter that:
- States the facts without editorializing
- References any previous warnings
- Is specific about what improvement is required
- States consequences clearly
- Includes a signature line for manager and employee acknowledgment
- Is firm but not hostile

Note: Have your attorney or HR advisor review termination-track letters.
```

---

### 8. Staff Meeting Agenda
*Use to run productive pre-shift or weekly team meetings.*

```
Write a staff meeting agenda for my restaurant.

Meeting type: [PRE-SHIFT BRIEFING (10 MIN) / WEEKLY TEAM MEETING (30 MIN) / MONTHLY ALL-HANDS (60 MIN)]
Team: [FOH ONLY / BOH ONLY / FULL TEAM]
Topics to cover this week:
- [TOPIC 1 — E.G., NEW MENU ITEMS LAUNCHING FRIDAY]
- [TOPIC 2 — E.G., SERVICE ISSUE FROM LAST WEEKEND]
- [TOPIC 3 — E.G., UPCOMING PRIVATE EVENT]
- [ANY RECOGNITION OR WINS TO SHARE]

Format the agenda with:
- Time allocation per topic
- Who leads each section
- Questions to ask the team (not just announcements)
- A clear close with one takeaway everyone leaves with

Also write: the one-minute pre-service "rally" speech for a busy Friday night.
```

---

### 9. Termination Letter
*Use when ending employment formally.*

```
Write a termination letter for a restaurant employee.

Employee name: [NAME] | Position: [ROLE]
Last day of employment: [DATE]
Reason: [PERFORMANCE / CONDUCT / BUSINESS REASONS (REDUCTION IN FORCE) / VIOLATION OF POLICY]
Previous warnings given: [LIST DATES IF APPLICABLE]
Final pay and benefits information: [E.G., FINAL PAYCHECK ON LAST DAY / ACCRUED PTO PAID OUT / NO BENEFITS CONTINUATION]
Return of property required: [KEYS / UNIFORMS / OTHER]

Write a professional, factual termination letter that:
- States the facts without excessive explanation
- Is legally defensible (no emotional language, no accusations without prior documentation)
- Covers logistics clearly
- Includes relevant final pay information
- Has signature lines for the record

IMPORTANT: Consult your state's labor laws and an HR advisor before terminating employment, especially in states with strong worker protections.
```

---

### 10. Vendor / Supplier Communication
*Use to manage food and beverage supplier relationships.*

```
Write professional vendor communications for my restaurant.

Write templates for:
1. New vendor inquiry (first contact asking about products and pricing)
2. Order placement (standard weekly order format)
3. Complaint about a delivery (wrong items / damaged goods / short order)
4. Price negotiation request ("our volume has increased — can we revisit pricing?")
5. Ending a vendor relationship (moving to a different supplier)

Each communication:
- Professional and direct
- Includes specific order numbers, product names, and quantities where relevant
- Gets to the point quickly — both sides are busy
- Maintains a positive relationship even in complaints or endings
```

---

### 11. Inventory and Ordering SOP
*Use to document your ordering and receiving procedure.*

```
Write an inventory management and ordering SOP for my restaurant.

Restaurant type: [QUICK SERVICE / CASUAL / FINE DINING]
Current inventory method: [PHYSICAL COUNT / DIGITAL (WHAT SOFTWARE?) / INFORMAL]
Ordering frequency: [DAILY / 2–3X WEEK / WEEKLY]
Key suppliers: [LIST CATEGORIES — E.G., PROTEIN / PRODUCE / DAIRY / DRY GOODS / BEVERAGE]
Biggest waste/shrinkage issues: [E.G., PRODUCE SPOILAGE / BAR OVERPOURING / PREP WASTE]

Write an SOP that covers:
1. Weekly inventory count procedure (who, when, how)
2. Par level system setup (how to set and adjust pars)
3. Order placement procedure by category
4. Receiving procedure (check in deliveries, sign off, storage)
5. Waste tracking
6. How to handle a short or incorrect delivery
7. Month-end inventory for food cost calculation
```

---

### 12. Training Material — Food Safety Reminder
*Use to keep staff current on food handling and sanitation standards.*

```
Write a food safety training reminder for my restaurant team.

Focus area: [HANDWASHING / TEMP CONTROL / ALLERGEN PROTOCOLS / CROSS-CONTAMINATION / GENERAL REFRESH]
Recent incident or audit finding: [IF APPLICABLE — E.G., "HEALTH INSPECTOR FLAGGED OUR WALK-IN TEMP LOGS"]
Team: [ALL STAFF / KITCHEN ONLY / NEW HIRES]

Write:
1. A brief training bulletin on the focus area (1 page — key points, not a textbook)
2. A quiz (5 questions) to check comprehension
3. The manager script for a 5-minute pre-shift safety reminder on this topic
4. A reminder of who to contact if there's a food safety concern

Keep it practical and clear. Staff who aren't engaged won't read theory — give them rules and examples.
```

---

### 13. Manager Shift Report Template
*Use to document what happened during each service.*

```
Create a manager shift report template for my restaurant.

Reporting frequency: [EVERY SHIFT / END OF DAY / WEEKLY SUMMARY]
Who reads it: [OWNER / GENERAL MANAGER / OWNERSHIP GROUP]
Key metrics to include: [COVERS / SALES / LABOR HOURS / ANY INCIDENTS]

Design a shift report covering:
1. Date, shift, manager on duty
2. Covers and revenue (vs. prior week same day if possible)
3. Staffing (scheduled vs. actual, any callouts)
4. Kitchen performance (ticket times, waste, any prep issues)
5. Service highlights or issues (specific table incidents, positive feedback)
6. Maintenance or facilities issues
7. Inventory notes (running low on anything critical)
8. Next shift prep notes
9. Manager rating of the shift: 1–5 with brief rationale

Should take under 10 minutes to complete and under 5 minutes to read.
```

---

### 14. Kitchen Line Setup Checklist
*Use to create standardized opening and closing kitchen checklists.*

```
Create a kitchen line setup and breakdown checklist for my restaurant.

Restaurant type: [CASUAL DINING / FINE DINING / FAST CASUAL]
Stations: [LIST YOUR STATIONS — E.G., GRILL / SAUTÉ / FRYER / COLD LINE / EXPO]
Service hours: [DESCRIBE — E.G., LUNCH AND DINNER / DINNER ONLY]

Create:
1. AM/Prep opening checklist (by station)
2. Pre-service line check (30 minutes before doors open)
3. Mid-service maintenance notes (what to check at 7 PM during a dinner service)
4. Closing/breakdown checklist (by station)
5. End-of-night safety check (gas, equipment, temps, locks)

Format as checkboxes. Should be laminated and kept at each station.
```

---

### 15. Opening / Closing Manager Checklist
*Use to standardize your open and close procedures.*

```
Create an opening and closing manager checklist for my restaurant.

Restaurant type: [DESCRIBE]
Opening time: [TIME] | Closing time: [TIME]
Any known gaps in current procedure: [E.G., "CLOSING STAFF FORGET TO LOG SAFE / OPENING MANAGER DOESN'T CHECK ALL EQUIPMENT"]

Create:
Opening Manager Checklist (arrival to doors open):
- Building and security check
- Equipment startup and temperature verification
- Staff arrival confirmation and briefing
- FOH and BOH readiness check
- POS and cash drawer setup
- Guest-facing readiness (appearance, music, specials confirmed)

Closing Manager Checklist (last guests out to manager departure):
- Last guest procedures
- Cash reconciliation and safe drop
- Equipment shutdown
- Cleaning verification
- Security check and lock-up
- Next-day prep notes

Format as printable daily checklists with sign-off lines.
```

---

### 16. Staff Incentive / Recognition Program
*Use to create a simple team incentive structure.*

```
Design a staff recognition and incentive program for my restaurant.

Team size: [NUMBER] | Restaurant type: [CASUAL / FINE DINING]
Current challenge: [E.G., "HIGH TURNOVER / LOW MORALE / SERVERS DON'T UPSELL / KITCHEN QUALITY INCONSISTENT"]
Budget for incentives: [MINIMAL / MODERATE / GENEROUS — DESCRIBE]

Design a program that includes:
1. Daily recognition (can be done in pre-shift, costs nothing)
2. Weekly performance incentive (tied to a measurable metric — covers, upsells, kitchen speed)
3. Monthly "employee of the month" structure (criteria, reward, how it's chosen)
4. How to handle high performers leaving (retention conversation and counter)
5. How to build a culture where people actually want to work here

Focus on what actually motivates restaurant workers — not just money.
```

---

### 17. Conflict Resolution Between Staff Members
*Use when two employees are having a conflict that affects service.*

```
Write a conflict resolution protocol and script for managing staff disputes.

Situation type: [FRONT OF HOUSE VS BACK OF HOUSE TENSION / TWO SERVERS / MANAGER VS EMPLOYEE / OTHER]
Nature of the conflict: [DESCRIBE WITHOUT TAKING SIDES]
Impact on the restaurant: [HOW IT'S AFFECTING SERVICE OR TEAM MORALE]
My goal: [RESOLVE AND MOVE FORWARD / DOCUMENT FOR HR PURPOSES / DETERMINE IF SOMEONE NEEDS TO BE LET GO]

Write:
1. The private conversation approach with each party (separately, first)
2. A joint conversation script (after hearing both sides)
3. The resolution documentation template
4. How to follow up in 2 weeks to ensure resolution held
5. When this becomes an HR or termination issue vs. a coaching issue
```

---

### 18. Health Inspection Prep Checklist
*Use before a scheduled or likely health inspection.*

```
Create a pre-health inspection checklist for my restaurant.

State/city: [YOUR JURISDICTION — INSPECTION CRITERIA VARY]
Last inspection score: [IF KNOWN]
Common violations I've received or worry about: [LIST OR "UNSURE"]
Type of restaurant: [FULL SERVICE / FAST CASUAL / FOOD TRUCK / BAR]

Create a comprehensive pre-inspection checklist covering:
1. Food storage (temps, labeling, FIFO)
2. Food handling (handwashing compliance, gloves, hair restraints)
3. Equipment (cleanliness, calibration, working condition)
4. Facilities (floors, walls, lighting, pest evidence)
5. Documentation (temp logs, cleaning schedules, employee food handler cards)
6. Walk-in and dry storage organization
7. Bar area (if applicable)
8. Restrooms

Format as a one-page daily/weekly checklist managers can run through so inspection prep is continuous, not a panic the day before.
```

---

### 19. Franchise / Location Expansion Evaluation
*Use when considering opening a second location.*

```
Write a structured evaluation framework for opening a second restaurant location.

My current restaurant: [NAME, CUISINE, YEARS OPEN, CURRENT PERFORMANCE — HONEST]
Proposed new location: [NEIGHBORHOOD / CITY / STREET — IF KNOWN]
My motivation: [WHY NOW?]

Create an evaluation framework covering:
1. Financial readiness checklist (what numbers need to be true before expanding)
2. Operational readiness checklist (are your systems actually documented and replicable?)
3. Site evaluation criteria (foot traffic, demographics, lease terms, competition, parking)
4. Staffing questions (who runs location 2 while you manage both?)
5. Capital requirements estimate (build-out, equipment, working capital)
6. The 5 biggest reasons restaurant expansions fail
7. A simple go/no-go decision matrix

Help me think this through before I commit to anything.
```

---

### 20. Partnership / Investor One-Pager
*Use when seeking a business partner or investor for your restaurant.*

```
Write a one-page restaurant business summary for a potential partner or investor.

Restaurant name: [NAME]
Concept: [BRIEF DESCRIPTION]
Location: [CITY/NEIGHBORHOOD]
Operational status: [OPEN X YEARS / PRE-OPENING / EXPANDING]
Revenue: [IF COMFORTABLE SHARING — APPROXIMATE ANNUAL]
What I'm seeking: [INVESTMENT AMOUNT / PARTNER SKILLS / SILENT INVESTOR]
What I'm offering: [EQUITY % / REVENUE SHARE / MANAGEMENT ROLE]
Use of funds: [HOW THE MONEY WILL BE USED]
Why this business: [THE CASE FOR INVESTMENT — TRACK RECORD, LOCATION, CONCEPT, GROWTH POTENTIAL]

Write a professional one-pager that:
- Opens with the restaurant concept and opportunity
- Shows traction (if open) or market validation (if pre-opening)
- Describes the ask clearly
- Is honest about risk (investors respect this)
- Ends with a call to schedule a conversation

I'll have my attorney review any formal investment documents.
```

---
