# 07 — The Restaurant Owner's AI Cheat Sheet

*The 12 most powerful prompts in this toolkit — ready to copy, paste, and use right now*

---

> **How to use:** Fill in every `[BRACKET]` before pasting. The more specific your inputs, the more ready-to-use the output. These are your most-reached-for prompts — bookmark this file.

---

### 🏆 Prompt 1: Menu Description Rewrite
*Source: 02-menu-marketing-prompts.md*
*Why it's here: Better menu copy increases average check size. This is one of the highest-ROI things you can do.*

```
You are a professional menu copywriter. Rewrite the following menu items to be more evocative and enticing.

Restaurant tone: [CASUAL AND WARM / ELEVATED AND REFINED / BOLD AND FUN]
Cuisine style: [YOUR CUISINE]
Current items to rewrite:
[PASTE YOUR CURRENT MENU ITEMS AND DESCRIPTIONS]

For each item: write a 2–3 sentence description using sensory language (texture, aroma, temperature, flavor). Mention cooking technique or sourcing where it differentiates the dish. Avoid clichés: "mouth-watering," "delicious," "amazing." Under 30 words per item.
```

---

### 🏆 Prompt 2: Response to a Negative Review
*Source: 03-customer-experience-prompts.md*
*Why it's here: Your response to bad reviews is read by every future customer. It's your best public PR.*

```
Write a professional public response to this negative restaurant review.

Review text: [PASTE THE REVIEW]
Restaurant name: [NAME]
The facts from our side: [WHAT ACTUALLY HAPPENED — INTERNAL CONTEXT ONLY]
My preferred resolution: [OFFER RETURN VISIT / TAKE OFFLINE / ALREADY RESOLVED]

Requirements:
- Under 100 words
- Acknowledge their experience without admitting liability
- Take the conversation offline (include email/phone)
- No arguing with their version of events publicly
- Sound like a real person, not a PR statement
- Make future readers think "this place handles feedback well"
```

---

### 🏆 Prompt 3: Weekly Specials Announcement
*Source: 02-menu-marketing-prompts.md*
*Why it's here: Promotes your highest-margin items across all channels in one sitting.*

```
Write multi-channel promotional copy for this week's restaurant specials.

Restaurant: [NAME] | Cuisine: [TYPE] | Tone: [CASUAL / UPSCALE / FUN]
This week's specials:
- [DISH 1]: [BRIEF DESCRIPTION AND PRICE]
- [DISH 2]: [BRIEF DESCRIPTION AND PRICE]
- [DRINK SPECIAL]: [BRIEF DESCRIPTION AND PRICE]
Available: [DAYS AND HOURS]

Write: Instagram/Facebook post (100–150 words + hook), email subject line, SMS text (under 160 characters), and chalkboard copy (20 words max per item).
```

---

### 🏆 Prompt 4: Staff Meeting Agenda
*Source: 04-operations-staff-prompts.md*
*Why it's here: A sharp pre-shift meeting sets the tone for service. This takes 5 minutes to prep.*

```
Write a pre-shift staff meeting agenda for my restaurant.

Meeting length: [10 MINUTES]
Team: [FOH / BOH / FULL TEAM]
Topics this shift:
- [TOPIC 1 — E.G., NEW SPECIAL AND HOW TO DESCRIBE IT]
- [TOPIC 2 — E.G., SERVICE ISSUE FROM LAST NIGHT TO ADDRESS]
- [RECOGNITION — ANY WIN TO CELEBRATE?]

Include: time per topic, who leads it, 1–2 questions to ask the team (not just announcements), and a 30-second closing rally for a busy service.
```

---

### 🏆 Prompt 5: Complaint Resolution Email
*Source: 03-customer-experience-prompts.md*
*Why it's here: A well-handled complaint turns a lost customer into a loyal one. Most owners ignore this.*

```
Write a guest complaint resolution email for my restaurant.

Guest situation: [DESCRIBE THE COMPLAINT SPECIFICALLY]
What happened from our side: [HONEST INTERNAL ASSESSMENT]
Resolution I'm offering: [COMP NEXT VISIT / REFUND / APOLOGY / INVESTIGATION]

Requirements:
- Open with the specific experience (not a generic apology)
- Take responsibility where appropriate, without admitting legal liability
- State what you're doing about it
- Offer the resolution naturally
- Invite them back genuinely
- Under 200 words
```

---

### 🏆 Prompt 6: Instagram Caption Pack
*Source: 05-social-reputation-prompts.md*
*Why it's here: Batch your captions monthly. 2 hours once beats 15 minutes every day.*

```
Write 10 Instagram captions for food photography posts at my restaurant.

Restaurant: [NAME] | Cuisine: [TYPE] | Tone: [CASUAL / PLAYFUL / ELEVATED / WARM]
Audience: [LOCAL FOODIES / FAMILIES / DATE NIGHT CROWD]

Dishes/moments to caption:
1. [DISH OR SCENE]
2. [DISH OR SCENE]
(list up to 10)

For each: a scroll-stopping first line, 2–3 sentences body, one CTA (reserve/visit/tag a friend), and 5 targeted local hashtags. Avoid "You NEED to try this!" energy — write with genuine confidence.
```

---

### 🏆 Prompt 7: Job Posting
*Source: 04-operations-staff-prompts.md*
*Why it's here: Vague job postings attract vague candidates. Specific postings attract who you actually want.*

```
Write a job posting for [POSITION] at my restaurant.

Restaurant name: [NAME] | Cuisine: [TYPE] | Location: [CITY]
Hours: [FULL/PART TIME — TYPICAL SCHEDULE]
Pay: [RATE + TIP STRUCTURE]
Experience required: [SPECIFIC — DON'T JUST SAY "PREFERRED"]
What makes working here great: [CULTURE / TEAM / MEALS / GROWTH]
Key responsibilities: [LIST 3–5 MAIN DUTIES]

Write a posting that leads with why this is a great place to work, lists requirements honestly, has personality matching the restaurant, and has a clear application instruction. Not corporate. Sounds like a real place with real culture.
```

---

### 🏆 Prompt 8: Email Newsletter
*Source: 02-menu-marketing-prompts.md*
*Why it's here: Your email list is the only audience you own. This keeps them engaged and coming back.*

```
Write a monthly restaurant email newsletter.

Restaurant: [NAME] | Month: [MONTH]
This month's highlights:
- New menu items: [LIST]
- Upcoming events: [LIST]
- Special offers: [LIST]
- Story or update: [E.G., NEW FARM PARTNERSHIP / CHEF AWARD / COMMUNITY INVOLVEMENT]

Write: subject line (under 50 chars), preview text (under 90 chars), newsletter body (300–400 words), and clear CTA. Tone: warm and personal, like an update from someone they like — not a corporate blast.
```

---

### 🏆 Prompt 9: Google Business Profile Post
*Source: 05-social-reputation-prompts.md*
*Why it's here: Free local SEO. Most competitors don't post here. 10 minutes gets you visibility they don't have.*

```
Write a Google Business Profile post for my restaurant.

Restaurant: [NAME] | Cuisine: [TYPE] | City: [LOCATION]
Post topic: [WEEKLY SPECIAL / NEW MENU ITEM / UPCOMING EVENT / SEASONAL CHANGE / BEHIND THE SCENES]
Specific details: [DESCRIBE WHAT YOU WANT TO FEATURE]
CTA: [RESERVE A TABLE / VISIT THIS WEEKEND / ORDER ONLINE]

Requirements: 150–250 words, no hashtags, natural location keywords, conversational tone, specific dish names and prices where relevant, clear CTA at end.
```

---

### 🏆 Prompt 10: Review Request Templates
*Source: 05-social-reputation-prompts.md*
*Why it's here: You get reviews from people who are upset by default. A system for asking happy guests reverses this.*

```
Write review request templates for my restaurant.

Restaurant: [NAME]
Platform target: [GOOGLE / YELP / BOTH]

Write:
1. In-restaurant table card text (30 words — drives to review link)
2. Post-visit SMS (under 160 characters — for loyalty/reservation members)
3. Post-visit email (100 words — friendly, specific, easy)
4. Server verbal script (under 20 words — memorizable for checkout moment)

Rule: never offer incentives for reviews — violates platform terms. Just ask at the right moment when they're happy and still with you.
```

---

### 🏆 Prompt 11: Reactivation Campaign
*Source: 02-menu-marketing-prompts.md*
*Why it's here: Bringing back a past customer costs 5x less than acquiring a new one.*

```
Write a 3-email reactivation sequence for restaurant customers who haven't visited in 60+ days.

Restaurant: [NAME] | Cuisine: [TYPE]
Incentive: [E.G., 20% OFF / FREE APPETIZER / $10 CREDIT]
What's new since they last visited: [NEW MENU / NEW HOURS / NEW SPACE / NEW CHEF]

Email 1 (Day 1): "We miss you" — personal, no hard sell
Email 2 (Day 5): Show what's new — curiosity hook
Email 3 (Day 10): Final offer with a specific expiry date

Each: under 150 words, subject line included, one clear CTA.
```

---

### 🏆 Prompt 12: Seasonal Opening Announcement
*Source: 02-menu-marketing-prompts.md*
*Why it's here: Build anticipation before launch. Buzz before opening is worth more than ads after.*

```
Write a new season / new menu launch campaign.

Restaurant: [NAME]
Launch date: [DATE]
What's new: [LIST 3–5 HIGHLIGHTS — DISHES, EVENTS, CHANGES]
What's the story: [THE HUMAN OR LOCAL ANGLE — NEW FARM PARTNER / CHEF INSPIRATION / SEASONAL TRADITION]

Write: email announcement (250 words + subject line), Instagram launch post (150 words + hook), in-restaurant table tent (50 words), and day-before reminder SMS (under 160 characters).
```

---

## QUICK VARIABLE CHEAT SHEET

| Variable | What to put |
|----------|-------------|
| [RESTAURANT_NAME] | Your restaurant's full name |
| [CUISINE_TYPE] | Italian, American, Mexican, etc. |
| [TONE] | Casual / Warm / Elevated / Fun / Bold |
| [CITY/NEIGHBORHOOD] | Where you are (local SEO anchor) |
| [DISH_NAME] | Exact menu item name |
| [PRICE] | Actual price (readers trust specifics) |
| [DAYS_AVAILABLE] | Exact days — "Thursday–Sunday" beats "weekends" |
| [GUEST_NAME] | First name from reservation or loyalty data |
| [REVIEW_TEXT] | Paste the full review as written |

---

*Full prompt libraries in files 02–05. These 12 cover 80% of your day-to-day needs.*
