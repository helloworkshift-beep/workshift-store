# 05 — Social Media & Reputation Prompts

*18 prompts for growing your online presence and building your restaurant's reputation*

---

### 1. Instagram Content Calendar (Monthly)
*Use to plan a full month of social content in one session.*

```
Create a 30-day Instagram content calendar for my restaurant.

Restaurant name: [NAME] | Cuisine: [TYPE]
Tone: [CASUAL AND FUN / WARM AND COMMUNITY-FOCUSED / ELEVATED AND SOPHISTICATED / BOLD AND ENERGETIC]
Posting frequency: [X TIMES PER WEEK]
Content mix I want: [E.G., FOOD PHOTOS / BEHIND THE SCENES / TEAM FEATURES / PROMOTIONS / LOCAL COMMUNITY]

For each post:
- Day and format (Feed Photo / Reel / Carousel / Story)
- Topic and angle
- First line / caption hook
- 3–5 relevant local hashtags

Ensure no more than 25% of posts are promotional. Build community, don't just advertise. Include at least 4 Stories ideas and 2 Reels concepts with hooks.
```

---

### 2. Instagram Reel Script
*Use to script short video content for maximum reach.*

```
Write an Instagram Reel script for my restaurant.

Concept options (choose one or describe your own):
- [ ] "Day in the life of our kitchen" (30 seconds)
- [ ] "[DISH] made from scratch in 15 seconds" (15 seconds)
- [ ] "We asked our chef why [DISH] is different — here's what he said" (30 seconds)
- [ ] "3 things you didn't know about [DISH/INGREDIENT]" (30 seconds)
- [ ] "Behind the scenes: how we prep for a Saturday night" (60 seconds)

My concept: [DESCRIBE]
Tone: [FUN / EDUCATIONAL / BEHIND-THE-SCENES / ASPIRATIONAL]
On-screen text style: [CAPTIONS / TALKING TO CAMERA / B-ROLL WITH TEXT OVERLAY]

Write:
1. Hook (first 2 seconds — must stop the scroll)
2. Body (what happens in the middle)
3. Closing frame (CTA or punchline)
4. Caption (for the post itself)
5. Audio suggestion (trending sound type or original)
```

---

### 3. TikTok / Short Video Strategy
*Use to build a TikTok presence for your restaurant.*

```
Write a TikTok content strategy for my restaurant.

Restaurant: [NAME] | Cuisine: [TYPE] | Location: [CITY]
My goal: [BRAND AWARENESS / LOCAL CUSTOMERS / VIRAL REACH / ALL THREE]
Who I want to attract: [DESCRIBE YOUR TARGET CUSTOMER]
What we have to work with: [E.G., PHOTOGENIC FOOD / INTERESTING KITCHEN / FUNNY TEAM / UNUSUAL PROCESS]
Current social following: [APPROXIMATE]

Create:
1. 10 TikTok video concepts with hooks (the first line matters most)
2. A "series" concept I can repeat weekly (consistency builds following)
3. The 3 formats that perform best for restaurants (with examples)
4. How to repurpose TikTok content to Instagram Reels and YouTube Shorts
5. What NOT to do on TikTok (mistakes that kill restaurant accounts)
```

---

### 4. Local Hashtag and SEO Strategy
*Use to maximize local discoverability on Instagram and Google.*

```
Create a local hashtag and social SEO strategy for my restaurant.

Restaurant name: [NAME]
City/neighborhood: [LOCATION]
Cuisine: [TYPE]
Target customer: [DESCRIBE]

Provide:
1. 30 targeted hashtags in 3 tiers:
   - High-volume (1M+ posts) — for reach
   - Medium-volume (100K–1M) — for discovery
   - Local/niche (under 100K) — for engaged audience
2. How to rotate hashtag sets so Instagram doesn't flag repetition
3. Instagram bio optimization (how to include location keywords)
4. Google Business Profile keywords to incorporate in descriptions
5. How to use location tags strategically
6. The right caption length for best Instagram engagement (research-based)
```

---

### 5. Press Release for Local Media
*Use to get editorial coverage in local publications.*

```
Write a press release for local media coverage of my restaurant.

Newsworthiness: [GRAND OPENING / CHEF AWARD / NEW CONCEPT / ANNIVERSARY / COMMUNITY INITIATIVE / MENU RELAUNCH]
Restaurant name: [NAME]
Location: [CITY AND NEIGHBORHOOD]
The story: [WHAT'S HAPPENING AND WHY IT MATTERS TO LOCAL READERS]
Key quote from owner/chef: [PROVIDE OR ASK ME TO DRAFT]
Contact for media: [NAME, EMAIL, PHONE]
Release date: [IMMEDIATE / EMBARGO UNTIL DATE]

Write a standard AP-format press release:
- Headline (present tense, active voice, under 15 words)
- Dateline
- Opening paragraph (who, what, when, where, why — the full story in 1 paragraph)
- Body paragraphs (supporting detail, background, quotes)
- Boilerplate ("About [Restaurant Name]" — 50 words)
- Contact information
- ### (end marker)

Target: local city magazine, food blog, neighborhood newspaper, and city section of major paper.
```

---

### 6. Yelp Elite / Food Blogger Outreach
*Use to invite influential food reviewers.*

```
Write an outreach message to a Yelp Elite reviewer or food blogger.

Their name: [NAME]
Their platform: [YELP / FOOD BLOG / INSTAGRAM]
Their review history/focus: [WHAT TYPE OF FOOD/RESTAURANTS THEY TYPICALLY REVIEW]
My restaurant: [NAME] | Cuisine: [TYPE] | What I'd invite them to: [INVITE FOR DINNER / NEW MENU PREVIEW / SEASONAL TASTING]

The message should:
- Reference something specific about their reviews or content (show research)
- Extend a genuine invitation (not a transaction)
- Mention what might interest them about our food
- Be under 150 words
- Not require or pressure coverage in exchange for the invite
- Include a specific date option and my direct contact
```

---

### 7. Facebook Community Engagement Posts
*Use to post in local Facebook groups to build awareness.*

```
Write Facebook community group posts for my restaurant.

Note: I'll only post these in groups where this type of content is welcome (local restaurant/food groups, community boards).

My restaurant: [NAME] | Cuisine: [TYPE] | City: [LOCATION]
Post contexts:
1. New to the neighborhood / just opened
2. Responding to someone asking for [CUISINE TYPE] recommendations
3. Announcing a new menu or seasonal special
4. Inviting the community to an event
5. Sharing a behind-the-scenes story about the restaurant

For each, write a post that:
- Feels like a community member, not an advertiser
- Leads with value or story, not promotion
- Includes a natural mention of the restaurant
- Is conversational and local in tone
- Is under 150 words
```

---

### 8. Email List Growth Campaign
*Use to grow your restaurant's email subscriber list.*

```
Create an email list growth campaign for my restaurant.

Restaurant name: [NAME]
Current list size: [APPROXIMATE OR "STARTING FROM ZERO"]
Incentive to subscribe: [E.G., 10% OFF FIRST VISIT / FREE APPETIZER / MONTHLY SPECIALS / BIRTHDAY REWARD]
Collection method: [POS SYSTEM / PAPER SIGN-UP / QR CODE / WEBSITE FORM / SERVER ASK]

Write:
1. In-restaurant sign-up card text (50 words)
2. Server script for asking guests to join (verbal — under 30 words, memorizable)
3. QR code landing page copy (100 words — why they should subscribe)
4. The welcome email sequence (3 emails):
   - Email 1 (immediate): Welcome + deliver the offer
   - Email 2 (3 days): Introduce the restaurant story
   - Email 3 (7 days): Highlight a signature dish or experience
```

---

### 9. Instagram Bio Optimization
*Use to maximize your Instagram profile for discovery and conversion.*

```
Optimize my restaurant's Instagram bio.

Restaurant name: [NAME]
Cuisine type: [DESCRIBE]
Location: [CITY AND NEIGHBORHOOD]
What we're most known for: [SIGNATURE DISH / ATMOSPHERE / VIBE]
What we want followers to do: [VISIT / RESERVE A TABLE / ORDER ONLINE / ALL]
Current bio (if any): [PASTE OR "NONE"]
Link in bio destination: [WEBSITE / RESERVATION LINK / MENU / LINKTREE]

Write an optimized bio that uses all 150 characters strategically:
1. Line 1: What you are (cuisine + location keyword)
2. Line 2: Why you're worth following (differentiator or signature)
3. Line 3: Social proof or recognizable credential (if any)
4. Line 4: CTA with link direction

Also write 3 "profile name" options (the bold name field above the bio — can include keywords).
```

---

### 10. Contest or Giveaway Campaign
*Use to run a social media contest to grow your following.*

```
Write a social media contest campaign for my restaurant.

Restaurant name: [NAME]
Prize: [E.G., DINNER FOR TWO / $100 GIFT CARD / FREE MEAL FOR A MONTH]
Entry mechanic: [FOLLOW + LIKE + TAG A FRIEND / SHARE OUR POST / POST A PHOTO WITH OUR HASHTAG]
Duration: [X DAYS]
Goal: [FOLLOWER GROWTH / UGC / ENGAGEMENT / AWARENESS]
Platforms: [INSTAGRAM / FACEBOOK / BOTH]

Write:
1. Contest announcement post (with hook, prize description, entry rules, deadline)
2. Midpoint reminder post
3. Last-chance post (24 hours before close)
4. Winner announcement template
5. Terms and conditions statement (brief — required for compliance)

Tone: exciting but not desperate. Contests should feel special, not like a discount.
```

---

### 11. User-Generated Content (UGC) Strategy
*Use to encourage guests to create content about your restaurant.*

```
Create a user-generated content strategy for my restaurant.

Restaurant name: [NAME]
What's visually compelling about my food/space: [DESCRIBE — PHOTOGENIC DISHES, UNIQUE DECOR, OPEN KITCHEN, ETC.]
Current UGC situation: [GUESTS SOMETIMES POST BUT WE DON'T SEE IT / HAVE SOME BUT WANT MORE]

Write:
1. An in-restaurant "photo moment" idea (a feature of the space designed to be photographed)
2. A hashtag strategy (create a branded hashtag, how to get guests to use it)
3. In-restaurant signage encouraging photo sharing (10 words, printed at table)
4. Server script for mentioning the hashtag naturally
5. How to respond when guests tag you (template for each scenario: great photo / average photo / negative connotation)
6. How to repost UGC on your feed legally and graciously
7. Monthly UGC collection and posting routine
```

---

### 12. Neighborhood / Community Integration Strategy
*Use to become a beloved part of your local community.*

```
Write a local community engagement strategy for my restaurant.

Restaurant name: [NAME] | Location: [CITY/NEIGHBORHOOD]
Target community: [RESIDENTIAL NEIGHBORHOOD / BUSINESS DISTRICT / TOURIST AREA / COLLEGE TOWN]
Community initiatives I'm open to: [SPONSORSHIPS / CHARITY EVENTS / LOCAL SCHOOL INVOLVEMENT / SPORTS TEAM SPONSORSHIP / COMMUNITY MEETINGS]
My budget for community involvement: [MINIMAL / MODERATE — DESCRIBE]

Create a strategy covering:
1. 3 local organization partnerships (specific types — e.g., school, sports team, charity)
2. A monthly community event concept
3. How to use local sourcing as a marketing story
4. Neighborhood newsletter / local publication placements
5. How to get mentioned on local neighborhood Facebook groups and Nextdoor
6. How to measure whether community engagement is driving business
```

---

### 13. Google My Business Posting Schedule
*Use to maintain an active, keyword-rich Google presence.*

```
Create a Google Business Profile posting schedule and 10 sample posts for my restaurant.

Restaurant name: [NAME] | Cuisine: [TYPE] | Location: [CITY]
Posting frequency: [WEEKLY / 2X PER MONTH]
Goals: [LOCAL SEO RANKING / SHOWCASE NEW DISHES / DRIVE RESERVATIONS / ANNOUNCE EVENTS]

Write 10 Google Business Profile posts covering:
1. Weekly specials (with specific dish names and prices)
2. Seasonal menu announcement
3. Event announcement
4. Behind the scenes story
5. Staff feature
6. Customer testimonial share
7. Parking/directions update
8. Hours change notice
9. Holiday message
10. "Why we're different" value proposition

Each post: 150–300 words, no hashtags, natural location keywords, clear CTA at end.
```

---

### 14. Crisis Communication Plan
*Use when something goes wrong and the internet is watching.*

```
Write a crisis communication plan and templates for my restaurant.

Potential crisis scenarios to prepare for:
1. A foodborne illness report (alleged)
2. A viral negative review or social media complaint
3. A health inspection failing grade posted publicly
4. An employee incident that goes public
5. A fire or emergency closure

For each scenario:
- First 30-minute response (what to do before saying anything publicly)
- Public statement template (holding statement + follow-up)
- What NOT to say (phrases that make things worse)
- When to call a lawyer vs. handle it yourself
- How to respond to press inquiries
- How to communicate to existing customers/reservations during closure

General principle: respond to the situation, not the social media pressure. Slow and thoughtful beats fast and wrong.
```

---

### 15. Influencer Partnership Brief
*Use when collaborating with a paid or trade influencer.*

```
Write a collaboration brief for an influencer partnership.

Influencer: [NAME / HANDLE]
Platform: [INSTAGRAM / TIKTOK / YOUTUBE / FOOD BLOG]
Their audience: [SIZE AND DEMOGRAPHICS]
Compensation: [TRADE (COMPLIMENTARY MEAL) / PAID — AMOUNT / HYBRID]
What I want: [SPECIFIC DELIVERABLES — E.G., 1 FEED POST + 3 STORIES / 1 REEL / HONEST REVIEW]
What I'm providing: [WHAT THEY'LL RECEIVE — EXPERIENCE, FOOD, COMPENSATION]
Timeline: [WHEN TO POST]
FTC compliance: [YES — MUST DISCLOSE PARTNERSHIP — SPECIFY HOW: #AD #PARTNER]
Brand guidelines: [ANY RESTRICTIONS — E.G., COMPETITOR MENTIONS, MINIMUM ENGAGEMENT THRESHOLD]

Write:
1. The outreach message (first contact — casual and specific to their content)
2. The collaboration brief (formal document once they agree)
3. The content approval process (what I review, what I don't micromanage)
4. Post-collaboration thank-you and performance recap message
```

---

### 16. Review Request to Recent Diners
*Use to systematically gather more Google/Yelp reviews.*

```
Write a review request strategy and templates for my restaurant.

Current review count: [APPROXIMATE ON GOOGLE / YELP]
My target: [WHAT I WANT TO REACH]
Collection method: [TEXT / EMAIL / QR CODE AT TABLE / RECEIPT MESSAGE / SERVER ASK]

Write:
1. In-restaurant QR code table card text (30 words — drives to Google review)
2. Post-visit text message (sent via SMS if I have their number — under 160 characters)
3. Post-visit email (from my reservation system or loyalty program — 100 words)
4. Server verbal script for mentioning reviews at checkout (under 20 words — memorizable)
5. Receipt message (3 lines max)

Rule: never offer incentives for reviews — it violates Google/Yelp terms of service. Just ask at the right moment (when they're happy and still in the restaurant).
```

---

### 17. Podcast / Radio Local Interview Pitch
*Use to pitch yourself to local food-focused podcasts or radio shows.*

```
Write a pitch for a local podcast, radio segment, or TV news feature about my restaurant.

My outlet target: [LOCAL FOOD PODCAST / MORNING RADIO SHOW / LOCAL TV FOOD SEGMENT / ALL]
Host/producer name: [IF KNOWN]
My story angle: [E.G., "IMMIGRANT FAMILY RECIPE TURNED NEIGHBORHOOD INSTITUTION" / "FORMER CORPORATE LAWYER OPENED DREAM RESTAURANT" / "SUSTAINABLE SOURCING STORY"]
What their audience would find interesting: [CONNECT TO THEIR LISTENERS]
My availability: [E.G., "AVAILABLE MORNINGS BEFORE SERVICE" / "CAN DO REMOTE OR IN-PERSON"]
What I could offer: [COOKING DEMO / TASTE TEST / TOUR OF THE KITCHEN / JUST AN INTERVIEW]

Write:
1. A 3-paragraph pitch email (under 200 words — these people get a lot of pitches)
2. Suggested interview questions I'd be great at answering
3. A 2-sentence "Why [Restaurant Name] is worth a feature" for the subject line or social announcement
```

---

### 18. End-of-Year "Thank You" Campaign
*Use to appreciate guests and drive December/January visits.*

```
Write a year-end appreciation campaign for my restaurant.

Restaurant name: [NAME] | Year: [YEAR]
What this year meant: [BRIEF — E.G., "FIRST FULL YEAR OPEN" / "SURVIVED A TOUGH YEAR" / "LAUNCHED A NEW MENU"]
Any year-end offer: [E.G., SPECIAL HOLIDAY MENU / GIFT CARD PROMOTION / NEW YEAR'S EVE RESERVATION]
Tone: Warm, genuine, not corporate.

Write:
1. Year-end email to your list (250 words — a genuine thank-you letter from the owner/team)
2. Instagram post reflecting on the year (150 words — vulnerable and human)
3. New Year's Eve event promotional post (if applicable)
4. January "New Year, Same Great Food" re-engagement campaign email (150 words)

The year-end touchpoint is one of the most powerful customer retention moments. Don't waste it on a generic holiday blast.
```

---
